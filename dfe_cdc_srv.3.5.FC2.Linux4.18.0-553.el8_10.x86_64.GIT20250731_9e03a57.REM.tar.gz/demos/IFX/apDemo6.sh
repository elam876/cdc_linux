#!/usr/bin/env bash
MODULE=demo_$CB_DBS_ID
source cbUtil.set
cnt=${1-20}
#NLS_LANG=AMERICAN #---要注意這一句必須指定，不然下一句不生效。
NLS_LANG=AMERICAN_AMERICA.AL32UTF8
export NLS_LANG
export NLS_LANG
db=`echo dfedemo_$CB_DBS_DBMS |  tr '[:upper:]' '[:lower:]'`

NLS_DATE_FORMAT='yyyy-mm-dd hh24:mi:ss'
NLS_DATE_FORMAT='yyyy-mm-dd'
export NLS_DATE_FORMAT


genSql()
{
    local id=$1
    local id2=$2
    dt=`date '+%Y-%m-%d'`
    tm=`date '+%H:%M:%S'`
    echo 'execute procedure sysmaster:ifx_allow_newline("t");'
    echo 1|awk -v id=$id -v id2=$id2 -v dt="$dt" \
               -v tm="$tm" -v cnt=$cnt '
       BEGIN {printf("BEGIN WORK;\n");}
       {
         for(i=1;i<=cnt;i++){
            newid=sprintf("%ld%.4d",id,i);
            printf ("insert into ifx_types_%d values\
				(%ld, @cc\\%ld.\n%d@,\
                 @v_c2@,@c_v3@,%d,%lf,\
                 TO_DATE(@%s@,@YYYY-MM-DD@),\
                 TO_DATE(@%s@,@HH24:MI:SS@)\
                 );\n", \
                 i%10+1, newid,id,i,\
                 i,i*0.3,dt,tm); 
            printf("update ifx_types_%d set c=@cc\t\\%ld.\n%d@, c3=@SLASH\\SLASH@ where id = %ld;\n",i%10+1,i,id,newid);
            if (cnt % 500 ==0) printf("commit work; begin work;\n");
         }
		printf("delete from ifx_types_%d where id > %ld - %d;\n",i%10+1,newid, i*0.5);
       }
       END {printf("commit work;\n");}
    '|sed -e s/'@'/"'"/g
}

go()
{

  for n in 1 #2 3 4 5 6
  do
    id=`timenow`
    id2=`expr $id - 10`
    genSql $id $id2 #| sqlRun.sh $db
  done
}
go &
wait
