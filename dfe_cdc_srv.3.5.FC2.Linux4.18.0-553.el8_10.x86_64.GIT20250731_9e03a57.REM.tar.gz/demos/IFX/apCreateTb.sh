#!/usr/bin/env bash
MODULE=demo_$CB_DBS_ID
source cbUtil.set
db=`echo dfedemo_$CB_DBS_DBMS |  tr '[:upper:]' '[:lower:]'`
export db
whoami=`whoami`
IS_CB_TEST_CASE=0
NO_REASSIGN=1


createDb()
{
    local db=$1
   
    echo "create database $db with log; "\
        | sqlRun.sh  -e sysmaster 
    echo
    echo "grant dba to $CB_DBS_USER;" \
        | sqlRun.sh  -e $db
    echo

}

createTb()
{

    #echo "
    #execute function syscdcv1:cdc_set_fullrowlogging('$db:$whoami.customer',0);
    #drop table $whoami.customer;" | sqlRun.sh -e $db
    echo "
    create table $whoami.customer 
      (
        customer_num serial,
        fname char(15),
        lname char(15),
        company char(20),
        address1 char(20),
        address2 char(20),
        city char(15),
        state char(2),
        zipcode char(5),
        phone char(18),
        primary key (customer_num) 
      );
    
    
    load from '$CB_PROJECT_DIR/demos/IFX/customer.unl' insert into customer;
    
    create index zip_ix on customer (zipcode) using btree 
        ;
    execute function syscdcv1:cdc_set_fullrowlogging('$db:$whoami.customer',1);
    
        "  > $MY_TMP.sql

    cat $MY_TMP.sql| sqlRun.sh -e $db > /dev/null 2> $MY_TMP.err2
    local ret=$?
    if [ $ret -ne 0 ]; then
    
        grep -v -E 'already exists|duplicate value'  $MY_TMP.err2 \
            | grep '^[ ][0-9]*: ' > $MY_TMP.err 
        if [ $? -ne 0 ]; then
            ret=0
        fi
    fi
    if [ $ret -ne 0 ]; then
        logMsg E "Failed to syscdcv1:cdc_set_fullrowlogging('$db:$whoami.customer',1) 1";
        cat $MY_TMP.err2 | logMsg M -
        exit 255
    fi
    echo ret=$ret
    exit 0
}

go()
{
  #createDb 
  createTb
}
go 2>&1 \
    grep "XXXXXXXXXXXXXXX" \

exit
    #| grep -v -E 'already exists|duplicate value' \
    #| grep -v 'already exists' > $MY_TMP.err
grep -i ISAM $MY_TMP.err > /dev/null
    #| grep -v 'ERROR at line 1:' \
    #| grep -v '111: ISAM error:' \
    #| grep ' error: '\
if [ $? -eq 0 ]; then
    logMsg E "Failed to create demo DB for $CB_DBS_DBMS:$CB_DBS_ID"
    cat $MY_TMP.err | logMsg M -
    exit 255
fi





destSrv=${1-$INFORMIXSERVER}
srcDb=dfedemo_ifx
destDb=dfedemo_ifx@$destSrv
table=customer
#source ./setenv
NO_COMPILE=1
NO_REASSIGN=1
export NOCOMPILE NO_REASSIGN
DEST_DBMS=ifx
export DEST_DBMS
source funIFX.set

#cleanRunTimeFiles

#reCreateDemoDBs

fullLogTb()
{
  local tb=$1
  local enabled=${2-1}
  showTitle Enable full row logging for table $tb
  echo " execute function syscdcv1:cdc_set_fullrowlogging("$tb", $enabled);"  \
      | sqlRun.sh -e syscdcv1
if [ $? -ne 0 ]; then
    logMsg E "Failed to cdc_set_fullrowlogging('$tb',1) 1";
    #cat $MY_TMP.err | logMsg M -
    exit 255
else
    return 0
fi
}

#fullLogTb "$srcDb:$whoami.customer"

exit
