#!/usr/bin/env bash
source cbUtil.set

NLS_LANG=AMERICAN #---要注意這一句必須指定，不然下一句不生效。
export NLS_LANG
whoami=`whoami`

NLS_DATE_FORMAT='yyyy-mm-dd hh24:mi:ss'
export NLS_DATE_FORMAT

source sqlCmd.set

db=`echo dfedemo_$CB_DBS_DBMS |  tr '[:upper:]' '[:lower:]'`
export db


createTb()
{
    (
    for i in `seq 10` 10000
    do
echo "
        --drop table ifx_test_$i;
        create table ifx_test_$i (id number, c varchar(60) );

        --drop table ifx_test_pk_$i;
        create table ifx_test_pk_$i (id number, idc varchar(20), c varchar(60) , primary key(id, idc));

        --drop table ifx_test_uidx_$i;
        create table ifx_test_uidx_$i (id number, c varchar(60));
        create unique index uidx_ifx_test_uidx_$i on ifx_test_uidx_$i(id);


        --drop table ifx_types_$i;
        create table ifx_types_$i ( 
			id number,
			c char(40),
			c2 varchar(40),
			c3 varchar(40),
			i number,
			--l long,
			f float,
			dt date,
			tm date,
			primary key(id)
		);
        execute function syscdcv1:cdc_set_fullrowlogging('$db:$whoami.ifx_types_$i',1);
    "
    done
    ) | convertSqlSchema ORA $CB_DBS_DBMS| sqlRun.sh -e $db
}

go()
{
  createTb
}

go 2>&1 \
    | grep -v 'multiple primary keys' \
    | grep -v 'already exists' > $MY_TMP.err
grep '^ *[0-9]*:' $MY_TMP.err > /dev/null
if [ $? -eq 0 ]; then
    logMsg E "Failed to create table in db [$db] of $CB_DBS_DBMS:$CB_DBS_ID"
    cat $MY_TMP.err | logMsg M -
    exit 255
fi

