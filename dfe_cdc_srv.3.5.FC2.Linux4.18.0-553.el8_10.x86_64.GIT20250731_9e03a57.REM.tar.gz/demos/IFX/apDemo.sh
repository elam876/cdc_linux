#!/usr/bin/env bash
MODULE=demo_$CB_DBS_ID
source cbUtil.set
NLS_LANG=AMERICAN_AMERICA.AL32UTF8
export NLS_LANG
logMsg M run $@ $CB_DBS_DBMS $CB_DBS_ID
db=`echo dfedemo_$CB_DBS_DBMS |  tr '[:upper:]' '[:lower:]'`

genSql()
{
    (
    echo 'delete from customer;'
    echo "load from '$CB_PROJECT_DIR/demos/IFX/customer.unl' insert into customer;"
    echo "update customer set fname=fname[1,5]||'pid='||$$;" 
    ) |sqlRun.sh $db
}

go()
{

  for n in 1 #2 3 4 5 6
  do
    id=`timenow`
    id2=`expr $id - 10`
    genSql id, id2, | sqlRun.sh $db
  done
}
go &
wait
