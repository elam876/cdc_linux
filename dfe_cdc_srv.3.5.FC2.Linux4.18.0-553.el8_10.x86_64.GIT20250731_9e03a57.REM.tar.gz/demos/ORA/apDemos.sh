#!/usr/bin/env bash
cnt=$1
if [ "$cnt" = "" ]; then
    . $CB_PROJECT_DIR/$CB_CONFIG_DIR/systemCfg.cfg 
    cnt=${1-$CB_NUMBER_OF_RECORDS_IN_TEST}
fi
MODULE=demo_$CB_DBS_ID
source cbUtil.set
NLS_LANG=AMERICAN_AMERICA.AL32UTF8
export NLS_LANG
logMsg M run $@ $CB_DBS_DBMS $CB_DBS_ID

genSql()
{
    local id=$1
    
    echo '
       {
for(tb=1;tb<=10;tb++) {
      tbname=sprintf("dfe_test_pk_%d",tb);
         for(i=1;i<=cnt;i++){
            u_id=sprintf("%ld%.6d",id,i);
            printf ("insert into %s values(%ld, @C.%ld@, @cc\\%ld.%d@);\n", tbname, u_id,id,id, i); 
            printf("update %s set c=@cc\t\\%ld.%d@ where id = %ld;\n",tbname, i,id,u_id);
            if (cnt % 500 ==0) printf("commit;\n");
          }
		printf("delete from %s where id > %ld - %d;\n",tbname, u_id, i*0.9);
       }
}
       END {printf("commit;\n");}
    ' > $MY_TMP.awk
    echo 1 \
        | awk -v id=$id -v cnt=$cnt -f $MY_TMP.awk \
        | sed -e s/'@'/"'"/g
}

go()
{

  for n in 1 #2 3 4 5 6
  do
    #id=`timenow`
    genSql `timenow` | sqlRun.sh
  done
}
go  
wait
