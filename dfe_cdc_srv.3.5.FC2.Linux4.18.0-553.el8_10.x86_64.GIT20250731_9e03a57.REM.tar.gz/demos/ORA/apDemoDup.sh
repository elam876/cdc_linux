#!/usr/bin/env bash
cnt=$1
if [ "$cnt" = "" ]; then
    . $CB_PROJECT_DIR/$CB_CONFIG_DIR/systemCfg.cfg 
    cnt=${1-$CB_NUMBER_OF_RECORDS_IN_TEST}
fi
cnt=4
MODULE=demo_$CB_DBS_ID
source cbUtil.set
NLS_LANG=AMERICAN_AMERICA.AL32UTF8
export NLS_LANG

genSql()
{
    local id=$1
    
now=`timenow`
    echo '
       {
      tbname=sprintf("dfe_test_dup_pk");
#for(x=1;x<=300;x++) {
for(x=1;x<=39;x++) {
         for(i=1;i<=cnt;i++){
            u_id=sprintf("%ld",i);
            id=sprintf("%.6ld%.3d",x,i);
            printf ("insert into %s values(%ld, @C.%ld@, @cc%ld.%d.%s@);\n", tbname, u_id,id,id, i,now); 
       #printf("commit;\n");
            printf("update %s set idc=@cc%ld.%d@ where id = %ld;\n",tbname, i,id,u_id);
       #printf("commit;\n");
            #if (cnt % 500 ==0) printf("commit;\n");
          }
	  #printf("delete from %s where id > %ld - %d;\n",tbname, u_id, i*0.9);
	  printf("delete from %s where id > %ld;\n",tbname, 2);
         printf("commit;\n");
       }
}
       #END {printf("commit;\n");}
    ' > $MY_TMP.awk
    echo 1 \
        | awk -v now=$now -v id=$id -v cnt=$cnt -f $MY_TMP.awk \
        | sed -e s/'@'/"'"/g
}

go()
{

#for  x in  `seq 10000`
  #do
  for n in 1 #2 3 4 5 6
  do
    #id=`timenow`
    #genSql `timenow` | sqlRun.sh
    genSql $n | sqlRun.sh
  done
#done
}
go  
wait
