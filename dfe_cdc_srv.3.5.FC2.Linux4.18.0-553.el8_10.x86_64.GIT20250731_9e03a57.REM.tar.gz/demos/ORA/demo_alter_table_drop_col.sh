echo '
alter table dfe.dfe_types_9 drop (x9,x10);
commit ;
' | sqlRun.sh
date +'%H:%M:%S'
