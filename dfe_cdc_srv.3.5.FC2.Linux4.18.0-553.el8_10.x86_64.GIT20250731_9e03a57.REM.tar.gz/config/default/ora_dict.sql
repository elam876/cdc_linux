/*
 * Oracle catalogs for information needed to build dictionary for 
 * getOraLog. The dictionary contains information about the instance
 * (e.g. where the logfiles are) and information about the replicated
 * tables (table ids, column ids, datatypes etc.)
 */
set pagesize 0
set lines 2000
set feedback off
WHENEVER SQLERROR EXIT SQL.SQLCODE

/* Oracle Version */
select 'oracle_version ' || substr(banner,1,instr(banner,' ')-1) version
from
(    select substr(banner,instr(banner,'Release ')+8) banner
     from v$version
     where banner like '%Oracle%'
);

/*
 *  Column "resetlogs_id" exists in v$database_incarnation only
 *  in Oracle 10 or higher.
 *  The query is executed in Dynamic SQL so that we can handle the
 *  possibility that the column does not exist.
 */
set serveroutput on
declare
   -- declare dynamic cursor type.
   type     dyncur_type is ref cursor;
   dyncur   dyncur_type;

   l_output varchar2(100);
begin
   -- Query resetlogs_id
   open  dyncur for 'select resetlogs_id from v$database_incarnation';
   fetch dyncur into l_output;

   dbms_output.put_line('resetlogs_id ' || l_output);
exception
    when others then
        -- If col does not exist, the query will raise the following error:
        -- ORA-00904: "RESETLOGS_ID": invalid identifier
        if sqlcode = -904 then
            dbms_output.put_line('resetlogs_id 0');
        else
            -- Something else is wrong, so re-raise error.
            raise;
        end if;
end;
/

/* instance name */
select 'instance_name ' || instance_name
from v$instance;

/* database name */
select 'database_name ' || name
from v$database;

/* cluster database */
select 'cluster_database ' || value
from v$parameter
where name='cluster_database';

/* archive mode */
select 'archive_mode '|| log_mode 
from v$database;

/* Archive format */
select 'archive_format ' || value 
from v$parameter 
where name = 'log_archive_format';

/* Archive Destination */
select 'archive_destination ' || destination
from   v$archive_dest
where  status = 'VALID'
and    exists
   (select 1
    from   v$database
    where  log_mode in ('ARCHIVELOG','MANUAL')
   )
union all
select 'archive_destination ' || 'NULL'
from   v$archive_dest
where  status = 'VALID'
and    not exists
   (select 1
    from   v$database
    where  log_mode in ('ARCHIVELOG', 'MANUAL')
   )
/

/* Redo log file states */
select  'logfile ' || log.thread# || ' ' || logfile.member
from v$log log, v$logfile logfile
where (upper(logfile.status) = 'STALE' or logfile.status is NULL) and log.group# = logfile.group#
order by log.thread#, log.group#, logfile.member;

/* ASM */
select  'asm_diskgroup ' || group_number || ' ' || allocation_unit_size || ' ' || name
from v$asm_diskgroup
order by group_number;

select  'asm_disk ' || group_number || ' ' || disk_number || ' ' || path
from v$asm_disk
order by group_number, disk_number;

/* User */
select 'user ' || usr.user# || ' ' || usr.name
from sys.user$ usr
order by usr.user#;

/* Type */
select 'type ' || usr.name || ' ' || obj.obj# || ' ' || type.toid || ' ' ||
       type.attributes||' '||type.typecode||' '||
       nvl(collect.elem_toid,'00000000000000000000000000000000')||' '||
       nvl(collect.charsetid,0)||' '||
       nvl(collect.charsetform,0)||' '||
       obj.name
from   sys.type$ type
,      sys.obj$  obj
,      sys.user$ usr
,      sys.collection$ collect
where  type.toid  = obj.oid$
and    obj.owner# = usr.user#
and    collect.toid (+) = type.toid
order by obj.obj#;

/* Table and Column */
col tab_id_noprint noprint
col col_id_noprint noprint

select tab.obj#    tab_id_noprint
,      -9999999    col_id_noprint
,      'table '||usr.name||' '||tab.obj#||' '||nvl(tab.clucols,0)||' '||obj.name
from   sys.tab$  tab
,      sys.obj$  obj
,      sys.user$ usr
where  tab.obj#   = obj.obj#
and    obj.owner# = usr.user#
union all
select tab.obj#    tab_id_noprint
,      segcol#     col_id_noprint
,      'column '||col.segcol#||' '||col.type#||' '||col.length||' '||col.property||' '||
       DECODE(lob.lobj#,NULL,0,lob.lobj#)||' '||col.charsetid||' '||col.charsetform||' '||col.name
from   sys.tab$  tab
,      sys.obj$  obj
,      sys.user$ usr
,      sys.col$  col
,      sys.lob$  lob
where  tab.obj#   = obj.obj#
and    obj.owner# = usr.user#
and    col.obj#   = tab.obj#
and    lob.obj#    (+) = col.obj#
and    lob.col#    (+) = col.segcol#
and    lob.intcol# (+) = col.intcol#
union all
select tab.obj#            tab_id_noprint
,      coltype.intcol# + 1 col_id_noprint
,      'columntype '||usr.name||' '||coltype.intcol#||' '||coltype.intcols||' '||
       DECODE(type.typecode,NULL,0,type.typecode)||' '||
       nvl(collect.charsetid,0)||' '||
       nvl(collect.charsetform,0)||' '||
       obj.name
from   sys.tab$     tab
,      sys.obj$     obj
,      sys.user$    usr
,      sys.coltype$ coltype
,      sys.collection$ collect
,      sys.type$    type
where  tab.obj#     = coltype.obj#
and    obj.owner#   = usr.user#
and    coltype.toid = obj.oid$
and    collect.toid (+) = coltype.toid
and    type.toid (+) = collect.elem_toid
order by tab_id_noprint,col_id_noprint;

/* Table Partition */
select 'tabpart '||usr.name||' '||tabpart.obj#||' '||tab.obj#
from   sys.tabpart$ tabpart
,      sys.tab$ tab
,      sys.obj$ obj
,      sys.user$ usr
where  tabpart.obj# = obj.obj#
and    tabpart.bo# = tab.obj#
and    obj.owner# = usr.user#
order by tab.obj#, obj.obj#;

/* Table Constraint */
select 'tabcdef '||idx.obj#||' '||tab.obj#
from   sys.obj$  tab
,      sys.obj$  idx
,      sys.cdef$ cdef
where  cdef.type# = 2
and    cdef.obj# = tab.obj#
and    cdef.enabled = idx.obj#
order by idx.obj#
/
