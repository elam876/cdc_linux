--update statistics;
--select tabname,nrows from systables where tabid > 99 order by nrows desc;
--select * from cgbqt2;
update cgbqt2 set bqt_amt=bqt_amt+1 where mod(bqt_no,10)<10;
