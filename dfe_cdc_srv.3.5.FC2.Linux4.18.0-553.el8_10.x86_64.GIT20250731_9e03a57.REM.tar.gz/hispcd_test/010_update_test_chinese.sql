
begin work;
--select ast_no,mod(acs_seq,10) from asacsitm;
update test_chinese set dt =current where id > 0;
--select qty from asacsitm;
--select * from asacsitm
commit work;
