
select sum(qty) from asacsitm;
begin work;
--select ast_no,mod(acs_seq,10) from asacsitm;
update asacsitm set qty=qty+5 where mod(acs_seq,10)<8;
--select qty from asacsitm;
--select * from asacsitm
select sum(qty) from asacsitm;
commit work;
select sum(qty) from asacsitm;
