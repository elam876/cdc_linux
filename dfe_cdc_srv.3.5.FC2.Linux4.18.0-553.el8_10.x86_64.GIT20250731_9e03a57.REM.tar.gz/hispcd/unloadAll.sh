#!/usr/bin/env bash
MODULE=unload
source cbUtil.set 
PARALLEL=${1-10}

nohup getCfgContent $CB_DBS_REPL_CONFIG | xargs -P $PARALLEL -l unloadTb.sh 
