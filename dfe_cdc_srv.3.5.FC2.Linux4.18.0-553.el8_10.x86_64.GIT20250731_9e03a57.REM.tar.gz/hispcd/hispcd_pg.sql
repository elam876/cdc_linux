DO $$
BEGIN
	IF NOT EXISTS (
	SELECT 1 FROM information_schema.schemata 
	WHERE schema_name = 'hispcd'
	) THEN
	EXECUTE 'CREATE SCHEMA hispcd';
	END IF;
	END;
$$;
set search_path=hispcd;


CREATE TABLE  mrpbd1
    (
    chart NUMERIC(10) NOT NULL
    typ CHAR(2)  NOT NULL
    ,nam CHAR(24)  NOT NULL
    ,born_yy NUMERIC(5) NOT NULL
    ,born_mmdd NUMERIC(5) NOT NULL
    ,sex CHAR(2)  NOT NULL
    ,l_mark CHAR(2)  NOT NULL
    ,c_r_cod NUMERIC(10) NOT NULL
    ,c_r_adrs CHAR(68)  NOT NULL
    ,domicile CHAR(16)  NOT NULL
    ,marr CHAR(2)  NOT NULL
    ,educ CHAR(2)  NOT NULL
    ,profes CHAR(6)  NOT NULL
    ,fil1 CHAR(2)  NOT NULL
    ,id_no CHAR(20)  NOT NULL
    ,tel_h NUMERIC(10) NOT NULL
    ,tel_o NUMERIC(10) NOT NULL
    ,bl_typ CHAR(4)  NOT NULL
    ,gl_typ CHAR(4)  NOT NULL
    ,pt_typ CHAR(4)  NOT NULL
    ,sp_typ CHAR(4)  NOT NULL
    ,sw_typ CHAR(4)  NOT NULL
    ,insured NUMERIC(10) NOT NULL
    ,cer_no NUMERIC(10) NOT NULL
    ,loc_o CHAR(2)  NOT NULL
    ,hpt_loc CHAR(2)  NOT NULL
    ,nv_times NUMERIC(5) NOT NULL
    ,bad_amt NUMERIC(10) NOT NULL
    ,no_good CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ocoditem
    (
    charg_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,tmp CHAR(2)  NOT NULL
    ,item_cod CHAR(14)  NOT NULL
    ,qty_prc NUMERIC(10)
    ,qty_tot CHAR(10)  NOT NULL
    ,usag CHAR(40)  NOT NULL
    ,self CHAR(2)  NOT NULL
    ,item_typ CHAR(2)  NOT NULL
    ,emg CHAR(2)  NOT NULL
    ,gl_cod NUMERIC(5) NOT NULL
    ,pt_cod NUMERIC(5) NOT NULL
    ,pr_amt NUMERIC(9,1)  NOT NULL
    ,gl_amt_p NUMERIC(9,1)  NOT NULL
    ,pt_amt NUMERIC(9,1)  NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ocdesc
    (
    charg_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,visit_no NUMERIC(11,0)
    ,tmp CHAR(2)  NOT NULL
    ,fil_1 CHAR(2)  NOT NULL
    ,prescriptor NUMERIC(5) NOT NULL
    ,gl_amt NUMERIC(10) NOT NULL
    ,gl_amt_p NUMERIC(10) NOT NULL
    ,pt_amt NUMERIC(10) NOT NULL
    ,collect_no NUMERIC(10) NOT NULL
    ,fil_2 CHAR(2)  NOT NULL
    ,lamp_typ CHAR(2)  NOT NULL
    ,lamp_no NUMERIC(5) NOT NULL
    ,dispenser NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgastitm
    (
    ast_cod NUMERIC(5) NOT NULL
    nam_a CHAR(8)  NOT NULL
    ,nam_f CHAR(80)  NOT NULL
    ,ast_amt NUMERIC(7,2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgbillgc
    (
    group_cod CHAR(14)  NOT NULL
    o_i CHAR(2)  NOT NULL
    ,detai_cod CHAR(14)  NOT NULL
    ,gen_qty NUMERIC(5) NOT NULL
    ,gon_qty NUMERIC(5) NOT NULL
    ,lau_qty NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgcnc
    (
    typ CHAR(2)  NOT NULL
    no NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgcncc
    (
    collect_no NUMERIC(10) NOT NULL
    typ NUMERIC(5) NOT NULL
    ,amt NUMERIC(10) NOT NULL
    ,bill_c CHAR(4)  NOT NULL
    ,bill_n NUMERIC(16,0)  NOT NULL
    ,sheet_c CHAR(4)  NOT NULL
    ,sheet_n NUMERIC(10) NOT NULL
    ,due_dat DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgcoment
    (
    item_cod CHAR(14)  NOT NULL
    comment CHAR(158)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgndmnam
    (
    item_cod CHAR(14)  NOT NULL
    unit CHAR(8)  NOT NULL
    ,nam CHAR(180)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgpar
    (
    chart NUMERIC(10) NOT NULL
    visit_no NUMERIC(11,0)
    ,typ NUMERIC(5)
    ,amt NUMERIC(10) NOT NULL
    ,author NUMERIC(5) NOT NULL
    ,reason CHAR(2)  NOT NULL
    ,pay_mod CHAR(2)  NOT NULL
    ,f_amt NUMERIC(10) NOT NULL
    ,e_amt NUMERIC(10) NOT NULL
    ,comp_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgpfdcnt
    (
    pt_typ CHAR(4)  NOT NULL
    fee_typ NUMERIC(5) NOT NULL
    ,o_discnt NUMERIC(4,2)  NOT NULL
    ,i_discnt NUMERIC(4,2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgptbd
    (
    pt_typ CHAR(4)  NOT NULL
    nam_a CHAR(8)  NOT NULL
    ,nam_f CHAR(80)  NOT NULL
    ,certific CHAR(40)  NOT NULL
    ,cash CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  dgfomula
    (
    drug_cod CHAR(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,description CHAR(160)  NOT NULL
    ,tsc CHAR(2)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  dgjobdsp
    (
    dispense_typ CHAR(2)  NOT NULL
    start_hhii NUMERIC(5) NOT NULL
    ,dis_qty NUMERIC(5) NOT NULL
    ,cycle NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  dgnam
    (
    drug_cod CHAR(10)  NOT NULL
    seq_no CHAR(2)  NOT NULL
    ,g_l CHAR(2)  NOT NULL
    ,pcs CHAR(2)  NOT NULL
    ,nam CHAR(80)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  glnprcn
    (
    cod CHAR(2)  NOT NULL
    nam CHAR(156)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mrocgprg
    (
    chart NUMERIC(10) NOT NULL
    rg_dat DATE NOT NULL
    ,evidenc_1 CHAR(2)  NOT NULL
    ,evidenc_2 CHAR(2)  NOT NULL
    ,evidenc_3 CHAR(2)  NOT NULL
    ,evidenc_4 CHAR(2)  NOT NULL
    ,patho_year NUMERIC(5) NOT NULL
    ,patho_no NUMERIC(5) NOT NULL
    ,init_dat DATE NOT NULL
    ,init_hos NUMERIC(10)
    ,diag NUMERIC(5) NOT NULL
    ,morphology NUMERIC(5) NOT NULL
    ,treat_1 CHAR(2)  NOT NULL
    ,treat_2 CHAR(2)  NOT NULL
    ,treat_3 CHAR(2)  NOT NULL
    ,treat_4 CHAR(2)  NOT NULL
    ,external CHAR(2)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,h_w NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mromcn
    (
    om_cod NUMERIC(5) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,nam CHAR(160)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mrpbd2
    (
    chart NUMERIC(10) NOT NULL
    l_r_cod NUMERIC(10) NOT NULL
    ,l_r_adrs CHAR(68)  NOT NULL
    ,tel_h2 NUMERIC(10)
    ,tel_a NUMERIC(10)
    ,eml_adrs CHAR(100)
    ,l_typ CHAR(4)  NOT NULL
    ,l_insured NUMERIC(10) NOT NULL
    ,husband_nam CHAR(16)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mtnam
    (
    mt_cod CHAR(14)  NOT NULL
    seq_no CHAR(2)  NOT NULL
    ,nam CHAR(180)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psemprel
    (
    emp_no NUMERIC(5) NOT NULL
    relat CHAR(2)  NOT NULL
    ,fil_1 CHAR(2)  NOT NULL
    ,pt_typ CHAR(4)  NOT NULL
    ,id_no CHAR(20)  NOT NULL
    ,stop_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psshcn
    (
    cod NUMERIC(5) NOT NULL
    nam_a CHAR(8)
    ,nam_f CHAR(40)
    ,typ CHAR(2)
    ,fil_1 CHAR(2)
    ,lau_h_no NUMERIC(10)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  rgrup2
    (
    opd_er CHAR(2)  NOT NULL
    charg_typ CHAR(2)  NOT NULL
    ,f_r CHAR(2)  NOT NULL
    ,pt_typ CHAR(4)  NOT NULL
    ,amt NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ucogfuncold
    (
    group_func_no CHAR(8)  NOT NULL
    func_no CHAR(8)  NOT NULL
    ,use_level CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgdfrat
    (
    item_cod CHAR(14)  NOT NULL
    df_rat NUMERIC(4,2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgroompf
    (
    class CHAR(2)  NOT NULL
    rank CHAR(2)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,gonbau CHAR(2)  NOT NULL
    ,laubau CHAR(2)  NOT NULL
    ,gen_rf NUMERIC(5) NOT NULL
    ,gen_nf NUMERIC(5) NOT NULL
    ,gen_df NUMERIC(5) NOT NULL
    ,gen_dg NUMERIC(5) NOT NULL
    ,gon_rf NUMERIC(5) NOT NULL
    ,gon_nf NUMERIC(5) NOT NULL
    ,gon_df NUMERIC(5) NOT NULL
    ,gon_self NUMERIC(5) NOT NULL
    ,lau_rf NUMERIC(5) NOT NULL
    ,lau_nf NUMERIC(5) NOT NULL
    ,lau_df NUMERIC(5) NOT NULL
    ,lau_self NUMERIC(5) NOT NULL
    ,lau_dg_1_5 NUMERIC(5) NOT NULL
    ,lau_dg_6 NUMERIC(5) NOT NULL
    ,cod_rf CHAR(14)
    ,cod_nf CHAR(14)
    ,cod_df CHAR(14)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgroompp
    (
    class CHAR(2)  NOT NULL
    rank CHAR(2)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,gonbau CHAR(2)  NOT NULL
    ,laubau CHAR(2)  NOT NULL
    ,gen_rf NUMERIC(5) NOT NULL
    ,gen_nf NUMERIC(5) NOT NULL
    ,gen_df NUMERIC(5) NOT NULL
    ,gen_dg NUMERIC(5) NOT NULL
    ,gon_rf NUMERIC(5) NOT NULL
    ,gon_nf NUMERIC(5) NOT NULL
    ,gon_df NUMERIC(5) NOT NULL
    ,gon_self NUMERIC(5) NOT NULL
    ,lau_rf NUMERIC(5) NOT NULL
    ,lau_nf NUMERIC(5) NOT NULL
    ,lau_df NUMERIC(5) NOT NULL
    ,lau_self NUMERIC(5) NOT NULL
    ,lau_dg_1_5 NUMERIC(5) NOT NULL
    ,lau_dg_6 NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  icoditem
    (
    charg_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,tmp CHAR(2)  NOT NULL
    ,item_cod CHAR(14)  NOT NULL
    ,qty_prc NUMERIC(10) NOT NULL
    ,qty_tot CHAR(10)  NOT NULL
    ,qty_remain NUMERIC(10) NOT NULL
    ,usag CHAR(40)  NOT NULL
    ,self CHAR(2)  NOT NULL
    ,item_typ CHAR(2)  NOT NULL
    ,emg CHAR(2)  NOT NULL
    ,gl_cod NUMERIC(5) NOT NULL
    ,pt_cod NUMERIC(5) NOT NULL
    ,pr_amt NUMERIC(9,1)  NOT NULL
    ,gl_amt_p NUMERIC(9,1)  NOT NULL
    ,pt_amt NUMERIC(9,1)  NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  bmasgnl
    (
    tp NUMERIC(5) NOT NULL
    td DATE NOT NULL
    ,thm NUMERIC(5) NOT NULL
    ,tl NUMERIC(5) NOT NULL
    ,tc CHAR(4)  NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,room_o CHAR(8)
    ,bed_o CHAR(4)  NOT NULL
    ,discha_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  bmrmlvl
    (
    room CHAR(8)
    bed CHAR(4)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,class CHAR(2)  NOT NULL
    ,rank CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  icglscon
    (
    acc_no NUMERIC(10) NOT NULL
    item_cod CHAR(14)  NOT NULL
    ,fil_1 CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  icrolog
    (
    tp NUMERIC(5) NOT NULL
    td DATE NOT NULL
    ,thm NUMERIC(5) NOT NULL
    ,tl NUMERIC(5) NOT NULL
    ,acc_no NUMERIC(10) NOT NULL
    ,col_no NUMERIC(10) NOT NULL
    ,tim_chg_no NUMERIC(10) NOT NULL
    ,ord_chg_no NUMERIC(10) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  rfdata
    (
    chart NUMERIC(10) NOT NULL
    visit_no NUMERIC(11,0)
    ,refer_hosp NUMERIC(10) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  icitmqty
    (
    acc_no NUMERIC(10) NOT NULL
    item_cod CHAR(14)  NOT NULL
    ,fee_cod NUMERIC(5) NOT NULL
    ,days NUMERIC(5) NOT NULL
    ,qty NUMERIC(10) NOT NULL
    ,amt_pr NUMERIC(9,1)
    ,amt_fil NUMERIC(9,1)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psdpatbd
    (
    sub_h_no NUMERIC(5) NOT NULL
    unit_no NUMERIC(5) NOT NULL
    ,level_no NUMERIC(5) NOT NULL
    ,nam_a CHAR(8)  NOT NULL
    ,nam_f CHAR(40)  NOT NULL
    ,strenth NUMERIC(5) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,mark_pson CHAR(2)  NOT NULL
    ,mark_acc CHAR(2)  NOT NULL
    ,mark_med CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  updicoi
    (
    charg_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(10) NOT NULL
    ,item_cod CHAR(14)  NOT NULL
    ,gl_cod NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  updocoi
    (
    charg_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(10) NOT NULL
    ,item_cod CHAR(14)  NOT NULL
    ,gl_cod NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  icptclog
    (
    tp NUMERIC(5) NOT NULL
    td DATE NOT NULL
    ,thm NUMERIC(5) NOT NULL
    ,tl NUMERIC(5) NOT NULL
    ,acc_no NUMERIC(10) NOT NULL
    ,gl_typ_o CHAR(4)  NOT NULL
    ,pt_typ_o CHAR(8)
    ,gl_typ_n CHAR(4)  NOT NULL
    ,pt_typ_n CHAR(8)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  cgpcs
    (
    chart NUMERIC(10) NOT NULL
    visit_no NUMERIC(11,0)
    ,typ NUMERIC(5) NOT NULL
    ,amt NUMERIC(10) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mricddsc
    (
    icd_cod CHAR(12)  NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,descr CHAR(500)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ntpdrscn
    (
    cod CHAR(4)  NOT NULL
    nam_c CHAR(16)  NOT NULL
    ,nam_e CHAR(60)  NOT NULL
    ,unit CHAR(8)  NOT NULL
    ,std NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ntpdrlog
    (
    acc_no NUMERIC(10) NOT NULL
    f_dat DATE NOT NULL
    ,f_meal CHAR(2)  NOT NULL
    ,prescriptor NUMERIC(5) NOT NULL
    ,cod1 CHAR(4)  NOT NULL
    ,qty1 NUMERIC(7,2)  NOT NULL
    ,cod2 CHAR(4)  NOT NULL
    ,qty2 NUMERIC(7,2)  NOT NULL
    ,cod3 CHAR(4)  NOT NULL
    ,qty3 NUMERIC(7,2)  NOT NULL
    ,cod4 CHAR(4)  NOT NULL
    ,qty4 NUMERIC(7,2)  NOT NULL
    ,cod5 CHAR(4)  NOT NULL
    ,qty5 NUMERIC(7,2)  NOT NULL
    ,coment CHAR(80)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  ntpdrest
    (
    acc_no NUMERIC(10) NOT NULL
    f_dat DATE NOT NULL
    ,f_meal CHAR(2)  NOT NULL
    ,prescriptor NUMERIC(5) NOT NULL
    ,cod1 CHAR(4)  NOT NULL
    ,qty1 NUMERIC(7,2)  NOT NULL
    ,cod2 CHAR(4)  NOT NULL
    ,qty2 NUMERIC(7,2)  NOT NULL
    ,cod3 CHAR(4)  NOT NULL
    ,qty3 NUMERIC(7,2)  NOT NULL
    ,cod4 CHAR(4)  NOT NULL
    ,qty4 NUMERIC(7,2)  NOT NULL
    ,cod5 CHAR(4)  NOT NULL
    ,qty5 NUMERIC(7,2)  NOT NULL
    ,coment CHAR(80)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ntpddesc
    (
    acc_no NUMERIC(10) NOT NULL
    dt_own CHAR(2)  NOT NULL
    ,f_dat DATE NOT NULL
    ,f_meal CHAR(2)  NOT NULL
    ,f_tim NUMERIC(5)
    ,t_dat DATE NOT NULL
    ,t_meal CHAR(2)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,item CHAR(2)  NOT NULL
    ,bkt_itm CHAR(2)
    ,lnh_itm CHAR(2)
    ,dnr_itm CHAR(2)
    ,vegetan CHAR(2)  NOT NULL
    ,avoid1 CHAR(2)  NOT NULL
    ,avoid2 CHAR(2)  NOT NULL
    ,avoid3 CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ntpddlog
    (
    acc_no NUMERIC(10) NOT NULL
    dt_own CHAR(2)  NOT NULL
    ,f_dat DATE NOT NULL
    ,f_meal CHAR(2)  NOT NULL
    ,f_tim NUMERIC(5)
    ,t_dat DATE NOT NULL
    ,t_meal CHAR(2)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,item CHAR(2)  NOT NULL
    ,bkt_itm CHAR(2)
    ,lnh_itm CHAR(2)
    ,dnr_itm CHAR(2)
    ,vegetan CHAR(2)  NOT NULL
    ,avoid1 CHAR(2)  NOT NULL
    ,avoid2 CHAR(2)  NOT NULL
    ,avoid3 CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  mrptdiag
    (
    chart NUMERIC(10) NOT NULL
    visit_no NUMERIC(11,0)
    ,diag CHAR(12)  NOT NULL
    ,doctor NUMERIC(5) NOT NULL
    ,f_hhmm NUMERIC(5) NOT NULL
    ,t_hhmm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  pslicens
    (
    emp_no NUMERIC(10) NOT NULL
    typ CHAR(2)  NOT NULL
    ,typ_1 CHAR(2)
    ,seq CHAR(2)  NOT NULL
    ,nam CHAR(80)
    ,cer_ch CHAR(60)  NOT NULL
    ,cer_no CHAR(40)  NOT NULL
    ,org_no NUMERIC(10)
    ,eff_dat DATE NOT NULL
    ,del_dat DATE NOT NULL
    ,coment CHAR(40)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  pssclcn
    (
    scl_no NUMERIC(5) NOT NULL
    nam_a CHAR(8)  NOT NULL
    ,nam_f CHAR(40)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psdptbd
    (
    depart NUMERIC(5) NOT NULL
    nam_a CHAR(24)  NOT NULL
    ,nam_f CHAR(40)  NOT NULL
    ,level_no NUMERIC(5) NOT NULL
    ,u_depart NUMERIC(5) NOT NULL
    ,strenth NUMERIC(5) NOT NULL
    ,lp_seq NUMERIC(5) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psdptitl
    (
    depart NUMERIC(5) NOT NULL
    titl CHAR(4)  NOT NULL
    ,strenth NUMERIC(5) NOT NULL
    ,diploma_l CHAR(2)  NOT NULL
    ,diploma_h CHAR(2)  NOT NULL
    ,qualifi CHAR(600)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgcolect
    (
    collect_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,visit_no NUMERIC(11,0)
    ,charg_amt NUMERIC(10) NOT NULL
    ,cash NUMERIC(10) NOT NULL
    ,vou_no NUMERIC(5) NOT NULL
    ,del_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  pscmback
    (
    emp_no NUMERIC(5) NOT NULL
    f_dat DATE NOT NULL
    ,t_dat DATE NOT NULL
    ,depart NUMERIC(5) NOT NULL
    ,titl CHAR(4)  NOT NULL
    ,rank NUMERIC(5) NOT NULL
    ,procs CHAR(2)  NOT NULL
    ,reason CHAR(4)  NOT NULL
    ,coment CHAR(42)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  pstrain
    (
    emp_no NUMERIC(5) NOT NULL
    f_dat DATE NOT NULL
    ,t_dat DATE NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,contract CHAR(2)  NOT NULL
    ,hol_fee CHAR(2)  NOT NULL
    ,place CHAR(8)  NOT NULL
    ,scl_fee NUMERIC(5) NOT NULL
    ,trvl_fee NUMERIC(5) NOT NULL
    ,coment CHAR(80)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psempscl
    (
    emp_no NUMERIC(5) NOT NULL
    scl_no NUMERIC(5) NOT NULL
    ,depart NUMERIC(5) NOT NULL
    ,grad_yy NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psephbcn
    (
    exp_hby CHAR(4)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,nam_a CHAR(8)  NOT NULL
    ,nam_f CHAR(40)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psexphby
    (
    emp_no NUMERIC(10) NOT NULL
    exp_hby CHAR(4)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,eff_dat DATE
    ,stp_dat DATE
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  pspripun
    (
    emp_no NUMERIC(5) NOT NULL
    pp_dat DATE NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,qty CHAR(2)  NOT NULL
    ,reason CHAR(40)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psprodod
    (
    emp_no NUMERIC(5) NOT NULL
    pre_od_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psufbd
    (
    typ CHAR(4)  NOT NULL
    nam CHAR(60)  NOT NULL
    ,fee_s NUMERIC(5) NOT NULL
    ,fee_c NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psunifom
    (
    emp_no NUMERIC(5) NOT NULL
    dat DATE NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,qty NUMERIC(5) NOT NULL
    ,coment CHAR(40)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psscldpt
    (
    dpt_no NUMERIC(5) NOT NULL
    nam_a CHAR(8)  NOT NULL
    ,nam_f CHAR(40)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  pstitlt
    (
    emp_no NUMERIC(10) NOT NULL
    td DATE NOT NULL
    ,tsc_typ CHAR(4)
    ,new_depart NUMERIC(10) NOT NULL
    ,new_mas_cod CHAR(16)
    ,new_titl CHAR(4)  NOT NULL
    ,new_fil_1 CHAR(2)
    ,rank NUMERIC(5) NOT NULL
    ,n_r CHAR(2)  NOT NULL
    ,coment CHAR(200)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ocmaoimt
    (
    item_cod CHAR(14)  NOT NULL
    lp_seq NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psepbd2
    (
    emp_no NUMERIC(5) NOT NULL
    underwrit_dat DATE NOT NULL
    ,tax_cnt NUMERIC(5) NOT NULL
    ,scl_no NUMERIC(5) NOT NULL
    ,dpt_no NUMERIC(5) NOT NULL
    ,introducer CHAR(24)  NOT NULL
    ,intrd_tel NUMERIC(10) NOT NULL
    ,od_reason CHAR(2)  NOT NULL
    ,od_procs CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  zzrptbd
    (
    typ CHAR(2)  NOT NULL
    lp_seq NUMERIC(5) NOT NULL
    ,nam CHAR(100)  NOT NULL
    ,loc CHAR(40)  NOT NULL
    ,copies NUMERIC(5) NOT NULL
    ,progrm CHAR(24)  NOT NULL
    ,secret CHAR(2)  NOT NULL
    ,author NUMERIC(5) NOT NULL
    ,maintainer NUMERIC(5) NOT NULL
    ,coment CHAR(80)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  pscareer
    (
    emp_no NUMERIC(5) NOT NULL
    organ_no NUMERIC(10) NOT NULL
    ,depart NUMERIC(5) NOT NULL
    ,titl CHAR(4)  NOT NULL
    ,f_dat DATE NOT NULL
    ,t_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  tttmp
    (
    chart NUMERIC(10)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  ofvacat
    (
    emp_no NUMERIC(5) NOT NULL
    typ CHAR(4)  NOT NULL
    ,f_dat DATE NOT NULL
    ,f_hm NUMERIC(5) NOT NULL
    ,t_dat DATE NOT NULL
    ,t_hm NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psyrexam
    (
    yymm NUMERIC(5)
    emp_no NUMERIC(10)
    ,exam_1 NUMERIC(4,1)  NOT NULL
    ,exam_2 NUMERIC(4,1)  NOT NULL
    ,exam_3 NUMERIC(4,1)  NOT NULL
    ,ext NUMERIC(4,1)
    ,cmt CHAR(200)
    ,thing_dat NUMERIC(4,1)  NOT NULL
    ,sick_dat NUMERIC(4,1)  NOT NULL
    ,lat_dat NUMERIC(5) NOT NULL
    ,absent_dat NUMERIC(4,1)  NOT NULL
    ,reward NUMERIC(4,1)  NOT NULL
    ,punish NUMERIC(4,1)
    ,stay NUMERIC(4,1)  NOT NULL
    ,stay_b NUMERIC(4,1)
    ,stay_q NUMERIC(4,1)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  psyrtot
    (
    emp_no NUMERIC(5) NOT NULL
    stay_dat NUMERIC(4,1)  NOT NULL
    ,auto_tot NUMERIC(4,1)  NOT NULL
    ,auto_level NUMERIC(5) NOT NULL
    ,last_level NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  pssalary
    (
    emp_no NUMERIC(5) NOT NULL
    bas_sal NUMERIC(10) NOT NULL
    ,year_add NUMERIC(10) NOT NULL
    ,duty_add NUMERIC(4,2)  NOT NULL
    ,chief_add NUMERIC(4,2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  icffamt
    (
    acc_no NUMERIC(10) NOT NULL
    each_dat DATE NOT NULL
    ,rf NUMERIC(5) NOT NULL
    ,nf NUMERIC(5) NOT NULL
    ,df NUMERIC(5) NOT NULL
    ,dg NUMERIC(5) NOT NULL
    ,rf_self NUMERIC(5) NOT NULL
    ,nf_self NUMERIC(5) NOT NULL
    ,df_self NUMERIC(5) NOT NULL
    ,dg_self NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  erptbd
    (
    chart NUMERIC(10) NOT NULL
    er_dat DATE NOT NULL
    ,er_thm NUMERIC(5) NOT NULL
    ,division NUMERIC(5) NOT NULL
    ,sick_typ CHAR(2)  NOT NULL
    ,treat_tm CHAR(40)  NOT NULL
    ,diag1 CHAR(16)  NOT NULL
    ,diag2 CHAR(16)  NOT NULL
    ,diag3 CHAR(16)  NOT NULL
    ,diag_dr1 CHAR(80)  NOT NULL
    ,diag_dr2 CHAR(80)  NOT NULL
    ,com_div1 NUMERIC(5) NOT NULL
    ,com_thm1 CHAR(22)
    ,arr_thm1 NUMERIC(5) NOT NULL
    ,com_div2 NUMERIC(5) NOT NULL
    ,com_thm2 CHAR(22)
    ,arr_thm2 NUMERIC(5) NOT NULL
    ,com_div3 NUMERIC(5) NOT NULL
    ,com_thm3 CHAR(22)
    ,arr_thm3 NUMERIC(5) NOT NULL
    ,hom_typ CHAR(2)  NOT NULL
    ,hom_tm CHAR(22)
    ,treat CHAR(22)
    ,roombed CHAR(12)  NOT NULL
    ,refer_h NUMERIC(10,0)
    ,rsn_h CHAR(4)
    ,refer_g NUMERIC(10,0)
    ,rsn_g CHAR(4)
    ,stay_see CHAR(2)  NOT NULL
    ,adm CHAR(2)
    ,rtn CHAR(2)
    ,rsn CHAR(2)
    ,aad_no NUMERIC(5)
    ,cmt CHAR(40)
    ,nurse NUMERIC(10) NOT NULL
    ,doctor NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ttt1
    (
    item_no CHAR(14)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  uddisodf
    (
    acc_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,ord_typ CHAR(2)  NOT NULL
    ,dc_typ CHAR(2)  NOT NULL
    ,dc_qty NUMERIC(7,2)  NOT NULL
    ,doctor NUMERIC(5) NOT NULL
    ,depart NUMERIC(5) NOT NULL
    ,item_cod CHAR(14)  NOT NULL
    ,qty_tot CHAR(10)  NOT NULL
    ,qty_prc NUMERIC(7,2)  NOT NULL
    ,usag CHAR(30)  NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,self CHAR(2)  NOT NULL
    ,start_dat DATE NOT NULL
    ,start_time NUMERIC(5) NOT NULL
    ,stop_dat DATE NOT NULL
    ,stop_time NUMERIC(5) NOT NULL
    ,qty_firstday NUMERIC(7,2)  NOT NULL
    ,qty_everyday NUMERIC(7,2)  NOT NULL
    ,last_usupd DATE NOT NULL
    ,last_usqty FLOAT NOT NULL
    ,high_price CHAR(2)  NOT NULL
    ,qty_highreq NUMERIC(7,2)  NOT NULL
    ,qty_nowown NUMERIC(7,2)  NOT NULL
    ,last_hiupd DATE NOT NULL
    ,last_hiqty FLOAT NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  uddologf
    (
    acc_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,log_typ CHAR(2)  NOT NULL
    ,new_seq_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  udductrf
    (
    usagcod CHAR(12)  NOT NULL
    div360 CHAR(2)  NOT NULL
    ,dap CHAR(8)  NOT NULL
    ,nam CHAR(40)  NOT NULL
    ,i_time CHAR(48)  NOT NULL
    ,t_time CHAR(48)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  lbbookbr
    (
    loc NUMERIC(10) NOT NULL
    borrower NUMERIC(5) NOT NULL
    ,acc_no NUMERIC(10) NOT NULL
    ,bor_dat DATE NOT NULL
    ,pre_dat DATE NOT NULL
    ,ret_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  gllauiff
    (
    gl_typ CHAR(4)  NOT NULL
    appl_depart NUMERIC(5) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,in_dat DATE NOT NULL
    ,out_dat DATE NOT NULL
    ,depart NUMERIC(5) NOT NULL
    ,fee_011 NUMERIC(10) NOT NULL
    ,fee_012 NUMERIC(10) NOT NULL
    ,fee_021 NUMERIC(10) NOT NULL
    ,fee_022 NUMERIC(10) NOT NULL
    ,fee_031 NUMERIC(10) NOT NULL
    ,fee_032 NUMERIC(10) NOT NULL
    ,fee_041 NUMERIC(10) NOT NULL
    ,fee_042 NUMERIC(10) NOT NULL
    ,fee_050 NUMERIC(10) NOT NULL
    ,fee_060 NUMERIC(10) NOT NULL
    ,fee_070 NUMERIC(10) NOT NULL
    ,fee_081 NUMERIC(10) NOT NULL
    ,fee_082 NUMERIC(10) NOT NULL
    ,fee_090 NUMERIC(10) NOT NULL
    ,fee_100 NUMERIC(10) NOT NULL
    ,fee_110 NUMERIC(10) NOT NULL
    ,fee_120 NUMERIC(10) NOT NULL
    ,fee_130 NUMERIC(10) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  iofeem
    (
    typ CHAR(2)  NOT NULL
    pt_typ CHAR(2)
    ,chart NUMERIC(10)
    ,in_dat DATE
    ,out_dat DATE
    ,doctor NUMERIC(5)
    ,depart NUMERIC(5)
    ,seq_no NUMERIC(5)
    ,fee_01 NUMERIC(10)
    ,fee_02 NUMERIC(10)
    ,fee_03 NUMERIC(10)
    ,fee_04 NUMERIC(10)
    ,fee_05 NUMERIC(10)
    ,fee_06 NUMERIC(10)
    ,fee_07 NUMERIC(10)
    ,fee_08 NUMERIC(10)
    ,fee_09 NUMERIC(10)
    ,fee_10 NUMERIC(10)
    ,fee_11 NUMERIC(10)
    ,fee_12 NUMERIC(10)
    ,fee_13 NUMERIC(10)
    ,fee_14 NUMERIC(10)
    ,fee_15 NUMERIC(10)
    ,fee_16 NUMERIC(10)
    ,fee_17 NUMERIC(10)
    ,fee_18 NUMERIC(10)
    ,fee_19 NUMERIC(10)
    ,fee_20 NUMERIC(10)
    ,fee_21 NUMERIC(10)
    ,fee_22 NUMERIC(10)
    ,fee_23 NUMERIC(10)
    ,fee_24 NUMERIC(10)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  dgdesc1
    (
    drug_cod CHAR(10)  NOT NULL
    tc CHAR(2)  NOT NULL
    ,nam CHAR(80)  NOT NULL
    ,content CHAR(50)  NOT NULL
    ,pcs_self CHAR(2)  NOT NULL
    ,dis CHAR(2)  NOT NULL
    ,ud CHAR(2)  NOT NULL
    ,slot_no NUMERIC(5) NOT NULL
    ,gonbau CHAR(2)  NOT NULL
    ,laubau CHAR(2)  NOT NULL
    ,sale_typ CHAR(2)  NOT NULL
    ,price_typ CHAR(2)  NOT NULL
    ,sale_unit CHAR(8)  NOT NULL
    ,std_unit CHAR(8)  NOT NULL
    ,sal_std_r NUMERIC(9,4)  NOT NULL
    ,dose_unit CHAR(8)  NOT NULL
    ,use_typ CHAR(4)  NOT NULL
    ,shaking CHAR(2)  NOT NULL
    ,prn CHAR(2)  NOT NULL
    ,eat_typ_1 CHAR(2)  NOT NULL
    ,eat_typ_2 CHAR(2)  NOT NULL
    ,ac_pc CHAR(2)  NOT NULL
    ,m_n CHAR(2)  NOT NULL
    ,storage CHAR(2)  NOT NULL
    ,notice CHAR(2)  NOT NULL
    ,ap_safe_typ CHAR(2)  NOT NULL
    ,license_no NUMERIC(10) NOT NULL
    ,orig_cntry CHAR(6)  NOT NULL
    ,orig_place CHAR(6)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  osdesc
    (
    order_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,visit_no NUMERIC(11,0)
    ,division NUMERIC(5) NOT NULL
    ,doctor NUMERIC(5) NOT NULL
    ,gl_typ CHAR(4)  NOT NULL
    ,tmp CHAR(2)  NOT NULL
    ,lamp_typ CHAR(2)  NOT NULL
    ,lamp_no NUMERIC(5) NOT NULL
    ,ap_visit_no NUMERIC(11,0)
    ,ret CHAR(2)  NOT NULL
    ,emg_rtt TIMESTAMP NOT NULL
    ,os_rtt TIMESTAMP NOT NULL
    ,oc_rtt TIMESTAMP NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ossoa
    (
    order_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,desc_cdc CHAR(510)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ossoal
    (
    order_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,desc_cdc CHAR(510)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  osditto
    (
    md_dr NUMERIC(5) NOT NULL
    ditto_no CHAR(12)  NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,desc_cdc CHAR(120)
    ,item_cod CHAR(14)
    ,usag CHAR(40)
    ,tot_qty CHAR(10)
    ,emg CHAR(2)
    ,chg CHAR(2)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  lbbookbd
    (
    loc NUMERIC(10) NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,class_no CHAR(14)  NOT NULL
    ,vol_no NUMERIC(5) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,title CHAR(120)  NOT NULL
    ,author CHAR(40)  NOT NULL
    ,pub_year NUMERIC(5) NOT NULL
    ,pub_edit NUMERIC(5) NOT NULL
    ,pubshr_no NUMERIC(5) NOT NULL
    ,sou_lb CHAR(2)  NOT NULL
    ,sou_loc NUMERIC(5) NOT NULL
    ,in_date DATE NOT NULL
    ,amt NUMERIC(10) NOT NULL
    ,com_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  iaasmst
    (
    assets_no NUMERIC(6,0)  NOT NULL
    assets_ser NUMERIC(5) NOT NULL
    ,assets_iname CHAR(40)  NOT NULL
    ,trans_date DATE NOT NULL
    ,unit CHAR(8)  NOT NULL
    ,quantity NUMERIC(5) NOT NULL
    ,trans_value NUMERIC(12,2)  NOT NULL
    ,basic_value NUMERIC(10,2)  NOT NULL
    ,add_value NUMERIC(10,2)  NOT NULL
    ,useful_life NUMERIC(5) NOT NULL
    ,month_dep NUMERIC(10,2)  NOT NULL
    ,accumu_dep NUMERIC(12,2)  NOT NULL
    ,supplier_no CHAR(16)  NOT NULL
    ,user_no NUMERIC(10) NOT NULL
    ,last_dep_date DATE NOT NULL
    ,dpt_c NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  iaassub
    (
    assets_no NUMERIC(6,0)  NOT NULL
    assets_ser NUMERIC(5) NOT NULL
    ,change_ser NUMERIC(5) NOT NULL
    ,change_type CHAR(2)  NOT NULL
    ,change_date DATE NOT NULL
    ,change_value NUMERIC(12,2)  NOT NULL
    ,change_user NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  iaassup
    (
    supplier_no CHAR(16)  NOT NULL
    suppli_name CHAR(40)
    ,suppli_tel CHAR(20)  NOT NULL
    ,suppli_addr CHAR(80)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  iaasuse
    (
    user_no NUMERIC(10) NOT NULL
    user_name CHAR(28)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  lbjvbd
    (
    loc NUMERIC(5) NOT NULL
    com_no NUMERIC(10) NOT NULL
    ,f_vol_no NUMERIC(5) NOT NULL
    ,f_seq_no NUMERIC(5) NOT NULL
    ,t_vol_no NUMERIC(5) NOT NULL
    ,t_seq_no NUMERIC(5) NOT NULL
    ,title CHAR(120)  NOT NULL
    ,sou_loc NUMERIC(5) NOT NULL
    ,in_date DATE NOT NULL
    ,remark CHAR(60)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  bmelidat
    (
    acc_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,el_days NUMERIC(5) NOT NULL
    ,reason CHAR(36)  NOT NULL
    ,coment CHAR(80)  NOT NULL
    ,diag CHAR(36)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,fil_1 CHAR(2)  NOT NULL
    ,fair CHAR(2)  NOT NULL
    ,apply CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mtdesc
    (
    mt_cod CHAR(14)  NOT NULL
    tc CHAR(2)  NOT NULL
    ,unit_e CHAR(8)  NOT NULL
    ,unit_c CHAR(8)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,sub_typ CHAR(2)  NOT NULL
    ,acc_typ CHAR(4)
    ,pcs_self CHAR(2)  NOT NULL
    ,sal_typ CHAR(2)  NOT NULL
    ,pric_typ CHAR(2)  NOT NULL
    ,gonbau CHAR(2)  NOT NULL
    ,laubau CHAR(2)  NOT NULL
    ,nam CHAR(160)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  sysmenuitems
    (
    imenuname CHAR(36)
    itemnum NUMERIC(10)
    ,mtext CHAR(120)
    ,mtype CHAR(2)
    ,progname CHAR(120)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgsiupf
    (
    item_cod CHAR(14)  NOT NULL
    tc CHAR(2)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,gonbau CHAR(2)  NOT NULL
    ,ng_reason CHAR(2)  NOT NULL
    ,gh CHAR(2)  NOT NULL
    ,laubau CHAR(2)  NOT NULL
    ,nl_reason CHAR(2)  NOT NULL
    ,p_typ CHAR(2)  NOT NULL
    ,o_lmt_gon NUMERIC(5) NOT NULL
    ,i_lmt_gon NUMERIC(5) NOT NULL
    ,o_lmt_lau NUMERIC(5) NOT NULL
    ,i_lmt_lau NUMERIC(5) NOT NULL
    ,high_price CHAR(2)  NOT NULL
    ,group_item CHAR(2)  NOT NULL
    ,cod_gen NUMERIC(5) NOT NULL
    ,cod_gon NUMERIC(5) NOT NULL
    ,cod_lau NUMERIC(5) NOT NULL
    ,e_rat_gen NUMERIC(4,2)  NOT NULL
    ,e_rat_gon NUMERIC(4,2)  NOT NULL
    ,e_rat_lau NUMERIC(4,2)  NOT NULL
    ,discnt_gen CHAR(2)  NOT NULL
    ,discnt_gon CHAR(2)  NOT NULL
    ,discnt_lau CHAR(2)  NOT NULL
    ,spe_cas CHAR(2)  NOT NULL
    ,mult_gon CHAR(2)  NOT NULL
    ,mult_lau CHAR(2)  NOT NULL
    ,up_gen NUMERIC(9,2)  NOT NULL
    ,up_gon NUMERIC(9,2)  NOT NULL
    ,up_lau NUMERIC(9,2)  NOT NULL
    ,ud_lmt NUMERIC(5) NOT NULL
    ,ud_round CHAR(2)  NOT NULL
    ,ud_nodis CHAR(2)  NOT NULL
    ,os_mapno NUMERIC(5) NOT NULL
    ,chg CHAR(2)  NOT NULL
    ,ppf_fg CHAR(2)  NOT NULL
    ,dos_sal_r1 NUMERIC(5) NOT NULL
    ,dos_sal_r2 NUMERIC(5) NOT NULL
    ,dos_qty CHAR(10)  NOT NULL
    ,usag CHAR(26)  NOT NULL
    ,use_typ CHAR(4)  NOT NULL
    ,ac_pc CHAR(2)  NOT NULL
    ,opiate CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgsiupp
    (
    item_cod CHAR(14)  NOT NULL
    tc CHAR(2)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,comment CHAR(2)  NOT NULL
    ,nam CHAR(90)  NOT NULL
    ,sal_unit CHAR(8)  NOT NULL
    ,dos_unit CHAR(8)  NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,test_drug CHAR(2)  NOT NULL
    ,gonbau CHAR(2)  NOT NULL
    ,ng_reason CHAR(2)  NOT NULL
    ,gh CHAR(2)  NOT NULL
    ,laubau CHAR(2)  NOT NULL
    ,nl_reason CHAR(2)  NOT NULL
    ,o_lmt_gon NUMERIC(5) NOT NULL
    ,i_lmt_gon NUMERIC(5) NOT NULL
    ,o_lmt_lau NUMERIC(5) NOT NULL
    ,i_lmt_lau NUMERIC(5) NOT NULL
    ,high_price CHAR(2)  NOT NULL
    ,group_item CHAR(2)  NOT NULL
    ,cod_gen NUMERIC(5) NOT NULL
    ,cod_gon NUMERIC(5) NOT NULL
    ,cod_lau NUMERIC(5) NOT NULL
    ,e_rat_gen NUMERIC(4,2)  NOT NULL
    ,e_rat_gon NUMERIC(4,2)  NOT NULL
    ,e_rat_lau NUMERIC(4,2)  NOT NULL
    ,discnt_gen CHAR(2)  NOT NULL
    ,discnt_gon CHAR(2)  NOT NULL
    ,discnt_lau CHAR(2)  NOT NULL
    ,spe_cas CHAR(2)  NOT NULL
    ,up_gen NUMERIC(9,2)  NOT NULL
    ,up_gon NUMERIC(9,2)  NOT NULL
    ,up_lau NUMERIC(9,2)  NOT NULL
    ,ud_lmt NUMERIC(5) NOT NULL
    ,ud_round CHAR(2)  NOT NULL
    ,ud_nodis CHAR(2)  NOT NULL
    ,os_mapno NUMERIC(5) NOT NULL
    ,chg CHAR(2)  NOT NULL
    ,ppf_fg CHAR(2)  NOT NULL
    ,dos_sal_r1 NUMERIC(5) NOT NULL
    ,dos_sal_r2 NUMERIC(5) NOT NULL
    ,dos_qty CHAR(10)  NOT NULL
    ,usag CHAR(26)  NOT NULL
    ,use_typ CHAR(4)  NOT NULL
    ,ac_pc CHAR(2)  NOT NULL
    ,opiate CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  icddata
    (
    chart NUMERIC(10) NOT NULL
    division NUMERIC(5) NOT NULL
    ,admit_dat DATE NOT NULL
    ,admit_hm NUMERIC(5) NOT NULL
    ,discha_dat DATE NOT NULL
    ,discha_hm NUMERIC(5) NOT NULL
    ,admit_window CHAR(2)  NOT NULL
    ,pt_typ CHAR(4)  NOT NULL
    ,discha_sts CHAR(4)  NOT NULL
    ,a_dr1 NUMERIC(5) NOT NULL
    ,a_dr2 NUMERIC(5) NOT NULL
    ,operator_1 NUMERIC(5) NOT NULL
    ,operator_2 NUMERIC(5) NOT NULL
    ,e_code CHAR(12)  NOT NULL
    ,m_code_1 CHAR(12)  NOT NULL
    ,m_code_2 CHAR(12)  NOT NULL
    ,v_code CHAR(12)  NOT NULL
    ,diag1 CHAR(12)  NOT NULL
    ,diag2 CHAR(12)  NOT NULL
    ,diag3 CHAR(12)  NOT NULL
    ,diag4 CHAR(12)  NOT NULL
    ,pathology CHAR(2)  NOT NULL
    ,operate_1 CHAR(12)  NOT NULL
    ,operate_2 CHAR(12)  NOT NULL
    ,operate_3 CHAR(12)  NOT NULL
    ,anesthesia CHAR(2)  NOT NULL
    ,born_typ CHAR(2)  NOT NULL
    ,baby_cond CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  iclaudat
    (
    chart NUMERIC(10) NOT NULL
    in_dat DATE NOT NULL
    ,in_hm NUMERIC(5) NOT NULL
    ,in_dat_lau DATE NOT NULL
    ,admit_1_no CHAR(4)  NOT NULL
    ,admit_2_no NUMERIC(10) NOT NULL
    ,appl_room_no CHAR(8)
    ,appl_bed_no CHAR(4)  NOT NULL
    ,pre_dis_dat DATE NOT NULL
    ,fst_appl_dat NUMERIC(10) NOT NULL
    ,sick_typ CHAR(2)  NOT NULL
    ,days_1 NUMERIC(5) NOT NULL
    ,days_2 NUMERIC(5) NOT NULL
    ,days_3 NUMERIC(5) NOT NULL
    ,days_4 NUMERIC(5) NOT NULL
    ,days_5 NUMERIC(5) NOT NULL
    ,days_6 NUMERIC(5) NOT NULL
    ,days_7 NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mrptccs
    (
    chart NUMERIC(10) NOT NULL
    diag CHAR(12)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,reason CHAR(2)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,division NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  dccontcb
    (
    dc_cod_m CHAR(12)  NOT NULL
    dc_cod_a CHAR(12)  NOT NULL
    ,cond_cod NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  zzcodnam
    (
    cod NUMERIC(5) NOT NULL
    nam_f CHAR(200)  NOT NULL
    ,nam_a CHAR(12)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mrpobd
    (
    organ_no NUMERIC(10,0)  NOT NULL
    organ_nam CHAR(80)  NOT NULL
    ,region_no NUMERIC(5) NOT NULL
    ,adrs CHAR(60)  NOT NULL
    ,head CHAR(16)  NOT NULL
    ,title CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,tel_no NUMERIC(10) NOT NULL
    ,fax_no NUMERIC(10) NOT NULL
    ,copies NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  rfdbd
    (
    hospital_no NUMERIC(10,0)  NOT NULL
    doctor_no NUMERIC(5) NOT NULL
    ,doctor_nam CHAR(16)  NOT NULL
    ,birthday DATE NOT NULL
    ,duty CHAR(2)  NOT NULL
    ,copies CHAR(2)  NOT NULL
    ,depart CHAR(8)  NOT NULL
    ,depart_m NUMERIC(5) NOT NULL
    ,depart_d NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  rgdata
    (
    chart NUMERIC(10) NOT NULL
    visit_no NUMERIC(11,0)
    ,seq_no NUMERIC(5) NOT NULL
    ,doctor NUMERIC(5) NOT NULL
    ,division_md NUMERIC(5) NOT NULL
    ,division_gl NUMERIC(5) NOT NULL
    ,gl_typ CHAR(4)  NOT NULL
    ,pt_typ CHAR(4)  NOT NULL
    ,charg_typ CHAR(2)  NOT NULL
    ,refer_h NUMERIC(10,0)  NOT NULL
    ,h_rank CHAR(2)  NOT NULL
    ,t_l CHAR(2)  NOT NULL
    ,a_c CHAR(2)  NOT NULL
    ,spe CHAR(2)  NOT NULL
    ,f_r CHAR(2)  NOT NULL
    ,mark CHAR(2)  NOT NULL
    ,comment CHAR(8)  NOT NULL
    ,visit_seq CHAR(2)  NOT NULL
    ,rg_deduct NUMERIC(5) NOT NULL
    ,haved_amt NUMERIC(5) NOT NULL
    ,chart_place CHAR(2)  NOT NULL
    ,print_dat DATE NOT NULL
    ,sp_typ CHAR(2)  NOT NULL
    ,drug_days NUMERIC(5) NOT NULL
    ,chronic CHAR(2)  NOT NULL
    ,gl_icd CHAR(160)  NOT NULL
    ,sick_typ CHAR(2)  NOT NULL
    ,permit CHAR(2)  NOT NULL
    ,rg_fee NUMERIC(5) NOT NULL
    ,dr_fee NUMERIC(5) NOT NULL
    ,dsp_fee NUMERIC(5) NOT NULL
    ,charg_no NUMERIC(10) NOT NULL
    ,fil_1 CHAR(2)  NOT NULL
    ,fil_2 CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  bmdrbac
    (
    division NUMERIC(5) NOT NULL
    doctor NUMERIC(5) NOT NULL
    ,own_cnt NUMERIC(5) NOT NULL
    ,bor_cnt NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mrcco
    (
    chronic_no CHAR(20)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,visit_no NUMERIC(11,0)
    ,doctor NUMERIC(5) NOT NULL
    ,cnt NUMERIC(5) NOT NULL
    ,drug_days NUMERIC(5) NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mrglcdcn
    (
    gl_cod CHAR(8)  NOT NULL
    g_l CHAR(2)  NOT NULL
    ,chronic CHAR(2)  NOT NULL
    ,crn_typ NUMERIC(5) NOT NULL
    ,serious CHAR(2)  NOT NULL
    ,cont_cure CHAR(2)  NOT NULL
    ,cont_cond NUMERIC(5) NOT NULL
    ,nam_c CHAR(100)  NOT NULL
    ,typ NUMERIC(5) NOT NULL
    ,std_days NUMERIC(5) NOT NULL
    ,g_amt NUMERIC(10) NOT NULL
    ,l_amt NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mricdcn
    (
    icd_cod CHAR(12)  NOT NULL
    gl_cod CHAR(8)  NOT NULL
    ,nam_c CHAR(300)  NOT NULL
    ,chronic CHAR(2)  NOT NULL
    ,crn_typ NUMERIC(5) NOT NULL
    ,serious CHAR(2)  NOT NULL
    ,cont_cure CHAR(2)  NOT NULL
    ,cont_cond NUMERIC(5) NOT NULL
    ,sex_limit CHAR(2)  NOT NULL
    ,diag_limit CHAR(2)  NOT NULL
    ,fil_1 CHAR(2)  NOT NULL
    ,age_f NUMERIC(5) NOT NULL
    ,age_t NUMERIC(5) NOT NULL
    ,std_days NUMERIC(5) NOT NULL
    ,g_amt NUMERIC(10) NOT NULL
    ,l_amt NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgndmdsc
    (
    item_cod CHAR(14)  NOT NULL
    tc CHAR(2)  NOT NULL
    ,unit CHAR(8)  NOT NULL
    ,nam CHAR(100)  NOT NULL
    ,gonbau CHAR(2)  NOT NULL
    ,laubau CHAR(2)  NOT NULL
    ,ps_gon CHAR(2)  NOT NULL
    ,ps_lau CHAR(2)  NOT NULL
    ,fct_typ CHAR(4)  NOT NULL
    ,dev_typ CHAR(8)  NOT NULL
    ,fil_2 NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  rgrtl
    (
    tp NUMERIC(5) NOT NULL
    thm NUMERIC(5) NOT NULL
    ,t1 NUMERIC(5) NOT NULL
    ,tc1 CHAR(2)  NOT NULL
    ,tc2 CHAR(2)  NOT NULL
    ,visit_dat DATE NOT NULL
    ,shift CHAR(2)  NOT NULL
    ,doctor NUMERIC(5) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  cgrmod
    (
    rmo_no NUMERIC(5) NOT NULL
    nam_a CHAR(16)  NOT NULL
    ,nam_f CHAR(100)
    ,ogt_cod CHAR(20)
    ,dat_f DATE
    ,dat_t DATE
    ,pa_i_rat NUMERIC(4,2)  NOT NULL
    ,xr_i_rat NUMERIC(4,2)  NOT NULL
    ,lb_i_rat NUMERIC(4,2)  NOT NULL
    ,pa_o_rat NUMERIC(4,2)  NOT NULL
    ,xr_o_rat NUMERIC(4,2)  NOT NULL
    ,lb_o_rat NUMERIC(4,2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,sup_no NUMERIC(10)
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  udmcwkds
    (
    ward CHAR(6)
    dat DATE NOT NULL
    ,mod CHAR(2)  NOT NULL
    ,mac_no CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  glrccd
    (
    id_no CHAR(20)  NOT NULL
    nam CHAR(24)  NOT NULL
    ,birthday DATE NOT NULL
    ,sample_dat DATE
    ,refer_dat DATE NOT NULL
    ,hospital_no NUMERIC(10,0)  NOT NULL
    ,nh_seq CHAR(4)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  rfhbd
    (
    hospital_no NUMERIC(10,0)  NOT NULL
    nam_f CHAR(100)
    ,nam_a CHAR(16)  NOT NULL
    ,zip NUMERIC(5) NOT NULL
    ,adrs CHAR(60)  NOT NULL
    ,tel_no NUMERIC(10) NOT NULL
    ,fax_no NUMERIC(10) NOT NULL
    ,eml_adr CHAR(100)
    ,head CHAR(16)  NOT NULL
    ,head_tel NUMERIC(10)
    ,birthday DATE NOT NULL
    ,title CHAR(2)  NOT NULL
    ,rank CHAR(2)  NOT NULL
    ,relat CHAR(2)  NOT NULL
    ,remot CHAR(2)  NOT NULL
    ,copies NUMERIC(5) NOT NULL
    ,typ_1 CHAR(2)  NOT NULL
    ,typ_2 CHAR(2)  NOT NULL
    ,eff_dat DATE
    ,stp_dat DATE
    ,depart CHAR(80)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mmivtcst
    (
    yy NUMERIC(5) NOT NULL
    giv_loc NUMERIC(5) NOT NULL
    ,req_loc NUMERIC(5) NOT NULL
    ,item_cod CHAR(14)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,qty01 NUMERIC(10) NOT NULL
    ,qty02 NUMERIC(10) NOT NULL
    ,qty03 NUMERIC(10) NOT NULL
    ,qty04 NUMERIC(10) NOT NULL
    ,qty05 NUMERIC(10) NOT NULL
    ,qty06 NUMERIC(10) NOT NULL
    ,qty07 NUMERIC(10) NOT NULL
    ,qty08 NUMERIC(10) NOT NULL
    ,qty09 NUMERIC(10) NOT NULL
    ,qty10 NUMERIC(10) NOT NULL
    ,qty11 NUMERIC(10) NOT NULL
    ,qty12 NUMERIC(10) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  pspoffd
    (
    emp_no NUMERIC(5) NOT NULL
    pre_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  oscnam
    (
    map_no NUMERIC(5) NOT NULL
    typ CHAR(2)  NOT NULL
    ,cod CHAR(16)  NOT NULL
    ,desc_cdc CHAR(60)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  orroombd
    (
    room CHAR(4)  NOT NULL
    rom_no NUMERIC(5) NOT NULL
    ,dev CHAR(4)  NOT NULL
    ,pri CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  oropday
    (
    room CHAR(4)  NOT NULL
    week NUMERIC(5) NOT NULL
    ,shift CHAR(2)  NOT NULL
    ,pri NUMERIC(5) NOT NULL
    ,dr NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  orasrmcd
    (
    room CHAR(4)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  moitem
    (
    ord_no NUMERIC(10) NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,dup_no NUMERIC(5)
    ,pos1 CHAR(6)
    ,pos2 CHAR(6)
    ,pos3 CHAR(6)
    ,tot_qty CHAR(10)
    ,self CHAR(2)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ord_no,dup_no,chg_cod)
);



CREATE TABLE  orexec
    (
    ord_no NUMERIC(10) NOT NULL
    tc1 CHAR(2)
    ,tc2 CHAR(2)
    ,opr_dr NUMERIC(5) NOT NULL
    ,opr_dr1 NUMERIC(5)
    ,opr_dr2 NUMERIC(5)
    ,opr_dr3 NUMERIC(5)
    ,opr_dat DATE NOT NULL
    ,opr_shift CHAR(2)  NOT NULL
    ,api_room CHAR(4)
    ,api_hm NUMERIC(5)
    ,pre_dt NUMERIC(5)
    ,bor_xr CHAR(2)
    ,ane_typ CHAR(2)  NOT NULL
    ,pri_typ NUMERIC(5) NOT NULL
    ,opr_room CHAR(4)  NOT NULL
    ,opr_seq NUMERIC(5)
    ,sta_nurse NUMERIC(5)
    ,ane_nurse NUMERIC(5)
    ,han_nurse NUMERIC(5)
    ,permit_psn NUMERIC(5)
    ,opr_cut CHAR(2)
    ,asa_typ CHAR(2)
    ,atn_hm NUMERIC(5)
    ,atd_hm NUMERIC(5)
    ,mnd_hm NUMERIC(5)
    ,tmo_hm NUMERIC(5)
    ,rip_hm NUMERIC(5)
    ,sew_hm NUMERIC(5)
    ,wait_hm NUMERIC(5)
    ,stt_hm NUMERIC(5)
    ,stp_hm NUMERIC(5)
    ,quit_hm NUMERIC(5)
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  uclogin
    (
    loc_id CHAR(12)  NOT NULL
    emp_no NUMERIC(5) NOT NULL
    ,group_func_no CHAR(8)  NOT NULL
    ,use_level CHAR(4)  NOT NULL
    ,func_no CHAR(8)  NOT NULL
    ,version CHAR(8)  NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cgctrl
    (
    chg_cod CHAR(14)  NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,desc_cdc CHAR(148)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,chk_cod CHAR(14)
    ,f_val CHAR(12)
    ,t_val CHAR(12)
    ,eff_days NUMERIC(5)
    ,tot_qty NUMERIC(5)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  moexeloc
    (
    map_no NUMERIC(5) NOT NULL
    loc NUMERIC(5) NOT NULL
    ,nam CHAR(20)  NOT NULL
    ,prn_loc CHAR(12)  NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  systableext
    (
    owner CHAR(64)
    tabname CHAR(64)
    ,extowner CHAR(64)
    ,tabalias CHAR(64)
    ,remarks CHAR(512)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  syscolumnext
    (
    owner CHAR(64)
    tabname CHAR(64)
    ,colname CHAR(64)
    ,extowner CHAR(64)
    ,colalias CHAR(64)
    ,collabel CHAR(64)
    ,coltitle CHAR(64)
    ,remarks CHAR(512)
    ,subtype CHAR(8)
    ,class CHAR(64)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  syscolformats
    (
    owner CHAR(64)
    tabname CHAR(64)
    ,colname CHAR(64)
    ,extowner CHAR(64)
    ,priority NUMERIC(5)
    ,typeface CHAR(128)
    ,fontsize NUMERIC(5)
    ,fontstyle NUMERIC(5)
    ,fontcolor NUMERIC(10)
    ,aidfa CHAR(60)
    ,formatmask CHAR(512)
    ,format4gl CHAR(256)
    ,align CHAR(2)
    ,case_cdc CHAR(2)
    ,ruletype CHAR(2)
    ,checktext CHAR(512)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  syscolinput
    (
    owner CHAR(64)
    tabname CHAR(64)
    ,colname CHAR(64)
    ,extowner CHAR(64)
    ,attrname CHAR(20)
    ,attrval CHAR(256)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  syscolinclude
    (
    owner CHAR(64)
    tabname CHAR(64)
    ,colname CHAR(64)
    ,extowner CHAR(64)
    ,priority NUMERIC(5)
    ,extvalue CHAR(128)
    ,intvalue CHAR(128)
    ,range CHAR(2)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  syssuperviews
    (
    svwid NUMERIC(10)  NOT NULL
    owner CHAR(64)
    ,svwname CHAR(64)
    ,remarks CHAR(144)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  syssvwtables
    (
    svwid NUMERIC(10)
    tableseq NUMERIC(10)
    ,owner CHAR(64)
    ,tabname CHAR(64)
    ,masteralias CHAR(64)
    ,cardinality CHAR(2)
    ,usetype CHAR(2)
    ,tabalias CHAR(64)
    ,levelname CHAR(64)
    ,remarks CHAR(144)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  syssvwjoins
    (
    svwid NUMERIC(10)
    tabalias CHAR(64)
    ,jcolseq NUMERIC(5)
    ,mastercol CHAR(64)
    ,detailcol1 CHAR(64)
    ,detailcol2 CHAR(64)
    ,joinoperator CHAR(4)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  syssvwaliases
    (
    svwid NUMERIC(10)
    tabalias CHAR(64)
    ,colseq NUMERIC(10)
    ,colname CHAR(64)
    ,colalias CHAR(64)
    ,label CHAR(64)
    ,title CHAR(64)
    ,flag NUMERIC(5)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  syssvworder
    (
    svwid NUMERIC(10)
    seqno NUMERIC(5)
    ,colalias CHAR(64)
    ,sorttype CHAR(2)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  syssvwauth
    (
    svwid NUMERIC(10)
    username CHAR(64)
    ,svwauth CHAR(16)
    ,rowlimit NUMERIC(10)
    ,readlimit NUMERIC(10)
    ,readsperrowlimit FLOAT
    ,elapsedtimelimit NUMERIC(10)
    ,isolationmode NUMERIC(5)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  syssvwformats
    (
    svwid NUMERIC(10)
    colalias CHAR(64)
    ,priority NUMERIC(5)
    ,typeface CHAR(128)
    ,fontsize NUMERIC(5)
    ,fontstyle NUMERIC(5)
    ,fontcolor NUMERIC(10)
    ,aidfa CHAR(60)
    ,formatmask CHAR(512)
    ,format4gl CHAR(256)
    ,align CHAR(2)
    ,case_cdc CHAR(2)
    ,ruletype CHAR(2)
    ,checktext CHAR(512)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  syssvwinput
    (
    svwid NUMERIC(10)
    colalias CHAR(64)
    ,attrname CHAR(20)
    ,attrval CHAR(256)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  syssvwinclude
    (
    svwid NUMERIC(10)
    colalias CHAR(64)
    ,priority NUMERIC(5)
    ,extvalue CHAR(128)
    ,intvalue CHAR(128)
    ,range CHAR(2)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  icdtfee
    (
    acc_no NUMERIC(10) NOT NULL
    each_dat DATE NOT NULL
    ,amt_gl NUMERIC(5) NOT NULL
    ,amt_self NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  sysulist
    (
    username CHAR(64)
    svagrantor CHAR(64)
    ,remarks CHAR(128)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  rhexedsc
    (
    job_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,visit_no NUMERIC(11,0)
    ,trp_dat DATE NOT NULL
    ,api_hm NUMERIC(5) NOT NULL
    ,cki_hm NUMERIC(5) NOT NULL
    ,charg_no NUMERIC(10) NOT NULL
    ,addr CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  xrbordat
    (
    apl_no NUMERIC(10)  NOT NULL
    frm_sys CHAR(4)  NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,bor_rsn CHAR(2)  NOT NULL
    ,bor_apl NUMERIC(5) NOT NULL
    ,bor_man NUMERIC(5) NOT NULL
    ,bor_psn NUMERIC(5) NOT NULL
    ,bor_dat DATE NOT NULL
    ,bor_hm NUMERIC(5) NOT NULL
    ,ret_man NUMERIC(5) NOT NULL
    ,ret_psn NUMERIC(5) NOT NULL
    ,ret_dat DATE NOT NULL
    ,ret_hm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  xrfilmst
    (
    chart NUMERIC(10) NOT NULL
    pos CHAR(8)  NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,cnt NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  nhhicicn
    (
    nh_cod CHAR(24)  NOT NULL
    c_e CHAR(2)  NOT NULL
    ,fil_1 CHAR(2)  NOT NULL
    ,nam CHAR(100)  NOT NULL
    ,unit CHAR(8)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  rhexeitm
    (
    job_no NUMERIC(10) NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,pos CHAR(6)  NOT NULL
    ,trp_man NUMERIC(5) NOT NULL
    ,result CHAR(2)  NOT NULL
    ,trp_itm1 CHAR(6)  NOT NULL
    ,trp_hm_f1 NUMERIC(5) NOT NULL
    ,trp_hm_t1 NUMERIC(5) NOT NULL
    ,das_no1 NUMERIC(5) NOT NULL
    ,trp_itm2 CHAR(6)  NOT NULL
    ,trp_hm_f2 NUMERIC(5) NOT NULL
    ,trp_hm_t2 NUMERIC(5) NOT NULL
    ,das_no2 NUMERIC(5) NOT NULL
    ,trp_itm3 CHAR(6)  NOT NULL
    ,trp_hm_f3 NUMERIC(5) NOT NULL
    ,trp_hm_t3 NUMERIC(5) NOT NULL
    ,das_no3 NUMERIC(5) NOT NULL
    ,trp_itm4 CHAR(6)  NOT NULL
    ,trp_hm_f4 NUMERIC(5) NOT NULL
    ,trp_hm_t4 NUMERIC(5) NOT NULL
    ,das_no4 NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mcconrec
    (
    chart NUMERIC(10) NOT NULL
    visit_no NUMERIC(11,0)
    ,dsc1 VARCHAR(1020)
    ,dsc2 VARCHAR(1020)
    ,dsc3 VARCHAR(1020)
    ,dsc4 VARCHAR(1020)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,visit_no)
);



CREATE TABLE  stcgst
    (
    charg_cod CHAR(14)  NOT NULL
    stock_cod CHAR(14)  NOT NULL
    ,ratio_c_s NUMERIC(5,1)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  xritem
    (
    ord_no NUMERIC(10) NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,dup_no NUMERIC(5) NOT NULL
    ,stock_cod CHAR(14)  NOT NULL
    ,def_qty NUMERIC(5) NOT NULL
    ,dis_qty_m NUMERIC(5) NOT NULL
    ,dis_qty_h NUMERIC(5) NOT NULL
    ,dis_qty_p NUMERIC(5) NOT NULL
    ,dis_qty_z NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  astbd
    (
    ast_no NUMERIC(10) NOT NULL
    tc1 CHAR(2)
    ,tc2 CHAR(2)
    ,td DATE
    ,nam_f VARCHAR(120)
    ,nam_a CHAR(12)
    ,cnt_unit CHAR(8)
    ,brand CHAR(20)
    ,mdl_siz CHAR(32)
    ,s_no NUMERIC(10)
    ,manu_no NUMERIC(5)
    ,sup_no NUMERIC(5)
    ,price1 NUMERIC(10)
    ,price2 NUMERIC(10)
    ,vlu NUMERIC(10)
    ,in_dat DATE
    ,lbl_loc NUMERIC(5)
    ,use_dpt NUMERIC(5)
    ,ast_ppy CHAR(2)
    ,hdl_man NUMERIC(5)
    ,loc_no CHAR(12)
    ,pos CHAR(8)
    ,nhd_typ CHAR(12)
    ,bas_typ CHAR(18)
    ,loc_typ NUMERIC(5)
    ,typ_1 CHAR(2)
    ,typ_2 CHAR(2)
    ,mtn CHAR(2)
    ,ast_old CHAR(20)
    ,rtp NUMERIC(5)
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  asacsitm
    (
    ast_no NUMERIC(10)
    acs_seq NUMERIC(5)
    ,acs_nam VARCHAR(120)
    ,cnt_unit CHAR(8)
    ,mdl_siz CHAR(32)
    ,price1 NUMERIC(10)
    ,price2 NUMERIC(10)
    ,vlu NUMERIC(10)
    ,acs_typ CHAR(2)
    ,qty NUMERIC(5)
    ,hdl_man NUMERIC(5)
    ,loc_no CHAR(12)
    ,pos CHAR(8)
    ,rtp NUMERIC(5)
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  asscdnam
    (
    ast_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5)
    ,nam VARCHAR(160)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mooprcon
    (
    division NUMERIC(5) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,opr_cnam CHAR(80)  NOT NULL
    ,opr_enam CHAR(80)  NOT NULL
    ,icd_cod CHAR(12)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mdvoc
    (
    own_no NUMERIC(5) NOT NULL
    map_no NUMERIC(5) NOT NULL
    ,voc_typ CHAR(4)  NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,coment VARCHAR(240)
    ,txt1 VARCHAR(1020)
    ,txt2 VARCHAR(1020)
    ,txt3 VARCHAR(1020)
    ,txt4 VARCHAR(1020)
    ,txt5 VARCHAR(1020)
    ,txt6 VARCHAR(1020)
    ,txt7 VARCHAR(1020)
    ,txt8 VARCHAR(1020)
    ,rtp NUMERIC(5)
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  rgovrl
    (
    room NUMERIC(5) NOT NULL
    loc CHAR(60)  NOT NULL
    ,loc_a CHAR(60)
    ,prn CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  modoc
    (
    ord_no NUMERIC(10) NOT NULL
    frm_sys CHAR(4)  NOT NULL
    ,dsc text NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mdvoc1
    (
    own_no NUMERIC(5) NOT NULL
    map_no NUMERIC(5) NOT NULL
    ,voc_typ CHAR(4)  NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,coment VARCHAR(240)
    ,txt text
    ,rtp NUMERIC(5)
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ucterml
    (
    loc_id NUMERIC(5) NOT NULL
    loc_nam CHAR(32)  NOT NULL
    ,device_id CHAR(24)  NOT NULL
    ,print_id CHAR(24)  NOT NULL
    ,term_typ CHAR(2)  NOT NULL
    ,fil_1 CHAR(2)  NOT NULL
    ,func_no CHAR(8)  NOT NULL
    ,prog_nam CHAR(16)  NOT NULL
    ,cnt NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ucolfuncold
    (
    func_no CHAR(8)  NOT NULL
    prog_nam CHAR(20)  NOT NULL
    ,prog_desc CHAR(56)  NOT NULL
    ,main_prog_nam CHAR(20)  NOT NULL
    ,ver_no CHAR(12)  NOT NULL
    ,ver_dat DATE NOT NULL
    ,prog_typ CHAR(2)  NOT NULL
    ,mtn_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  paucdata
    (
    pa_typ CHAR(2)
    pa_no NUMERIC(10) NOT NULL
    ,id_no CHAR(20)  NOT NULL
    ,nam CHAR(20)  NOT NULL
    ,birthday DATE NOT NULL
    ,rep_dat DATE NOT NULL
    ,rep_cod CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  sttrms
    (
    loc NUMERIC(5) NOT NULL
    stk_cod CHAR(14)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ositem
    (
    order_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,dc CHAR(2)  NOT NULL
    ,item_cod CHAR(14)  NOT NULL
    ,item_mark CHAR(2)  NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,usag CHAR(40)  NOT NULL
    ,tot_qty CHAR(10)  NOT NULL
    ,self_qty CHAR(10)  NOT NULL
    ,emg CHAR(2)  NOT NULL
    ,self CHAR(2)  NOT NULL
    ,chg CHAR(2)  NOT NULL
    ,prn_map CHAR(2)  NOT NULL
    ,ppf_no NUMERIC(5) NOT NULL
    ,prm_no NUMERIC(10) NOT NULL
    ,map_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  nsipcl
    (
    chart NUMERIC(10) NOT NULL
    typ CHAR(2)  NOT NULL
    ,ass_dat DATE NOT NULL
    ,ass_hm NUMERIC(5) NOT NULL
    ,grd NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  nsphw
    (
    chart NUMERIC(10) NOT NULL
    msr_dat DATE NOT NULL
    ,msr_hm NUMERIC(5) NOT NULL
    ,hgh NUMERIC(4,1)  NOT NULL
    ,wgh NUMERIC(4,1)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  nspnvs
    (
    chart NUMERIC(10) NOT NULL
    msr_dat DATE NOT NULL
    ,msr_hm NUMERIC(5) NOT NULL
    ,tpr NUMERIC(4,1)  NOT NULL
    ,mab NUMERIC(5) NOT NULL
    ,hrt NUMERIC(5) NOT NULL
    ,rpr NUMERIC(5) NOT NULL
    ,prs_h NUMERIC(5) NOT NULL
    ,prs_l NUMERIC(5) NOT NULL
    ,drh CHAR(2)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mrpar
    (
    chart NUMERIC(10) NOT NULL
    alg VARCHAR(1020)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  sepbd
    (
    sep_no NUMERIC(10)  NOT NULL
    hospital_no NUMERIC(10,0)  NOT NULL
    ,old_chart CHAR(16)  NOT NULL
    ,nam CHAR(24)  NOT NULL
    ,sex CHAR(2)  NOT NULL
    ,born_yy NUMERIC(5) NOT NULL
    ,born_mmdd NUMERIC(5) NOT NULL
    ,id_no CHAR(20)  NOT NULL
    ,lab_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  seitem
    (
    sep_no NUMERIC(10) NOT NULL
    tc CHAR(2)  NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,amt NUMERIC(10) NOT NULL
    ,rpt text
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  mrmrdir
    (
    chart NUMERIC(10) NOT NULL
    dcg_dat DATE NOT NULL
    ,dcg_hm NUMERIC(5)
    ,lst_psn NUMERIC(5) NOT NULL
    ,lst_dat DATE NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ofjbd
    (
    dpt_no NUMERIC(5) NOT NULL
    job_no NUMERIC(5) NOT NULL
    ,nam VARCHAR(160)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,pns NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ofjobdsp
    (
    dpt_no NUMERIC(5) NOT NULL
    job_no NUMERIC(5) NOT NULL
    ,dat DATE NOT NULL
    ,sft CHAR(2)  NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  tgavou
    (
    vou_dat DATE NOT NULL
    sub_h_no CHAR(2)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,item_no NUMERIC(5) NOT NULL
    ,enter_dat DATE NOT NULL
    ,remark NUMERIC(5) NOT NULL
    ,fil_01 CHAR(8)  NOT NULL
    ,acc_cod CHAR(12)  NOT NULL
    ,amt NUMERIC(10) NOT NULL
    ,rc NUMERIC(5) NOT NULL
    ,outlf_cod NUMERIC(5) NOT NULL
    ,outlf_desc VARCHAR( 100 )  NOT NULL
    ,project_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  seril
    (
    num NUMERIC(10)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  moapdn
    (
    chart NUMERIC(10) NOT NULL
    visit_no NUMERIC(10) NOT NULL
    ,typ NUMERIC(10) NOT NULL
    ,txt text NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mrppsc
    (
    chart NUMERIC(10) NOT NULL
    sck_dat DATE NOT NULL
    ,visit_no NUMERIC(11,0)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  dgfmindx
    (
    nam CHAR(80)  NOT NULL
    pc_12 CHAR(4)  NOT NULL
    ,pc_3 CHAR(2)  NOT NULL
    ,pc_sub1 CHAR(2)  NOT NULL
    ,pc_sub2 CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,seq NUMERIC(5) NOT NULL
    ,pag_no NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  dgfmproc
    (
    pc_12 CHAR(4)  NOT NULL
    pc_3 CHAR(2)  NOT NULL
    ,pc_sub1 CHAR(2)  NOT NULL
    ,pc_sub2 CHAR(2)  NOT NULL
    ,nam_s CHAR(80)  NOT NULL
    ,drug_cod CHAR(10)  NOT NULL
    ,main_pc_cod CHAR(10)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  pmmember
    (
    nam CHAR(24)  NOT NULL
    sex CHAR(2)  NOT NULL
    ,id_no CHAR(20)
    ,pt_typ CHAR(4)  NOT NULL
    ,born_dat DATE NOT NULL
    ,tel_h NUMERIC(10) NOT NULL
    ,tel_o NUMERIC(10) NOT NULL
    ,reg_no NUMERIC(10) NOT NULL
    ,adrs VARCHAR(136)  NOT NULL
    ,act_dat DATE NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  nhtncic
    (
    itm_cod CHAR(14)  NOT NULL
    dat_f DATE NOT NULL
    ,dat_t DATE NOT NULL
    ,nhi_cod CHAR(24)  NOT NULL
    ,nhi_up NUMERIC(9,2)  NOT NULL
    ,qty NUMERIC(6,1)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  dcicdcn1
    (
    icd_cod CHAR(12)  NOT NULL
    nhi_cod CHAR(12)  NOT NULL
    ,drg_cod CHAR(10)  NOT NULL
    ,qip_drg CHAR(6)
    ,nam_e VARCHAR(1020)  NOT NULL
    ,icd_typ NUMERIC(5) NOT NULL
    ,sru_mrk CHAR(2)  NOT NULL
    ,crn_mrk CHAR(2)  NOT NULL
    ,crn_typ NUMERIC(5) NOT NULL
    ,con_mrk CHAR(2)  NOT NULL
    ,con_typ NUMERIC(5) NOT NULL
    ,sex_lmt CHAR(2)  NOT NULL
    ,dag_lmt CHAR(2)  NOT NULL
    ,fil_1 CHAR(2)  NOT NULL
    ,min_age NUMERIC(5) NOT NULL
    ,max_age NUMERIC(5) NOT NULL
    ,std_days NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  dcicddsc
    (
    icd_cod CHAR(12)  NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,dsc VARCHAR(1000)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  zzrrcn
    (
    region_no NUMERIC(10) NOT NULL
    region_nam CHAR(40)  NOT NULL
    ,net_no NUMERIC(5) NOT NULL
    ,zip NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  nsiprdl
    (
    tp NUMERIC(5) NOT NULL
    td DATE NOT NULL
    ,thm NUMERIC(5) NOT NULL
    ,acc_no NUMERIC(10) NOT NULL
    ,dct_r NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  nsiprd
    (
    acc_no NUMERIC(10) NOT NULL
    dct_r NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  rgovt
    (
    wek_day CHAR(2)  NOT NULL
    sft CHAR(2)  NOT NULL
    ,room NUMERIC(5) NOT NULL
    ,dct_no NUMERIC(5) NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,stp CHAR(2)  NOT NULL
    ,chg_typ CHAR(2)  NOT NULL
    ,lmt_typ CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,lmt_no NUMERIC(5) NOT NULL
    ,fvt_lmt NUMERIC(5)
    ,app_sat NUMERIC(5) NOT NULL
    ,fvt_sat NUMERIC(5) NOT NULL
    ,fvt_stp NUMERIC(5) NOT NULL
    ,vip_sat NUMERIC(5) NOT NULL
    ,vip_stp NUMERIC(5) NOT NULL
    ,sat_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  rgctrl
    (
    visit_dat DATE NOT NULL
    sft CHAR(2)  NOT NULL
    ,room NUMERIC(5) NOT NULL
    ,dct_no NUMERIC(5) NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,stp CHAR(2)  NOT NULL
    ,chg_typ CHAR(2)  NOT NULL
    ,lmt_typ CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,lim_no NUMERIC(5) NOT NULL
    ,fvt_lmt NUMERIC(5)
    ,cur_cnt NUMERIC(5) NOT NULL
    ,rht_no NUMERIC(5) NOT NULL
    ,app_sat NUMERIC(5) NOT NULL
    ,app_no NUMERIC(5) NOT NULL
    ,fvt_sat NUMERIC(5) NOT NULL
    ,fvt_stp NUMERIC(5) NOT NULL
    ,fvt_no NUMERIC(5) NOT NULL
    ,vip_sat NUMERIC(5) NOT NULL
    ,vip_no NUMERIC(5) NOT NULL
    ,vip_stp NUMERIC(5) NOT NULL
    ,lon_no NUMERIC(5) NOT NULL
    ,sat_no NUMERIC(5) NOT NULL
    ,fil_1 CHAR(2)  NOT NULL
    ,fil_2 CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cpndsp
    (
    drg_cod CHAR(10)  NOT NULL
    eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,itm_cod CHAR(14)  NOT NULL
    ,atb CHAR(2)  NOT NULL
    ,itm_1st CHAR(14)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  rgnofee
    (
    visit_dat DATE NOT NULL
    chart NUMERIC(10) NOT NULL
    ,nam CHAR(24)  NOT NULL
    ,dummy1 CHAR(8)  NOT NULL
    ,dummy2 CHAR(8)  NOT NULL
    ,dummy3 CHAR(8)  NOT NULL
    ,amt NUMERIC(10) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  osinst
    (
    mapno NUMERIC(5) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,nam CHAR(40)  NOT NULL
    ,gl_inst CHAR(108)  NOT NULL
    ,gen_inst CHAR(108)  NOT NULL
    ,color CHAR(2)  NOT NULL
    ,prt_no NUMERIC(5) NOT NULL
    ,soa CHAR(2)  NOT NULL
    ,coment VARCHAR(1020)  NOT NULL
    ,sp_div CHAR(8)
    ,sp_rpt CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mrcharbr
    (
    borrower NUMERIC(5) NOT NULL
    bor_dat DATE NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,vol_no CHAR(4)  NOT NULL
    ,bor_obj CHAR(2)  NOT NULL
    ,ret_mark CHAR(2)  NOT NULL
    ,ret_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  gactoa
    (
    acc_cod CHAR(12)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,pd_typ CHAR(2)  NOT NULL
    ,nh_typ CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mrpbd3
    (
    chart NUMERIC(10) NOT NULL
    nam CHAR(24)  NOT NULL
    ,born_yy NUMERIC(5) NOT NULL
    ,born_mmdd NUMERIC(5) NOT NULL
    ,sex CHAR(2)  NOT NULL
    ,l_mark CHAR(2)  NOT NULL
    ,c_r_cod NUMERIC(10) NOT NULL
    ,c_r_adrs CHAR(68)  NOT NULL
    ,domicile CHAR(16)  NOT NULL
    ,marr CHAR(2)  NOT NULL
    ,educ CHAR(2)  NOT NULL
    ,profes CHAR(6)  NOT NULL
    ,fil1 CHAR(2)  NOT NULL
    ,id_no CHAR(20)  NOT NULL
    ,tel_h NUMERIC(10) NOT NULL
    ,tel_o NUMERIC(10) NOT NULL
    ,blood_typ CHAR(4)  NOT NULL
    ,gl_typ CHAR(4)  NOT NULL
    ,pt_typ CHAR(4)  NOT NULL
    ,sp_typ CHAR(4)  NOT NULL
    ,sw_typ CHAR(4)  NOT NULL
    ,insured NUMERIC(10) NOT NULL
    ,cer_no NUMERIC(10) NOT NULL
    ,loc_o CHAR(2)  NOT NULL
    ,loc_i CHAR(2)  NOT NULL
    ,nv_times NUMERIC(5) NOT NULL
    ,bad_amt NUMERIC(10) NOT NULL
    ,no_good CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mrpbd4
    (
    chart NUMERIC(10) NOT NULL
    l_r_cod NUMERIC(10) NOT NULL
    ,l_r_adrs CHAR(68)  NOT NULL
    ,l_typ CHAR(4)  NOT NULL
    ,l_insured NUMERIC(10) NOT NULL
    ,husband_nam CHAR(16)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  rhtibd
    (
    trp_itm CHAR(6)  NOT NULL
    nam_f CHAR(90)  NOT NULL
    ,nam_a CHAR(16)  NOT NULL
    ,chg_typ CHAR(2)  NOT NULL
    ,trp_typ CHAR(2)  NOT NULL
    ,dur_tim NUMERIC(5) NOT NULL
    ,ast_typ NUMERIC(5) NOT NULL
    ,nhi_cod CHAR(10)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  rgmdcn
    (
    division NUMERIC(5) NOT NULL
    nam_a CHAR(8)  NOT NULL
    ,nam_f CHAR(40)  NOT NULL
    ,nam_e CHAR(80)
    ,dpt_no NUMERIC(5) NOT NULL
    ,div_pho NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  ucclicfg
    (
    loc_id CHAR(12)  NOT NULL
    cmp_nam CHAR(24)  NOT NULL
    ,loc_dsc CHAR(60)
    ,loc_no NUMERIC(5) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,dep_no NUMERIC(5) NOT NULL
    ,mac_adr CHAR(60)  NOT NULL
    ,tcp_adr CHAR(60)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,tel_fun CHAR(8)  NOT NULL
    ,ctl_flg CHAR(20)  NOT NULL
    ,lgi_lvl CHAR(2)
    ,scr_ctl CHAR(2)
    ,err_cod NUMERIC(5)
    ,tst_lvl CHAR(2)
    ,lpt_sts CHAR(2)  NOT NULL
    ,def_prt CHAR(20)  NOT NULL
    ,not_prt CHAR(20)  NOT NULL
    ,trd_prt CHAR(20)
    ,mem_txt VARCHAR(1020)  NOT NULL
    ,log_tim TIMESTAMP NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (loc_id)
);



CREATE TABLE  ucctrl
    (
    emp_no NUMERIC(5) NOT NULL
    dbs_pri CHAR(20)  NOT NULL
    ,hot_f1 CHAR(8)  NOT NULL
    ,hot_f2 CHAR(8)  NOT NULL
    ,hot_f3 CHAR(8)  NOT NULL
    ,hot_f4 CHAR(8)  NOT NULL
    ,hot_f5 CHAR(8)  NOT NULL
    ,hot_f6 CHAR(8)  NOT NULL
    ,hot_f7 CHAR(8)  NOT NULL
    ,hot_f8 CHAR(8)  NOT NULL
    ,hot_f9 CHAR(8)  NOT NULL
    ,hot_f10 CHAR(8)  NOT NULL
    ,bot_fun CHAR(8)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,loc CHAR(12)  NOT NULL
    ,ctl_flg CHAR(40)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (emp_no)
);



CREATE TABLE  bmfftran
    (
    acc_no NUMERIC(10) NOT NULL
    f_dat DATE NOT NULL
    ,f_hm NUMERIC(5) NOT NULL
    ,t_dat DATE NOT NULL
    ,t_hm NUMERIC(5) NOT NULL
    ,room CHAR(8)
    ,bed CHAR(4)  NOT NULL
    ,class CHAR(2)  NOT NULL
    ,rank CHAR(2)  NOT NULL
    ,care_level CHAR(10)
    ,a_dr1 NUMERIC(5) NOT NULL
    ,a_dr2 NUMERIC(5) NOT NULL
    ,a_dr3 NUMERIC(5) NOT NULL
    ,a_dr4 NUMERIC(5) NOT NULL
    ,division NUMERIC(5) NOT NULL
    ,a_dr1_mod CHAR(2)  NOT NULL
    ,a_dr2_mod CHAR(2)  NOT NULL
    ,a_dr3_mod CHAR(2)  NOT NULL
    ,a_dr4_mod CHAR(2)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,leav CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  bmfflog
    (
    acc_no NUMERIC(10) NOT NULL
    f_dat DATE NOT NULL
    ,f_hm NUMERIC(5) NOT NULL
    ,t_dat DATE NOT NULL
    ,t_hm NUMERIC(5) NOT NULL
    ,room CHAR(8)
    ,bed CHAR(4)  NOT NULL
    ,class CHAR(2)  NOT NULL
    ,rank CHAR(2)  NOT NULL
    ,care_level CHAR(10)
    ,a_dr1 NUMERIC(5) NOT NULL
    ,a_dr2 NUMERIC(5) NOT NULL
    ,a_dr3 NUMERIC(5) NOT NULL
    ,a_dr4 NUMERIC(5) NOT NULL
    ,division NUMERIC(5) NOT NULL
    ,a_dr1_mod CHAR(2)  NOT NULL
    ,a_dr2_mod CHAR(2)  NOT NULL
    ,a_dr3_mod CHAR(2)  NOT NULL
    ,a_dr4_mod CHAR(2)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,leav CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  mrvcsn
    (
    vsn NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,visit_no NUMERIC(11,0)
    ,card_yy NUMERIC(11,0)
    ,icc_no CHAR(24)
    ,vsn_nh CHAR(8)  NOT NULL
    ,cas_typ CHAR(4)  NOT NULL
    ,sick_typ CHAR(2)  NOT NULL
    ,pay_typ CHAR(6)  NOT NULL
    ,cg_rtp NUMERIC(5) NOT NULL
    ,cg_rtd DATE NOT NULL
    ,cg_rthm NUMERIC(5) NOT NULL
    ,chk_rtp NUMERIC(5) NOT NULL
    ,chk_rtd NUMERIC(10) NOT NULL
    ,seq_no_nh NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn)
);



CREATE TABLE  modsc
    (
    ord_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,map_no NUMERIC(5) NOT NULL
    ,frm_no NUMERIC(10)
    ,div_no NUMERIC(5) NOT NULL
    ,ord_man NUMERIC(5) NOT NULL
    ,ord_dat DATE
    ,ord_hm NUMERIC(5)
    ,ord_loc NUMERIC(5)
    ,tsc CHAR(2)
    ,usg VARCHAR(72)
    ,sts CHAR(2)
    ,exp_dat DATE
    ,pre_dat DATE
    ,pre_hm NUMERIC(5)
    ,job_typ CHAR(4)
    ,job_no NUMERIC(10)
    ,exe_man NUMERIC(5)
    ,exe_dat DATE
    ,exe_hm NUMERIC(5)
    ,exe_wrd NUMERIC(5)
    ,exe_loc NUMERIC(5)
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ord_no)
);



CREATE TABLE  motxt
    (
    ord_no NUMERIC(10) NOT NULL
    chart NUMERIC(10) NOT NULL
    ,sub VARCHAR(1020)
    ,obj VARCHAR(1020)
    ,ass VARCHAR(1020)
    ,cmt VARCHAR(1020)
    ,rpt_man NUMERIC(5)
    ,rpt_dat DATE
    ,rpt_hm NUMERIC(5)
    ,rpt_typ CHAR(8)
    ,rpt text
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ord_no)
);



CREATE TABLE  mopdd
    (
    vsn NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,eff_man NUMERIC(5) NOT NULL
    ,eff_dat DATE
    ,icd_cod CHAR(24)  NOT NULL
    ,icd_dsc VARCHAR(1020)  NOT NULL
    ,stp_man NUMERIC(5)
    ,stp_dat DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn,seq_no)
);



CREATE TABLE  mower
    (
    map_no NUMERIC(5) NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  mopar
    (
    evt_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,act_typ CHAR(2)  NOT NULL
    ,sts CHAR(2)
    ,act_man NUMERIC(5) NOT NULL
    ,act_dat DATE
    ,act_hm NUMERIC(5)
    ,act_loc NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  monot3
    (
    not_no NUMERIC(10)
    vsn NUMERIC(10) NOT NULL
    ,typ NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5)
    ,txt text
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  moinst
    (
    map_no NUMERIC(5) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,nam CHAR(24)  NOT NULL
    ,tit CHAR(40)  NOT NULL
    ,nhi_inst CHAR(108)  NOT NULL
    ,gen_inst CHAR(108)  NOT NULL
    ,prn_color CHAR(2)  NOT NULL
    ,pag_cnt NUMERIC(5) NOT NULL
    ,soa CHAR(2)  NOT NULL
    ,cmt text
    ,prn_typ CHAR(8)
    ,prn_nam CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (map_no,seq_no)
);



CREATE TABLE  nsntwdh
    (
    rom CHAR(8)
    bed CHAR(4)  NOT NULL
    ,tim CHAR(2)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tem CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rom,bed,tim,eff_dat)
);



CREATE TABLE  moeps
    (
    chg_cod CHAR(14)  NOT NULL
    eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,nam VARCHAR(180)  NOT NULL
    ,map_no NUMERIC(5) NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,dos_qty CHAR(10)  NOT NULL
    ,dos_unt CHAR(8)  NOT NULL
    ,sal_unt CHAR(8)  NOT NULL
    ,dsr FLOAT
    ,usg VARCHAR(72)
    ,use_way CHAR(8)  NOT NULL
    ,ctl_dug CHAR(2)  NOT NULL
    ,opd_lmt NUMERIC(5) NOT NULL
    ,ipd_lmt NUMERIC(5) NOT NULL
    ,day_lmt NUMERIC(5) NOT NULL
    ,nhi_ctl CHAR(2)  NOT NULL
    ,soa CHAR(2)  NOT NULL
    ,adv VARCHAR(1020)
    ,int_pnt CHAR(2)  NOT NULL
    ,use_pnt CHAR(2)  NOT NULL
    ,div_pnt CHAR(2)  NOT NULL
    ,dct_pnt CHAR(2)  NOT NULL
    ,cmt_pnt CHAR(2)  NOT NULL
    ,ord_own CHAR(2)  NOT NULL
    ,grp_itm CHAR(2)  NOT NULL
    ,hgh_upp CHAR(2)  NOT NULL
    ,gen_cod NUMERIC(5) NOT NULL
    ,nhi_cod NUMERIC(5) NOT NULL
    ,emg_rat NUMERIC(4,2)  NOT NULL
    ,gen_dis CHAR(2)  NOT NULL
    ,nhi_dis CHAR(2)  NOT NULL
    ,gen_upp NUMERIC(9,2)  NOT NULL
    ,nhi_upp NUMERIC(9,2)  NOT NULL
    ,nhi_rat NUMERIC(9,2)  NOT NULL
    ,rud_mrk CHAR(2)  NOT NULL
    ,odm_qty NUMERIC(5) NOT NULL
    ,nod_mrk CHAR(2)  NOT NULL
    ,fil_1 CHAR(2)  NOT NULL
    ,fil_2 CHAR(2)  NOT NULL
    ,fil_3 CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chg_cod,eff_tim)
);



CREATE TABLE  movoc
    (
    own_no NUMERIC(10) NOT NULL
    map_no NUMERIC(5) NOT NULL
    ,voc_typ CHAR(24)
    ,seq_no NUMERIC(5) NOT NULL
    ,cmt VARCHAR(240)
    ,wod VARCHAR(1020)
    ,txt text
    ,rtp NUMERIC(10)
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (own_no,map_no,voc_typ,seq_no)
);



CREATE TABLE  udusgtim
    (
    usg_cod CHAR(12)  NOT NULL
    div_ped CHAR(2)  NOT NULL
    ,dap CHAR(8)  NOT NULL
    ,tim_i CHAR(96)  NOT NULL
    ,tim_t CHAR(96)  NOT NULL
    ,tim_o CHAR(96)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (usg_cod,div_ped,dap)
);



CREATE TABLE  nsntwd
    (
    dat DATE NOT NULL
    rom CHAR(8)
    ,bed CHAR(4)  NOT NULL
    ,wad CHAR(6)  NOT NULL
    ,tem_d CHAR(2)  NOT NULL
    ,tem_e CHAR(2)  NOT NULL
    ,tem_n CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dat,rom,bed)
);



CREATE TABLE  dginter
    (
    srv_cod CHAR(10)  NOT NULL
    clt_cod CHAR(10)  NOT NULL
    ,sig_rat CHAR(2)  NOT NULL
    ,eff_rat CHAR(2)  NOT NULL
    ,ost CHAR(2)  NOT NULL
    ,sev_rat CHAR(2)  NOT NULL
    ,src CHAR(2)  NOT NULL
    ,ref_doc CHAR(2)  NOT NULL
    ,doc_rec CHAR(2)  NOT NULL
    ,int_typ CHAR(4)  NOT NULL
    ,mec_lnk NUMERIC(5) NOT NULL
    ,eff_lnk NUMERIC(5) NOT NULL
    ,sug_lnk NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (srv_cod,clt_cod)
);



CREATE TABLE  dgintdoc
    (
    int_typ CHAR(4)  NOT NULL
    doc_no NUMERIC(5) NOT NULL
    ,doc text
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (int_typ,doc_no)
);



CREATE TABLE  ucolfunc
    (
    func_no CHAR(8)  NOT NULL
    prog_nam CHAR(40)  NOT NULL
    ,def_par VARCHAR(512)  NOT NULL
    ,prg_pth VARCHAR(512)  NOT NULL
    ,prog_desc VARCHAR(1000)  NOT NULL
    ,mut_run CHAR(2)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,hom_pth VARCHAR(512)
    ,main_prog_nam CHAR(20)  NOT NULL
    ,ver_no CHAR(24)  NOT NULL
    ,ver_dat DATE NOT NULL
    ,prog_typ CHAR(2)  NOT NULL
    ,mtn_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (func_no)
);



CREATE TABLE  pstitlcn
    (
    titl CHAR(4)  NOT NULL
    nam CHAR(40)  NOT NULL
    ,edu_pnt NUMERIC(5) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  bmptbd
    (
    acc_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,visit_no NUMERIC(11,0)
    ,baby_mark CHAR(2)  NOT NULL
    ,admit_dat DATE NOT NULL
    ,admit_hm NUMERIC(5) NOT NULL
    ,gl_typ CHAR(4)  NOT NULL
    ,pt_typ CHAR(4)  NOT NULL
    ,admit_will CHAR(2)  NOT NULL
    ,admit_window CHAR(2)  NOT NULL
    ,link_acc NUMERIC(11,0)
    ,sign_dr NUMERIC(5) NOT NULL
    ,diag1 CHAR(24)  NOT NULL
    ,diag2 CHAR(24)  NOT NULL
    ,diag3 CHAR(24)  NOT NULL
    ,id_copy CHAR(2)  NOT NULL
    ,medical_sheet CHAR(2)  NOT NULL
    ,room CHAR(8)
    ,bed CHAR(4)  NOT NULL
    ,care_level CHAR(10)
    ,a_dr1 NUMERIC(5) NOT NULL
    ,a_dr2 NUMERIC(5) NOT NULL
    ,a_dr3 NUMERIC(5) NOT NULL
    ,a_dr4 NUMERIC(5) NOT NULL
    ,division NUMERIC(5) NOT NULL
    ,tran_div DATE NOT NULL
    ,a_dr1_mod CHAR(2)  NOT NULL
    ,a_dr2_mod CHAR(2)  NOT NULL
    ,a_dr3_mod CHAR(2)  NOT NULL
    ,a_dr4_mod CHAR(2)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,consent CHAR(2)  NOT NULL
    ,pre_days NUMERIC(5) NOT NULL
    ,ac_pp_amt NUMERIC(10) NOT NULL
    ,acc_amt NUMERIC(10) NOT NULL
    ,spe_tmp_amt NUMERIC(10) NOT NULL
    ,gen_tmp_amt NUMERIC(10) NOT NULL
    ,gl_tmp_amt NUMERIC(10) NOT NULL
    ,credit_typ CHAR(2)  NOT NULL
    ,tp_dat DATE NOT NULL
    ,tp_hm NUMERIC(5) NOT NULL
    ,discha_sts CHAR(4)  NOT NULL
    ,close_acc CHAR(2)  NOT NULL
    ,comp_acc NUMERIC(10) NOT NULL
    ,dsc_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  bmpobd
    (
    chart NUMERIC(10) NOT NULL
    tel_no NUMERIC(10) NOT NULL
    ,pre_dat DATE NOT NULL
    ,adm_win CHAR(2)  NOT NULL
    ,adm_rsn CHAR(2)  NOT NULL
    ,sick_rank CHAR(2)  NOT NULL
    ,bed_class CHAR(2)  NOT NULL
    ,div1_no NUMERIC(5) NOT NULL
    ,div2_no NUMERIC(5) NOT NULL
    ,div3_no NUMERIC(5) NOT NULL
    ,dct1_no NUMERIC(5) NOT NULL
    ,dct2_no NUMERIC(5) NOT NULL
    ,dct3_no NUMERIC(5) NOT NULL
    ,icd1_cod CHAR(24)  NOT NULL
    ,icd2_cod CHAR(24)  NOT NULL
    ,icd3_cod CHAR(24)  NOT NULL
    ,drg_cod CHAR(12)
    ,cmt VARCHAR(1020)  NOT NULL
    ,isolat CHAR(2)  NOT NULL
    ,sts CHAR(4)
    ,admit_dat DATE NOT NULL
    ,flt1 CHAR(2)
    ,flt2 CHAR(2)
    ,flt3 CHAR(2)
    ,flt4 CHAR(2)
    ,vsn NUMERIC(10)
    ,lnk_no NUMERIC(10)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  morprv
    (
    ord_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5)
    ,rpt_tim TIMESTAMP NOT NULL
    ,rpt text
    ,rpt_typ CHAR(8)
    ,rpt_man NUMERIC(10)
    ,mdf_typ CHAR(6)
    ,oth_rsn VARCHAR(200)
    ,rtp NUMERIC(10)
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ord_no,rpt_tim)
);



CREATE TABLE  moitmh
    (
    dit_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,dos_qty CHAR(10)
    ,usg VARCHAR(72)
    ,itm1 CHAR(8)
    ,itm2 CHAR(8)
    ,itm3 CHAR(8)
    ,itm4 CHAR(8)
    ,nhi_qty NUMERIC(5,1)
    ,slf_qty NUMERIC(5,1)
    ,mrk CHAR(2)
    ,adv VARCHAR(1020)
    ,atb CHAR(2)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dit_no,seq_no)
);



CREATE TABLE  mosoah
    (
    dit_no NUMERIC(10)  NOT NULL
    own_no CHAR(10)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,nam CHAR(200)  NOT NULL
    ,itm_no NUMERIC(10)
    ,seq_no NUMERIC(5)
    ,sub VARCHAR(1020)
    ,obj VARCHAR(1020)
    ,ass VARCHAR(1020)
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dit_no)
);



CREATE TABLE  nsidpr
    (
    chart NUMERIC(10) NOT NULL
    typ CHAR(12)  NOT NULL
    ,sam_dat DATE NOT NULL
    ,sam CHAR(14)  NOT NULL
    ,cnt NUMERIC(5) NOT NULL
    ,pmg_dat DATE NOT NULL
    ,pmg_dr NUMERIC(5) NOT NULL
    ,rqt_dat DATE NOT NULL
    ,pmg_no CHAR(20)  NOT NULL
    ,rlt CHAR(2)  NOT NULL
    ,cmt VARCHAR(320)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,typ,sam_dat)
);



CREATE TABLE  dcicdkw
    (
    key_word CHAR(40)  NOT NULL
    icd_cod CHAR(12)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (key_word,icd_cod)
);



CREATE TABLE  mrssr
    (
    idn CHAR(20)  NOT NULL
    icd_cod CHAR(24)
    ,i10_cod CHAR(24)
    ,icd_ver CHAR(20)
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,ifq_mrk CHAR(2)
    ,crd_no NUMERIC(11,0)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (idn,icd_cod,i10_cod,eff_dat)
);



CREATE TABLE  cpoidc
    (
    itm_cod CHAR(14)  NOT NULL
    qty NUMERIC(5) NOT NULL
    ,drg_cod CHAR(10)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_cod,qty)
);



CREATE TABLE  nshpbd
    (
    chart NUMERIC(10) NOT NULL
    hdr_dat DATE NOT NULL
    ,epo_dat DATE NOT NULL
    ,hts CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,typ_o CHAR(12)  NOT NULL
    ,wil CHAR(2)  NOT NULL
    ,cur CHAR(2)  NOT NULL
    ,bld_pas CHAR(2)  NOT NULL
    ,qty CHAR(2)  NOT NULL
    ,thm CHAR(2)  NOT NULL
    ,lqd CHAR(2)  NOT NULL
    ,wrk CHAR(2)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,die_rsn CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart)
);



CREATE TABLE  moutt
    (
    usg CHAR(36)  NOT NULL
    map_no NUMERIC(5) NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,tim1 CHAR(96)  NOT NULL
    ,tim2 CHAR(96)  NOT NULL
    ,tim3 CHAR(96)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (usg,map_no,div_no)
);



CREATE TABLE  moexe
    (
    vsn NUMERIC(10) NOT NULL
    chart NUMERIC(10)
    ,chg_cod CHAR(14)  NOT NULL
    ,exe_dat DATE NOT NULL
    ,nhi_qty NUMERIC(5,1)  NOT NULL
    ,slf_qty NUMERIC(5,1)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn,chg_cod,exe_dat)
);



CREATE TABLE  npndbd
    (
    nrs_dag CHAR(12)  NOT NULL
    tsc CHAR(2)
    ,nam VARCHAR(1020)  NOT NULL
    ,car_tim1 NUMERIC(5) NOT NULL
    ,car_tim2 NUMERIC(5) NOT NULL
    ,car_tim3 NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (nrs_dag)
);



CREATE TABLE  npntcn
    (
    nrs_cod NUMERIC(10) NOT NULL
    tsc CHAR(2)
    ,nam VARCHAR(1020)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (nrs_cod)
);



CREATE TABLE  npdsc
    (
    npn NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,nrs_dag CHAR(12)  NOT NULL
    ,tsc CHAR(2)
    ,ord_man NUMERIC(5) NOT NULL
    ,ord_dat DATE
    ,eff_dat DATE NOT NULL
    ,stp_man NUMERIC(5) NOT NULL
    ,stp_dat DATE
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (npn)
);



CREATE TABLE  npitm
    (
    npn NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,nrs_cod NUMERIC(10) NOT NULL
    ,eff_man NUMERIC(5) NOT NULL
    ,eff_dat DATE NOT NULL
    ,exe_man NUMERIC(5)
    ,exe_dat DATE
    ,exe_sts CHAR(2)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (npn,seq_no)
);



CREATE TABLE  npddi
    (
    nrs_dag CHAR(12)  NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,nrs_cod NUMERIC(10) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (nrs_dag,seq_no)
);



CREATE TABLE  mooso
    (
    vsn NUMERIC(10) NOT NULL
    sub VARCHAR(1020)
    ,obj VARCHAR(1020)
    ,cmt VARCHAR(1020)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn)
);



CREATE TABLE  dgdesc
    (
    drug_cod CHAR(10)  NOT NULL
    tc CHAR(2)  NOT NULL
    ,nam CHAR(80)  NOT NULL
    ,content CHAR(50)  NOT NULL
    ,pcs_self CHAR(2)  NOT NULL
    ,dis CHAR(2)  NOT NULL
    ,ud CHAR(2)  NOT NULL
    ,slot_no NUMERIC(5) NOT NULL
    ,lng_ord CHAR(2)  NOT NULL
    ,laubau CHAR(2)  NOT NULL
    ,sale_typ CHAR(2)  NOT NULL
    ,price_typ CHAR(2)  NOT NULL
    ,sale_unit CHAR(8)  NOT NULL
    ,std_unit CHAR(8)  NOT NULL
    ,sal_std_r NUMERIC(9,4)  NOT NULL
    ,dose_unit CHAR(8)  NOT NULL
    ,use_typ CHAR(4)  NOT NULL
    ,shaking CHAR(2)  NOT NULL
    ,prn CHAR(2)  NOT NULL
    ,eat_typ_1 CHAR(2)  NOT NULL
    ,eat_typ_2 CHAR(2)  NOT NULL
    ,ac_pc CHAR(2)  NOT NULL
    ,m_n CHAR(2)  NOT NULL
    ,storage CHAR(2)  NOT NULL
    ,notice CHAR(2)  NOT NULL
    ,ap_safe_typ CHAR(2)  NOT NULL
    ,hgh_alt CHAR(2)
    ,cln_way CHAR(160)
    ,license_no CHAR(22)  NOT NULL
    ,orig_cntry CHAR(6)  NOT NULL
    ,orig_place VARCHAR(1020)  NOT NULL
    ,sub_cod CHAR(10)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  igdsc
    (
    ord_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,rpt_img CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ord_no,seq_no)
);



CREATE TABLE  igetr
    (
    ord_no NUMERIC(10) NOT NULL
    ane_typ CHAR(2)  NOT NULL
    ,tpe_no CHAR(16)
    ,feq_use NUMERIC(5)
    ,glc_c CHAR(2)
    ,glc_a CHAR(2)
    ,glc_i CHAR(2)
    ,glc_b CHAR(2)
    ,glc_p CHAR(2)
    ,glc_h CHAR(2)
    ,glc_ic CHAR(2)
    ,phc CHAR(2)
    ,vla CHAR(2)
    ,amp_r CHAR(2)
    ,amp_l CHAR(2)
    ,muw_r CHAR(2)
    ,muw_l CHAR(2)
    ,phy CHAR(2)
    ,per CHAR(2)
    ,vtf_som CHAR(2)
    ,vtf_mov CHAR(2)
    ,ary_som CHAR(2)
    ,ary_mov CHAR(2)
    ,hyp CHAR(2)
    ,cmt CHAR(160)
    ,rtp NUMERIC(5)
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ord_no)
);



CREATE TABLE  mrchtbor
    (
    evt_no NUMERIC(10)  NOT NULL
    bor_man NUMERIC(5) NOT NULL
    ,bor_psn NUMERIC(5) NOT NULL
    ,bor_dat DATE NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,dcg_dat DATE NOT NULL
    ,bor_use CHAR(2)  NOT NULL
    ,pre_dat DATE NOT NULL
    ,ret_psn NUMERIC(5) NOT NULL
    ,ret_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  mrumrdr
    (
    evt_no NUMERIC(10) NOT NULL
    eff_dat DATE NOT NULL
    ,end_dat DATE NOT NULL
    ,dct NUMERIC(5) NOT NULL
    ,rsn CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  progt
    (
    ogt_no NUMERIC(5) NOT NULL
    nam VARCHAR(160)  NOT NULL
    ,dpt_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ogt_no)
);



CREATE TABLE  prrbd
    (
    idn CHAR(20)  NOT NULL
    nam CHAR(24)  NOT NULL
    ,sex CHAR(2)  NOT NULL
    ,brn_dat DATE
    ,tel_h NUMERIC(10)
    ,tel_o NUMERIC(10)
    ,tel_b NUMERIC(10)
    ,eml_no VARCHAR(120)
    ,crc_no NUMERIC(10) NOT NULL
    ,crc_adr VARCHAR(136)  NOT NULL
    ,rrc_no NUMERIC(10) NOT NULL
    ,ngb_no NUMERIC(5) NOT NULL
    ,rrc_adr VARCHAR(136)  NOT NULL
    ,prt_grp NUMERIC(5)
    ,rsp_man NUMERIC(5)
    ,cmt VARCHAR(1020)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (idn)
);



CREATE TABLE  prrog
    (
    idn CHAR(20)  NOT NULL
    org_no NUMERIC(10) NOT NULL
    ,tit_nam VARCHAR(80)  NOT NULL
    ,stp_dat DATE
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (idn,org_no,stp_dat)
);



CREATE TABLE  pbvac
    (
    sys_id CHAR(4)  NOT NULL
    vac_dat DATE NOT NULL
    ,typ1 CHAR(2)  NOT NULL
    ,typ2 CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sys_id,vac_dat)
);



CREATE TABLE  dgdcr2
    (
    vsn NUMERIC(10) NOT NULL
    con_typ NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn,con_typ)
);



CREATE TABLE  bcbemp
    (
    bbc_no NUMERIC(10) NOT NULL
    emp_no NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bbc_no)
);



CREATE TABLE  bccbcr
    (
    emp_no NUMERIC(5) NOT NULL
    cal_tim TIMESTAMP NOT NULL
    ,cal_man NUMERIC(5) NOT NULL
    ,bbc_no NUMERIC(10) NOT NULL
    ,msg VARCHAR(1020)  NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (emp_no,cal_tim)
);



CREATE TABLE  bcgcn
    (
    grp_no NUMERIC(5) NOT NULL
    grp_nam CHAR(40)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (grp_no)
);



CREATE TABLE  bcgemp
    (
    grp_no NUMERIC(5) NOT NULL
    emp_no NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (grp_no,emp_no)
);



CREATE TABLE  bcmcd
    (
    msg_typ NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,msg_dsc VARCHAR(320)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (msg_typ,seq_no)
);



CREATE TABLE  bcmtn
    (
    msg_typ NUMERIC(10)  NOT NULL
    dpt_no NUMERIC(5) NOT NULL
    ,typ_nam CHAR(40)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (msg_typ)
);



CREATE TABLE  momic
    (
    map_no NUMERIC(5) NOT NULL
    loc_no NUMERIC(5) NOT NULL
    ,wek_day CHAR(2)  NOT NULL
    ,eff_hm NUMERIC(5) NOT NULL
    ,stp_hm NUMERIC(5) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (map_no,loc_no,wek_day,stp_hm,seq_no)
);



CREATE TABLE  eraadrcn
    (
    aad_no NUMERIC(5) NOT NULL
    nam CHAR(80)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aad_no)
);



CREATE TABLE  oledbversion
    (
    srvrver VARCHAR(72)
    oledbver NUMERIC(5)
    ,oleobjsmodtime TIMESTAMP
    ,nullc CHAR(2)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  oledbtabtypes
    (
    typecode CHAR(2)
    issystem VARCHAR(20)
    ,typedesc VARCHAR(72)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (typecode,issystem)
);



CREATE TABLE  oledbbmk
    (
    tabtype CHAR(2)
    fragmented NUMERIC(5)
    ,withrowids NUMERIC(5)
    ,hasbmk VARCHAR(20)
    ,bmktype NUMERIC(10)
    ,bmkdtype NUMERIC(5)
    ,bmkmaxlen NUMERIC(10)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tabtype,fragmented,withrowids)
);



CREATE TABLE  oledbtypes
    (
    typename VARCHAR(512)
    datatype NUMERIC(5)
    ,columnsize NUMERIC(10)
    ,literalprefix VARCHAR(160)
    ,literalsuffix VARCHAR(160)
    ,createparams VARCHAR(72)
    ,isnullable VARCHAR(20)
    ,casesensitive VARCHAR(20)
    ,searchable NUMERIC(10)
    ,unsignedattribute VARCHAR(20)
    ,fixedprecscale VARCHAR(20)
    ,autouniquevalue VARCHAR(20)
    ,minimumscale NUMERIC(5)
    ,maximumscale NUMERIC(5)
    ,islong VARCHAR(20)
    ,bestmatch VARCHAR(20)
    ,is_fixedlength VARCHAR(20)
    ,xstid NUMERIC(10)
    ,udonly VARCHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (xstid)
);



CREATE TABLE  oledboleobjects
    (
    database VARCHAR(128)  NOT NULL
    owner VARCHAR(128)  NOT NULL
    ,name VARCHAR(512)  NOT NULL
    ,comadapter VARCHAR(20)  NOT NULL
    ,persiststorage VARCHAR(20)  NOT NULL
    ,progid VARCHAR(512)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (database,owner,name)
);



CREATE TABLE  oledbprivtypes
    (
    code CHAR(2)
    name VARCHAR(64)
    ,is_grantable VARCHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (code)
);



CREATE TABLE  oledbconstrtypes
    (
    code CHAR(2)
    name VARCHAR(64)
    ,isprimary VARCHAR(20)
    ,isunique VARCHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (code)
);



CREATE TABLE  oledbconstrdefers
    (
    objstate CHAR(2)
    isdeferred VARCHAR(20)
    ,deferrable_cdc VARCHAR(20)
    ,issystab VARCHAR(20)
    ,code NUMERIC(5)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (objstate,issystab)
);



CREATE TABLE  oledbusagetypes
    (
    tabname CHAR(36)
    usagetype VARCHAR(72)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tabname)
);



CREATE TABLE  oledbordinals
    (
    ordinal NUMERIC(10)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ordinal)
);



CREATE TABLE  ucmsg
    (
    msg_no NUMERIC(10)  NOT NULL
    tbl_id CHAR(16)  NOT NULL
    ,fun_no CHAR(8)  NOT NULL
    ,evt_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,lvl CHAR(2)  NOT NULL
    ,cmt VARCHAR(1020)  NOT NULL
    ,sed_man NUMERIC(5) NOT NULL
    ,sed_tim TIMESTAMP NOT NULL
    ,sed_loc NUMERIC(5) NOT NULL
    ,lmt_dat DATE
    ,rec_man NUMERIC(5) NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_loc NUMERIC(5) NOT NULL
    ,exe_tim TIMESTAMP NOT NULL
    ,cfm_cmt VARCHAR(1020)  NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (msg_no)
);



CREATE TABLE  mohint
    (
    dct_no NUMERIC(5) NOT NULL
    dsc text
    ,see_tim TIMESTAMP NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dct_no)
);



CREATE TABLE  dgprnctl
    (
    def_prt CHAR(20)  NOT NULL
    swt_prt CHAR(20)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (def_prt)
);



CREATE TABLE  sysmenus
    (
    menuname CHAR(36)
    title CHAR(120)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  dgdnc
    (
    hpt_loc CHAR(2)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,cur_no NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  nsmss
    (
    wrd NUMERIC(5) NOT NULL
    itm_no NUMERIC(5) NOT NULL
    ,mtl_cod CHAR(14)  NOT NULL
    ,smt_no NUMERIC(10)
    ,qty NUMERIC(5) NOT NULL
    ,nam_a CHAR(40)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (wrd,itm_no)
);



CREATE TABLE  dcptbd
    (
    vsn NUMERIC(10) NOT NULL
    chart NUMERIC(10) NOT NULL
    ,nhi_typ CHAR(4)  NOT NULL
    ,age NUMERIC(5) NOT NULL
    ,reg_no NUMERIC(10) NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,icu CHAR(2)  NOT NULL
    ,adm_dat DATE NOT NULL
    ,adm_win CHAR(2)  NOT NULL
    ,dis_dat DATE NOT NULL
    ,dis_sts CHAR(4)  NOT NULL
    ,ane_typ CHAR(2)  NOT NULL
    ,rtd DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn)
);



CREATE TABLE  modct
    (
    vsn NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,dct_no NUMERIC(5) NOT NULL
    ,eff_dat DATE
    ,eff_hm NUMERIC(5)
    ,stp_dat DATE
    ,stp_hm NUMERIC(5)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn,stp_dat,stp_hm,seq_no)
);



CREATE TABLE  morsh
    (
    seq_no NUMERIC(10)  NOT NULL
    cmd CHAR(510)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  tecico
    (
    rec_tim TIMESTAMP
    sub_tel NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_tim,sub_tel,typ)
);



CREATE TABLE  tectsr
    (
    tel_loc CHAR(8)  NOT NULL
    wek_day CHAR(2)  NOT NULL
    ,sat_hhmm NUMERIC(5) NOT NULL
    ,stp_hhmm NUMERIC(5) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE
    ,bas_qty NUMERIC(5) NOT NULL
    ,bas_unt CHAR(2)  NOT NULL
    ,amt NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tel_loc,wek_day,sat_hhmm,stp_dat)
);



CREATE TABLE  tecttr
    (
    sat_tim TIMESTAMP NOT NULL
    sub_tel NUMERIC(10) NOT NULL
    ,vsn NUMERIC(10) NOT NULL
    ,out_tel CHAR(32)  NOT NULL
    ,use_sec NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sat_tim,sub_tel)
);



CREATE TABLE  tetbd
    (
    sub_tel NUMERIC(10) NOT NULL
    nam VARCHAR(160)  NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,cur_sts CHAR(2)  NOT NULL
    ,ctl_sts CHAR(2)  NOT NULL
    ,dpt_no NUMERIC(5) NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  nhtpi
    (
    pkg_cod CHAR(14)  NOT NULL
    eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pkg_cod,eff_dat,chg_cod)
);



CREATE TABLE  nhtppd
    (
    chart NUMERIC(10) NOT NULL
    visit_no NUMERIC(11,0)  NOT NULL
    ,pkg_cod CHAR(14)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,visit_no)
);



CREATE TABLE  cgbai
    (
    chg_cod CHAR(14)  NOT NULL
    eff_dat DATE
    ,stp_dat DATE
    ,bai_amt NUMERIC(7,1)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chg_cod,eff_dat)
);



CREATE TABLE  dgusgdat
    (
    usg_cod CHAR(36)  NOT NULL
    nam CHAR(40)  NOT NULL
    ,usg_dsc CHAR(100)  NOT NULL
    ,usg_typ CHAR(2)  NOT NULL
    ,frq_typ CHAR(2)  NOT NULL
    ,frq NUMERIC(5) NOT NULL
    ,cnt NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  mocnam
    (
    map_no NUMERIC(5) NOT NULL
    typ CHAR(2)  NOT NULL
    ,cod CHAR(36)  NOT NULL
    ,dsc CHAR(80)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (map_no,typ,cod)
);



CREATE TABLE  motdn
    (
    vsn NUMERIC(10) NOT NULL
    ord_no NUMERIC(10)
    ,trn_tim TIMESTAMP NOT NULL
    ,old_div_no NUMERIC(5) NOT NULL
    ,old_dct_no NUMERIC(5) NOT NULL
    ,new_div_no NUMERIC(5) NOT NULL
    ,new_dct_no1 NUMERIC(5) NOT NULL
    ,new_dct_no2 NUMERIC(5) NOT NULL
    ,new_dct_no3 NUMERIC(5) NOT NULL
    ,new_dct_no4 NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,txt_01 text
    ,txt_02 text
    ,txt_03 text
    ,txt_04 text
    ,txt_05 text
    ,txt_06 text
    ,txt_07 text
    ,txt_08 text
    ,txt_09 text
    ,txt_10 text
    ,txt_11 text
    ,txt_12 text
    ,txt_13 text
    ,txt_14 text
    ,txt_15 text
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn,trn_tim)
);



CREATE TABLE  cpcpv
    (
    itm_no NUMERIC(10) NOT NULL
    var_no1 NUMERIC(5) NOT NULL
    ,var_no2 NUMERIC(5) NOT NULL
    ,var_no3 NUMERIC(5) NOT NULL
    ,elm_no1 NUMERIC(5) NOT NULL
    ,elm_no2 NUMERIC(5) NOT NULL
    ,elm_no3 NUMERIC(5) NOT NULL
    ,car_no1 NUMERIC(5) NOT NULL
    ,car_no2 NUMERIC(5) NOT NULL
    ,car_no3 NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  cpveccn
    (
    vec_no NUMERIC(5) NOT NULL
    nam CHAR(80)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vec_no)
);



CREATE TABLE  dgads
    (
    hsp_no CHAR(2)  NOT NULL
    adj_dat DATE NOT NULL
    ,lmp_typ CHAR(2)  NOT NULL
    ,adj_man01 NUMERIC(5) NOT NULL
    ,adj_man02 NUMERIC(5) NOT NULL
    ,adj_man03 NUMERIC(5) NOT NULL
    ,adj_man04 NUMERIC(5) NOT NULL
    ,adj_man05 NUMERIC(5) NOT NULL
    ,adj_man06 NUMERIC(5) NOT NULL
    ,adj_man07 NUMERIC(5) NOT NULL
    ,adj_man08 NUMERIC(5) NOT NULL
    ,adj_man09 NUMERIC(5) NOT NULL
    ,adj_man10 NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (hsp_no,adj_dat,lmp_typ)
);



CREATE TABLE  nhdcn
    (
    drg_cod CHAR(10)  NOT NULL
    eff_dat DATE NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,nam CHAR(196)  NOT NULL
    ,nam_a CHAR(80)
    ,amt_apl NUMERIC(10) NOT NULL
    ,rat_max NUMERIC(5) NOT NULL
    ,amt_min NUMERIC(10) NOT NULL
    ,day_low NUMERIC(5) NOT NULL
    ,day_hgh NUMERIC(5) NOT NULL
    ,amt_low NUMERIC(10) NOT NULL
    ,amt_hgh NUMERIC(10) NOT NULL
    ,rat_exe NUMERIC(5) NOT NULL
    ,apl_cod CHAR(24)  NOT NULL
    ,txt text
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  hcbtm
    (
    chart NUMERIC(10) NOT NULL
    btm_seq CHAR(2)
    ,idn CHAR(20)  NOT NULL
    ,brn_dat DATE NOT NULL
    ,rtp NUMERIC(5)
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart)
);



CREATE TABLE  hcvcd
    (
    vcd_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,icc_typ CHAR(4)  NOT NULL
    ,btm CHAR(2)
    ,rcm CHAR(2)
    ,sam_id CHAR(24)  NOT NULL
    ,wrt_tim CHAR(26)  NOT NULL
    ,sfe_sign CHAR(512)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vcd_no)
);



CREATE TABLE  rosars
    (
    idn CHAR(20)  NOT NULL
    nam CHAR(24)  NOT NULL
    ,hop_nam CHAR(40)  NOT NULL
    ,adm_dat DATE
    ,dis_dat DATE
    ,tel_no NUMERIC(10)
    ,cmt CHAR(40)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (idn)
);



CREATE TABLE  uciolog
    (
    log_tim TIMESTAMP
    emp_no NUMERIC(5) NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,log_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_tim,emp_no)
);



CREATE TABLE  smreq
    (
    sed_no NUMERIC(10)  NOT NULL
    apl_man NUMERIC(5) NOT NULL
    ,tel_no NUMERIC(10) NOT NULL
    ,msg CHAR(318)
    ,sed_tim TIMESTAMP NOT NULL
    ,chg_man NUMERIC(10) NOT NULL
    ,apl_tim TIMESTAMP NOT NULL
    ,apl_loc NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sed_no)
);



CREATE TABLE  nsntm
    (
    chg_cod CHAR(14)  NOT NULL
    typ CHAR(8)  NOT NULL
    ,mat_cod CHAR(14)  NOT NULL
    ,inc_itm CHAR(2)  NOT NULL
    ,min_qty NUMERIC(5) NOT NULL
    ,max_qty NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chg_cod,typ)
);



CREATE TABLE  nentm
    (
    chg_cod CHAR(14)  NOT NULL
    typ CHAR(8)  NOT NULL
    ,mat_cod CHAR(14)  NOT NULL
    ,inc_itm CHAR(2)  NOT NULL
    ,min_qty NUMERIC(5) NOT NULL
    ,max_qty NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chg_cod,typ)
);



CREATE TABLE  garcbd
    (
    rc NUMERIC(5) NOT NULL
    level_no CHAR(16)  NOT NULL
    ,nam_a CHAR(12)  NOT NULL
    ,nam_f CHAR(40)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,mark_gaon CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  hcccd
    (
    ccd_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,icc_typ CHAR(4)  NOT NULL
    ,vsn_nh CHAR(8)  NOT NULL
    ,wrt_tim CHAR(26)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ccd_no)
);



CREATE TABLE  hcwcs
    (
    ccd_no NUMERIC(10) NOT NULL
    btm CHAR(2)
    ,rcm CHAR(2)
    ,sam_id CHAR(24)  NOT NULL
    ,sfe_sign CHAR(512)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ccd_no)
);



CREATE TABLE  dcdsc92
    (
    icd_cod CHAR(12)  NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,dsc VARCHAR(1000)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  dcicd92
    (
    icd_cod CHAR(12)  NOT NULL
    nhi_cod CHAR(12)  NOT NULL
    ,drg_cod CHAR(10)  NOT NULL
    ,qip_drg CHAR(6)  NOT NULL
    ,nam_e CHAR(510)  NOT NULL
    ,icd_typ NUMERIC(5) NOT NULL
    ,sru_mrk CHAR(2)  NOT NULL
    ,crn_mrk CHAR(2)  NOT NULL
    ,crn_typ NUMERIC(5) NOT NULL
    ,con_mrk CHAR(2)  NOT NULL
    ,con_typ NUMERIC(5) NOT NULL
    ,sex_lmt CHAR(2)  NOT NULL
    ,dag_lmt CHAR(2)  NOT NULL
    ,fil_1 CHAR(2)  NOT NULL
    ,min_age NUMERIC(5) NOT NULL
    ,max_age NUMERIC(5) NOT NULL
    ,std_days NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  scpbd
    (
    scp_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,scn_typ CHAR(6)  NOT NULL
    ,hpt_loc CHAR(2)
    ,dct_no NUMERIC(5) NOT NULL
    ,eff_dat DATE
    ,stp_dat DATE
    ,dis_typ CHAR(4)
    ,eff_rsn CHAR(2)
    ,stp_rsn CHAR(2)  NOT NULL
    ,cle NUMERIC(5) NOT NULL
    ,cle_dat DATE
    ,lst_dat DATE
    ,lst_cod CHAR(14)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (scp_no)
);



CREATE TABLE  sccer
    (
    scp_no NUMERIC(10) NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,pkg_cod CHAR(14)  NOT NULL
    ,ord_dat DATE NOT NULL
    ,ord_man NUMERIC(5)
    ,cfm_mrk CHAR(30)  NOT NULL
    ,cfm_dat DATE
    ,reg_dat DATE
    ,exe_man NUMERIC(5)
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (scp_no,pkg_cod,vsn)
);



CREATE TABLE  scceibd
    (
    pkg_cod CHAR(14)  NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,exe_nam CHAR(40)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pkg_cod,seq_no)
);



CREATE TABLE  sccrd
    (
    scn_typ CHAR(6)  NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,pkg_cod CHAR(14)  NOT NULL
    ,frq CHAR(2)  NOT NULL
    ,itv_day NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (scn_typ,seq_no)
);



CREATE TABLE  ucofunl
    (
    emp_no NUMERIC(5) NOT NULL
    fun_no CHAR(8)  NOT NULL
    ,dpt_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (emp_no,fun_no,dpt_no)
);



CREATE TABLE  dgtest
    (
    chg_cod CHAR(10)  NOT NULL
    dct_no NUMERIC(5) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,pay_typ CHAR(2)
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chg_cod,dct_no,chart)
);



CREATE TABLE  dcicdcn
    (
    icd_cod CHAR(12)  NOT NULL
    nhi_cod CHAR(12)  NOT NULL
    ,drg_cod CHAR(10)  NOT NULL
    ,qip_drg CHAR(6)  NOT NULL
    ,nam_e CHAR(510)  NOT NULL
    ,icd_typ NUMERIC(5) NOT NULL
    ,sru_mrk NUMERIC(5) NOT NULL
    ,ifq_mrk CHAR(2)
    ,crn_mrk CHAR(2)  NOT NULL
    ,crn_typ CHAR(12)
    ,con_mrk CHAR(2)  NOT NULL
    ,con_typ NUMERIC(5) NOT NULL
    ,sex_lmt CHAR(2)  NOT NULL
    ,dag_lmt CHAR(2)  NOT NULL
    ,fil_1 CHAR(4)
    ,min_age NUMERIC(5) NOT NULL
    ,max_age NUMERIC(5) NOT NULL
    ,std_days NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  cndcn
    (
    dag_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,dag_dat DATE NOT NULL
    ,dag_typ NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,dct_no NUMERIC(5) NOT NULL
    ,ord_man NUMERIC(5) NOT NULL
    ,dag_txt text
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dag_no)
);



CREATE TABLE  cndrd
    (
    itm_cod NUMERIC(5) NOT NULL
    dsc CHAR(260)  NOT NULL
    ,scr NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_cod)
);



CREATE TABLE  cndss
    (
    own_no NUMERIC(5) NOT NULL
    dag_typ NUMERIC(5) NOT NULL
    ,nam CHAR(24)  NOT NULL
    ,dsc text NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (own_no,dag_typ,nam)
);



CREATE TABLE  cnssp
    (
    cod CHAR(40)  NOT NULL
    dsc CHAR(40)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dsc)
);



CREATE TABLE  xrrwdr
    (
    typ CHAR(6)
    map_no NUMERIC(5) NOT NULL
    ,chg_cod CHAR(20)
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,src CHAR(2)  NOT NULL
    ,wek_day CHAR(2)  NOT NULL
    ,sat_val NUMERIC(5) NOT NULL
    ,end_val NUMERIC(5) NOT NULL
    ,rpt_man NUMERIC(10)
    ,rpt_man2 NUMERIC(10)
    ,rtp NUMERIC(10)
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (map_no,src,wek_day,eff_dat,sat_val)
);



CREATE TABLE  ositeml
    (
    order_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,dc CHAR(2)  NOT NULL
    ,item_cod CHAR(14)  NOT NULL
    ,item_mark CHAR(2)  NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,usag CHAR(40)  NOT NULL
    ,tot_qty CHAR(10)  NOT NULL
    ,self_qty CHAR(10)  NOT NULL
    ,emg CHAR(2)  NOT NULL
    ,self CHAR(2)  NOT NULL
    ,chg CHAR(2)  NOT NULL
    ,prn_map CHAR(2)  NOT NULL
    ,ppf_no NUMERIC(5) NOT NULL
    ,prm_no NUMERIC(10) NOT NULL
    ,map_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  oshint
    (
    dct_no NUMERIC(5) NOT NULL
    dsc text
    ,see_tim TIMESTAMP
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dct_no)
);



CREATE TABLE  hcvch
    (
    his_no NUMERIC(10)  NOT NULL
    idn CHAR(20)  NOT NULL
    ,wrt_tim CHAR(26)  NOT NULL
    ,icc_typ CHAR(4)  NOT NULL
    ,vsn_nh CHAR(8)  NOT NULL
    ,btm CHAR(2)
    ,rcm CHAR(2)
    ,hsp_no CHAR(20)  NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (his_no)
);



CREATE TABLE  hcpst
    (
    ccd_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,nhi_cod CHAR(24)  NOT NULL
    ,pos CHAR(12)  NOT NULL
    ,usg CHAR(36)  NOT NULL
    ,day NUMERIC(5) NOT NULL
    ,qty NUMERIC(7,2)  NOT NULL
    ,mrk CHAR(4)  NOT NULL
    ,pst_sign CHAR(80)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ccd_no,seq_no)
);



CREATE TABLE  pipvr
    (
    chart NUMERIC(10) NOT NULL
    tsc CHAR(2)
    ,lnk_no NUMERIC(10)
    ,btm_seq CHAR(2)  NOT NULL
    ,idn CHAR(20)  NOT NULL
    ,inj_dat DATE
    ,bat_no CHAR(40)
    ,vac_seq CHAR(2)  NOT NULL
    ,exe_man NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,bat_no,vac_seq,inj_dat)
);



CREATE TABLE  pivbd
    (
    vac_cod CHAR(40)
    nam CHAR(100)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  pibvr
    (
    bat_no CHAR(40)
    vac_cod CHAR(40)
    ,slf_typ CHAR(2)  NOT NULL
    ,eff_dat DATE
    ,vac_com CHAR(40)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  moocl
    (
    ord_no NUMERIC(10) NOT NULL
    dct_no NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ord_no,dct_no)
);



CREATE TABLE  ucogfunc
    (
    group_func_no NUMERIC(5)
    func_no CHAR(8)  NOT NULL
    ,use_level CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (group_func_no,func_no)
);



CREATE TABLE  psepbdat
    (
    emp_no NUMERIC(5) NOT NULL
    emp_nam CHAR(20)  NOT NULL
    ,birthday DATE NOT NULL
    ,enter_dat DATE NOT NULL
    ,quit_dat DATE NOT NULL
    ,depart NUMERIC(5) NOT NULL
    ,division NUMERIC(5) NOT NULL
    ,titl CHAR(4)  NOT NULL
    ,rank NUMERIC(5) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,fil_1 CHAR(2)  NOT NULL
    ,group_func_no NUMERIC(5)
    ,passwd NUMERIC(10) NOT NULL
    ,err_times NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  mopomr
    (
    vsn NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rcd_dat DATE NOT NULL
    ,act_txt CHAR(510)  NOT NULL
    ,hpd_dat CHAR(24)  NOT NULL
    ,nct_txt CHAR(360)  NOT NULL
    ,rlt_dat CHAR(24)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn,seq_no)
);



CREATE TABLE  rfhpwd
    (
    hpt_no NUMERIC(10,0)  NOT NULL
    dct_no NUMERIC(5) NOT NULL
    ,pwd CHAR(20)  NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (hpt_no)
);



CREATE TABLE  dgdbd2
    (
    drg_cod CHAR(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,txt CHAR(160)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (drg_cod,typ)
);



CREATE TABLE  mrumrt
    (
    evt_no NUMERIC(10)  NOT NULL
    reg_dat DATE NOT NULL
    ,reg_psn NUMERIC(5) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,dcg_dat DATE NOT NULL
    ,dcg_hm NUMERIC(5)
    ,snd_dat DATE NOT NULL
    ,itm1 DATE NOT NULL
    ,itm2 DATE NOT NULL
    ,itm3 DATE NOT NULL
    ,itm4 DATE NOT NULL
    ,itm5 DATE NOT NULL
    ,itm6 DATE NOT NULL
    ,itm7 DATE NOT NULL
    ,itm8 DATE NOT NULL
    ,itm9 DATE NOT NULL
    ,itm10 DATE NOT NULL
    ,itm11 DATE
    ,itm12 DATE
    ,itm13 DATE
    ,itm14 DATE
    ,dct_r NUMERIC(5) NOT NULL
    ,pre_dat_r DATE NOT NULL
    ,don_dat_r DATE NOT NULL
    ,dct_v NUMERIC(5) NOT NULL
    ,pre_dat_v DATE NOT NULL
    ,don_dat_v DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  smdmolq
    (
    yymm NUMERIC(5) NOT NULL
    dct NUMERIC(5) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,qty_b NUMERIC(5)
    ,qty_l NUMERIC(5) NOT NULL
    ,qty_a NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (yymm,dct,typ)
);



CREATE TABLE  mmres
    (
    tel_no NUMERIC(10,0)  NOT NULL
    res_tim TIMESTAMP NOT NULL
    ,msg CHAR(4)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tel_no,res_tim)
);



CREATE TABLE  mmcodctt
    (
    sms_no NUMERIC(5) NOT NULL
    nam CHAR(256)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sms_no)
);



CREATE TABLE  icdesc
    (
    charg_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,gl_typ CHAR(4)  NOT NULL
    ,pt_typ CHAR(4)  NOT NULL
    ,room CHAR(8)  NOT NULL
    ,bed CHAR(4)  NOT NULL
    ,prescriptor NUMERIC(5) NOT NULL
    ,division_md NUMERIC(5) NOT NULL
    ,orddat NUMERIC(5) NOT NULL
    ,tmp CHAR(2)  NOT NULL
    ,gl_amt NUMERIC(10) NOT NULL
    ,gl_amt_p NUMERIC(10) NOT NULL
    ,pt_amt NUMERIC(10) NOT NULL
    ,collect_no NUMERIC(10) NOT NULL
    ,permit_rson CHAR(2)  NOT NULL
    ,lamp_typ CHAR(2)  NOT NULL
    ,lamp_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  dcifqcb
    (
    icd_cod_m CHAR(16)  NOT NULL
    icd_cod_a CHAR(16)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (icd_cod_m,icd_cod_a)
);



CREATE TABLE  ntdwm
    (
    dpt_no NUMERIC(5) NOT NULL
    eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,dtn_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dpt_no,eff_dat)
);



CREATE TABLE  mrpsr
    (
    chart NUMERIC(10) NOT NULL
    spc_mrk NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,spc_mrk)
);



CREATE TABLE  old_dcheccd
    (
    icd_cod_m CHAR(12)  NOT NULL
    icd_cod_c CHAR(12)  NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (icd_cod_m,icd_cod_c)
);



CREATE TABLE  ntpdadt
    (
    acc_no NUMERIC(10) NOT NULL
    dt_own CHAR(2)  NOT NULL
    ,f_dat DATE NOT NULL
    ,f_meal CHAR(2)  NOT NULL
    ,adt_mel CHAR(2)  NOT NULL
    ,adt_itm CHAR(2)  NOT NULL
    ,qty NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (acc_no,dt_own,f_dat,f_meal,adt_mel,adt_itm)
);



CREATE TABLE  tddrgnfc
    (
    drg_cod CHAR(10)  NOT NULL
    eff_ym NUMERIC(5) NOT NULL
    ,stp_ym NUMERIC(5) NOT NULL
    ,day_avg NUMERIC(5) NOT NULL
    ,amt_low NUMERIC(10) NOT NULL
    ,amt_hgh NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (drg_cod,eff_ym)
);



CREATE TABLE  tdmdcbd
    (
    mdc CHAR(4)  NOT NULL
    nam_e CHAR(160)  NOT NULL
    ,nam_c CHAR(80)  NOT NULL
    ,yy NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mdc)
);



CREATE TABLE  tdncbd
    (
    mdc CHAR(4)  NOT NULL
    eff_ym NUMERIC(5) NOT NULL
    ,stp_ym NUMERIC(5) NOT NULL
    ,rat_m_1 NUMERIC(4,2)  NOT NULL
    ,rat_m_2 NUMERIC(4,2)  NOT NULL
    ,rat_m_3 NUMERIC(4,2)  NOT NULL
    ,rat_p_1 NUMERIC(4,2)  NOT NULL
    ,rat_p_2 NUMERIC(4,2)  NOT NULL
    ,rat_p_3 NUMERIC(4,2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mdc,eff_ym)
);



CREATE TABLE  tddrgcn
    (
    drg_cod CHAR(10)  NOT NULL
    nam_e CHAR(240)  NOT NULL
    ,nam_c CHAR(240)  NOT NULL
    ,div_typ CHAR(2)  NOT NULL
    ,mrk CHAR(2)  NOT NULL
    ,eff_dat DATE
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (drg_cod)
);



CREATE TABLE  tdcctoc
    (
    chg_cod CHAR(14)  NOT NULL
    opr_cod1 CHAR(12)  NOT NULL
    ,opr_cod2 CHAR(12)  NOT NULL
    ,opr_cod3 CHAR(12)  NOT NULL
    ,opr_cod4 CHAR(12)  NOT NULL
    ,bgn_dat DATE
    ,tsc CHAR(2)
    ,opr_cnt1 NUMERIC(10)
    ,pas_dat DATE
    ,cmt CHAR(40)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chg_cod,opr_cod1,opr_cod2,opr_cod3,opr_cod4)
);



CREATE TABLE  tdheccd
    (
    icd_cod_m CHAR(12)  NOT NULL
    icd_cod_c CHAR(12)  NOT NULL
    ,cnt NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (icd_cod_m,icd_cod_c)
);



CREATE TABLE  tdorc
    (
    opr_cod1 CHAR(12)  NOT NULL
    opr_cod2 CHAR(12)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (opr_cod1,opr_cod2)
);



CREATE TABLE  tdpdmdcr
    (
    icd_cod CHAR(12)  NOT NULL
    mdc_cod CHAR(4)  NOT NULL
    ,tma CHAR(2)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (icd_cod,mdc_cod,eff_dat)
);



CREATE TABLE  tddord
    (
    icd_cod CHAR(12)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,sex_chk CHAR(2)  NOT NULL
    ,age_chk CHAR(2)  NOT NULL
    ,icd_chk CHAR(2)  NOT NULL
    ,opr_chk CHAR(4)
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (icd_cod,typ,eff_dat)
);



CREATE TABLE  tddrgjr1
    (
    mdc_cod CHAR(4)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,icd_cod CHAR(12)  NOT NULL
    ,jud_mrk CHAR(2)  NOT NULL
    ,jud_ref CHAR(2)  NOT NULL
    ,jud_cod CHAR(2)  NOT NULL
    ,age NUMERIC(5) NOT NULL
    ,drg1 CHAR(10)  NOT NULL
    ,drg2 CHAR(10)  NOT NULL
    ,drg3 CHAR(10)  NOT NULL
    ,drg4 CHAR(10)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mdc_cod,typ,icd_cod,eff_dat)
);



CREATE TABLE  tddrgjr2
    (
    mdc_cod CHAR(4)  NOT NULL
    drg CHAR(10)  NOT NULL
    ,jud_ref CHAR(2)  NOT NULL
    ,icd_cod CHAR(12)  NOT NULL
    ,jud_cod CHAR(2)  NOT NULL
    ,age NUMERIC(5) NOT NULL
    ,drg1 CHAR(10)  NOT NULL
    ,drg2 CHAR(10)  NOT NULL
    ,drg3 CHAR(10)  NOT NULL
    ,drg4 CHAR(10)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mdc_cod,drg,jud_ref,icd_cod,eff_dat)
);



CREATE TABLE  tdccrd
    (
    npd_cod CHAR(12)  NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,icd_sat CHAR(12)  NOT NULL
    ,icd_end CHAR(12)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (npd_cod,seq_no)
);



CREATE TABLE  tdcnpd
    (
    icd_cod CHAR(12)  NOT NULL
    eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (icd_cod,eff_dat)
);



CREATE TABLE  tddrgps
    (
    mdc_cod CHAR(4)  NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,drg CHAR(10)  NOT NULL
    ,wgt NUMERIC(8,4)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mdc_cod,seq_no,eff_dat)
);



CREATE TABLE  modcttgb
    (
    dct_no NUMERIC(5) NOT NULL
    eff_dat DATE NOT NULL
    ,eff_hm NUMERIC(5) NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dct_no,eff_dat)
);



CREATE TABLE  mrumrh
    (
    evt_no NUMERIC(10) NOT NULL
    typ CHAR(2)  NOT NULL
    ,dct NUMERIC(5) NOT NULL
    ,pre_dat DATE NOT NULL
    ,don_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no,typ,dct,pre_dat)
);



CREATE TABLE  osagr
    (
    chart NUMERIC(10) NOT NULL
    visit_no NUMERIC(11,0)  NOT NULL
    ,asm_gad CHAR(2)  NOT NULL
    ,day_fre CHAR(2)  NOT NULL
    ,ngt_fre CHAR(2)  NOT NULL
    ,pef_bst CHAR(2)  NOT NULL
    ,pef_var CHAR(2)  NOT NULL
    ,act_ctl CHAR(2)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,visit_no)
);



CREATE TABLE  eheer
    (
    eer_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,frm NUMERIC(10) NOT NULL
    ,eer_man NUMERIC(5) NOT NULL
    ,eer_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)
    ,scn CHAR(6)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (eer_no)
);



CREATE TABLE  ehvsr
    (
    eer_no NUMERIC(10) NOT NULL
    vtl_itm CHAR(2)  NOT NULL
    ,way CHAR(4)
    ,val NUMERIC(6,3)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (eer_no,vtl_itm)
);



CREATE TABLE  dgcdr
    (
    chart NUMERIC(10) NOT NULL
    chg_cod CHAR(10)  NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,dct_no NUMERIC(5) NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,chg_cod)
);



CREATE TABLE  teeamt
    (
    emp_no NUMERIC(5) NOT NULL
    eff_dat DATE NOT NULL
    ,stp_dat DATE
    ,tel_o NUMERIC(10,0)  NOT NULL
    ,tel_i NUMERIC(10)
    ,typ_f CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,rsn CHAR(2)
    ,dsc CHAR(120)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (emp_no,eff_dat,tel_o)
);



CREATE TABLE  cgpcfamt
    (
    pt_typ CHAR(4)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,eff_dat DATE
    ,stp_dat DATE
    ,amt_o NUMERIC(10) NOT NULL
    ,amt_i NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pt_typ,chg_cod,eff_dat)
);



CREATE TABLE  cgppi2
    (
    pkg_cod CHAR(12)  NOT NULL
    nam CHAR(100)  NOT NULL
    ,eff_dat DATE
    ,stp_dat DATE
    ,typ CHAR(2)  NOT NULL
    ,pkg_amt NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pkg_cod,eff_dat)
);



CREATE TABLE  zzccn
    (
    cnt_cod CHAR(4)  NOT NULL
    nam CHAR(40)  NOT NULL
    ,nam_e CHAR(104)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cnt_cod)
);



CREATE TABLE  cgwfr
    (
    evt_num NUMERIC(10) NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,dug_tsc CHAR(2)  NOT NULL
    ,mtr_tsc CHAR(2)  NOT NULL
    ,mdc_tsc CHAR(2)  NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_num)
);



CREATE TABLE  mompc
    (
    ser_no NUMERIC(10)  NOT NULL
    src CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,dct_no NUMERIC(5) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  osowsd
    (
    chart NUMERIC(10) NOT NULL
    visit_no NUMERIC(11,0)  NOT NULL
    ,chk_tim NUMERIC(5) NOT NULL
    ,vst_tim NUMERIC(5) NOT NULL
    ,cmt CHAR(60)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,visit_no)
);



CREATE TABLE  osowss
    (
    eff_dat DATE NOT NULL
    stp_dat DATE NOT NULL
    ,eff_no NUMERIC(5) NOT NULL
    ,stp_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (eff_dat,stp_dat)
);



CREATE TABLE  mrtrr
    (
    chart NUMERIC(10) NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,rct_dat DATE NOT NULL
    ,rct_dsc CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,chg_cod,rct_dat,rct_dsc)
);



CREATE TABLE  mrspp
    (
    chart NUMERIC(10) NOT NULL
    pwd NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart)
);



CREATE TABLE  psctcont
    (
    contra_no CHAR(6)
    contnt CHAR(2000)  NOT NULL
    ,secret CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,cmt CHAR(120)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  xrxtd
    (
    grp_cod CHAR(14)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,use_way CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (grp_cod,chg_cod)
);



CREATE TABLE  ifpil
    (
    chart NUMERIC(10) NOT NULL
    eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,dis_typ CHAR(2)  NOT NULL
    ,eff_rsn CHAR(160)  NOT NULL
    ,eff_man NUMERIC(5) NOT NULL
    ,ett TIMESTAMP
    ,stp_rsn CHAR(160)
    ,stp_man NUMERIC(5) NOT NULL
    ,stt TIMESTAMP
    ,cmt CHAR(160)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,eff_dat,dis_typ)
);



CREATE TABLE  dgtxt
    (
    drg_cod CHAR(14)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,dsc text NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (drg_cod,typ)
);



CREATE TABLE  dgdbd3
    (
    drg_cod CHAR(14)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,val NUMERIC(10,2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (drg_cod,typ)
);



CREATE TABLE  cgrnc
    (
    typ NUMERIC(5) NOT NULL
    cod CHAR(10)  NOT NULL
    ,nam CHAR(80)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (typ,cod)
);



CREATE TABLE  ucudpr
    (
    emp_no NUMERIC(5) NOT NULL
    tel_o NUMERIC(10) NOT NULL
    ,tel_bs NUMERIC(5) NOT NULL
    ,tel_bf NUMERIC(10,0)  NOT NULL
    ,tel_h NUMERIC(10) NOT NULL
    ,adr CHAR(120)  NOT NULL
    ,agt NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (emp_no)
);



CREATE TABLE  ospfer
    (
    vsn NUMERIC(10) NOT NULL
    edc_cod CHAR(14)  NOT NULL
    ,itm CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn,edc_cod,itm)
);



CREATE TABLE  mrdrt
    (
    chart NUMERIC(10) NOT NULL
    visit_no NUMERIC(11,0)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,visit_no,typ)
);



CREATE TABLE  cgtxt
    (
    chg_cod CHAR(14)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,dsc text NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chg_cod,typ)
);



CREATE TABLE  morcr
    (
    rec_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,eff_dat DATE
    ,eff_hm NUMERIC(5)
    ,stp_dat DATE
    ,stp_hm NUMERIC(5)
    ,dct_no NUMERIC(5) NOT NULL
    ,pgy_no NUMERIC(5)
    ,pgd_no NUMERIC(5)
    ,pts_no NUMERIC(5)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  cgbit
    (
    bqt_no NUMERIC(10) NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,qty NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bqt_no,chg_cod)
);



CREATE TABLE  cgbqt2
    (
    bqt_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,bqt_gov CHAR(4)  NOT NULL
    ,bqt_amt NUMERIC(10) NOT NULL
    ,acc_amt NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bqt_no)
);



CREATE TABLE  cgbqt
    (
    bqt_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,bqt_gov CHAR(4)  NOT NULL
    ,bqt_amt NUMERIC(10) NOT NULL
    ,acc_amt NUMERIC(10) NOT NULL
    ,dug_bqt_top NUMERIC(10)
    ,dug_bqt_acc NUMERIC(10)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bqt_no)
);



CREATE TABLE  ospmh
    (
    pmh_num NUMERIC(10)  NOT NULL
    tsc CHAR(2)  NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,frv_prn CHAR(2)  NOT NULL
    ,dsc VARCHAR(1020)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pmh_num)
);



CREATE TABLE  mogrpitm
    (
    grp_cod CHAR(14)  NOT NULL
    sys CHAR(2)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,dtl_cod CHAR(14)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (grp_cod,sys,eff_dat,dtl_cod)
);



CREATE TABLE  smdsolq
    (
    yymm NUMERIC(5) NOT NULL
    dct NUMERIC(5) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,qty_b NUMERIC(5) NOT NULL
    ,qty_l NUMERIC(5) NOT NULL
    ,qty_a NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (yymm,dct,typ)
);



CREATE TABLE  mocrs
    (
    sch_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,sch_dat1 NUMERIC(10) NOT NULL
    ,sch_dat2 NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sch_no)
);



CREATE TABLE  mrdnrosr
    (
    rec_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rec_sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10)
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  mrdnrosc
    (
    vsn NUMERIC(10) NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,rcp NUMERIC(10)
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn)
);



CREATE TABLE  dgdcr
    (
    dcr_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,con_typ CHAR(2)
    ,con_man NUMERIC(5) NOT NULL
    ,con_tim CHAR(2)  NOT NULL
    ,con_dsc text
    ,trc_man NUMERIC(5) NOT NULL
    ,trc_tim CHAR(2)  NOT NULL
    ,trc_dsc text
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dcr_no)
);



CREATE TABLE  dgdcct
    (
    dcr_no NUMERIC(10) NOT NULL
    dug_cod CHAR(10)  NOT NULL
    ,con_typ NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dcr_no,dug_cod,con_typ)
);



CREATE TABLE  mopftm
    (
    exm_no NUMERIC(10) NOT NULL
    dct_no NUMERIC(5) NOT NULL
    ,dos_qty NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (exm_no)
);



CREATE TABLE  mopftr
    (
    exm_no NUMERIC(10) NOT NULL
    itm CHAR(2)  NOT NULL
    ,ref_val NUMERIC(5,2)  NOT NULL
    ,pre_mea NUMERIC(5,2)  NOT NULL
    ,pst_mea NUMERIC(5,2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (exm_no,itm)
);



CREATE TABLE  mrbatbor
    (
    chart NUMERIC(10) NOT NULL
    src_typ CHAR(2)  NOT NULL
    ,dat DATE NOT NULL
    ,tim NUMERIC(5) NOT NULL
    ,bor CHAR(2)  NOT NULL
    ,bor_man NUMERIC(5) NOT NULL
    ,bor_use CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,bat_num NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,src_typ,dat,bor_man)
);



CREATE TABLE  qmamicr
    (
    vsn NUMERIC(10) NOT NULL
    dct_no NUMERIC(10) NOT NULL
    ,flf_nrs NUMERIC(10) NOT NULL
    ,exp_iln CHAR(2)  NOT NULL
    ,ptn_frm CHAR(2)  NOT NULL
    ,fde_scr NUMERIC(5) NOT NULL
    ,fde_fix CHAR(2)  NOT NULL
    ,pan_scr NUMERIC(5) NOT NULL
    ,pln_way CHAR(2)  NOT NULL
    ,ner_tim TIMESTAMP NOT NULL
    ,pel_tim TIMESTAMP
    ,arv_tim TIMESTAMP NOT NULL
    ,dbl_tim TIMESTAMP NOT NULL
    ,cpt_lsn CHAR(2)  NOT NULL
    ,pci_tmi CHAR(2)  NOT NULL
    ,pci_cbg CHAR(2)  NOT NULL
    ,cdc_drt CHAR(2)  NOT NULL
    ,dwt_tim TIMESTAMP
    ,tit_dsc CHAR(40)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn)
);



CREATE TABLE  qmamier
    (
    vsn NUMERIC(10) NOT NULL
    dct_no NUMERIC(5) NOT NULL
    ,flf_nrs NUMERIC(5) NOT NULL
    ,crd_num NUMERIC(5)
    ,ctc_dgr CHAR(2)  NOT NULL
    ,adm_way CHAR(2)  NOT NULL
    ,atk_tim TIMESTAMP NOT NULL
    ,arv_tim TIMESTAMP NOT NULL
    ,ekg_tim TIMESTAMP NOT NULL
    ,ncd_tim TIMESTAMP
    ,nod_tim TIMESTAMP
    ,ncn_tim TIMESTAMP
    ,ncp_tim TIMESTAMP NOT NULL
    ,cda_tim TIMESTAMP
    ,oda_tim TIMESTAMP
    ,cna_tim TIMESTAMP
    ,cpa_tim TIMESTAMP
    ,emr_drt CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn)
);



CREATE TABLE  qmamir2
    (
    vsn NUMERIC(10) NOT NULL
    itm_cls NUMERIC(5) NOT NULL
    ,sel_itm CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn,itm_cls,sel_itm)
);



CREATE TABLE  qmothr
    (
    vsn NUMERIC(10) NOT NULL
    itm_no NUMERIC(5) NOT NULL
    ,oth_cmt CHAR(200)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn,itm_no)
);



CREATE TABLE  osrec
    (
    order_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (order_no,seq_no)
);



CREATE TABLE  psdsdiv
    (
    emp_no NUMERIC(5) NOT NULL
    div_no NUMERIC(5) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (emp_no,div_no,eff_dat)
);



CREATE TABLE  pswtmd
    (
    div_no NUMERIC(5) NOT NULL
    emp_no NUMERIC(5) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (div_no,emp_no,eff_dat)
);



CREATE TABLE  eaieb
    (
    eva_no NUMERIC(10) NOT NULL
    div_no NUMERIC(10)
    ,eva_nam CHAR(120)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (eva_no)
);



CREATE TABLE  eaeir1
    (
    rec_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,eff_man NUMERIC(5) NOT NULL
    ,stp_man NUMERIC(5) NOT NULL
    ,stp_rsn CHAR(2)
    ,ftr_nat CHAR(2)  NOT NULL
    ,mtr_nat CHAR(2)  NOT NULL
    ,ftr_edc CHAR(2)  NOT NULL
    ,mtr_edc CHAR(2)  NOT NULL
    ,cas_frm CHAR(2)  NOT NULL
    ,eva_hty CHAR(2)  NOT NULL
    ,eis_txt text NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  eaeir2
    (
    itm_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  eaeipr
    (
    rec_no NUMERIC(10) NOT NULL
    rec_man NUMERIC(5) NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no,rec_tim)
);



CREATE TABLE  npbfr
    (
    vsn NUMERIC(10) NOT NULL
    dty_nrs NUMERIC(5) NOT NULL
    ,flf_nrs NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,adm_way CHAR(2)  NOT NULL
    ,mrt_sts CHAR(2)  NOT NULL
    ,rsd_sts CHAR(2)  NOT NULL
    ,edc_lvl CHAR(2)  NOT NULL
    ,ocp CHAR(2)  NOT NULL
    ,mlt CHAR(2)
    ,fml_pdg text
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn)
);



CREATE TABLE  npbfr2
    (
    vsn NUMERIC(10) NOT NULL
    itm_cls NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,sel_itm CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn,itm_cls,tsc,sel_itm)
);



CREATE TABLE  npfr
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,cls_typ CHAR(4)  NOT NULL
    ,rec_sts CHAR(2)
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,qty NUMERIC(6,1)
    ,itm_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  npfrdi
    (
    di_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(5) NOT NULL
    ,tsc CHAR(2)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (di_no)
);



CREATE TABLE  nposs
    (
    cls_typ CHAR(2)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(40)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cls_typ,itm_no)
);



CREATE TABLE  npoth
    (
    vsn NUMERIC(10) NOT NULL
    itm_no NUMERIC(5) NOT NULL
    ,oth_cmt CHAR(120)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn,itm_no)
);



CREATE TABLE  nppahr
    (
    adm_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,adm_dat CHAR(14)  NOT NULL
    ,hpt_no NUMERIC(10,0)  NOT NULL
    ,adm_rsn CHAR(200)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (adm_no)
);



CREATE TABLE  nppecm
    (
    ect_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,ect_seq NUMERIC(5) NOT NULL
    ,ect_nam CHAR(24)  NOT NULL
    ,ect_rlt1 CHAR(24)
    ,ect_tlp1 NUMERIC(10) NOT NULL
    ,ect_tlp2 NUMERIC(10) NOT NULL
    ,ect_mbl1 NUMERIC(10) NOT NULL
    ,ect_mbl2 NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ect_no)
);



CREATE TABLE  nppohr
    (
    opr_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,opr_dat CHAR(14)  NOT NULL
    ,hpt_no NUMERIC(10,0)  NOT NULL
    ,opr_nam CHAR(200)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (opr_no)
);



CREATE TABLE  nprr
    (
    cls_typ CHAR(4)  NOT NULL
    itm_no NUMERIC(5) NOT NULL
    ,itm_nam CHAR(100)
    ,itm_pct NUMERIC(5,2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cls_typ,itm_no)
);



CREATE TABLE  mecmc
    (
    cve_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,cve_man NUMERIC(5) NOT NULL
    ,act_man NUMERIC(5) NOT NULL
    ,met_tim TIMESTAMP NOT NULL
    ,met_loc CHAR(32)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rpy_lmt NUMERIC(5) NOT NULL
    ,not_rec text
    ,cls_tim TIMESTAMP NOT NULL
    ,cls_rsn CHAR(2)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cve_no)
);



CREATE TABLE  mecmm
    (
    mbr_no NUMERIC(10)  NOT NULL
    cve_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,pre_dpt NUMERIC(5) NOT NULL
    ,pre_man NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,msg_sts CHAR(4)  NOT NULL
    ,exe_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mbr_no)
);



CREATE TABLE  meccr
    (
    ccr_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,cse_rul CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cve_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ccr_no)
);



CREATE TABLE  mecms
    (
    sch_no NUMERIC(10)  NOT NULL
    sch_dat DATE NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,dpt_no NUMERIC(5) NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,seq CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sch_no)
);



CREATE TABLE  moccdi
    (
    ccd_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,itm CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ccd_no)
);



CREATE TABLE  mrlet
    (
    chart NUMERIC(10) NOT NULL
    ent_dat DATE NOT NULL
    ,ent_tim NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart)
);



CREATE TABLE  nhocmd
    (
    div_no NUMERIC(5) NOT NULL
    eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (div_no,eff_dat)
);



CREATE TABLE  nhocmp
    (
    id_no CHAR(20)  NOT NULL
    eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (id_no,eff_dat)
);



CREATE TABLE  nppm
    (
    chart NUMERIC(10) NOT NULL
    eff_dat DATE NOT NULL
    ,eff_hm NUMERIC(5)
    ,rsn CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,eff_dat,eff_hm,rsn,tsc)
);



CREATE TABLE  mocclog
    (
    log_tim TIMESTAMP
    emp_no NUMERIC(5) NOT NULL
    ,vsn NUMERIC(10) NOT NULL
    ,typ NUMERIC(10) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  icpab
    (
    map_no NUMERIC(5) NOT NULL
    eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,oln_acd CHAR(2)
    ,pst_acd CHAR(2)
    ,pnt_in CHAR(2)  NOT NULL
    ,pnt_out CHAR(2)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (map_no,eff_dat)
);



CREATE TABLE  cgctr
    (
    rec_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,visit_no NUMERIC(11,0)  NOT NULL
    ,tst_typ CHAR(2)  NOT NULL
    ,val_old CHAR(16)
    ,val_new CHAR(16)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  npdphra
    (
    ast_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,ast_dat DATE NOT NULL
    ,ast_tim NUMERIC(5) NOT NULL
    ,ast_nrs NUMERIC(5) NOT NULL
    ,ast_frm CHAR(2)  NOT NULL
    ,tsc CHAR(2)
    ,age CHAR(2)  NOT NULL
    ,sen_gcs CHAR(2)  NOT NULL
    ,emv CHAR(6)  NOT NULL
    ,liv_adl CHAR(2)  NOT NULL
    ,lmb_fun CHAR(2)  NOT NULL
    ,nrp_adm CHAR(2)  NOT NULL
    ,use_rpt CHAR(2)  NOT NULL
    ,enm CHAR(2)  NOT NULL
    ,cut_cab CHAR(2)  NOT NULL
    ,car_abt CHAR(2)  NOT NULL
    ,car_typ CHAR(2)  NOT NULL
    ,lng_tub CHAR(2)  NOT NULL
    ,ast_rcv CHAR(2)  NOT NULL
    ,rsn_rcv CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ast_no)
);



CREATE TABLE  npfdhra
    (
    ast_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,ast_dat DATE NOT NULL
    ,ast_tim NUMERIC(5) NOT NULL
    ,ast_nrs NUMERIC(5) NOT NULL
    ,tsc CHAR(2)
    ,age CHAR(2)  NOT NULL
    ,fd_hst CHAR(2)  NOT NULL
    ,sns_sts CHAR(2)  NOT NULL
    ,act_sts CHAR(2)  NOT NULL
    ,ntt_sts CHAR(2)  NOT NULL
    ,sen_hnd CHAR(2)  NOT NULL
    ,slf_knw CHAR(2)  NOT NULL
    ,use_dug CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ast_no)
);



CREATE TABLE  nppshra
    (
    ast_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,ast_dat DATE NOT NULL
    ,ast_tim NUMERIC(5) NOT NULL
    ,ast_nrs NUMERIC(5) NOT NULL
    ,tsc CHAR(2)
    ,fee_lvl CHAR(2)  NOT NULL
    ,hum_lvl CHAR(2)  NOT NULL
    ,act_pwr CHAR(2)  NOT NULL
    ,trn_pwr CHAR(2)  NOT NULL
    ,ntt_sts CHAR(2)  NOT NULL
    ,fcn_cut CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ast_no)
);



CREATE TABLE  modcuicd
    (
    dcu_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,icd_cod CHAR(12)  NOT NULL
    ,cnt NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dcu_no)
);



CREATE TABLE  nhdaig
    (
    nhi_cod CHAR(24)  NOT NULL
    grp_cod CHAR(24)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (nhi_cod)
);



CREATE TABLE  nhdpaipr
    (
    id_no CHAR(20)  NOT NULL
    apl_dat DATE NOT NULL
    ,grp_cod CHAR(24)  NOT NULL
    ,pos CHAR(4)  NOT NULL
    ,typ CHAR(2)
    ,sts CHAR(2)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (id_no,apl_dat,grp_cod,pos)
);



CREATE TABLE  hcpirr
    (
    id_no CHAR(20)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,rrd DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (id_no,typ)
);



CREATE TABLE  modibd
    (
    cod CHAR(14)  NOT NULL
    itm CHAR(6)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,nam CHAR(300)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cod,itm,eff_dat)
);



CREATE TABLE  mmreq2
    (
    sed_no NUMERIC(10) NOT NULL
    rcv_man NUMERIC(5) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,lnk_no1 NUMERIC(10) NOT NULL
    ,lnk_no2 NUMERIC(10) NOT NULL
    ,nrs_man NUMERIC(5) NOT NULL
    ,nrs_tim TIMESTAMP NOT NULL
    ,exe_tim TIMESTAMP NOT NULL
    ,exe_rsn CHAR(2)  NOT NULL
    ,cmt CHAR(256)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sed_no)
);



CREATE TABLE  npieb
    (
    eva_no NUMERIC(10)  NOT NULL
    div_no NUMERIC(5) NOT NULL
    ,msr_no CHAR(18)  NOT NULL
    ,det_no CHAR(16)  NOT NULL
    ,tbl_rel CHAR(2)  NOT NULL
    ,eva_nam CHAR(500)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (eva_no)
);



CREATE TABLE  qmerm
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,frm_no NUMERIC(10) NOT NULL
    ,frm CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  qmged
    (
    itm_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,eva_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  qmhss
    (
    hss_no NUMERIC(10)  NOT NULL
    frm_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,hss_1a CHAR(2)  NOT NULL
    ,hss_1b CHAR(2)  NOT NULL
    ,hss_1c CHAR(2)  NOT NULL
    ,hss_2 CHAR(2)  NOT NULL
    ,hss_3 CHAR(2)  NOT NULL
    ,hss_4 CHAR(2)  NOT NULL
    ,hss_5a CHAR(2)  NOT NULL
    ,hss_5b CHAR(2)  NOT NULL
    ,hss_6a CHAR(2)  NOT NULL
    ,hss_6b CHAR(2)  NOT NULL
    ,hss_7 CHAR(2)  NOT NULL
    ,hss_8 CHAR(2)  NOT NULL
    ,hss_9 CHAR(2)  NOT NULL
    ,hss_10 CHAR(2)  NOT NULL
    ,hss_11 CHAR(2)  NOT NULL
    ,mrs CHAR(2)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (hss_no)
);



CREATE TABLE  qmols
    (
    itm_no NUMERIC(10) NOT NULL
    oth_dsc CHAR(240)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  qmoss
    (
    itm_no NUMERIC(10) NOT NULL
    oth_dsc CHAR(40)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  qmqrl
    (
    log_no NUMERIC(10)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_no)
);



CREATE TABLE  qmserd
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,crd_num NUMERIC(5)
    ,ill_tim TIMESTAMP NOT NULL
    ,arv_tim TIMESTAMP NOT NULL
    ,fds_tim TIMESTAMP
    ,cva_3hr CHAR(2)  NOT NULL
    ,gcs CHAR(6)  NOT NULL
    ,tpt CHAR(10)  NOT NULL
    ,pls NUMERIC(5) NOT NULL
    ,btr NUMERIC(5) NOT NULL
    ,sps CHAR(10)  NOT NULL
    ,dps CHAR(10)  NOT NULL
    ,cto_tim TIMESTAMP NOT NULL
    ,cte_tim TIMESTAMP NOT NULL
    ,tmb_rgl CHAR(2)  NOT NULL
    ,ndv CHAR(2)  NOT NULL
    ,nte_tim TIMESTAMP NOT NULL
    ,ndv_tim TIMESTAMP NOT NULL
    ,eok_tim TIMESTAMP NOT NULL
    ,ijt_tpa CHAR(2)  NOT NULL
    ,rtm_tim TIMESTAMP NOT NULL
    ,atm_tim TIMESTAMP NOT NULL
    ,lbo_tim TIMESTAMP NOT NULL
    ,lbr_tim TIMESTAMP NOT NULL
    ,tpa_tim TIMESTAMP NOT NULL
    ,ijt_tim TIMESTAMP NOT NULL
    ,tpa_bds CHAR(10)  NOT NULL
    ,tpa_tds CHAR(10)  NOT NULL
    ,bld CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  qmsicr
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,stp_rsn CHAR(2)  NOT NULL
    ,lpd CHAR(2)  NOT NULL
    ,ecg CHAR(2)  NOT NULL
    ,acl_in CHAR(2)  NOT NULL
    ,trb_in CHAR(2)  NOT NULL
    ,dsd_in CHAR(2)  NOT NULL
    ,acl_out CHAR(2)  NOT NULL
    ,trb_out CHAR(2)  NOT NULL
    ,dsd_out CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  moilar
    (
    icu_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,in_dat DATE NOT NULL
    ,in_hm NUMERIC(5) NOT NULL
    ,room CHAR(8)  NOT NULL
    ,bed CHAR(4)  NOT NULL
    ,rec_days NUMERIC(5) NOT NULL
    ,dct_man NUMERIC(5) NOT NULL
    ,rcd_man NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,sol_mtd CHAR(400)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (icu_no)
);



CREATE TABLE  moilaod
    (
    itm_no NUMERIC(10) NOT NULL
    oth_dsc CHAR(200)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  moilari
    (
    itm_no NUMERIC(10)  NOT NULL
    icu_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,itm CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  mmcai
    (
    itm_no NUMERIC(10)  NOT NULL
    set_no NUMERIC(10) NOT NULL
    ,itm_typ NUMERIC(5) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,val_hgh CHAR(10)  NOT NULL
    ,val_low CHAR(10)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (set_no,itm_typ,eff_tim)
);



CREATE TABLE  mmcap
    (
    set_no NUMERIC(10) NOT NULL
    ctt_typ NUMERIC(5) NOT NULL
    ,ctt_man NUMERIC(5) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (set_no,ctt_typ,eff_tim)
);



CREATE TABLE  mmcam
    (
    set_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,typ_no NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,eff_man NUMERIC(5) NOT NULL
    ,stp_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (set_no)
);



CREATE TABLE  dgpar
    (
    par_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10)
    ,vsn NUMERIC(10) NOT NULL
    ,tsc CHAR(2)
    ,drg_dat DATE NOT NULL
    ,par_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (par_no)
);



CREATE TABLE  dgpad
    (
    par_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,rlt CHAR(2)  NOT NULL
    ,cod CHAR(10)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (par_no,seq_no)
);



CREATE TABLE  dgpadsc
    (
    par_no NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,rlt CHAR(2)  NOT NULL
    ,dsc CHAR(120)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (par_no,seq_no)
);



CREATE TABLE  smedos
    (
    yymm NUMERIC(10) NOT NULL
    dct NUMERIC(5) NOT NULL
    ,qty_o NUMERIC(5) NOT NULL
    ,qty_t NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (yymm,dct)
);



CREATE TABLE  mrqar
    (
    chart NUMERIC(10) NOT NULL
    dat DATE NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,val CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,dat,typ)
);



CREATE TABLE  oscphc
    (
    cph_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,hgh NUMERIC(4,1)  NOT NULL
    ,wgh NUMERIC(4,1)  NOT NULL
    ,hc NUMERIC(4,1)  NOT NULL
    ,hlt_est CHAR(2)  NOT NULL
    ,grw_est CHAR(2)  NOT NULL
    ,bdy_chk CHAR(2)  NOT NULL
    ,dvp_est CHAR(2)  NOT NULL
    ,spc_mrk CHAR(60)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn)
);



CREATE TABLE  oscphaitm
    (
    cph_no NUMERIC(10) NOT NULL
    cod CHAR(6)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cph_no,cod)
);



CREATE TABLE  cgnam
    (
    chg_cod CHAR(14)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,nam CHAR(160)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chg_cod,typ)
);



CREATE TABLE  moval
    (
    lnk_num NUMERIC(10) NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,val NUMERIC(10) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (lnk_num,seq_no)
);



CREATE TABLE  cgcid
    (
    cid_no NUMERIC(10)  NOT NULL
    charg_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,vit_typ CHAR(2)  NOT NULL
    ,rec_typ CHAR(4)  NOT NULL
    ,rec_dat CHAR(40)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cid_no)
);



CREATE TABLE  meacr
    (
    acr_no NUMERIC(10)  NOT NULL
    src CHAR(2)
    ,lnk_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,acr_man NUMERIC(5) NOT NULL
    ,acr_rul CHAR(2)  NOT NULL
    ,acr_dsc CHAR(120)
    ,acr_tim TIMESTAMP NOT NULL
    ,tch_cse CHAR(2)
    ,rcv_no NUMERIC(10) NOT NULL
    ,rcv_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (acr_no)
);



CREATE TABLE  mecmr
    (
    rcv_no NUMERIC(10)  NOT NULL
    src CHAR(2)
    ,lnk_no NUMERIC(10) NOT NULL
    ,hst_man NUMERIC(5)
    ,cvn_man NUMERIC(5) NOT NULL
    ,met_loc CHAR(40)  NOT NULL
    ,met_txt text
    ,met_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cls_rsn CHAR(2)
    ,cls_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rcv_no)
);



CREATE TABLE  mecmp
    (
    psn_no NUMERIC(10)  NOT NULL
    rcv_no NUMERIC(10) NOT NULL
    ,pre_man CHAR(20)
    ,exe_man CHAR(20)
    ,typ CHAR(4)
    ,eat CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (psn_no)
);



CREATE TABLE  megmc
    (
    rcd_no NUMERIC(10)  NOT NULL
    rcv_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,days NUMERIC(5) NOT NULL
    ,est CHAR(2)  NOT NULL
    ,sgt CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rcd_no)
);



CREATE TABLE  mesrr
    (
    rcd_no NUMERIC(10)  NOT NULL
    rcv_no NUMERIC(10) NOT NULL
    ,sex CHAR(2)
    ,age CHAR(2)
    ,typ CHAR(40)
    ,mut_div CHAR(2)
    ,tsc CHAR(2)  NOT NULL
    ,dct_atd CHAR(2)  NOT NULL
    ,nrs_atd CHAR(2)  NOT NULL
    ,oth_atd CHAR(2)  NOT NULL
    ,oth_psn CHAR(40)  NOT NULL
    ,pat_lis CHAR(2)  NOT NULL
    ,dtl_see CHAR(2)  NOT NULL
    ,pfn_abt CHAR(2)  NOT NULL
    ,trt_ste CHAR(2)  NOT NULL
    ,asp_pvt CHAR(2)  NOT NULL
    ,idl_hdl CHAR(2)  NOT NULL
    ,cpl_hdl CHAR(2)  NOT NULL
    ,cms_dos CHAR(2)
    ,cms_pud CHAR(2)
    ,cms_utp CHAR(2)
    ,cms_ncp CHAR(2)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rcd_no)
);



CREATE TABLE  emtemr
    (
    emr_no NUMERIC(10)  NOT NULL
    emr_typ CHAR(4)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,cmp_man NUMERIC(5) NOT NULL
    ,cmp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,tsf_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (emr_no)
);



CREATE TABLE  qmcpr
    (
    rcd_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rcd_no)
);



CREATE TABLE  moipar
    (
    evt_no NUMERIC(10)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,act_typ CHAR(2)  NOT NULL
    ,sts CHAR(2)
    ,act_man NUMERIC(5) NOT NULL
    ,act_dat DATE
    ,act_hm NUMERIC(5)
    ,act_loc NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  mocdtc
    (
    itm_cod1 CHAR(14)  NOT NULL
    itm_cod2 CHAR(14)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,ratio NUMERIC(6,2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_cod1,itm_cod2,tc)
);



CREATE TABLE  mocori
    (
    ptc_cod CHAR(14)  NOT NULL
    tc CHAR(2)  NOT NULL
    ,itm_nam CHAR(100)  NOT NULL
    ,tmt_cyc CHAR(510)  NOT NULL
    ,idc_lst CHAR(510)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ptc_cod)
);



CREATE TABLE  mocodi
    (
    ptc_no NUMERIC(10)  NOT NULL
    ptc_cod CHAR(14)  NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,itm_cod CHAR(14)  NOT NULL
    ,itm_grp CHAR(2)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,dos_qty CHAR(10)  NOT NULL
    ,dos_unt CHAR(10)  NOT NULL
    ,use_usg CHAR(12)  NOT NULL
    ,day NUMERIC(5) NOT NULL
    ,dly_day NUMERIC(5) NOT NULL
    ,way CHAR(12)  NOT NULL
    ,spd CHAR(60)  NOT NULL
    ,cmt CHAR(320)
    ,drp_cod CHAR(14)  NOT NULL
    ,int_drp CHAR(2)  NOT NULL
    ,drp_way CHAR(4)  NOT NULL
    ,dlt_vlm CHAR(10)  NOT NULL
    ,dlt_unt CHAR(10)  NOT NULL
    ,max_qty CHAR(10)  NOT NULL
    ,one_qty CHAR(10)  NOT NULL
    ,llg_qty CHAR(10)  NOT NULL
    ,low_dlt CHAR(10)  NOT NULL
    ,hgh_dlt CHAR(10)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ptc_no)
);



CREATE TABLE  mocdqo
    (
    itm_cod CHAR(14)  NOT NULL
    low_qty CHAR(10)  NOT NULL
    ,hgh_qty CHAR(10)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,inc_qty CHAR(10)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_cod,low_qty)
);



CREATE TABLE  moppr
    (
    rec_tim TIMESTAMP
    emp_no NUMERIC(5) NOT NULL
    ,fun_no CHAR(8)  NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,rec_typ CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_tim,emp_no)
);



CREATE TABLE  dgingc
    (
    dug_cod CHAR(14)  NOT NULL
    ing CHAR(40)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,tot NUMERIC(10,3)  NOT NULL
    ,tot_unt CHAR(20)  NOT NULL
    ,vlm NUMERIC(6,1)  NOT NULL
    ,vlm_unt CHAR(20)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dug_cod,ing)
);



CREATE TABLE  mools3
    (
    itm_no NUMERIC(10) NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,oth_dsc CHAR(200)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no,cls_typ)
);



CREATE TABLE  moieb
    (
    itm_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,cls_typ CHAR(2)  NOT NULL
    ,itm CHAR(2)  NOT NULL
    ,val CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  mored
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,cls_typ CHAR(2)  NOT NULL
    ,rsn CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  cgflag
    (
    chg_cod CHAR(14)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5)
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chg_cod,typ,eff_dat)
);



CREATE TABLE  nperm
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,frq CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10)
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  npdds
    (
    cls_typ CHAR(2)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cls_typ,itm_no)
);



CREATE TABLE  npiebom
    (
    eva_no NUMERIC(10) NOT NULL
    typ CHAR(2)  NOT NULL
    ,own_no CHAR(10)  NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (eva_no,typ,own_no)
);



CREATE TABLE  npols
    (
    cls_typ CHAR(2)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(240)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cls_typ,itm_no)
);



CREATE TABLE  nprf
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,nqu_no NUMERIC(10)
    ,rec_man NUMERIC(5) NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_sts CHAR(2)  NOT NULL
    ,rec_txt text NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  npder
    (
    nqu_no NUMERIC(10) NOT NULL
    typ CHAR(2)  NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,eva_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (nqu_no,eva_no)
);



CREATE TABLE  npged
    (
    itm_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,eva_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  npnrl
    (
    log_no NUMERIC(10)  NOT NULL
    rec_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_no)
);



CREATE TABLE  npqbd
    (
    nqu_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,frm_no NUMERIC(10)
    ,eff_man NUMERIC(5) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,stp_man NUMERIC(5) NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (nqu_no)
);



CREATE TABLE  oritmlog
    (
    ord_no NUMERIC(10) NOT NULL
    opr_ord NUMERIC(10) NOT NULL
    ,dat_s DATE NOT NULL
    ,thm_s NUMERIC(5) NOT NULL
    ,dat_e DATE NOT NULL
    ,thm_e NUMERIC(5) NOT NULL
    ,mark CHAR(2)  NOT NULL
    ,opr_typ CHAR(2)  NOT NULL
    ,o_i CHAR(2)  NOT NULL
    ,ane_typ CHAR(2)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ord_no)
);



CREATE TABLE  orexec2
    (
    rec_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,eff_tim TIMESTAMP
    ,emp_no NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  cgidcv
    (
    chg_cod CHAR(14)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,way CHAR(2)  NOT NULL
    ,val NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chg_cod,typ,eff_dat)
);



CREATE TABLE  cgidct
    (
    typ CHAR(4)  NOT NULL
    nam CHAR(120)  NOT NULL
    ,cmt CHAR(200)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (typ)
);



CREATE TABLE  npsvr
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,val CHAR(20)  NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  npsvir
    (
    itm_no NUMERIC(10) NOT NULL
    itm_nam CHAR(200)  NOT NULL
    ,itm_unt CHAR(24)
    ,lvl CHAR(20)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  sdrsc
    (
    rsc_num NUMERIC(10)  NOT NULL
    rsc_typ NUMERIC(5) NOT NULL
    ,ppt_no NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,nam CHAR(40)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rsc_num)
);



CREATE TABLE  sdmis
    (
    mis_num NUMERIC(10)  NOT NULL
    rsc_num NUMERIC(10) NOT NULL
    ,nam CHAR(90)  NOT NULL
    ,cst_tim NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mis_num)
);



CREATE TABLE  sdrule
    (
    rul_num NUMERIC(10)  NOT NULL
    lnk_num NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,sat_val CHAR(20)  NOT NULL
    ,end_val CHAR(20)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rul_num)
);



CREATE TABLE  sdcal
    (
    evt_num NUMERIC(10)  NOT NULL
    tsc CHAR(2)  NOT NULL
    ,sub CHAR(40)  NOT NULL
    ,lnk_typ CHAR(2)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,mis_num NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,pmt CHAR(2)  NOT NULL
    ,coment CHAR(2000)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_num)
);



CREATE TABLE  emerda
    (
    emr_no NUMERIC(10)  NOT NULL
    act_dat DATE NOT NULL
    ,emr_typ CHAR(6)
    ,map_no NUMERIC(5) NOT NULL
    ,his_cnt NUMERIC(10) NOT NULL
    ,hte_cnt NUMERIC(10) NOT NULL
    ,emr_cnt NUMERIC(10) NOT NULL
    ,snt_cnt NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (emr_no)
);



CREATE TABLE  nppfdhra
    (
    ast_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,ast_dat DATE NOT NULL
    ,ast_tim NUMERIC(5) NOT NULL
    ,ast_nrs NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,age CHAR(2)  NOT NULL
    ,dis_fac CHAR(2)  NOT NULL
    ,fd_hst CHAR(2)  NOT NULL
    ,env_fct CHAR(2)  NOT NULL
    ,or_sts CHAR(2)  NOT NULL
    ,use_dug CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ast_no)
);



CREATE TABLE  dglleqr
    (
    evt_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,ord_dat DATE NOT NULL
    ,ord_man NUMERIC(5) NOT NULL
    ,exe_qty NUMERIC(5,1)  NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  moicda
    (
    icd_no NUMERIC(10)  NOT NULL
    dpt_no NUMERIC(5) NOT NULL
    ,icd_nam CHAR(510)  NOT NULL
    ,icd_cod CHAR(256)  NOT NULL
    ,icd_acd text
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (icd_no)
);



CREATE TABLE  molleqr
    (
    evt_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,ord_dat DATE NOT NULL
    ,ord_man NUMERIC(5) NOT NULL
    ,exe_qty NUMERIC(5,1)  NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  mrptar
    (
    apl_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,apl_man NUMERIC(5) NOT NULL
    ,apl_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (apl_no)
);



CREATE TABLE  scptv
    (
    ptv_no NUMERIC(10)  NOT NULL
    scp_no NUMERIC(10) NOT NULL
    ,ptv_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,ptv_rlt CHAR(6)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ptv_no)
);



CREATE TABLE  mocodif
    (
    ptc_no NUMERIC(10)  NOT NULL
    cri_no NUMERIC(10) NOT NULL
    ,ptc_cod CHAR(14)  NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,seq_mrk CHAR(2)
    ,typ CHAR(2)  NOT NULL
    ,itm_cod CHAR(14)  NOT NULL
    ,itm_grp CHAR(2)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,dos_qty CHAR(10)  NOT NULL
    ,dos_unt CHAR(10)  NOT NULL
    ,use_usg CHAR(12)  NOT NULL
    ,day NUMERIC(5) NOT NULL
    ,dly_day NUMERIC(5) NOT NULL
    ,way CHAR(12)  NOT NULL
    ,spd CHAR(60)  NOT NULL
    ,inj_spd NUMERIC(5)
    ,cmt CHAR(320)  NOT NULL
    ,drp_cod CHAR(14)  NOT NULL
    ,int_drp CHAR(2)  NOT NULL
    ,drp_way CHAR(4)  NOT NULL
    ,dlt_vlm CHAR(10)  NOT NULL
    ,dlt_unt CHAR(10)  NOT NULL
    ,max_qty CHAR(10)  NOT NULL
    ,one_qty CHAR(10)  NOT NULL
    ,llg_qty CHAR(10)  NOT NULL
    ,low_dlt CHAR(10)  NOT NULL
    ,hgh_dlt CHAR(10)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ptc_no)
);



CREATE TABLE  bmval
    (
    acc_no NUMERIC(10) NOT NULL
    typ CHAR(4)  NOT NULL
    ,val NUMERIC(7,2)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (acc_no,typ)
);



CREATE TABLE  qmcadrm
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,rec_typ CHAR(4)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  qmcadrd
    (
    itm_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,eva_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  uccwc
    (
    rec_no NUMERIC(10)  NOT NULL
    ccp_no NUMERIC(10) NOT NULL
    ,crd_loc CHAR(2)  NOT NULL
    ,crd_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  ucccp
    (
    ccp_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,cod CHAR(20)  NOT NULL
    ,num NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ccp_no)
);



CREATE TABLE  ocoditm2
    (
    cit_no NUMERIC(10)  NOT NULL
    charg_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cit_no)
);



CREATE TABLE  ucusb
    (
    rec_no NUMERIC(10)  NOT NULL
    emp_no NUMERIC(5) NOT NULL
    ,fun_cod CHAR(8)  NOT NULL
    ,itm_nam CHAR(40)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  ofdedd
    (
    ser_no NUMERIC(10)  NOT NULL
    dat DATE NOT NULL
    ,dct NUMERIC(5) NOT NULL
    ,rdr NUMERIC(5) NOT NULL
    ,nsp NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  psemrnsr
    (
    evt_no NUMERIC(10)  NOT NULL
    emp_no NUMERIC(5) NOT NULL
    ,qit_dat DATE NOT NULL
    ,sgn_sts CHAR(2)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  mopadr
    (
    anc_no NUMERIC(10)  NOT NULL
    ptc_no NUMERIC(10) NOT NULL
    ,val NUMERIC(10) NOT NULL
    ,rsn CHAR(240)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (anc_no)
);



CREATE TABLE  mopcot
    (
    ptc_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,ptc_cod CHAR(14)  NOT NULL
    ,ord_dat DATE NOT NULL
    ,ord_hm NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,pre_cot NUMERIC(5) NOT NULL
    ,cur_cot NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ptc_no)
);



CREATE TABLE  eobaaccount
    (
    ahospitalid CHAR(20)  NOT NULL
    aemployeeid CHAR(20)  NOT NULL
    ,arightfingerprint text
    ,aleftfingerprint text
    ,aaccountid CHAR(20)  NOT NULL
    ,apassword CHAR(64)
    ,aeditnum NUMERIC(4,0)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aemployeeid)
);



CREATE TABLE  eobaaccountrights
    (
    ahospitalid CHAR(20)  NOT NULL
    aaccountid CHAR(20)  NOT NULL
    ,ascreenid CHAR(20)  NOT NULL
    ,acannew CHAR(2)
    ,acanupdate CHAR(2)
    ,acandelete CHAR(2)
    ,acanquery CHAR(2)
    ,acanprint CHAR(2)
    ,acansign CHAR(2)
    ,acanqueryall CHAR(2)
    ,acanprintall CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aaccountid,ascreenid)
);



CREATE TABLE  eobaarrivehospital
    (
    ahospitalid CHAR(20)  NOT NULL
    aarriveid CHAR(4)  NOT NULL
    ,arrivename CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aarriveid)
);



CREATE TABLE  eobabulletinboard
    (
    aid CHAR(8)  NOT NULL
    ahospitalid CHAR(20)  NOT NULL
    ,abulletintype CHAR(4)
    ,atitle TEXT
    ,acontent TEXT
    ,astartdate TIMESTAMP
    ,aenddate TIMESTAMP
    ,aistop CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aid,ahospitalid)
);



CREATE TABLE  eobadivisionrights
    (
    ahospitalid CHAR(20)  NOT NULL
    adivisionid CHAR(20)  NOT NULL
    ,ascreenid CHAR(20)  NOT NULL
    ,acannew CHAR(2)
    ,acanupdate CHAR(2)
    ,acandelete CHAR(2)
    ,acanquery CHAR(2)
    ,acanprint CHAR(2)
    ,acansign CHAR(2)
    ,acanqueryall CHAR(2)
    ,acanprintall CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,adivisionid,ascreenid)
);



CREATE TABLE  eobahospital
    (
    ahospitalid CHAR(20)  NOT NULL
    achinesename VARCHAR(400)
    ,aenglishname VARCHAR(400)
    ,aabbrname VARCHAR(120)
    ,alevelid CHAR(2)
    ,anhihospitalid CHAR(20)
    ,auniformno CHAR(16)
    ,ataxno CHAR(18)
    ,asuperintend CHAR(60)
    ,atel CHAR(40)
    ,afax CHAR(40)
    ,aemail VARCHAR(200)
    ,aweb VARCHAR(200)
    ,azipcode CHAR(6)
    ,aaddress VARCHAR(400)
    ,aisheadhospital CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,apicturedata text
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid)
);



CREATE TABLE  eobahospitallevel
    (
    alevelid CHAR(2)  NOT NULL
    alevelname VARCHAR(120)
    ,anhiapplyid CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (alevelid)
);



CREATE TABLE  eobanhihospital
    (
    anhihospitalid CHAR(20)  NOT NULL
    anhihospitalname VARCHAR(400)
    ,abranch CHAR(4)
    ,aaddress VARCHAR(400)
    ,atelid CHAR(10)
    ,atel CHAR(40)
    ,aspecialtype CHAR(4)
    ,ahospitaltype CHAR(4)
    ,anhihospitaltype VARCHAR(40)
    ,aterminatedate TIMESTAMP
    ,aisteaching CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (anhihospitalid)
);



CREATE TABLE  eobascreen
    (
    ahospitalid CHAR(20)  NOT NULL
    ascreenid CHAR(20)  NOT NULL
    ,ascreenname VARCHAR(40)
    ,ahasnew CHAR(2)
    ,ahasupdate CHAR(2)
    ,ahasdelete CHAR(2)
    ,ahasquery CHAR(2)
    ,ahasprint CHAR(2)
    ,ahassign CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,ascreenid)
);



CREATE TABLE  eobasystemlog
    (
    ano NUMERIC(10)  NOT NULL
    ahospitalid CHAR(20)
    ,aaccountid CHAR(20)
    ,ascreenid CHAR(20)
    ,alogtype CHAR(4)
    ,alogdatetime TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ano)
);



CREATE TABLE  eobatrdetaillist
    (
    ano NUMERIC(10) NOT NULL
    ahospitalid CHAR(20)  NOT NULL
    ,acid CHAR(10)
    ,atid CHAR(8)
    ,attasjudgeid CHAR(8)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ano,ahospitalid)
);



CREATE TABLE  eobatriagecc
    (
    aid CHAR(10)  NOT NULL
    asid CHAR(6)
    ,achinesename VARCHAR(400)
    ,aenglishname VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aid)
);



CREATE TABLE  eobatriagejudge
    (
    aid CHAR(8)  NOT NULL
    achinesename TEXT
    ,aenglishname TEXT
    ,arank5 CHAR(2)
    ,amark CHAR(10)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aid)
);



CREATE TABLE  eobatriagerule
    (
    aid CHAR(6)  NOT NULL
    aitem1 CHAR(6)
    ,alow1 NUMERIC(4,1)
    ,ahigh1 NUMERIC(4,0)
    ,aitem2 CHAR(6)
    ,alow2 NUMERIC(4,1)
    ,ahigh2 NUMERIC(4,0)
    ,aitem3 CHAR(6)
    ,alow3 NUMERIC(4,1)
    ,ahigh3 NUMERIC(4,0)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aid)
);



CREATE TABLE  eobatriagesystem
    (
    aid CHAR(6)  NOT NULL
    achinesename VARCHAR(400)
    ,aenglishname VARCHAR(400)
    ,adepartmentid CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aid)
);



CREATE TABLE  eodebodysystem
    (
    atraumaid CHAR(10)  NOT NULL
    asystemid CHAR(10)  NOT NULL
    ,achinesename VARCHAR(200)
    ,aenglishname VARCHAR(400)
    ,adiseasecname VARCHAR(200)
    ,adiseaseename VARCHAR(400)
    ,asymptomcname VARCHAR(200)
    ,asymptomename VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (atraumaid,asystemid)
);



CREATE TABLE  eodedocumentlog
    (
    ahospitalid CHAR(20)  NOT NULL
    anoid CHAR(4)  NOT NULL
    ,anoname VARCHAR(200)
    ,areturnzero CHAR(2)
    ,apresentno CHAR(30)
    ,amark VARCHAR(800)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,anoid)
);



CREATE TABLE  eodesystemconfig
    (
    ahospitalid CHAR(20)  NOT NULL
    asystemid CHAR(20)  NOT NULL
    ,asystemdescription VARCHAR(400)
    ,asystemvalue CHAR(100)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,asystemid)
);



CREATE TABLE  eotrnursephrase
    (
    ahospitalid CHAR(20)  NOT NULL
    atypeid CHAR(4)  NOT NULL
    ,aphraseid CHAR(32)  NOT NULL
    ,aphrasecontent TEXT
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atypeid,aphraseid)
);



CREATE TABLE  eotrtriagedanger
    (
    ahospitalid CHAR(20)  NOT NULL
    atriageid CHAR(26)  NOT NULL
    ,atriagetimes CHAR(8)  NOT NULL
    ,avisitno VARCHAR(52)
    ,aitema CHAR(2)
    ,aitemb CHAR(2)
    ,aitemc CHAR(2)
    ,aitemd CHAR(2)
    ,aiteme CHAR(2)
    ,aitemf CHAR(2)
    ,aitemg CHAR(2)
    ,aitemh CHAR(2)
    ,aitemi CHAR(2)
    ,aitemj CHAR(2)
    ,aitemk CHAR(2)
    ,aiteml CHAR(2)
    ,aitemm CHAR(2)
    ,aitemn CHAR(2)
    ,aitemo CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atriageid,atriagetimes)
);



CREATE TABLE  eotrtriagereferral
    (
    ahospitalid CHAR(20)  NOT NULL
    atriageid CHAR(26)  NOT NULL
    ,atriagetimes CHAR(8)  NOT NULL
    ,avisitno VARCHAR(52)
    ,areferralorgid CHAR(20)
    ,auserinputorg TEXT
    ,areferralreason CHAR(6)
    ,ahasreferralpaper CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atriageid,atriagetimes)
);



CREATE TABLE  eotrtrlevelcount
    (
    ahospitalid CHAR(20)  NOT NULL
    adate CHAR(16)  NOT NULL
    ,alevel1 NUMERIC(10)
    ,alevel2 NUMERIC(10)
    ,alevel3 NUMERIC(10)
    ,alevel4 NUMERIC(10)
    ,alevel5 NUMERIC(10)
    ,alevel0 NUMERIC(10)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,adate)
);



CREATE TABLE  eotrtrspecialcase
    (
    ahospitalid CHAR(20)  NOT NULL
    atriageid CHAR(26)  NOT NULL
    ,atriagetimes CHAR(8)  NOT NULL
    ,avisitno VARCHAR(52)
    ,aitema CHAR(2)
    ,aitemb CHAR(2)
    ,aitemc CHAR(2)
    ,aitemd CHAR(2)
    ,aiteme CHAR(2)
    ,aitemf CHAR(2)
    ,adateitema TIMESTAMP
    ,adateitemb TIMESTAMP
    ,adateitemc TIMESTAMP
    ,adateitemd TIMESTAMP
    ,adateiteme TIMESTAMP
    ,adateitemf TIMESTAMP
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atriageid,atriagetimes)
);



CREATE TABLE  npqtr
    (
    qtr_no NUMERIC(10)  NOT NULL
    nqu_no NUMERIC(10) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,eva_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (qtr_no)
);



CREATE TABLE  npqtri
    (
    qti_no NUMERIC(10)  NOT NULL
    qtr_no NUMERIC(10) NOT NULL
    ,frm_no NUMERIC(10) NOT NULL
    ,ord_man NUMERIC(5) NOT NULL
    ,ord_tim TIMESTAMP NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,exe_man NUMERIC(5) NOT NULL
    ,exe_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (qti_no)
);



CREATE TABLE  npqtrp
    (
    qtp_no NUMERIC(10)  NOT NULL
    qtr_no NUMERIC(10) NOT NULL
    ,frm_no NUMERIC(10) NOT NULL
    ,ord_man NUMERIC(5) NOT NULL
    ,ord_tim TIMESTAMP NOT NULL
    ,eva_sts CHAR(2)  NOT NULL
    ,pre_tim TIMESTAMP NOT NULL
    ,eva_tim TIMESTAMP NOT NULL
    ,eva_man NUMERIC(5) NOT NULL
    ,eva_rlt CHAR(2)  NOT NULL
    ,eva_dsc NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (qtp_no)
);



CREATE TABLE  npolls
    (
    lls_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(600)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (lls_no)
);



CREATE TABLE  mrsencas
    (
    sst_no NUMERIC(10) NOT NULL
    cas_typ CHAR(2)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sst_no,cas_typ)
);



CREATE TABLE  mrsstmr
    (
    sst_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,eff_man NUMERIC(5) NOT NULL
    ,stp_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sst_no)
);



CREATE TABLE  mrsensar
    (
    aut_no NUMERIC(10)  NOT NULL
    sst_no NUMERIC(10) NOT NULL
    ,aut_man NUMERIC(5) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,aut_rsn CHAR(160)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aut_no)
);



CREATE TABLE  eobapersonalconfig
    (
    ahospitalid CHAR(20)  NOT NULL
    aemployeeid CHAR(20)  NOT NULL
    ,asystemid CHAR(20)  NOT NULL
    ,asystemdescription VARCHAR(400)
    ,asystemvalue CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aemployeeid,asystemid)
);



CREATE TABLE  eoteteacher
    (
    ahospitalid CHAR(20)  NOT NULL
    aid CHAR(20)  NOT NULL
    ,aname VARCHAR(120)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aid)
);



CREATE TABLE  eobaemployee
    (
    ahospitalid CHAR(20)  NOT NULL
    aemployeeid CHAR(20)  NOT NULL
    ,aemployeeidno CHAR(30)
    ,adivisionid CHAR(20)
    ,aprofessionid CHAR(6)
    ,apositionid CHAR(10)
    ,aemployeename VARCHAR(120)
    ,aenglishname VARCHAR(120)
    ,abegindate TIMESTAMP
    ,aenddate TIMESTAMP
    ,abirthday TIMESTAMP
    ,asex CHAR(2)
    ,abloodid CHAR(4)
    ,aphotopath VARCHAR(400)
    ,amaritalstatus CHAR(2)
    ,atel CHAR(40)
    ,amobile CHAR(40)
    ,ahospitalphone CHAR(40)
    ,ahigheducational VARCHAR(200)
    ,azipcode CHAR(6)
    ,aaddress VARCHAR(400)
    ,aregisterzipcode CHAR(6)
    ,aregisteraddress VARCHAR(400)
    ,aemail VARCHAR(200)
    ,acontactname VARCHAR(120)
    ,acontactrelation VARCHAR(120)
    ,acontacttel CHAR(40)
    ,acontactmobile CHAR(40)
    ,acontactaddresszip CHAR(6)
    ,acontactaddress VARCHAR(400)
    ,apicturedata text
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aemployeeid)
);



CREATE TABLE  eosopersonalconfig
    (
    ahospitalid CHAR(20)  NOT NULL
    aemployeeid CHAR(20)  NOT NULL
    ,aafilter VARCHAR(80)
    ,aasequence VARCHAR(80)
    ,aasearchmode CHAR(2)
    ,apfilter VARCHAR(200)
    ,apsequence VARCHAR(120)
    ,apsearchmode CHAR(2)
    ,aisminimizeina CHAR(2)
    ,aisminimizeinp CHAR(2)
    ,aisminimizeins CHAR(2)
    ,aisminimizeino CHAR(2)
    ,aafontsize CHAR(4)
    ,apfontsize CHAR(4)
    ,asfontsize CHAR(4)
    ,aofontsize CHAR(4)
    ,assearchmode CHAR(2)
    ,aosearchmode CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aemployeeid)
);



CREATE TABLE  emsndly
    (
    dly_no NUMERIC(10)  NOT NULL
    eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,dly_man NUMERIC(5) NOT NULL
    ,rsn CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dly_no)
);



CREATE TABLE  eowtpt
    (
    division NUMERIC(5) NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (division)
);



CREATE TABLE  eobldmsg
    (
    msg_num NUMERIC(10)  NOT NULL
    msg text NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (msg_num)
);



CREATE TABLE  bmwtbd
    (
    wbd_num NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,dat DATE NOT NULL
    ,hm NUMERIC(5) NOT NULL
    ,class CHAR(2)  NOT NULL
    ,wbd_wrd CHAR(6)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (wbd_num)
);



CREATE TABLE  moocn
    (
    rec_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,vsn NUMERIC(10) NOT NULL
    ,lnk_no NUMERIC(10)
    ,typ1 CHAR(2)  NOT NULL
    ,typ2 NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,txt text
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  qmeierm
    (
    est_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,sys_typ CHAR(4)  NOT NULL
    ,itm_typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,est_tim TIMESTAMP NOT NULL
    ,est_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (est_no)
);



CREATE TABLE  qmeierd
    (
    itm_no NUMERIC(10)  NOT NULL
    est_no NUMERIC(10) NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,eva_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  eotrtriageepidemic
    (
    ahospitalid CHAR(20)  NOT NULL
    atriageid CHAR(26)  NOT NULL
    ,atriagetimes CHAR(8)  NOT NULL
    ,avisitno VARCHAR(52)
    ,aitema CHAR(2)
    ,aitemb CHAR(2)
    ,aitemc CHAR(2)
    ,aitemd CHAR(2)
    ,aiteme CHAR(2)
    ,aquarantine VARCHAR(800)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atriageid,atriagetimes)
);



CREATE TABLE  eobabedexpand
    (
    ahospitalid CHAR(20)  NOT NULL
    aroomno CHAR(20)  NOT NULL
    ,abedno CHAR(20)  NOT NULL
    ,ailltype CHAR(2)
    ,aisnhibed CHAR(2)
    ,aisudbed CHAR(2)
    ,aguaranteefund NUMERIC(6,0)
    ,aext CHAR(10)
    ,acalculatebedrate CHAR(2)
    ,abedopendate TIMESTAMP
    ,abedclosedate TIMESTAMP
    ,avisitno CHAR(26)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aroomno,abedno)
);



CREATE TABLE  eobabedmap
    (
    ahospitalid CHAR(20)  NOT NULL
    aroomno CHAR(20)  NOT NULL
    ,abedno CHAR(20)  NOT NULL
    ,aisfix CHAR(2)
    ,aishorizontal CHAR(2)
    ,alocationleft FLOAT
    ,alocationtop FLOAT
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aroomno,abedno)
);



CREATE TABLE  eobaroommap
    (
    ahospitalid CHAR(20)  NOT NULL
    aroomno CHAR(20)  NOT NULL
    ,amapname VARCHAR(400)
    ,aftppath VARCHAR(400)
    ,alocationleft FLOAT
    ,alocationtop FLOAT
    ,awidth FLOAT
    ,aheight FLOAT
    ,acolor CHAR(50)
    ,apicturedata text
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aroomno)
);



CREATE TABLE  eobeerptstatus
    (
    aid NUMERIC(10) NOT NULL
    ahospitalid CHAR(20)
    ,avisitno CHAR(26)
    ,achartno CHAR(30)
    ,astatustypeid CHAR(4)
    ,astatusid CHAR(4)
    ,astatus VARCHAR(600)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aid)
);



CREATE TABLE  eobepatientstatus
    (
    ahospitalid CHAR(20)  NOT NULL
    astatusid CHAR(4)  NOT NULL
    ,atypeid CHAR(4)  NOT NULL
    ,achinesename VARCHAR(400)
    ,aenglishname VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,astatusid,atypeid)
);



CREATE TABLE  eodecommontime
    (
    ahospitalid CHAR(20)  NOT NULL
    atimeid CHAR(12)  NOT NULL
    ,atimetypeid CHAR(10)  NOT NULL
    ,aenglishname VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atimeid,atimetypeid)
);



CREATE TABLE  eodecomtimevalue
    (
    ahospitalid CHAR(20)  NOT NULL
    aid NUMERIC(10) NOT NULL
    ,atimeid CHAR(12)  NOT NULL
    ,atimevalueid CHAR(12)  NOT NULL
    ,aenglishname VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,unique  (  aid  )
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aid)
);



CREATE TABLE  eodecontinent
    (
    acontinentid CHAR(10)  NOT NULL
    achinesename VARCHAR(200)
    ,aenglishname VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (acontinentid)
);



CREATE TABLE  eodecontinentarea
    (
    acontinentid CHAR(10)  NOT NULL
    aareaid CHAR(10)  NOT NULL
    ,achinesename VARCHAR(200)
    ,aenglishname VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (acontinentid,aareaid)
);



CREATE TABLE  eodecountry
    (
    acontinentid CHAR(10)  NOT NULL
    aareaid CHAR(10)  NOT NULL
    ,acountryid CHAR(16)  NOT NULL
    ,achinesename VARCHAR(200)
    ,aenglishname VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (acontinentid,aareaid,acountryid)
);



CREATE TABLE  eodestatustype
    (
    ahospitalid CHAR(20)  NOT NULL
    atypeid CHAR(4)  NOT NULL
    ,achinesename VARCHAR(400)
    ,aenglishname VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atypeid)
);



CREATE TABLE  eodierdischargent
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,atriagecontent TEXT
    ,aexceptionalfound TEXT
    ,aadmissiondiag TEXT
    ,amaintreatment TEXT
    ,asuggestions TEXT
    ,ahealthnotices TEXT
    ,aleavereasonid CHAR(4)
    ,aleavereasondesc TEXT
    ,amedicalhistory TEXT
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno)
);



CREATE TABLE  eodierfinaldiag
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aicdid CHAR(12)
    ,achieficdid CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,asequenceno)
);



CREATE TABLE  eodihealthnotice
    (
    ahospitalid CHAR(20)  NOT NULL
    adepartmentid VARCHAR(120)  NOT NULL
    ,atitle VARCHAR(1020)  NOT NULL
    ,acontent TEXT
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,adepartmentid,atitle)
);



CREATE TABLE  eosobodysystemicd9
    (
    ahospitalid CHAR(20)  NOT NULL
    adepartmentid CHAR(20)  NOT NULL
    ,asystemid CHAR(10)  NOT NULL
    ,aicd9id CHAR(24)
    ,atraumaid CHAR(10)  NOT NULL
    ,aitemno CHAR(10)  NOT NULL
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,adepartmentid,asystemid,aicd9id)
);



CREATE TABLE  eosocomallergytype
    (
    ahospitalid CHAR(20)  NOT NULL
    atypeid CHAR(8)  NOT NULL
    ,atypename VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atypeid)
);



CREATE TABLE  eosocomdepartment
    (
    ahospitalid CHAR(20)  NOT NULL
    aid CHAR(20)  NOT NULL
    ,acommontype CHAR(4)  NOT NULL
    ,aispublic CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aid,acommontype)
);



CREATE TABLE  eosocomdrugdetail
    (
    ahospitalid CHAR(20)  NOT NULL
    adepartmentid CHAR(20)  NOT NULL
    ,agroupid CHAR(30)  NOT NULL
    ,adrugid CHAR(30)  NOT NULL
    ,aunit CHAR(20)
    ,afrequencyid CHAR(20)
    ,ameals NUMERIC(4,0)
    ,arouteid CHAR(20)
    ,aday NUMERIC(4,0)
    ,atotalquantity NUMERIC(4,0)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,adepartmentid,agroupid,adrugid)
);



CREATE TABLE  eosocommedicalvoc
    (
    ahospitalid CHAR(20)  NOT NULL
    aid NUMERIC(10)  NOT NULL
    ,avocabularyname VARCHAR(320)
    ,asnomedid CHAR(40)
    ,ausenum NUMERIC(10)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aid)
);



CREATE TABLE  eosocommonallergy
    (
    ahospitalid CHAR(20)  NOT NULL
    aallergytypeid CHAR(10)  NOT NULL
    ,aallergyid CHAR(10)  NOT NULL
    ,achinesename VARCHAR(200)
    ,aenglishname VARCHAR(400)
    ,ausenum NUMERIC(10)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aallergytypeid,aallergyid)
);



CREATE TABLE  eosocommondrug
    (
    ahospitalid CHAR(20)  NOT NULL
    adepartmentid CHAR(20)  NOT NULL
    ,adrugtypeid CHAR(20)  NOT NULL
    ,adrugid CHAR(30)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aisgroup CHAR(2)
    ,aunit VARCHAR(40)
    ,afrequencyid CHAR(20)
    ,ameals NUMERIC(5,2)
    ,arouteid CHAR(20)
    ,aday NUMERIC(4,0)
    ,atotalquantity NUMERIC(10,2)
    ,amapno CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT pk_eosocommondrug PRIMARY KEY (ahospitalid,adepartmentid,adrugtypeid,adrugid,asequenceno)

);



CREATE TABLE  eosocommonexam
    (
    ahospitalid CHAR(20)  NOT NULL
    adepartmentid CHAR(20)  NOT NULL
    ,aexamtypeid CHAR(20)  NOT NULL
    ,aexamid CHAR(30)  NOT NULL
    ,aquantity NUMERIC(4,0)
    ,afrequencyid CHAR(20)
    ,amapno CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,adepartmentid,aexamtypeid,aexamid)
);



CREATE TABLE  eosocommonicd9
    (
    ahospitalid CHAR(20)  NOT NULL
    adepartmentid CHAR(20)  NOT NULL
    ,atypeid CHAR(8)  NOT NULL
    ,aicd9id CHAR(24)
    ,atraumaid CHAR(10)  NOT NULL
    ,aitemno CHAR(10)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,adepartmentid,atypeid,aicd9id)
);



CREATE TABLE  eosocommonicd9type
    (
    ahospitalid CHAR(20)  NOT NULL
    atypeid CHAR(8)  NOT NULL
    ,adepartmentid CHAR(20)
    ,atypename VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atypeid)
);



CREATE TABLE  eosocommonlab
    (
    ahospitalid CHAR(20)  NOT NULL
    adepartmentid CHAR(20)  NOT NULL
    ,alabtypeid CHAR(20)  NOT NULL
    ,alabid CHAR(30)  NOT NULL
    ,aquantity NUMERIC(4,0)
    ,aspecimentypeid CHAR(20)
    ,afrequencyid CHAR(20)
    ,amapno CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,adepartmentid,alabtypeid,alabid)
);



CREATE TABLE  eosocommonlabtype
    (
    ahospitalid CHAR(20)  NOT NULL
    alabtypeid CHAR(20)  NOT NULL
    ,alabtypename VARCHAR(120)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,alabtypeid)
);



CREATE TABLE  eosocommonsymptom
    (
    ahospitalid CHAR(20)  NOT NULL
    atraumaid CHAR(10)  NOT NULL
    ,asystemid CHAR(10)  NOT NULL
    ,asymptomid CHAR(12)  NOT NULL
    ,achinesename VARCHAR(200)
    ,aenglishname VARCHAR(400)
    ,asnomedid CHAR(40)
    ,ausenum NUMERIC(10)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atraumaid,asystemid,asymptomid)
);



CREATE TABLE  eosocommontype
    (
    ahospitalid CHAR(20)  NOT NULL
    atypeid CHAR(8)  NOT NULL
    ,adepartmentid CHAR(20)  NOT NULL
    ,atypename CHAR(200)
    ,aclassification CHAR(4)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atypeid,adepartmentid)
);



CREATE TABLE  eosocomprocedure
    (
    ahospitalid CHAR(20)  NOT NULL
    adepartmentid CHAR(20)  NOT NULL
    ,aproceduretypeid CHAR(20)  NOT NULL
    ,aprocedureid CHAR(30)  NOT NULL
    ,aquantity NUMERIC(4,0)
    ,afrequencyid CHAR(20)
    ,amapno CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT pk_eosocommonproce PRIMARY KEY (ahospitalid,adepartmentid,aproceduretypeid,aprocedureid)

);



CREATE TABLE  eosodrugfirstday
    (
    itemno NUMERIC(10) NOT NULL
    orderno NUMERIC(10) NOT NULL
    ,visitno CHAR(26)  NOT NULL
    ,priceno CHAR(14)  NOT NULL
    ,firstdayqty NUMERIC(5,1)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itemno)
);



CREATE TABLE  eosodrugtype
    (
    ahospitalid CHAR(20)  NOT NULL
    adrugtypeid CHAR(20)  NOT NULL
    ,adrugtypename CHAR(100)
    ,atypeenglishname VARCHAR(240)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,adrugtypeid)
);



CREATE TABLE  eosoernursetpr
    (
    aid NUMERIC(10)  NOT NULL
    ahospitalid CHAR(20)  NOT NULL
    ,avisitno CHAR(26)  NOT NULL
    ,atemperature NUMERIC(4,1)
    ,abreath NUMERIC(4,0)
    ,apulse NUMERIC(4,0)
    ,asbp NUMERIC(4,0)
    ,adbp NUMERIC(4,0)
    ,aweight NUMERIC(5,2)
    ,asao2 NUMERIC(4,0)
    ,agcse CHAR(2)
    ,agcsv CHAR(2)
    ,agcsm CHAR(2)
    ,abloodsugar CHAR(10)
    ,aother1 CHAR(10)
    ,aother2 CHAR(10)
    ,aother3 CHAR(10)
    ,aother4 CHAR(10)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aid)
);



CREATE TABLE  eosoerpatientddesc
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,aadescription text
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,ahisgetdate TIMESTAMP
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes)
);



CREATE TABLE  eosoerpatientdiag
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aitemno NUMERIC(10)
    ,aicd9id CHAR(24)  NOT NULL
    ,achieficd9id CHAR(2)
    ,agreatill CHAR(2)
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,awordstyle CHAR(2)
    ,ahisgetdate TIMESTAMP
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eosoerpatientpdesc
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,apdescription text
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,ahisgetdate TIMESTAMP
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes)
);



CREATE TABLE  eosoerpatientph
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aitemno NUMERIC(10)
    ,atitle VARCHAR(320)
    ,acontent TEXT
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,ahisgetdate TIMESTAMP
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eosoerpatientphl
    (
    ano NUMERIC(10)  NOT NULL
    ahospitalid CHAR(20)
    ,avisitno CHAR(26)
    ,aordertimes CHAR(8)
    ,asequenceno CHAR(10)
    ,aitemno NUMERIC(10)
    ,atitle VARCHAR(320)
    ,acontent TEXT
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ano)
);



CREATE TABLE  eosoerpatientpot
    (
    avsn NUMERIC(10) NOT NULL
    aordertimes CHAR(8)  NOT NULL
    ,aordno NUMERIC(10) NOT NULL
    ,achartno CHAR(30)
    ,avisitno CHAR(26)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (avsn,aordertimes,aordno)
);



CREATE TABLE  eosoerptobject
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aitemno NUMERIC(10)
    ,atitle VARCHAR(320)
    ,acontent TEXT
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,ahisgetdate TIMESTAMP
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eosoerptobjectl
    (
    ano NUMERIC(10)  NOT NULL
    ahospitalid CHAR(20)
    ,avisitno CHAR(26)
    ,aordertimes CHAR(8)
    ,asequenceno CHAR(10)
    ,aitemno NUMERIC(10)
    ,atitle VARCHAR(320)
    ,acontent TEXT
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ano)
);



CREATE TABLE  eosoerptocappic
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,aimagefiles VARCHAR(200)
    ,abodypartid VARCHAR(400)
    ,astatus CHAR(2)
    ,aflag CHAR(2)
    ,ahisgetdate TIMESTAMP
    ,apicturedata text
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,aimagefiles)
);



CREATE TABLE  eosoerptodrawpic
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,aimagefile VARCHAR(200)  NOT NULL
    ,abodypart VARCHAR(400)
    ,astatus CHAR(2)
    ,aflag CHAR(2)
    ,abackgroundfile text
    ,abgimagefile VARCHAR(200)
    ,apicturedata text
    ,ahisgetdate TIMESTAMP
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,aimagefile)
);



CREATE TABLE  eosoerptprotocol
    (
    aid NUMERIC(10) NOT NULL
    ahospitalid CHAR(20)
    ,avisitno CHAR(26)
    ,aordertimes CHAR(8)
    ,aprotocolname VARCHAR(400)
    ,ahtmlname VARCHAR(400)
    ,aflag CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aid)
);



CREATE TABLE  eosoerptsubject
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aitemno NUMERIC(10)
    ,achiefcomplaint TEXT
    ,apresentillness TEXT
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,ahisgetdate TIMESTAMP
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eosonhiicallergy
    (
    ahospitalid CHAR(20)
    achartno CHAR(30)
    ,allergy1 VARCHAR(200)
    ,allergy2 VARCHAR(200)
    ,allergy3 VARCHAR(200)
    ,allergy4 VARCHAR(200)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,achartno)
);



CREATE TABLE  eosonursingwarning
    (
    ahospitalid CHAR(20)  NOT NULL
    asequenceno CHAR(8)  NOT NULL
    ,avisitno CHAR(26)  NOT NULL
    ,acontent TEXT
    ,anurseid CHAR(20)
    ,aisread CHAR(2)
    ,aisdelete CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,asequenceno,avisitno)
);



CREATE TABLE  eosooccupation
    (
    aoccupationid CHAR(10)  NOT NULL
    achinesename VARCHAR(200)
    ,aenglishname VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aoccupationid)
);
CREATE TABLE eosoodrawiistroke ( ahospitalid CHAR(20) not null ainfoid VARCHAR(120) not null ,astrokeindex CHAR(8) not null ,astrokewh CHAR(6) ,astrokecolor CHAR(30) ,astrokepoints TEXT ,acreatedate TIMESTAMP ,acreateuserid CHAR(20) ,amodifydate TIMESTAMP ,amodifyuserid CHAR(20) ,acreatehospitalid CHAR(20) ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP ,PRIMARY KEY (ahospitalid,ainfoid,astrokeindex) );
CREATE TABLE eosoodrawingiitext ( ahospitalid CHAR(20) not null ainfoid VARCHAR(120) not null ,auiindex CHAR(8) not null ,auitext TEXT ,auifontsize CHAR(6) ,auifontcolor CHAR(20) ,auifontleft CHAR(10) ,auifonttop CHAR(10) ,acreatedate TIMESTAMP ,acreateuserid CHAR(20) ,amodifydate TIMESTAMP ,amodifyuserid CHAR(20) ,acreatehospitalid CHAR(20) ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP ,PRIMARY KEY (ahospitalid,ainfoid,auiindex) );



CREATE TABLE  eosopainscore
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,apainscore CHAR(4)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes)
);



CREATE TABLE  eososoapdataforhis
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asubject TEXT
    ,aobject TEXT
    ,aassessment TEXT
    ,aplan TEXT
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes)
);



CREATE TABLE  eososoapmaster
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,apgyid CHAR(20)
    ,avsid CHAR(20)
    ,apgydate TIMESTAMP
    ,aispgyedit CHAR(2)
    ,achartno CHAR(30)
    ,aorderstatus CHAR(2)
    ,ahisgetdate TIMESTAMP
    ,aemrpdfpath TEXT
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes)
);



CREATE TABLE  eososoapuserlog
    (
    aid NUMERIC(10)  NOT NULL
    ahospitalid CHAR(20)
    ,aaccountid CHAR(20)
    ,alogtype CHAR(4)
    ,alogdatetime TIMESTAMP
    ,avisitno CHAR(26)
    ,aordertimes CHAR(8)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aid)
);



CREATE TABLE  eosotempconsult
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,adepartmentid CHAR(20)
    ,adoctorid CHAR(20)
    ,asubjectid CHAR(20)
    ,aconsultcontent TEXT
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid)
);



CREATE TABLE  eosotempdiagnosis
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aicd9id CHAR(24)  NOT NULL
    ,achiefcomplaints CHAR(2)
    ,agreatill CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,typ CHAR(4)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid,asequenceno,typ)
);



CREATE TABLE  eosotemplateadesc
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,aadescription text
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,typ CHAR(4)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid,typ)
);



CREATE TABLE  eosotemplatedrug
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,adrugid CHAR(30)
    ,aunit CHAR(20)
    ,afrequencyid CHAR(20)
    ,ameals NUMERIC(5,2)
    ,arouteid CHAR(20)
    ,aisprivateexpense CHAR(2)
    ,aday NUMERIC(4,0)
    ,atotalquantity NUMERIC(10,2)
    ,aisgrand CHAR(2)
    ,ahasattach CHAR(2)
    ,aflowrapid CHAR(20)
    ,amapno CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid,asequenceno)
);



CREATE TABLE  eosotemplatedrugat
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,adrugid CHAR(30)  NOT NULL
    ,ameals NUMERIC(5,2)
    ,aisprivateexpense CHAR(2)
    ,aunit CHAR(20)
    ,amapno CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid,asequenceno,adrugid)
);



CREATE TABLE  eosotemplateexam
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aexamid CHAR(30)
    ,aquantity NUMERIC(4,0)
    ,apartid CHAR(20)
    ,adirection CHAR(2)
    ,aisurgent CHAR(2)
    ,aisprivateexpense CHAR(2)
    ,aisportable CHAR(2)
    ,areason TEXT
    ,afrequencyid CHAR(20)
    ,amapno CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid,asequenceno)
);



CREATE TABLE  eosotemplatelab
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,alabid CHAR(30)
    ,aquantity NUMERIC(4,0)
    ,aspecimentypeid CHAR(20)
    ,aisurgent CHAR(2)
    ,aisprivateexpense CHAR(2)
    ,afrequencyid CHAR(20)
    ,amapno CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid,asequenceno)
);



CREATE TABLE  eosotemplatemaster
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,asystemid CHAR(10)
    ,adepartmentid CHAR(20)
    ,adoctorid CHAR(20)
    ,asubjectid CHAR(20)
    ,adocumentid CHAR(10)
    ,ausenum NUMERIC(10)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid)
);



CREATE TABLE  eosotemplateobject
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,atitle VARCHAR(120)
    ,acontent TEXT
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid,asequenceno)
);



CREATE TABLE  eosotemplatepdesc
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,adescription text
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid)
);



CREATE TABLE  eosotemplateph
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,atitle VARCHAR(120)
    ,acontent TEXT
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid,asequenceno)
);



CREATE TABLE  eosotempmaterial
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,amaterialid CHAR(30)
    ,aquantity NUMERIC(4,0)
    ,aisprivateexpense CHAR(2)
    ,afrequencyid CHAR(20)
    ,amapno CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid,asequenceno)
);



CREATE TABLE  eosotempprocedure
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aprocedureid CHAR(30)  NOT NULL
    ,aquantity NUMERIC(4,0)
    ,apartid CHAR(20)
    ,adescription VARCHAR(800)
    ,aisurgent CHAR(2)
    ,aisprivateexpense CHAR(2)
    ,afrequencyid CHAR(20)
    ,amapno CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid,asequenceno,aprocedureid)
);



CREATE TABLE  eosotempsubject
    (
    ahospitalid CHAR(20)  NOT NULL
    atemplateid VARCHAR(120)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,achiefcomplaint TEXT
    ,apresentillness TEXT
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atemplateid,asequenceno)
);



CREATE TABLE  eosotimetype
    (
    atimetypeid CHAR(10)  NOT NULL
    achinesename VARCHAR(200)
    ,aenglishname VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (atimetypeid)
);



CREATE TABLE  eosoerptsubjectl
    (
    ano NUMERIC(10)  NOT NULL
    ahospitalid CHAR(20)
    ,avisitno CHAR(26)
    ,aordertimes CHAR(8)
    ,asequenceno CHAR(10)
    ,aitemno NUMERIC(10)
    ,achiefcomplaint TEXT
    ,apresentillness TEXT
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ano)
);



CREATE TABLE  eobaspecimentype
    (
    ahospitalid CHAR(20)  NOT NULL
    aspecimentypeid CHAR(20)  NOT NULL
    ,aspecimentypename VARCHAR(200)
    ,atypeenglishname VARCHAR(200)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,aspecimentypeid)
);



CREATE TABLE  eotrtrpasthistory
    (
    ahospitalid CHAR(20)  NOT NULL
    auserkeyinid VARCHAR(60)  NOT NULL
    ,achartno VARCHAR(60)
    ,aitema CHAR(2)
    ,aitemb CHAR(2)
    ,aitemc CHAR(2)
    ,aitemd CHAR(2)
    ,aiteme CHAR(2)
    ,aitemf CHAR(2)
    ,aitemg CHAR(2)
    ,aitemh CHAR(2)
    ,aitemi CHAR(2)
    ,aitemj CHAR(2)
    ,aitemk CHAR(2)
    ,aiteml CHAR(2)
    ,aitemm CHAR(2)
    ,aitemn CHAR(2)
    ,aitemo CHAR(2)
    ,aitemp CHAR(2)
    ,aitemq CHAR(2)
    ,aitemr CHAR(2)
    ,aitems CHAR(2)
    ,aitemt CHAR(2)
    ,aitemu CHAR(2)
    ,aitemv CHAR(2)
    ,aitemw CHAR(2)
    ,aitemx CHAR(2)
    ,aheartother VARCHAR(400)
    ,adigestionother VARCHAR(400)
    ,aurinaryother VARCHAR(400)
    ,acancerother VARCHAR(400)
    ,abreathingother VARCHAR(400)
    ,ametabolismother VARCHAR(400)
    ,acentralother CHAR(200)
    ,allother CHAR(200)
    ,atetanustype CHAR(2)
    ,aitemaa CHAR(2)
    ,aitemy CHAR(2)
    ,aallergya TEXT
    ,aallergyb TEXT
    ,aallergyc TEXT
    ,aallergyd TEXT
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,auserkeyinid)
);



CREATE TABLE  eosoerpatientdiagl
    (
    ano NUMERIC(10)  NOT NULL
    ahospitalid CHAR(20)
    ,avisitno CHAR(26)
    ,aordertimes CHAR(8)
    ,asequenceno CHAR(10)
    ,aitemno NUMERIC(10)
    ,aicd9id CHAR(24)  NOT NULL
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ano)
);



CREATE TABLE  eosoerrptsubject
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aitemno NUMERIC(10)
    ,achiefcomplaint TEXT
    ,apresentillness TEXT
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,ahisgetdate TIMESTAMP
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eosoerrpatientph
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aitemno NUMERIC(10)
    ,atitle TEXT
    ,acontent TEXT
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eosoerrptobject
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aitemno NUMERIC(10)
    ,atitle TEXT
    ,acontent TEXT
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eosoerrptodrawp
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,aimagefile VARCHAR(200)  NOT NULL
    ,abodypart VARCHAR(400)
    ,astatus CHAR(2)
    ,aflag CHAR(2)
    ,apicturedata text
    ,abackgroundfile text
    ,abgimagefile VARCHAR(200)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,aimagefile)
);



CREATE TABLE  eosoerrptocappic
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,aimagefile VARCHAR(200)  NOT NULL
    ,abodypart VARCHAR(400)
    ,astatus CHAR(2)
    ,aflag CHAR(2)
    ,apicturedata text
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,aimagefile)
);



CREATE TABLE  eosoerrpatientdiag
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aitemno NUMERIC(10)
    ,aicd9id CHAR(24)  NOT NULL
    ,achieficd9id CHAR(2)
    ,agreatill CHAR(2)
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eosoerrptddesc
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,aadescription TEXT
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes)
);



CREATE TABLE  eosoerrptpdesc
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,apdescription TEXT
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes)
);



CREATE TABLE  eosoerrpatientdrug
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,adrugid CHAR(30)
    ,adrugdescription VARCHAR(800)
    ,ameals NUMERIC(5,2)
    ,aunit CHAR(20)
    ,afrequencyid CHAR(20)
    ,arouteid CHAR(20)
    ,aday NUMERIC(5,2)
    ,atotalquantity NUMERIC(10,2)
    ,aexecutestatus CHAR(2)
    ,aisprivateexpense CHAR(2)
    ,aisgrind CHAR(2)
    ,aisattach CHAR(2)
    ,aflowrapid CHAR(20)
    ,areadreporttime TIMESTAMP
    ,areadreportdoctor CHAR(20)
    ,agetdrugno CHAR(20)
    ,astationid CHAR(20)
    ,aisshow CHAR(2)
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eosoerrptdrugat
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,adrugid CHAR(30)  NOT NULL
    ,ameals NUMERIC(5,2)
    ,aunit CHAR(20)
    ,afrequencyid CHAR(20)
    ,arouteid CHAR(20)
    ,aday NUMERIC(5,2)
    ,atotalquantity NUMERIC(10,2)
    ,aflowrapid CHAR(20)
    ,aisprivateexpense CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno,adrugid)
);



CREATE TABLE  eosoerrpatientlab
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,alabid CHAR(30)
    ,aquantity NUMERIC(4,0)
    ,aspecimentypeid CHAR(20)
    ,aisurgent CHAR(2)
    ,astationid CHAR(20)
    ,aprice NUMERIC(6,0)
    ,agetspecimentime TIMESTAMP
    ,aspecimendelivert TIMESTAMP
    ,areportfinishtime TIMESTAMP
    ,areadreporttime TIMESTAMP
    ,areadreportdoctor CHAR(20)
    ,aisprivateexpense CHAR(2)
    ,aexecutestatus CHAR(2)
    ,aisshow CHAR(2)
    ,aexstatus CHAR(2)
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,alabdescription TEXT
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eosoerrpatientexam
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aexamid CHAR(30)
    ,aquantity NUMERIC(4,0)
    ,apartid CHAR(20)
    ,adirection CHAR(2)
    ,aisurgent CHAR(2)
    ,areasons TEXT
    ,areasono TEXT
    ,areasona TEXT
    ,aexstatus CHAR(2)
    ,aexecutestatus CHAR(2)
    ,aisprivateexpense CHAR(2)
    ,aportable CHAR(2)
    ,atoexamtime TIMESTAMP
    ,aexamfinishtime TIMESTAMP
    ,areportfinishtime TIMESTAMP
    ,areadreporttime TIMESTAMP
    ,areadreportdoctor CHAR(20)
    ,astationid CHAR(20)
    ,aisshow CHAR(2)
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,aexamdescription VARCHAR(800)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eosoerrpatientproc
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aprocedureid CHAR(30)
    ,adescription TEXT
    ,aquantity NUMERIC(4,0)
    ,apartid CHAR(20)
    ,aexecutestatus CHAR(2)
    ,aisprivateexpense CHAR(2)
    ,aisurgent CHAR(2)
    ,aprocstarttime TIMESTAMP
    ,aprocfinishtime TIMESTAMP
    ,areadreporttime TIMESTAMP
    ,areadreportdoctor CHAR(20)
    ,aconsultno CHAR(26)
    ,afinishdoctorid CHAR(20)
    ,aphoneanswerdate TIMESTAMP
    ,aphoneansweruserid CHAR(20)
    ,astationid CHAR(20)
    ,aisshow CHAR(2)
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eosoerrpatientmtl
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,amaterialid CHAR(30)
    ,aquantity NUMERIC(4,0)
    ,astationid CHAR(20)
    ,aadvancenotice CHAR(2)
    ,aisprivateexpense CHAR(2)
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eobebedtransfer
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aoldroomno CHAR(20)
    ,aoldbedno CHAR(20)
    ,anewroomno CHAR(20)
    ,anewbedno CHAR(20)
    ,atransferdate TIMESTAMP
    ,atransferempid CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,asequenceno)
);



CREATE TABLE  ntgad
    (
    des_no NUMERIC(10)  NOT NULL
    ass_no NUMERIC(10) NOT NULL
    ,ass_typ CHAR(4)
    ,ass_seq NUMERIC(5) NOT NULL
    ,nut_itm NUMERIC(5) NOT NULL
    ,nut_cmt text NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (des_no)
);



CREATE TABLE  ntgar
    (
    ass_no NUMERIC(10)  NOT NULL
    ass_dat DATE NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,room CHAR(8)  NOT NULL
    ,bed CHAR(6)  NOT NULL
    ,hgt NUMERIC(5,1)  NOT NULL
    ,wgt NUMERIC(5,1)  NOT NULL
    ,ord CHAR(120)  NOT NULL
    ,ord_cmt CHAR(120)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ass_no)
);



CREATE TABLE  mocmm
    (
    cnr_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,ord_no NUMERIC(10)
    ,sys_typ CHAR(4)  NOT NULL
    ,itm_typ CHAR(4)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cnr_tim TIMESTAMP NOT NULL
    ,cnr_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cnr_no)
);



CREATE TABLE  mocmi
    (
    evt_no NUMERIC(10)  NOT NULL
    cnr_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,itm_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  mofib
    (
    itm_no NUMERIC(10)  NOT NULL
    div_no NUMERIC(5) NOT NULL
    ,msr_no CHAR(18)  NOT NULL
    ,det_no CHAR(16)  NOT NULL
    ,tbl_rel CHAR(2)  NOT NULL
    ,itm_nam CHAR(500)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  mooss
    (
    oss_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(40)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (oss_no)
);



CREATE TABLE  moolls
    (
    lls_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(600)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (lls_no)
);



CREATE TABLE  modds
    (
    dds_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dds_no)
);



CREATE TABLE  mootxt
    (
    txt_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,oth_dsc text NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (txt_no)
);



CREATE TABLE  mools
    (
    ols_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(240)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  zztblupd
    (
    tbl_nam CHAR(80)  NOT NULL
    last_upd TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tbl_nam)
);



CREATE TABLE  ifdpm
    (
    ifd_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,drg_dct NUMERIC(5) NOT NULL
    ,pmg_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ifd_no)
);



CREATE TABLE  ifdpmi
    (
    rec_no NUMERIC(10)  NOT NULL
    ifd_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,itm_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  ifdpms
    (
    sts_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,snd_dat DATE NOT NULL
    ,tsc CHAR(2)
    ,exm_rlt CHAR(2)  NOT NULL
    ,pmg_no CHAR(26)  NOT NULL
    ,mng_sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5)
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sts_no)
);



CREATE TABLE  cmcbd
    (
    chart NUMERIC(10) NOT NULL
    inc_yea NUMERIC(5) NOT NULL
    ,nat_ion CHAR(20)  NOT NULL
    ,edu_lev CHAR(2)  NOT NULL
    ,lan_edu CHAR(2)  NOT NULL
    ,lan_oth CHAR(20)  NOT NULL
    ,mar_sta CHAR(2)  NOT NULL
    ,job_sta CHAR(2)  NOT NULL
    ,job_oth CHAR(20)  NOT NULL
    ,eco_sta CHAR(2)  NOT NULL
    ,hv NUMERIC(5,1)  NOT NULL
    ,wv NUMERIC(5,1)  NOT NULL
    ,dri_hab CHAR(2)  NOT NULL
    ,dri_cap CHAR(40)
    ,dro_yea CHAR(40)
    ,drl_yea CHAR(40)
    ,smo_hab CHAR(2)  NOT NULL
    ,smo_cap CHAR(40)
    ,smo_yea CHAR(40)
    ,smn_yea CHAR(40)
    ,are_hab CHAR(2)  NOT NULL
    ,are_cap CHAR(40)
    ,are_yea CHAR(40)
    ,arn_yea CHAR(40)
    ,con_nao CHAR(20)  NOT NULL
    ,con_teo CHAR(60)  NOT NULL
    ,con_reo CHAR(2)  NOT NULL
    ,con_nas CHAR(20)  NOT NULL
    ,con_tes CHAR(60)  NOT NULL
    ,con_res CHAR(2)  NOT NULL
    ,lmp_cod CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart)
);



CREATE TABLE  cmcsd
    (
    sub_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,sub_seq NUMERIC(5) NOT NULL
    ,sub_oth CHAR(60)  NOT NULL
    ,sub_yea CHAR(40)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sub_no)
);



CREATE TABLE  cmcpird
    (
    pat_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,pat_dat DATE NOT NULL
    ,his_typ CHAR(2)  NOT NULL
    ,his_oth CHAR(80)  NOT NULL
    ,org_dif CHAR(2)  NOT NULL
    ,org_oth CHAR(80)  NOT NULL
    ,siz_hei NUMERIC(6,2)  NOT NULL
    ,siz_wei NUMERIC(6,2)  NOT NULL
    ,sur_mar CHAR(2)  NOT NULL
    ,lym_nod CHAR(2)  NOT NULL
    ,lym_cnt NUMERIC(5) NOT NULL
    ,lym_dit NUMERIC(5) NOT NULL
    ,dis_met CHAR(2)  NOT NULL
    ,dis_cmt CHAR(100)  NOT NULL
    ,inv_pos CHAR(2)  NOT NULL
    ,inv_cmt CHAR(100)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pat_no)
);



CREATE TABLE  cmcesd
    (
    enr_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,enr_dat DATE NOT NULL
    ,enr_typ CHAR(2)  NOT NULL
    ,enr_rea CHAR(2)  NOT NULL
    ,enr_emp NUMERIC(5) NOT NULL
    ,sgn_sts CHAR(2)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (enr_no)
);



CREATE TABLE  cmcctd
    (
    tre_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,tre_sta DATE NOT NULL
    ,tre_end DATE NOT NULL
    ,tre_typ NUMERIC(5) NOT NULL
    ,tre_po1 CHAR(8)  NOT NULL
    ,tre_po2 CHAR(8)  NOT NULL
    ,tre_po3 CHAR(8)  NOT NULL
    ,tre_po4 CHAR(8)  NOT NULL
    ,dos_qty NUMERIC(7,2)  NOT NULL
    ,dos_tot NUMERIC(5) NOT NULL
    ,dos_cmt text NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tre_no)
);



CREATE TABLE  cmccad
    (
    adv_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,adv_dat DATE NOT NULL
    ,adv_tis NUMERIC(5) NOT NULL
    ,adv_tie NUMERIC(5) NOT NULL
    ,age_str CHAR(2)  NOT NULL
    ,adv_ide CHAR(2)  NOT NULL
    ,adv_cmt CHAR(100)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (adv_no)
);



CREATE TABLE  cmctfur
    (
    tfu_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,tfu_typ CHAR(2)  NOT NULL
    ,fol_dat DATE NOT NULL
    ,nex_dat DATE NOT NULL
    ,nex_int CHAR(2)  NOT NULL
    ,fol_emp NUMERIC(5) NOT NULL
    ,fol_flg CHAR(2)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tfu_no)
);



CREATE TABLE  cmched
    (
    edu_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,edu_dat DATE NOT NULL
    ,edu_tis NUMERIC(5) NOT NULL
    ,edu_tie NUMERIC(5) NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,edu_fam CHAR(4)  NOT NULL
    ,fam_oth CHAR(40)  NOT NULL
    ,edu_itm CHAR(2)  NOT NULL
    ,edu_oth CHAR(100)  NOT NULL
    ,ref_sev CHAR(2)  NOT NULL
    ,ref_oth CHAR(100)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (edu_no)
);



CREATE TABLE  cmtmppd
    (
    mpp_no NUMERIC(10)  NOT NULL
    mee_no NUMERIC(10) NOT NULL
    ,mee_dct NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mpp_no)
);



CREATE TABLE  cmtpcd
    (
    tem_no NUMERIC(10)  NOT NULL
    can_typ NUMERIC(5) NOT NULL
    ,tem_dct NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tem_no)
);



CREATE TABLE  rodipr
    (
    dia_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,ecg_sts CHAR(2)  NOT NULL
    ,kps_sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dia_no)
);



CREATE TABLE  rocpsr
    (
    cps_no NUMERIC(10)  NOT NULL
    dia_no NUMERIC(10) NOT NULL
    ,dia_sta CHAR(2)  NOT NULL
    ,dia_lev NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cps_no)
);



CREATE TABLE  rotgr
    (
    tre_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,tre_eff DATE NOT NULL
    ,tre_stp DATE NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,tre_tgt CHAR(2)  NOT NULL
    ,rad_tre CHAR(2)  NOT NULL
    ,sur_seq CHAR(2)  NOT NULL
    ,com_che CHAR(2)  NOT NULL
    ,com_rgm text NOT NULL
    ,rad_tgt CHAR(2)  NOT NULL
    ,tre_hsp CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tre_no)
);



CREATE TABLE  rostr
    (
    xra_no NUMERIC(10)  NOT NULL
    xra_dat DATE NOT NULL
    ,tre_no NUMERIC(10) NOT NULL
    ,oth_rad CHAR(2)  NOT NULL
    ,rad_rsm text NOT NULL
    ,eng_sid text NOT NULL
    ,rad_res CHAR(2)  NOT NULL
    ,rad_emp NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (xra_no)
);



CREATE TABLE  rosldtr
    (
    sum_no NUMERIC(10)  NOT NULL
    sum_dat DATE NOT NULL
    ,tre_no NUMERIC(10) NOT NULL
    ,tre_pos CHAR(4)  NOT NULL
    ,sum_dos CHAR(2)  NOT NULL
    ,sum_tcd CHAR(2)  NOT NULL
    ,tum_tot NUMERIC(5) NOT NULL
    ,tum_cnt NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sum_no)
);



CREATE TABLE  rosdtter
    (
    det_no NUMERIC(10)  NOT NULL
    sum_no NUMERIC(10) NOT NULL
    ,tre_seq NUMERIC(5) NOT NULL
    ,tre_dos NUMERIC(5) NOT NULL
    ,tre_unt CHAR(2)  NOT NULL
    ,tre_cmt CHAR(200)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (det_no)
);



CREATE TABLE  rodtsr
    (
    pos_no NUMERIC(10)  NOT NULL
    tre_pos CHAR(4)  NOT NULL
    ,pos_nam CHAR(80)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pos_no)
);



CREATE TABLE  eoged
    (
    itm_no NUMERIC(10)  NOT NULL
    atriageid CHAR(26)  NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,oth_dsc CHAR(120)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  momsg
    (
    msg_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,map_no NUMERIC(5) NOT NULL
    ,lvl CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,fun_no CHAR(8)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,lnk_cod CHAR(14)
    ,sed_man NUMERIC(5) NOT NULL
    ,sed_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,rec_tim TIMESTAMP
    ,rec_loc NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (msg_no)
);



CREATE TABLE  momsg2
    (
    msg_no NUMERIC(10) NOT NULL
    msg_txt CHAR(510)  NOT NULL
    ,exe_tim TIMESTAMP NOT NULL
    ,exe_rsn CHAR(2)
    ,cmt CHAR(256)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (msg_no)
);



CREATE TABLE  mosmi
    (
    mst_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,fun_typ CHAR(4)  NOT NULL
    ,sht_typ CHAR(4)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mst_no)
);



CREATE TABLE  mosdi
    (
    dtl_no NUMERIC(10)  NOT NULL
    mst_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,itm_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dtl_no)
);



CREATE TABLE  roptar
    (
    pta_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,pta_dat DATE NOT NULL
    ,pta_typ CHAR(2)  NOT NULL
    ,pta_txt text NOT NULL
    ,pta_doc NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pta_no)
);



CREATE TABLE  mrpsrdd
    (
    dtl_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,spc_mrk NUMERIC(5) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,spc_dsc CHAR(40)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dtl_no)
);



CREATE TABLE  moccirp
    (
    ref_no NUMERIC(10)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,ptc_cod CHAR(14)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ref_no)
);



CREATE TABLE  movuot
    (
    vsn NUMERIC(10) NOT NULL
    ord_rtt TIMESTAMP
    ,nod_rtt TIMESTAMP
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vsn)
);



CREATE TABLE  mocfl
    (
    cfm_no NUMERIC(10)  NOT NULL
    cfm_typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,cfm_man NUMERIC(5) NOT NULL
    ,cfm_tim TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cfm_no)
);



CREATE TABLE  npieb2
    (
    rec_no NUMERIC(10)  NOT NULL
    eva_no NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  moicpm
    (
    icp_no NUMERIC(10)  NOT NULL
    eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,cmb_pst CHAR(32)  NOT NULL
    ,icp_cod CHAR(20)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (icp_no)
);



CREATE TABLE  udsdr
    (
    sdr_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,exp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,room CHAR(8)  NOT NULL
    ,bed CHAR(4)  NOT NULL
    ,prt_nam CHAR(20)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sdr_no)
);



CREATE TABLE  udsdd
    (
    det_no NUMERIC(10)  NOT NULL
    sdr_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,dug_typ CHAR(2)  NOT NULL
    ,udr_qty1 NUMERIC(8,2)  NOT NULL
    ,udr_qty2 NUMERIC(8,2)  NOT NULL
    ,sdr_man NUMERIC(5) NOT NULL
    ,sdr_tim TIMESTAMP NOT NULL
    ,snd_way NUMERIC(5) NOT NULL
    ,cfm_sts CHAR(2)
    ,cfm_man NUMERIC(5) NOT NULL
    ,cfm_tim TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (det_no)
);



CREATE TABLE  udsddlog
    (
    log_no NUMERIC(10)  NOT NULL
    det_no NUMERIC(10) NOT NULL
    ,sdr_man NUMERIC(5) NOT NULL
    ,sdr_tim TIMESTAMP NOT NULL
    ,snd_way NUMERIC(5) NOT NULL
    ,cfm_sts CHAR(2)
    ,cfm_man NUMERIC(5) NOT NULL
    ,cfm_tim TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_no)
);



CREATE TABLE  udsdbd
    (
    sbd_no NUMERIC(10)  NOT NULL
    sbd_typ CHAR(2)  NOT NULL
    ,ref_cod CHAR(20)  NOT NULL
    ,ref_nam CHAR(40)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sbd_no)
);



CREATE TABLE  nherst
    (
    ser_no NUMERIC(10)  NOT NULL
    itm_cod CHAR(12)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  nhudficd
    (
    ser_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,icd_f CHAR(12)  NOT NULL
    ,icd_t CHAR(12)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  mrvrd
    (
    vrd_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,rec_typ CHAR(4)  NOT NULL
    ,rec_txt CHAR(40)  NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vrd_no)
);



CREATE TABLE  nhietnms
    (
    ser_no NUMERIC(10)  NOT NULL
    itm_f CHAR(24)  NOT NULL
    ,itm_t CHAR(24)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  ifdmr
    (
    ifd_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,drg_dct NUMERIC(5) NOT NULL
    ,pmg_dat DATE NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ifd_no)
);



CREATE TABLE  mracbd
    (
    acb_no NUMERIC(10)  NOT NULL
    tc CHAR(2)  NOT NULL
    ,id_no CHAR(20)  NOT NULL
    ,nam CHAR(40)  NOT NULL
    ,born_yy NUMERIC(5) NOT NULL
    ,born_mmdd NUMERIC(5) NOT NULL
    ,sex CHAR(2)  NOT NULL
    ,c_r_cod NUMERIC(10) NOT NULL
    ,c_r_adrs CHAR(68)  NOT NULL
    ,tel_1 NUMERIC(10) NOT NULL
    ,tel_2 NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (acb_no)
);



CREATE TABLE  mocacdi
    (
    cac_no NUMERIC(10)  NOT NULL
    dtl_typ CHAR(4)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,itm_sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cac_no)
);



CREATE TABLE  ocmcpgmd2
    (
    evt_no NUMERIC(10)  NOT NULL
    cas_no NUMERIC(10) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,use_typ CHAR(2)  NOT NULL
    ,use_dat DATE NOT NULL
    ,use_qty NUMERIC(6,2)  NOT NULL
    ,cmt CHAR(200)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  ocmcpgmd
    (
    evt_no NUMERIC(10)  NOT NULL
    cas_no NUMERIC(10) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,use_typ CHAR(2)  NOT NULL
    ,use_dat DATE NOT NULL
    ,use_qty NUMERIC(6,2)  NOT NULL
    ,visit_no NUMERIC(11,0)
    ,pas_sts CHAR(2)
    ,cmt CHAR(200)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  cmcg
    (
    cmg_id NUMERIC(10)  NOT NULL
    grp_id NUMERIC(10) NOT NULL
    ,cus_id NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rthm TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cmg_id)
);



CREATE TABLE  mrrmdm
    (
    dcm_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,frm CHAR(2)
    ,typ CHAR(2)  NOT NULL
    ,did_no CHAR(60)
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtd DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dcm_no)
);



CREATE TABLE  moiolog
    (
    log_num NUMERIC(10)  NOT NULL
    fun_no CHAR(8)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,log_sts CHAR(2)  NOT NULL
    ,log_tim TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_num)
);



CREATE TABLE  moqr
    (
    log_tim TIMESTAMP
    emp_no NUMERIC(5) NOT NULL
    ,fun_no CHAR(8)  NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,map_no NUMERIC(5)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_tim,emp_no,map_no)
);



CREATE TABLE  sdcallog
    (
    log_num NUMERIC(10)  NOT NULL
    evt_num NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,sub CHAR(40)  NOT NULL
    ,lnk_typ CHAR(2)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,mis_num NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,pmt CHAR(2)  NOT NULL
    ,coment CHAR(2000)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_num)
);



CREATE TABLE  tddrgab
    (
    ser_no NUMERIC(10)  NOT NULL
    fym NUMERIC(5) NOT NULL
    ,tym NUMERIC(5) NOT NULL
    ,spr NUMERIC(10) NOT NULL
    ,sla NUMERIC(10) NOT NULL
    ,rat_b NUMERIC(4,3)  NOT NULL
    ,rat_c NUMERIC(4,3)  NOT NULL
    ,rat_m NUMERIC(4,3)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  mopnmp
    (
    prc_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,typ NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,ver_no NUMERIC(5)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (prc_no)
);



CREATE TABLE  doolev
    (
    lev_no NUMERIC(10)  NOT NULL
    dct_no NUMERIC(10) NOT NULL
    ,apl_dat DATE NOT NULL
    ,eff_dat DATE NOT NULL
    ,fhm NUMERIC(5) NOT NULL
    ,stp_dat DATE NOT NULL
    ,thm NUMERIC(5) NOT NULL
    ,lev_typ CHAR(10)  NOT NULL
    ,go_abd CHAR(2)  NOT NULL
    ,opd CHAR(2)  NOT NULL
    ,cmt CHAR(120)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,sgn_seq CHAR(4)  NOT NULL
    ,lnk_lev NUMERIC(10) NOT NULL
    ,amc_tot NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (lev_no)
);



CREATE TABLE  dolevoa
    (
    agt_no NUMERIC(10)  NOT NULL
    lev_no NUMERIC(10) NOT NULL
    ,vst_dat DATE NOT NULL
    ,sft CHAR(2)  NOT NULL
    ,rom NUMERIC(5) NOT NULL
    ,agt_typ CHAR(2)  NOT NULL
    ,agt_rom NUMERIC(5) NOT NULL
    ,agt_dct NUMERIC(10) NOT NULL
    ,sgn_seq CHAR(4)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,lnk_agt NUMERIC(10) NOT NULL
    ,amc_amt NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (agt_no)
);



CREATE TABLE  dolevwa
    (
    wgt_no NUMERIC(10)  NOT NULL
    lev_no NUMERIC(10) NOT NULL
    ,dct NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (wgt_no)
);



CREATE TABLE  doolsp
    (
    sgn_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,sgn_seq CHAR(4)  NOT NULL
    ,sgn_sts CHAR(2)  NOT NULL
    ,sgn_cmt CHAR(200)  NOT NULL
    ,sgn_emp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sgn_no)
);



CREATE TABLE  cgrcod
    (
    chg_cod CHAR(14)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,cod CHAR(24)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chg_cod,typ,eff_dat,cod)
);



CREATE TABLE  mocdus
    (
    itm_no NUMERIC(10) NOT NULL
    src CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,def_seq NUMERIC(5) NOT NULL
    ,rel_seq NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  lbplval
    (
    rvl_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,lab_nam CHAR(20)  NOT NULL
    ,val CHAR(40)  NOT NULL
    ,lv CHAR(20)  NOT NULL
    ,hv CHAR(40)  NOT NULL
    ,rpt_tim TIMESTAMP NOT NULL
    ,lab_no NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rvl_no)
);



CREATE TABLE  nhdnicc
    (
    nhi_cod CHAR(24)  NOT NULL
    ctl_cod CHAR(24)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (nhi_cod)
);



CREATE TABLE  nhtpgd
    (
    ser_no NUMERIC(10)  NOT NULL
    grp CHAR(4)  NOT NULL
    ,pos CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  mtval
    (
    val_no NUMERIC(10)  NOT NULL
    mt_cod CHAR(14)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,val NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (val_no)
);



CREATE TABLE  moeci
    (
    chk_no NUMERIC(10)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,chk_nam CHAR(200)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chk_no)
);



CREATE TABLE  bmbed
    (
    room CHAR(8)
    bed CHAR(4)  NOT NULL
    ,class CHAR(2)  NOT NULL
    ,rank CHAR(2)  NOT NULL
    ,division_rm NUMERIC(5) NOT NULL
    ,doctor_rm NUMERIC(5) NOT NULL
    ,ward CHAR(6)
    ,dpt_no NUMERIC(5)
    ,team CHAR(2)  NOT NULL
    ,ud CHAR(2)  NOT NULL
    ,toilet CHAR(2)  NOT NULL
    ,disbu CHAR(2)  NOT NULL
    ,sex_ctl CHAR(2)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,acc_no NUMERIC(10) NOT NULL
    ,isolat CHAR(2)  NOT NULL
    ,nam CHAR(24)  NOT NULL
    ,sex CHAR(2)  NOT NULL
    ,born_yy NUMERIC(5) NOT NULL
    ,zip NUMERIC(5) NOT NULL
    ,fil1 CHAR(2)  NOT NULL
    ,pre_dat DATE NOT NULL
    ,pre_chart NUMERIC(10) NOT NULL
    ,cur_loc CHAR(6)  NOT NULL
    ,udd_dat DATE
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  moitm
    (
    itm_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5)
    ,chg_cod CHAR(14)  NOT NULL
    ,dos_qty CHAR(10)
    ,itm1 CHAR(8)
    ,itm2 CHAR(8)
    ,itm3 CHAR(8)
    ,itm4 CHAR(8)
    ,exe_qty CHAR(10)
    ,nhi_qty NUMERIC(5,1)
    ,slf_qty NUMERIC(5,1)
    ,mrk CHAR(2)
    ,adv VARCHAR(1020)
    ,lnk_typ CHAR(2)
    ,lnk_no NUMERIC(10)
    ,nrs_man NUMERIC(5)
    ,nrs_dat DATE
    ,nrs_hm NUMERIC(5)
    ,nrs_sts CHAR(2)
    ,chg_no NUMERIC(10)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  mtbillgn
    (
    grp_no NUMERIC(10)  NOT NULL
    grp_cod CHAR(14)  NOT NULL
    ,nhi_cod CHAR(24)  NOT NULL
    ,qty NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (grp_no)
);



CREATE TABLE  npcmr
    (
    cvr_no NUMERIC(10)  NOT NULL
    emp_no NUMERIC(5) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cvr_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cvr_no)
);



CREATE TABLE  npstcm
    (
    sft_no NUMERIC(10)  NOT NULL
    dpt_no NUMERIC(5) NOT NULL
    ,grp CHAR(6)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,stc_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sft_no)
);



CREATE TABLE  npgrb
    (
    grp_no NUMERIC(10)  NOT NULL
    dpt_no NUMERIC(5) NOT NULL
    ,grp CHAR(6)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,stp_rsn CHAR(2)  NOT NULL
    ,room CHAR(8)  NOT NULL
    ,bed CHAR(4)  NOT NULL
    ,acc_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (grp_no)
);



CREATE TABLE  npoxls
    (
    xls_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(1200)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (xls_no)
);



CREATE TABLE  cmtmpd
    (
    mpd_no NUMERIC(10)  NOT NULL
    mee_no NUMERIC(10) NOT NULL
    ,can_typ NUMERIC(5)
    ,chart NUMERIC(10) NOT NULL
    ,icd_cod text NOT NULL
    ,oth_cmt CHAR(120)  NOT NULL
    ,met_obj CHAR(40)  NOT NULL
    ,met_oth CHAR(120)  NOT NULL
    ,met_con text NOT NULL
    ,met_res text NOT NULL
    ,met_rep NUMERIC(5) NOT NULL
    ,tre_gui CHAR(2)  NOT NULL
    ,gui_cmt CHAR(510)  NOT NULL
    ,cmt text NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mpd_no)
);



CREATE TABLE  cmctmr
    (
    mee_no NUMERIC(10)  NOT NULL
    mee_dat DATE NOT NULL
    ,mee_typ NUMERIC(5) NOT NULL
    ,mee_obj CHAR(80)  NOT NULL
    ,mee_yy NUMERIC(5) NOT NULL
    ,mee_seq NUMERIC(5) NOT NULL
    ,mee_hos NUMERIC(5) NOT NULL
    ,mee_rec NUMERIC(5) NOT NULL
    ,mee_loc CHAR(60)  NOT NULL
    ,acc_div NUMERIC(5) NOT NULL
    ,act_div NUMERIC(5) NOT NULL
    ,new_cas NUMERIC(5) NOT NULL
    ,act_dis NUMERIC(5) NOT NULL
    ,pri_dis NUMERIC(5) NOT NULL
    ,dis_chd CHAR(80)  NOT NULL
    ,cmt text NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mee_no)
);



CREATE TABLE  cmpipd
    (
    pip_no NUMERIC(10)  NOT NULL
    mpd_no NUMERIC(10) NOT NULL
    ,ind_dct NUMERIC(5) NOT NULL
    ,cmt text NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pip_no)
);



CREATE TABLE  mrchgadr
    (
    chg_no NUMERIC(10)  NOT NULL
    old_adr CHAR(68)  NOT NULL
    ,new_adr CHAR(68)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chg_no)
);



CREATE TABLE  moir
    (
    rlt_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,frm_no NUMERIC(10) NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rlt_no)
);



CREATE TABLE  dglmpr
    (
    rec_no NUMERIC(10)  NOT NULL
    rec_typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,cmp_tim TIMESTAMP NOT NULL
    ,hpt_loc CHAR(2)
    ,lmp_loc NUMERIC(5) NOT NULL
    ,lmp_typ CHAR(2)  NOT NULL
    ,lmp_no NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,prn_tim TIMESTAMP NOT NULL
    ,chg_tim TIMESTAMP
    ,out_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  npnsr
    (
    nsr_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,act_typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,act_man NUMERIC(5) NOT NULL
    ,act_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (nsr_no)
);



CREATE TABLE  ntpdadt2
    (
    acc_no NUMERIC(10) NOT NULL
    f_dat DATE NOT NULL
    ,f_meal CHAR(2)  NOT NULL
    ,add_typ CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (acc_no,f_dat,f_meal)
);



CREATE TABLE  pdpcr
    (
    ser_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,sgn_dtt TIMESTAMP NOT NULL
    ,stp_dtt TIMESTAMP
    ,tsc CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,cst CHAR(2)  NOT NULL
    ,opt CHAR(10)
    ,frm CHAR(8)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  cgppi
    (
    pkg_no NUMERIC(10)  NOT NULL
    pkg_cod CHAR(14)  NOT NULL
    ,nam CHAR(100)  NOT NULL
    ,eff_dat DATE
    ,stp_dat DATE
    ,typ CHAR(4)  NOT NULL
    ,pkg_amt NUMERIC(10) NOT NULL
    ,cmt CHAR(160)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pkg_no)
);



CREATE TABLE  dci10cn
    (
    icd_cod CHAR(16)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,nhi_cod CHAR(18)  NOT NULL
    ,drg_cod CHAR(10)  NOT NULL
    ,qip_drg CHAR(12)  NOT NULL
    ,nam_e CHAR(510)  NOT NULL
    ,nam_c CHAR(510)  NOT NULL
    ,icd_typ CHAR(8)  NOT NULL
    ,sru_mrk NUMERIC(5) NOT NULL
    ,ifq_mrk CHAR(2)  NOT NULL
    ,crn_mrk CHAR(2)  NOT NULL
    ,crn_typ CHAR(12)  NOT NULL
    ,con_mrk CHAR(2)  NOT NULL
    ,con_typ NUMERIC(5) NOT NULL
    ,sex_lmt CHAR(2)  NOT NULL
    ,dag_lmt CHAR(2)  NOT NULL
    ,spc_typ CHAR(4)  NOT NULL
    ,min_age NUMERIC(5) NOT NULL
    ,max_age NUMERIC(5) NOT NULL
    ,std_days NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (icd_cod)
);



CREATE TABLE  dcicdm
    (
    imp_no NUMERIC(10)  NOT NULL
    i09_cod CHAR(12)  NOT NULL
    ,i10_cod CHAR(16)  NOT NULL
    ,map_typ CHAR(10)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (imp_no)
);



CREATE TABLE  ooptmeet
    (
    evt_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,visit_no NUMERIC(11,0)  NOT NULL
    ,exm_typ CHAR(2)  NOT NULL
    ,evt_typ CHAR(2)  NOT NULL
    ,cnt NUMERIC(5) NOT NULL
    ,tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  ooptmret
    (
    evt_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,visit_no NUMERIC(11,0)  NOT NULL
    ,evt_typ CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  mrpbd99
    (
    chart NUMERIC(10) NOT NULL
    nam CHAR(24)  NOT NULL
    ,born_yy NUMERIC(5) NOT NULL
    ,born_mmdd NUMERIC(5) NOT NULL
    ,sex CHAR(2)  NOT NULL
    ,l_mark CHAR(2)  NOT NULL
    ,c_r_cod NUMERIC(10) NOT NULL
    ,c_r_adrs CHAR(68)  NOT NULL
    ,domicile CHAR(16)  NOT NULL
    ,marr CHAR(2)  NOT NULL
    ,educ CHAR(2)  NOT NULL
    ,profes CHAR(6)  NOT NULL
    ,fil1 CHAR(2)  NOT NULL
    ,id_no CHAR(20)  NOT NULL
    ,tel_h NUMERIC(10) NOT NULL
    ,tel_o NUMERIC(10) NOT NULL
    ,gl_typ CHAR(4)  NOT NULL
    ,bl_typ CHAR(4)  NOT NULL
    ,pt_typ CHAR(4)  NOT NULL
    ,sp_typ CHAR(4)  NOT NULL
    ,sw_typ CHAR(4)  NOT NULL
    ,insured NUMERIC(10) NOT NULL
    ,cer_no NUMERIC(10) NOT NULL
    ,loc_o CHAR(2)  NOT NULL
    ,hpt_loc CHAR(2)  NOT NULL
    ,nv_times NUMERIC(5) NOT NULL
    ,bad_amt NUMERIC(10) NOT NULL
    ,no_good CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  emrunset
    (
    run_no VARCHAR(128)  NOT NULL
    typ1 VARCHAR(48)
    ,typ2 VARCHAR(48)
    ,typ_nam VARCHAR(400)
    ,run_ap VARCHAR(400)
    ,run_url VARCHAR(400)
    ,ap_dsc VARCHAR(400)
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (run_no)
);



CREATE TABLE  mtdesc2
    (
    mt_cod CHAR(14)  NOT NULL
    qlt_typ CHAR(4)  NOT NULL
    ,qlt_cmt CHAR(160)
    ,dvc CHAR(160)
    ,saf_mm NUMERIC(5)
    ,mt_cod12 CHAR(24)
    ,spc CHAR(40)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mt_cod)
);



CREATE TABLE  mooir
    (
    oir_no NUMERIC(10)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,frm CHAR(2)  NOT NULL
    ,val VARCHAR(80)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (oir_no)
);



CREATE TABLE  pcvilned
    (
    eff_no NUMERIC(10)  NOT NULL
    frm CHAR(2)  NOT NULL
    ,acd_no NUMERIC(10) NOT NULL
    ,itm_cod CHAR(14)  NOT NULL
    ,lot_no CHAR(40)
    ,eff_dat DATE NOT NULL
    ,qty NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (eff_no)
);



CREATE TABLE  dgldap
    (
    ldp_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,apt_man NUMERIC(5) NOT NULL
    ,rcd_dat DATE NOT NULL
    ,apt_dat DATE NOT NULL
    ,hpt_loc CHAR(2)
    ,seq_no NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ldp_no)
);



CREATE TABLE  npned
    (
    itm_no NUMERIC(10)  NOT NULL
    ast_no NUMERIC(10) NOT NULL
    ,itm_cls NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,sel_dat DATE NOT NULL
    ,sel_itm CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  mofulog
    (
    log_num NUMERIC(10)  NOT NULL
    fun_no CHAR(8)  NOT NULL
    ,fun_typ CHAR(4)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,rec_val CHAR(14)  NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,log_tim TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_num)
);



CREATE TABLE  nhocmr
    (
    rcd_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,id_no CHAR(20)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,mrk CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rcd_no)
);



CREATE TABLE  cgupbdm
    (
    rul_no NUMERIC(10)  NOT NULL
    cod_typ CHAR(4)  NOT NULL
    ,cod CHAR(20)  NOT NULL
    ,pay_typ CHAR(2)  NOT NULL
    ,vit_typ CHAR(2)  NOT NULL
    ,grp_id NUMERIC(5) NOT NULL
    ,rul_typ CHAR(4)  NOT NULL
    ,rul_val CHAR(80)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rul_no)
);



CREATE TABLE  cgupbdr
    (
    det_no NUMERIC(10)  NOT NULL
    rul_no NUMERIC(10) NOT NULL
    ,use_pnt CHAR(4)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rng_typ CHAR(2)  NOT NULL
    ,sat_val CHAR(20)  NOT NULL
    ,end_val CHAR(20)  NOT NULL
    ,ret_val NUMERIC(5)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (det_no)
);



CREATE TABLE  cmcpd
    (
    psy_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,psy_dat DATE NOT NULL
    ,num_min NUMERIC(5) NOT NULL
    ,ref_sou NUMERIC(5) NOT NULL
    ,sco_sht NUMERIC(5) NOT NULL
    ,sev_cmt text NOT NULL
    ,pla_cmt text NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (psy_no)
);



CREATE TABLE  cmupl
    (
    upl_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,icd_cod CHAR(12)  NOT NULL
    ,doctor NUMERIC(5) NOT NULL
    ,desc_cdc CHAR(160)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (upl_no)
);



CREATE TABLE  nppvlm
    (
    vlm_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,typ1 CHAR(4)  NOT NULL
    ,typ2 CHAR(2)  NOT NULL
    ,dsc CHAR(80)  NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vlm_no)
);



CREATE TABLE  dgprn
    (
    prn_no NUMERIC(10)  NOT NULL
    drg_cod CHAR(10)  NOT NULL
    ,seq_no NUMERIC(5)
    ,prn_typ CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (prn_no)
);



CREATE TABLE  dgdbd4
    (
    drg_no NUMERIC(10)  NOT NULL
    drg_cod CHAR(10)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,use_way CHAR(4)  NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,dsc CHAR(160)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (drg_no)
);



CREATE TABLE  nhailsoe
    (
    ser_no NUMERIC(10)  NOT NULL
    nhi_f CHAR(24)  NOT NULL
    ,nhi_t CHAR(24)  NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,dsc CHAR(200)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  mrcnmqva
    (
    apl_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,opn_man NUMERIC(5) NOT NULL
    ,qry_rsn CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (apl_no)
);



CREATE TABLE  dgddd
    (
    drg_cod CHAR(10)  NOT NULL
    val NUMERIC(10,2)  NOT NULL
    ,dos_unt CHAR(8)  NOT NULL
    ,dos_sal_r1 NUMERIC(5) NOT NULL
    ,dos_sal_r2 NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (drg_cod)
);



CREATE TABLE  dgdibd
    (
    itm_no NUMERIC(10)  NOT NULL
    cod CHAR(14)  NOT NULL
    ,itm CHAR(6)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,nam CHAR(300)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  mofht
    (
    hnt_no NUMERIC(10)  NOT NULL
    fun_no CHAR(8)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,dsc text
    ,see_tim TIMESTAMP NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (hnt_no)
);



CREATE TABLE  mrpsdsc
    (
    dsc_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,spc_mrk NUMERIC(5) NOT NULL
    ,dsc CHAR(100)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dsc_no)
);



CREATE TABLE  dcordmd
    (
    odm_no NUMERIC(10)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,val CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (odm_no)
);



CREATE TABLE  nhpnpic
    (
    chart NUMERIC(10) NOT NULL
    nhi_cod CHAR(24)  NOT NULL
    ,qty_l NUMERIC(9,2)  NOT NULL
    ,qty_a NUMERIC(9,2)  NOT NULL
    ,rpd DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chart,nhi_cod)
);



CREATE TABLE  nhpnpit
    (
    trn_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,frm_cls CHAR(2)  NOT NULL
    ,frm_no NUMERIC(10) NOT NULL
    ,nhi_cod CHAR(24)  NOT NULL
    ,qty NUMERIC(9,2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (trn_no)
);



CREATE TABLE  dcdccr
    (
    rec_no NUMERIC(10)  NOT NULL
    dcc_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,itm_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  bmhrpc
    (
    itm_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,eff_dat DATE
    ,tsc CHAR(2)  NOT NULL
    ,itp NUMERIC(5) NOT NULL
    ,itt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  dcdcc
    (
    dcc_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,frm_no NUMERIC(10) NOT NULL
    ,dcc_typ CHAR(2)  NOT NULL
    ,dcc_man NUMERIC(5) NOT NULL
    ,dcc_txt text
    ,dcc_tim TIMESTAMP NOT NULL
    ,dcc_tsc CHAR(2)  NOT NULL
    ,rpy_man NUMERIC(5) NOT NULL
    ,rpy_txt text
    ,rpy_tim TIMESTAMP
    ,rpy_tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dcc_no)
);



CREATE TABLE  dgadmcr
    (
    dmc_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,mng_sts CHAR(2)  NOT NULL
    ,val CHAR(2)  NOT NULL
    ,dsc CHAR(100)
    ,res_dat DATE NOT NULL
    ,par_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dmc_no)
);



CREATE TABLE  dgpadr
    (
    adr_no NUMERIC(10)  NOT NULL
    dmc_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cod CHAR(24)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (adr_no)
);



CREATE TABLE  emumrt
    (
    itm_no NUMERIC(10)  NOT NULL
    evt_no NUMERIC(10) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,don_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  dcdcd
    (
    dcd_no NUMERIC(10)  NOT NULL
    div_no NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,val CHAR(16)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dcd_no)
);



CREATE TABLE  mocrir
    (
    cri_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,typ1 CHAR(4)  NOT NULL
    ,typ2 CHAR(4)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,val CHAR(40)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cri_no)
);



CREATE TABLE  cgqtsr
    (
    qts_no NUMERIC(10)  NOT NULL
    qts_typ CHAR(2)  NOT NULL
    ,itm_no CHAR(20)  NOT NULL
    ,qts_tim TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (qts_no)
);



CREATE TABLE  hdpgd
    (
    pgd_no NUMERIC(10)  NOT NULL
    yyymm NUMERIC(5) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,grp CHAR(2)  NOT NULL
    ,shift CHAR(2)  NOT NULL
    ,room NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,pgd_man NUMERIC(5) NOT NULL
    ,prn_tim TIMESTAMP NOT NULL
    ,comment CHAR(160)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pgd_no)
);



CREATE TABLE  cgdcdr
    (
    dcd_no NUMERIC(10)  NOT NULL
    ivc_no CHAR(24)  NOT NULL
    ,vsn NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dcd_no)
);



CREATE TABLE  npcrm
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,typ CHAR(4)
    ,tsc CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  npcrd
    (
    itm_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,eva_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  mrpcr
    (
    pcr_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,cst_typ CHAR(2)  NOT NULL
    ,sgn_dtt TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10)
    ,cst_way CHAR(2)  NOT NULL
    ,cst_wrd CHAR(6)
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pcr_no)
);



CREATE TABLE  morsnm
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,src CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,typ_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  morsndt
    (
    det_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,rsn_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (det_no)
);



CREATE TABLE  qmatsarm
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rec_typ CHAR(2)  NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  qmatsari
    (
    itm_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,ext_no NUMERIC(10) NOT NULL
    ,eva_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  dcdicdm
    (
    imp_no NUMERIC(10)  NOT NULL
    div_no NUMERIC(5) NOT NULL
    ,i09_cod CHAR(12)  NOT NULL
    ,i10_cod CHAR(16)  NOT NULL
    ,map_typ CHAR(10)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cmt CHAR(510)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (imp_no)
);



CREATE TABLE  cgpra
    (
    pre_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,pre_amt NUMERIC(10) NOT NULL
    ,collect_no NUMERIC(10)
    ,chg_tim TIMESTAMP
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pre_no)
);



CREATE TABLE  mrirbm
    (
    mng_no NUMERIC(10)  NOT NULL
    id CHAR(20)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rsh_no NUMERIC(10) NOT NULL
    ,fct_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mng_no)
);



CREATE TABLE  mrirbrp
    (
    pts_no NUMERIC(10)  NOT NULL
    rsh_no NUMERIC(10) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pts_no)
);



CREATE TABLE  mrirbr
    (
    rsh_no NUMERIC(10)  NOT NULL
    irb_cod CHAR(14)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,apl_man NUMERIC(5) NOT NULL
    ,rsh_nam CHAR(60)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rsh_no)
);



CREATE TABLE  mrirbf
    (
    fct_no NUMERIC(10)  NOT NULL
    nam CHAR(60)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (fct_no)
);



CREATE TABLE  ntpes
    (
    pes_cod CHAR(10)  NOT NULL
    nam CHAR(80)  NOT NULL
    ,nam_e CHAR(120)  NOT NULL
    ,def CHAR(1000)  NOT NULL
    ,bio CHAR(1000)  NOT NULL
    ,ant CHAR(1000)  NOT NULL
    ,rec CHAR(1000)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pes_cod)
);



CREATE TABLE  qmacarm
    (
    ast_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,ord_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,ast_typ CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ast_no)
);



CREATE TABLE  qmacai
    (
    rec_no NUMERIC(10)  NOT NULL
    ast_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,itm_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  qmaipr
    (
    ast_no NUMERIC(10) NOT NULL
    ast_typ CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ast_no,rtt)
);



CREATE TABLE  moltxt
    (
    txt_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,txt text NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (txt_no)
);



CREATE TABLE  rgfstdat
    (
    fvt_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,frv_dat DATE NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (fvt_no)
);



CREATE TABLE  cmrcud
    (
    rcu_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,can_typ CHAR(4)  NOT NULL
    ,rep_hsp CHAR(2)  NOT NULL
    ,rep_no CHAR(20)  NOT NULL
    ,rep_nam CHAR(200)
    ,id_no CHAR(20)  NOT NULL
    ,sex CHAR(20)  NOT NULL
    ,name CHAR(20)  NOT NULL
    ,birth CHAR(20)  NOT NULL
    ,adr_cod CHAR(8)  NOT NULL
    ,rep_dat1 CHAR(16)  NOT NULL
    ,rep_dat2 CHAR(16)  NOT NULL
    ,ord_dat CHAR(16)  NOT NULL
    ,can_pos CHAR(4)  NOT NULL
    ,cli_sta CHAR(2)  NOT NULL
    ,kno_sts CHAR(2)
    ,kno_oth CHAR(60)
    ,fam_sts CHAR(2)
    ,fam_oth CHAR(60)
    ,tra_rec CHAR(2)  NOT NULL
    ,tra_num CHAR(2)  NOT NULL
    ,hsp_typ CHAR(2)  NOT NULL
    ,hsp_no CHAR(20)  NOT NULL
    ,pro_mod CHAR(2)  NOT NULL
    ,die_sts CHAR(2)  NOT NULL
    ,not_cur CHAR(40)  NOT NULL
    ,cau_cmt CHAR(60)  NOT NULL
    ,fir_dat CHAR(16)  NOT NULL
    ,fir_typ CHAR(2)  NOT NULL
    ,fir_cmt CHAR(60)  NOT NULL
    ,pat_sta CHAR(2)  NOT NULL
    ,tre_dee CHAR(2)  NOT NULL
    ,tre_cmt CHAR(60)  NOT NULL
    ,tra_dat CHAR(16)  NOT NULL
    ,tra_typ CHAR(2)  NOT NULL
    ,tra_cmt CHAR(60)  NOT NULL
    ,cmt CHAR(200)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rcu_no)
);



CREATE TABLE  cmncud
    (
    ncu_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,can_typ CHAR(4)  NOT NULL
    ,dia_hsp CHAR(2)  NOT NULL
    ,dia_no CHAR(20)  NOT NULL
    ,dia_nam CHAR(200)
    ,id_no CHAR(20)  NOT NULL
    ,sex CHAR(20)  NOT NULL
    ,name CHAR(20)  NOT NULL
    ,birth CHAR(20)  NOT NULL
    ,adr_cod CHAR(8)  NOT NULL
    ,ord_dat CHAR(16)  NOT NULL
    ,dia_dat CHAR(16)  NOT NULL
    ,oth_dat CHAR(16)  NOT NULL
    ,can_pos CHAR(4)  NOT NULL
    ,eff_typ CHAR(2)  NOT NULL
    ,cli_sta CHAR(2)  NOT NULL
    ,kno_sts CHAR(2)
    ,kno_oth CHAR(60)
    ,fam_sts CHAR(2)
    ,fam_oth CHAR(60)
    ,tra_rec CHAR(2)  NOT NULL
    ,tra_num CHAR(2)  NOT NULL
    ,hsp_typ CHAR(2)  NOT NULL
    ,hsp_no CHAR(20)  NOT NULL
    ,pro_mod CHAR(2)  NOT NULL
    ,die_sts CHAR(2)  NOT NULL
    ,not_cur CHAR(40)  NOT NULL
    ,cau_cmt CHAR(60)  NOT NULL
    ,fir_dat CHAR(16)  NOT NULL
    ,fir_typ CHAR(2)  NOT NULL
    ,fir_cmt CHAR(60)  NOT NULL
    ,pat_sta CHAR(2)  NOT NULL
    ,tre_dee CHAR(2)  NOT NULL
    ,tre_cmt CHAR(60)  NOT NULL
    ,tra_dat CHAR(16)  NOT NULL
    ,tra_typ CHAR(2)  NOT NULL
    ,tra_cmt CHAR(60)  NOT NULL
    ,cmt CHAR(200)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ncu_no)
);



CREATE TABLE  cmcirtr
    (
    irt_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,irt_itm CHAR(2)  NOT NULL
    ,irt_oth CHAR(80)  NOT NULL
    ,irt_dat CHAR(20)  NOT NULL
    ,irt_typ CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (irt_no)
);



CREATE TABLE  cmcdd
    (
    dia_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,dia_dat CHAR(20)  NOT NULL
    ,dia_hsp CHAR(40)  NOT NULL
    ,hsp_no CHAR(20)
    ,dia_age NUMERIC(5) NOT NULL
    ,cas_typ NUMERIC(5) NOT NULL
    ,cas_oth CHAR(20)  NOT NULL
    ,enr_way CHAR(2)  NOT NULL
    ,enr_oth CHAR(40)  NOT NULL
    ,sta_dia CHAR(2)  NOT NULL
    ,sta_oth CHAR(40)  NOT NULL
    ,tra_sta CHAR(2)  NOT NULL
    ,tra_oth CHAR(40)  NOT NULL
    ,fit_eco CHAR(2)  NOT NULL
    ,fit_kps NUMERIC(5) NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,can_oth CHAR(80)  NOT NULL
    ,can_pos CHAR(4)
    ,cli_lev CHAR(2)  NOT NULL
    ,cli_t CHAR(30)  NOT NULL
    ,cli_n CHAR(30)  NOT NULL
    ,cli_m CHAR(30)  NOT NULL
    ,cli_sta CHAR(30)  NOT NULL
    ,cli_stb CHAR(30)  NOT NULL
    ,pat_lev CHAR(2)  NOT NULL
    ,pat_t CHAR(30)  NOT NULL
    ,pat_n CHAR(30)  NOT NULL
    ,pat_m CHAR(30)  NOT NULL
    ,pat_sta CHAR(30)  NOT NULL
    ,pat_stb CHAR(30)  NOT NULL
    ,dis_rec CHAR(2)  NOT NULL
    ,dis_hsp CHAR(2)
    ,dis_no CHAR(20)
    ,fir_dat DATE
    ,dis_dat DATE NOT NULL
    ,dis_pos CHAR(2)  NOT NULL
    ,tre_way CHAR(2)  NOT NULL
    ,tre_oth CHAR(80)  NOT NULL
    ,die_dat CHAR(20)  NOT NULL
    ,tra_dat CHAR(20)  NOT NULL
    ,a_dr1 NUMERIC(5)
    ,a_dr2 NUMERIC(5)
    ,a_dr3 NUMERIC(5)
    ,a_dr4 NUMERIC(5)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dia_no)
);



CREATE TABLE  cmctcrr
    (
    res_no NUMERIC(10)  NOT NULL
    sou_no NUMERIC(10)
    ,sou_typ NUMERIC(5)
    ,chart NUMERIC(10) NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,cau_dat CHAR(20)  NOT NULL
    ,cau_no NUMERIC(5) NOT NULL
    ,cau_cmt CHAR(120)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (res_no)
);



CREATE TABLE  cmcird
    (
    ins_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,ins_dat CHAR(20)  NOT NULL
    ,ins_typ NUMERIC(5) NOT NULL
    ,ins_sta CHAR(2)  NOT NULL
    ,ins_pos CHAR(40)  NOT NULL
    ,ins_pro CHAR(40)  NOT NULL
    ,exe_dat DATE NOT NULL
    ,cmt_pos CHAR(510)  NOT NULL
    ,cmt_pro CHAR(510)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ins_no)
);



CREATE TABLE  mofltstr
    (
    rec_no NUMERIC(10)  NOT NULL
    rec_typ CHAR(4)  NOT NULL
    ,idx_str_1 CHAR(256)  NOT NULL
    ,idx_str_2 CHAR(256)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  dcordmi
    (
    itm_no NUMERIC(10)  NOT NULL
    odm_no NUMERIC(10) NOT NULL
    ,rlt CHAR(6)
    ,tsc CHAR(2)  NOT NULL
    ,val CHAR(24)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  ntdns
    (
    dns_cod CHAR(20)  NOT NULL
    dns_typ CHAR(4)
    ,nam CHAR(80)  NOT NULL
    ,nam_e CHAR(200)  NOT NULL
    ,def CHAR(3000)  NOT NULL
    ,res CHAR(3000)  NOT NULL
    ,bio CHAR(3000)  NOT NULL
    ,ant CHAR(3000)  NOT NULL
    ,nhy CHAR(3000)  NOT NULL
    ,rec CHAR(3000)  NOT NULL
    ,phy CHAR(3000)  NOT NULL
    ,sts CHAR(2)
    ,rtp NUMERIC(10)
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dns_cod)
);



CREATE TABLE  emogm
    (
    grp_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (grp_no)
);



CREATE TABLE  emogi
    (
    itm_no NUMERIC(10)  NOT NULL
    grp_no NUMERIC(10) NOT NULL
    ,ord_no NUMERIC(10) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  osdesclog
    (
    rec_no NUMERIC(10)  NOT NULL
    order_no NUMERIC(10) NOT NULL
    ,dlr_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  ositemlog
    (
    det_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,item_cod CHAR(14)  NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,usag CHAR(40)  NOT NULL
    ,tot_qty CHAR(10)  NOT NULL
    ,self_qty CHAR(10)  NOT NULL
    ,emg CHAR(2)  NOT NULL
    ,self CHAR(2)  NOT NULL
    ,chg CHAR(2)  NOT NULL
    ,prm_no NUMERIC(10) NOT NULL
    ,ppf_no NUMERIC(10)
    ,map_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (det_no)
);



CREATE TABLE  moimgm
    (
    rec_no NUMERIC(10)  NOT NULL
    src CHAR(2)  NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,lnk_num2 NUMERIC(10)
    ,fm_rec NUMERIC(10)
    ,upd_tim TIMESTAMP
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  moimgd
    (
    det_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,pth CHAR(256)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (det_no)
);



CREATE TABLE  rpmmrd
    (
    mmr_no NUMERIC(10)  NOT NULL
    sou_no NUMERIC(10)
    ,ord_no NUMERIC(10) NOT NULL
    ,sed_man NUMERIC(10) NOT NULL
    ,sed_tim TIMESTAMP NOT NULL
    ,sed_typ CHAR(4)  NOT NULL
    ,msg text NOT NULL
    ,rec_man NUMERIC(10) NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mmr_no)
);



CREATE TABLE  cgval
    (
    val_no NUMERIC(10)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,val NUMERIC(10,2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (val_no)
);



CREATE TABLE  mrrdr
    (
    rdr_no NUMERIC(10)  NOT NULL
    idn CHAR(20)  NOT NULL
    ,icd_cod CHAR(16)  NOT NULL
    ,i10_cod CHAR(16)
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rdr_no)
);



CREATE TABLE  uddir
    (
    dir_no NUMERIC(10)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,acc_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,rec_dat DATE NOT NULL
    ,val NUMERIC(8,2)  NOT NULL
    ,mrk CHAR(2)
    ,room CHAR(8)  NOT NULL
    ,bed CHAR(4)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dir_no)
);



CREATE TABLE  hccdh
    (
    cdh_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,typ CHAR(20)  NOT NULL
    ,icd_cod CHAR(16)  NOT NULL
    ,atc_cod CHAR(14)  NOT NULL
    ,ing_cod CHAR(24)  NOT NULL
    ,nhi_cod CHAR(24)  NOT NULL
    ,dos_qty CHAR(12)  NOT NULL
    ,dos_unt CHAR(12)  NOT NULL
    ,use_usg CHAR(40)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,crt_man NUMERIC(5) NOT NULL
    ,crt_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cdh_no)
);



CREATE TABLE  nhnicatc
    (
    imp_no NUMERIC(10)  NOT NULL
    nhi_cod CHAR(24)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,nhi_nam CHAR(240)  NOT NULL
    ,atc_cod CHAR(14)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (imp_no)
);



CREATE TABLE  rgscdv
    (
    scd_no NUMERIC(10)  NOT NULL
    visit_dat DATE NOT NULL
    ,sft CHAR(2)  NOT NULL
    ,room NUMERIC(5) NOT NULL
    ,dct_no NUMERIC(5) NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (scd_no)
);



CREATE TABLE  rgwscdv
    (
    wsd_no NUMERIC(10)  NOT NULL
    wek_day CHAR(2)  NOT NULL
    ,sft CHAR(2)  NOT NULL
    ,room NUMERIC(5) NOT NULL
    ,stp_dat DATE NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (wsd_no)
);



CREATE TABLE  moepdsc
    (
    epd_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,map_no NUMERIC(5) NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,ord_man NUMERIC(5) NOT NULL
    ,ord_dat DATE
    ,ord_hm NUMERIC(5)
    ,ord_loc NUMERIC(5)
    ,tsc CHAR(2)
    ,lnk_no NUMERIC(10)
    ,usg VARCHAR(72)
    ,sts CHAR(2)
    ,exp_dat DATE
    ,pre_dat DATE
    ,pre_hm NUMERIC(5)
    ,exe_man NUMERIC(5)
    ,exe_dat DATE
    ,exe_hm NUMERIC(5)
    ,exe_wrd NUMERIC(5)
    ,exe_loc NUMERIC(5)
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (epd_no)
);



CREATE TABLE  moepitm
    (
    epi_no NUMERIC(10)  NOT NULL
    epd_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5)
    ,chg_cod CHAR(14)  NOT NULL
    ,dos_qty CHAR(10)
    ,itm1 CHAR(8)
    ,itm2 CHAR(8)
    ,itm3 CHAR(8)
    ,itm4 CHAR(8)
    ,exe_qty CHAR(10)
    ,nhi_qty NUMERIC(5,1)
    ,slf_qty NUMERIC(5,1)
    ,adv VARCHAR(1020)
    ,exe_man NUMERIC(5)
    ,exe_dat DATE
    ,exe_hm NUMERIC(5)
    ,exe_sts CHAR(2)
    ,lnk_no NUMERIC(10)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (epi_no)
);



CREATE TABLE  eosoerpatientddesc2
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,aadescription text
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,ahisgetdate TIMESTAMP
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes)
);



CREATE TABLE  eosoerpatientdiag2
    (
    ahospitalid CHAR(20)  NOT NULL
    avisitno CHAR(26)  NOT NULL
    ,aordertimes CHAR(8)  NOT NULL
    ,asequenceno CHAR(10)  NOT NULL
    ,aitemno NUMERIC(10)
    ,aicd9id CHAR(24)  NOT NULL
    ,achieficd9id CHAR(2)
    ,agreatill CHAR(2)
    ,aflag CHAR(2)
    ,astatus CHAR(2)
    ,awordstyle CHAR(2)
    ,ahisgetdate TIMESTAMP
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,avisitno,aordertimes,asequenceno)
);



CREATE TABLE  eosoerpatientdiagl2
    (
    ano NUMERIC(10)  NOT NULL
    ahospitalid CHAR(20)
    ,avisitno CHAR(26)
    ,aordertimes CHAR(8)
    ,asequenceno CHAR(10)
    ,aitemno NUMERIC(10)
    ,aicd9id CHAR(16)
    ,astatus CHAR(2)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ano)
);



CREATE TABLE  dci10kw
    (
    key_word CHAR(40)  NOT NULL
    icd_cod CHAR(24)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (key_word,icd_cod)
);



CREATE TABLE  mear
    (
    mea_no NUMERIC(10)  NOT NULL
    met_no NUMERIC(10) NOT NULL
    ,mea_nam CHAR(256)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mea_no)
);



CREATE TABLE  mecr
    (
    met_no NUMERIC(10)  NOT NULL
    typ CHAR(6)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,cvn_man NUMERIC(5) NOT NULL
    ,met_loc CHAR(60)  NOT NULL
    ,met_tim TIMESTAMP NOT NULL
    ,met_txt text
    ,rec_man NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (lnk_no)
);



CREATE TABLE  mepr
    (
    mep_no NUMERIC(10)  NOT NULL
    met_no NUMERIC(10) NOT NULL
    ,pre_man NUMERIC(5) NOT NULL
    ,exe_man NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mep_no)
);



CREATE TABLE  moipcl
    (
    est_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10)
    ,chart NUMERIC(10) NOT NULL
    ,sys CHAR(2)
    ,typ CHAR(2)  NOT NULL
    ,itm CHAR(6)  NOT NULL
    ,ass_dat DATE NOT NULL
    ,ass_hm NUMERIC(5) NOT NULL
    ,dct_no NUMERIC(5) NOT NULL
    ,grd NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (est_no)
);



CREATE TABLE  peerm
    (
    rec_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,frq CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  peged
    (
    itm_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,eva_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  peerl
    (
    log_no NUMERIC(10)  NOT NULL
    rec_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_no)
);



CREATE TABLE  fmmrimgd
    (
    det_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,uno CHAR(100)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (det_no)
);



CREATE TABLE  fmmrimgm
    (
    rec_no NUMERIC(10)  NOT NULL
    src CHAR(2)  NOT NULL
    ,typ1 CHAR(10)  NOT NULL
    ,typ2 CHAR(14)  NOT NULL
    ,lnk_typ CHAR(2)  NOT NULL
    ,sed_tim TIMESTAMP NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,vsn NUMERIC(10) NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,oth_lnk CHAR(64)
    ,tsc CHAR(2)  NOT NULL
    ,sav_loc CHAR(2)
    ,sav_num NUMERIC(5)
    ,sav_ets CHAR(20)
    ,p_sts CHAR(2)
    ,p_tim TIMESTAMP
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  mtoitg
    (
    grp_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,itm CHAR(6)
    ,mt_cod CHAR(14)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (grp_no)
);



CREATE TABLE  nhuapi
    (
    rec_num NUMERIC(10)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,nhi_cod CHAR(24)  NOT NULL
    ,dat_f DATE NOT NULL
    ,dat_t DATE NOT NULL
    ,nam CHAR(90)  NOT NULL
    ,nhi_up NUMERIC(9,2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_num)
);



CREATE TABLE  mtoibcr
    (
    rec_no NUMERIC(10)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5)
    ,bar_cod CHAR(200)  NOT NULL
    ,lot_no CHAR(40)  NOT NULL
    ,vaildity DATE
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  fmmridsc
    (
    det_no NUMERIC(10) NOT NULL
    det_typ CHAR(14)  NOT NULL
    ,det_loc CHAR(14)  NOT NULL
    ,det_dsc CHAR(120)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (det_no)
);



CREATE TABLE  fmmrimgl
    (
    imy_no NUMERIC(10)  NOT NULL
    det_no NUMERIC(10) NOT NULL
    ,imy_typ CHAR(2)  NOT NULL
    ,uno CHAR(100)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (imy_no)
);



CREATE TABLE  nhdin
    (
    din_no NUMERIC(10)  NOT NULL
    ing_cod CHAR(20)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,ing_nam CHAR(640)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (din_no)
);



CREATE TABLE  mocfr
    (
    rec_no NUMERIC(10)  NOT NULL
    fun_no CHAR(8)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,val CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  dgparm
    (
    par_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,vsn NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,par_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (par_no)
);



CREATE TABLE  dgpari
    (
    rec_no NUMERIC(10)  NOT NULL
    par_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,itm_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  cgcodctr
    (
    ctr_no NUMERIC(10)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,val CHAR(20)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ctr_no)
);



CREATE TABLE  mocmi2
    (
    evt_no NUMERIC(10)  NOT NULL
    sub_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,itm_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  mocmm2
    (
    sub_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,ord_no NUMERIC(10) NOT NULL
    ,cnr_no NUMERIC(10) NOT NULL
    ,sys_typ CHAR(4)  NOT NULL
    ,itm_typ CHAR(4)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cnr_tim TIMESTAMP NOT NULL
    ,cnr_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sub_no)
);



CREATE TABLE  mootxt2
    (
    txt_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,oth_dsc text NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (txt_no)
);



CREATE TABLE  mooss2
    (
    oss_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(40)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (oss_no)
);



CREATE TABLE  mools2
    (
    ols_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(240)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ols_no)
);



CREATE TABLE  modds2
    (
    dds_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dds_no)
);



CREATE TABLE  moolls2
    (
    lls_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(600)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (lls_no)
);



CREATE TABLE  ifdpmsi
    (
    det_no NUMERIC(10)  NOT NULL
    sts_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,itm_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (det_no)
);



CREATE TABLE  morur
    (
    rur_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,map_no NUMERIC(10) NOT NULL
    ,vis_typ CHAR(2)  NOT NULL
    ,adm_dr NUMERIC(10) NOT NULL
    ,tsc CHAR(2)
    ,asg_dat DATE
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rur_no)
);



CREATE TABLE  pdctbd
    (
    ser_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,nam CHAR(120)  NOT NULL
    ,nam_a CHAR(40)
    ,dat_f DATE
    ,dat_t DATE
    ,eff_day NUMERIC(5)
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  empoia
    (
    oia_no NUMERIC(10)  NOT NULL
    map_typ CHAR(2)  NOT NULL
    ,map_no NUMERIC(5)
    ,itm_cod CHAR(14)
    ,sht_typ CHAR(6)
    ,oia_dat DATE NOT NULL
    ,tsc CHAR(2)
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (oia_no)
);



CREATE TABLE  emshtsch
    (
    sht_typ_no CHAR(6)  NOT NULL
    sht_nam CHAR(120)  NOT NULL
    ,sht_nam_e CHAR(120)
    ,word_path CHAR(200)
    ,xml_path CHAR(200)
    ,prt_path CHAR(200)
    ,hbe_mrk CHAR(2)
    ,het_mrk CHAR(2)
    ,rpt_mrk CHAR(2)
    ,he_mrk CHAR(2)
    ,pt_mrk CHAR(2)
    ,rf_mrk CHAR(2)
    ,ef_mrk CHAR(2)
    ,ins_mrk CHAR(2)
    ,con_mrk CHAR(2)
    ,cf_mrk CHAR(2)
    ,pap_mrk CHAR(2)
    ,hc_mrk CHAR(2)
    ,pic_mrk CHAR(2)
    ,grp_mrk CHAR(2)
    ,cs_mrk CHAR(2)
    ,iaw text
    ,mes text
    ,ncc_dat DATE
    ,ec_dat DATE
    ,ieo_man NUMERIC(10)
    ,emr_dat DATE
    ,emr_man NUMERIC(10)
    ,uu_dpt NUMERIC(5)
    ,uu_man NUMERIC(10)
    ,iu_mrk CHAR(2)
    ,sau_mrk CHAR(2)
    ,use_tim text
    ,pid_mrk CHAR(20)
    ,pg text
    ,cmt text
    ,tsc CHAR(2)
    ,sht_typ CHAR(6)  NOT NULL
    ,law_chk CHAR(2)
    ,e_sig CHAR(2)
    ,dcl_mrk CHAR(2)
    ,visit_typ CHAR(6)
    ,dcl_dat DATE
    ,his_pre_dat DATE
    ,emr_pre_dat DATE
    ,on_line_prt CHAR(2)
    ,rp31_prt CHAR(2)
    ,paper_path CHAR(200)
    ,xml_dat DATE
    ,xml_man NUMERIC(10)
    ,dsr_mrk CHAR(2)
    ,lr_mrk CHAR(2)
    ,ps_mrk CHAR(2)
    ,barcode CHAR(2)
    ,bar_cod CHAR(10)
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sht_typ_no)
);



CREATE TABLE  nptjr
    (
    rec_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,bpd_n NUMERIC(10,0)  NOT NULL
    ,arr_tim TIMESTAMP NOT NULL
    ,sgn_man NUMERIC(10)
    ,lec_fir CHAR(2)
    ,chk_tim TIMESTAMP NOT NULL
    ,chk_man NUMERIC(10)
    ,rck_man NUMERIC(10)
    ,tsf_tim TIMESTAMP NOT NULL
    ,tsf_man NUMERIC(10)
    ,tsf_dtr NUMERIC(10)
    ,rtf_man NUMERIC(10)
    ,rec_sts CHAR(2)
    ,rtn_lnk NUMERIC(10)
    ,rtn_hei NUMERIC(10)
    ,rtn_vis NUMERIC(10)
    ,stp_tim TIMESTAMP
    ,stp_man NUMERIC(10)
    ,stp_dtr NUMERIC(10)
    ,rtp NUMERIC(10)
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  moctrl
    (
    log_no NUMERIC(10)  NOT NULL
    log_tim TIMESTAMP
    ,log_typ CHAR(4)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,val_old CHAR(20)  NOT NULL
    ,val_new CHAR(20)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_no)
);



CREATE TABLE  dci10fa
    (
    itm_no NUMERIC(10)  NOT NULL
    yyyymm NUMERIC(10) NOT NULL
    ,typ1 CHAR(4)  NOT NULL
    ,typ2 CHAR(2)  NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,i10_cod CHAR(24)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cnt NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  dccdspcs
    (
    itm_no NUMERIC(10)  NOT NULL
    icd_cod CHAR(24)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,sct CHAR(510)  NOT NULL
    ,bdy_sys CHAR(510)  NOT NULL
    ,opr CHAR(510)  NOT NULL
    ,bdy_prt CHAR(510)  NOT NULL
    ,apc CHAR(510)  NOT NULL
    ,dvc CHAR(510)  NOT NULL
    ,qlf CHAR(510)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  cndcnr
    (
    cnr_no NUMERIC(10)  NOT NULL
    dag_no NUMERIC(10) NOT NULL
    ,apt_dat DATE NOT NULL
    ,cnr_typ CHAR(2)  NOT NULL
    ,nam CHAR(24)  NOT NULL
    ,tel NUMERIC(10) NOT NULL
    ,cnr_cut NUMERIC(5) NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,val CHAR(100)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cnr_no)
);



CREATE TABLE  mrvci
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  rfhbrd
    (
    brd_no NUMERIC(10)  NOT NULL
    hsp_no NUMERIC(10,0)  NOT NULL
    ,seq CHAR(2)  NOT NULL
    ,nam_a CHAR(16)  NOT NULL
    ,nam_f CHAR(100)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (brd_no)
);



CREATE TABLE  npotxt
    (
    txt_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,oth_dsc text NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (txt_no)
);



CREATE TABLE  smdmola
    (
    dmo_no NUMERIC(10)  NOT NULL
    sub_no NUMERIC(5) NOT NULL
    ,yymm NUMERIC(5) NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,dct NUMERIC(5) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,amt_l_o NUMERIC(10) NOT NULL
    ,amt_l NUMERIC(10) NOT NULL
    ,cnt_a NUMERIC(10) NOT NULL
    ,amt_a NUMERIC(10) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dmo_no)
);



CREATE TABLE  monot
    (
    not_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,typ NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5)
    ,txt text
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (not_no)
);



CREATE TABLE  mrvts
    (
    rec_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,str_man NUMERIC(5) NOT NULL
    ,str_tim TIMESTAMP
    ,ntc_man NUMERIC(5) NOT NULL
    ,ntc_tim TIMESTAMP
    ,txt CHAR(400)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  ifdpmsr
    (
    pm_no NUMERIC(10)  NOT NULL
    sts_no NUMERIC(10) NOT NULL
    ,pm_sts CHAR(2)  NOT NULL
    ,fil_nam CHAR(120)  NOT NULL
    ,ret_dsc text NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pm_no)
);



CREATE TABLE  scerm
    (
    erm_no NUMERIC(10)  NOT NULL
    scp_no NUMERIC(10) NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,erm_man NUMERIC(5) NOT NULL
    ,erm_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (erm_no)
);



CREATE TABLE  scedf
    (
    itm_no NUMERIC(10)  NOT NULL
    erm_no NUMERIC(10) NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,eva_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  cgpap
    (
    pap_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,use_typ CHAR(4)  NOT NULL
    ,collect_no NUMERIC(10) NOT NULL
    ,amt NUMERIC(10) NOT NULL
    ,mrk CHAR(120)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pap_no)
);



CREATE TABLE  tdcctipc
    (
    itm_no NUMERIC(10)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,icd_cod CHAR(24)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  mofnd
    (
    dtl_no NUMERIC(10)  NOT NULL
    mst_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,itm_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dtl_no)
);



CREATE TABLE  nssmtc
    (
    smt_no NUMERIC(10)  NOT NULL
    wrd NUMERIC(5) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,nam CHAR(60)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (smt_no)
);



CREATE TABLE  mofnm
    (
    mst_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,itm CHAR(6)  NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mst_no)
);



CREATE TABLE  cmrols
    (
    itm_no NUMERIC(10)  NOT NULL
    res_no NUMERIC(10) NOT NULL
    ,cau_cmt CHAR(1000)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  cmirm
    (
    cmm_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,ord_no NUMERIC(10) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,ord_dat DATE NOT NULL
    ,rpt_dat DATE NOT NULL
    ,frm_typ CHAR(4)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cmm_no)
);



CREATE TABLE  cmird
    (
    ird_no NUMERIC(10)  NOT NULL
    con_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,ext_no NUMERIC(10) NOT NULL
    ,itm_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ird_no)
);



CREATE TABLE  fofib
    (
    itm_no NUMERIC(10)  NOT NULL
    sys_no CHAR(8)  NOT NULL
    ,msr_no CHAR(20)  NOT NULL
    ,det_no CHAR(16)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,tbl_rel CHAR(2)  NOT NULL
    ,itm_nam CHAR(500)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  fooss
    (
    oss_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(4)  NOT NULL
    ,ird_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(40)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (oss_no)
);



CREATE TABLE  fools
    (
    ols_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(4)  NOT NULL
    ,ird_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(240)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ols_no)
);



CREATE TABLE  foolls
    (
    lls_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(4)  NOT NULL
    ,ird_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(600)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (lls_no)
);



CREATE TABLE  footxt
    (
    txt_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(4)  NOT NULL
    ,ird_no NUMERIC(10) NOT NULL
    ,oth_dsc text NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (txt_no)
);



CREATE TABLE  tdccrdag
    (
    ccg_no NUMERIC(10)  NOT NULL
    icd_grp NUMERIC(5) NOT NULL
    ,icd_cod CHAR(24)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ccg_no)
);



CREATE TABLE  tdccrda
    (
    cca_no NUMERIC(10)  NOT NULL
    npd_cod CHAR(24)  NOT NULL
    ,icd_grp NUMERIC(5) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cca_no)
);



CREATE TABLE  fodds
    (
    dds_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(4)  NOT NULL
    ,ird_no NUMERIC(10) NOT NULL
    ,dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dds_no)
);



CREATE TABLE  ucapes
    (
    user_key NUMERIC(10)  NOT NULL
    trigger_dttm VARCHAR(56)  NOT NULL
    ,user_id VARCHAR(128)  NOT NULL
    ,user_name VARCHAR(256)  NOT NULL
    ,password VARCHAR(256)  NOT NULL
    ,user_status CHAR(2)  NOT NULL
    ,user_level VARCHAR(64)  NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (user_key)
);



CREATE TABLE  cmspr
    (
    spr_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,frm CHAR(2)  NOT NULL
    ,cir_no NUMERIC(10) NOT NULL
    ,spr_typ CHAR(2)  NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,eff_man NUMERIC(5) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,spr_sts CHAR(4)  NOT NULL
    ,spr_man NUMERIC(5)
    ,spr_tim TIMESTAMP
    ,pre_cnt NUMERIC(5) NOT NULL
    ,pre_nam CHAR(24)  NOT NULL
    ,pre_tim TIMESTAMP NOT NULL
    ,pre_dtr CHAR(24)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (spr_no)
);



CREATE TABLE  cmcrm
    (
    rec_no NUMERIC(10)  NOT NULL
    lnk_typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,frm CHAR(2)  NOT NULL
    ,cir_no NUMERIC(10) NOT NULL
    ,rec_typ CHAR(4)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  cmcrd
    (
    itm_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,grp_no NUMERIC(10) NOT NULL
    ,ext_no NUMERIC(10) NOT NULL
    ,eva_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  cmpcr
    (
    cir_no NUMERIC(10)  NOT NULL
    typ CHAR(6)  NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,vsn NUMERIC(10) NOT NULL
    ,dis_typ CHAR(4)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,stp_rsn CHAR(2)  NOT NULL
    ,dct1 NUMERIC(10) NOT NULL
    ,dct2 NUMERIC(10) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cir_no)
);



CREATE TABLE  cgmie
    (
    itm_no NUMERIC(10)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,dsc CHAR(160)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  eobatriagejudge2
    (
    aid CHAR(8)  NOT NULL
    achinesename TEXT
    ,aenglishname TEXT
    ,arank5 CHAR(2)
    ,amark CHAR(10)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aid)
);



CREATE TABLE  eobatriagecc2
    (
    aid CHAR(10)  NOT NULL
    asid CHAR(6)
    ,achinesename VARCHAR(400)
    ,aenglishname VARCHAR(400)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aid)
);



CREATE TABLE  eobatrdetaillist2
    (
    ano NUMERIC(10) NOT NULL
    ahospitalid CHAR(20)  NOT NULL
    ,acid CHAR(10)
    ,atid CHAR(8)
    ,attasjudgeid CHAR(8)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ano,ahospitalid)
);



CREATE TABLE  tddrgspm
    (
    mst_no NUMERIC(10)  NOT NULL
    eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,drg_cod_f CHAR(10)  NOT NULL
    ,drg_cod_t CHAR(10)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mst_no)
);



CREATE TABLE  tddrgspd
    (
    rec_no NUMERIC(10)  NOT NULL
    mst_no NUMERIC(10) NOT NULL
    ,icd_cod CHAR(16)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  mrpbie
    (
    pbe_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,clm_typ CHAR(4)  NOT NULL
    ,val CHAR(400)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pbe_no)
);



CREATE TABLE  xrpdip
    (
    pdi_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,acs_no CHAR(40)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pdi_no)
);



CREATE TABLE  hcpicc
    (
    rec_no NUMERIC(10)  NOT NULL
    icd_cod CHAR(16)  NOT NULL
    ,cod CHAR(10)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  pbges
    (
    evt_qno NUMERIC(10)  NOT NULL
    evt_sou CHAR(20)  NOT NULL
    ,evt_tag CHAR(64)  NOT NULL
    ,evt_sys CHAR(8)  NOT NULL
    ,evt_fun CHAR(30)
    ,evt_lvl CHAR(2)
    ,evt_lnk CHAR(64)
    ,evt_val text NOT NULL
    ,par_enc CHAR(2)
    ,pre_sts CHAR(2)
    ,pre_tag CHAR(64)
    ,pre_val text
    ,pre_tim TIMESTAMP
    ,frm_id CHAR(20)
    ,tar_id CHAR(20)
    ,exe_tim TIMESTAMP
    ,flag CHAR(64)
    ,evt_rtp NUMERIC(10) NOT NULL
    ,evt_rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_qno)
);



CREATE TABLE  eaeiicm
    (
    rec_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,eff_man NUMERIC(5) NOT NULL
    ,stp_man NUMERIC(5) NOT NULL
    ,stp_rsn CHAR(2)  NOT NULL
    ,ast_typ CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  eaeiici
    (
    itm_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  eaeiicr
    (
    ser_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,rec_man NUMERIC(5) NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  nhtdaacd
    (
    ser_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,adm_dat DATE NOT NULL
    ,dcg_dat DATE NOT NULL
    ,dct_no NUMERIC(10) NOT NULL
    ,amt_r NUMERIC(10) NOT NULL
    ,amt_n NUMERIC(10) NOT NULL
    ,cmb CHAR(2)
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  cgqec
    (
    qec_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,chg_qty NUMERIC(10) NOT NULL
    ,exe_qty NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (qec_no)
);



CREATE TABLE  cgqecd
    (
    trn_no NUMERIC(10)  NOT NULL
    qec_no NUMERIC(10) NOT NULL
    ,fun_typ CHAR(4)  NOT NULL
    ,exe_dat DATE NOT NULL
    ,exe_qty NUMERIC(5) NOT NULL
    ,exe_man NUMERIC(10) NOT NULL
    ,mrk CHAR(2)
    ,had_exe_qty NUMERIC(5)
    ,lnk_no NUMERIC(10)
    ,lnk_seq_no NUMERIC(5)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (trn_no)
);



CREATE TABLE  cgdud
    (
    ser_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,rec_typ CHAR(4)  NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  dccdrc
    (
    drc_no NUMERIC(10)  NOT NULL
    frm_typ CHAR(8)
    ,cnc_no NUMERIC(10) NOT NULL
    ,itm CHAR(6)  NOT NULL
    ,val CHAR(500)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (drc_no)
);



CREATE TABLE  eoptbr
    (
    trg_no NUMERIC(10)  NOT NULL
    trg_tim TIMESTAMP NOT NULL
    ,bar_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,vsn NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (trg_no)
);



CREATE TABLE  osppbr
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,bed_typ CHAR(2)  NOT NULL
    ,cmt CHAR(60)
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  ospptr
    (
    tim_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,rec_typ CHAR(2)  NOT NULL
    ,tim_typ CHAR(2)  NOT NULL
    ,rec_tim NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tim_no)
);



CREATE TABLE  ospprr
    (
    rsn_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,rsn_dsc CHAR(60)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rsn_no)
);



CREATE TABLE  ntird
    (
    ird_no NUMERIC(10)  NOT NULL
    ass_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(10) NOT NULL
    ,ext_no NUMERIC(10) NOT NULL
    ,itm_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ird_no)
);



CREATE TABLE  ntrcr
    (
    rcr_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,acc_no NUMERIC(10) NOT NULL
    ,adm_dat DATE NOT NULL
    ,rc_typ CHAR(6)  NOT NULL
    ,rc_dat DATE NOT NULL
    ,ec_dat DATE NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rcr_no)
);



CREATE TABLE  nteid
    (
    exi_no NUMERIC(10)  NOT NULL
    ass_no NUMERIC(10) NOT NULL
    ,ord_no NUMERIC(10) NOT NULL
    ,rpt_tim TIMESTAMP NOT NULL
    ,itm_typ CHAR(4)  NOT NULL
    ,itm_cod CHAR(14)  NOT NULL
    ,itm_nam CHAR(90)  NOT NULL
    ,val CHAR(40)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (exi_no)
);



CREATE TABLE  ntdwd
    (
    dwd_no NUMERIC(10)  NOT NULL
    emp_no NUMERIC(10) NOT NULL
    ,ward CHAR(6)  NOT NULL
    ,dpt_no NUMERIC(5) NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dwd_no)
);



CREATE TABLE  nttfnud
    (
    tub_no NUMERIC(10)  NOT NULL
    tub_cod CHAR(14)  NOT NULL
    ,tub_nam CHAR(80)  NOT NULL
    ,tub_abb CHAR(40)  NOT NULL
    ,tub_cap CHAR(12)  NOT NULL
    ,tub_unt CHAR(12)  NOT NULL
    ,tub_typ CHAR(2)  NOT NULL
    ,nut_eng CHAR(12)  NOT NULL
    ,nut_pro CHAR(12)  NOT NULL
    ,nut_fat CHAR(12)  NOT NULL
    ,nut_cho CHAR(12)  NOT NULL
    ,nut_va CHAR(12)  NOT NULL
    ,nut_bta CHAR(12)  NOT NULL
    ,nut_vd CHAR(12)  NOT NULL
    ,nut_ve CHAR(12)  NOT NULL
    ,nut_vk CHAR(12)  NOT NULL
    ,nut_vb1 CHAR(12)  NOT NULL
    ,nut_vb2 CHAR(12)  NOT NULL
    ,nut_vb6 CHAR(12)  NOT NULL
    ,nut_vb12 CHAR(12)  NOT NULL
    ,nut_vc CHAR(12)  NOT NULL
    ,nut_nia CHAR(12)  NOT NULL
    ,nut_foc CHAR(12)  NOT NULL
    ,nut_pa CHAR(12)  NOT NULL
    ,nut_bio CHAR(12)  NOT NULL
    ,nut_col CHAR(12)  NOT NULL
    ,nut_ino CHAR(12)  NOT NULL
    ,nut_ca CHAR(12)  NOT NULL
    ,nut_p CHAR(12)  NOT NULL
    ,nut_fe CHAR(12)  NOT NULL
    ,nut_na CHAR(12)  NOT NULL
    ,nut_k CHAR(12)  NOT NULL
    ,nut_cl CHAR(12)  NOT NULL
    ,nut_mg CHAR(12)  NOT NULL
    ,nut_zn CHAR(12)  NOT NULL
    ,nut_cu CHAR(12)  NOT NULL
    ,nut_i CHAR(12)  NOT NULL
    ,nut_mn CHAR(12)  NOT NULL
    ,nut_se CHAR(12)  NOT NULL
    ,nut_cr CHAR(12)  NOT NULL
    ,nut_mo CHAR(12)  NOT NULL
    ,nut_tau CHAR(12)  NOT NULL
    ,nut_crn CHAR(12)  NOT NULL
    ,nut_arg CHAR(12)  NOT NULL
    ,nut_glu CHAR(12)  NOT NULL
    ,nut_fib CHAR(12)  NOT NULL
    ,nut_so CHAR(12)  NOT NULL
    ,nut_ace CHAR(12)  NOT NULL
    ,nut_gcn CHAR(12)  NOT NULL
    ,nut_dp CHAR(12)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tub_no)
);



CREATE TABLE  mrwpr
    (
    rec_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,func_no CHAR(8)  NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,prt_nam CHAR(20)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  cgnhdud
    (
    ser_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,nhi_cod CHAR(24)  NOT NULL
    ,rec_typ CHAR(4)  NOT NULL
    ,stp_dat DATE NOT NULL
    ,rct_frm CHAR(20)  NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  cmrf
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,rec_man NUMERIC(10) NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_sts CHAR(2)  NOT NULL
    ,rec_txt text NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  hccexmh
    (
    cdh_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,typ CHAR(20)  NOT NULL
    ,yyymm CHAR(12)  NOT NULL
    ,div_cod CHAR(4)  NOT NULL
    ,icd_cod CHAR(24)  NOT NULL
    ,exm_typ CHAR(12)  NOT NULL
    ,nhi_cod CHAR(24)  NOT NULL
    ,pos_nam CHAR(40)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,opr_cnt CHAR(12)  NOT NULL
    ,crt_man NUMERIC(10) NOT NULL
    ,crt_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cdh_no)
);



CREATE TABLE  hccoprh
    (
    cdh_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,typ CHAR(20)  NOT NULL
    ,yyymm CHAR(12)  NOT NULL
    ,div_cod CHAR(4)  NOT NULL
    ,icd_cod CHAR(24)  NOT NULL
    ,nhi_cod CHAR(24)  NOT NULL
    ,pos_nam CHAR(40)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,opr_cnt CHAR(12)  NOT NULL
    ,crt_man NUMERIC(10) NOT NULL
    ,crt_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cdh_no)
);



CREATE TABLE  hccdenh
    (
    cdh_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,typ CHAR(20)  NOT NULL
    ,yyymm CHAR(12)  NOT NULL
    ,icd_cod CHAR(24)  NOT NULL
    ,nhi_cod CHAR(24)  NOT NULL
    ,pos_nam CHAR(40)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,opr_cnt CHAR(12)  NOT NULL
    ,crt_man NUMERIC(10) NOT NULL
    ,crt_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cdh_no)
);



CREATE TABLE  hccalgh
    (
    cdh_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,typ CHAR(20)  NOT NULL
    ,upl_dat DATE NOT NULL
    ,upl_hm NUMERIC(5) NOT NULL
    ,upl_idno CHAR(20)  NOT NULL
    ,upl_sgn CHAR(1200)  NOT NULL
    ,alg_nam CHAR(400)  NOT NULL
    ,crt_man NUMERIC(10) NOT NULL
    ,crt_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cdh_no)
);



CREATE TABLE  nhcodecn
    (
    imp_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,cod CHAR(24)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,lng_typ CHAR(2)  NOT NULL
    ,cod_nam CHAR(300)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (imp_no)
);



CREATE TABLE  dgdfi
    (
    dfi_no NUMERIC(10)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rls_sts CHAR(2)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dfi_no)
);



CREATE TABLE  rgdie
    (
    rde_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,clm_typ CHAR(4)  NOT NULL
    ,val CHAR(60)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rde_no)
);



CREATE TABLE  rrsyspar
    (
    par_id CHAR(40)  NOT NULL
    par_nam CHAR(80)  NOT NULL
    ,par_val CHAR(40)  NOT NULL
    ,par_v01 CHAR(40)  NOT NULL
    ,par_v02 CHAR(40)  NOT NULL
    ,par_v03 CHAR(40)  NOT NULL
    ,par_v04 CHAR(40)  NOT NULL
    ,par_v05 CHAR(40)  NOT NULL
    ,par_v06 CHAR(40)  NOT NULL
    ,par_v07 CHAR(40)  NOT NULL
    ,par_v08 CHAR(40)  NOT NULL
    ,par_v09 CHAR(40)  NOT NULL
    ,par_v10 CHAR(40)  NOT NULL
    ,par_dsc CHAR(256)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (par_id)
);



CREATE TABLE  pfdpdsb
    (
    ser_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10)
    ,emp_no NUMERIC(10) NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,typ_d CHAR(2)
    ,rat NUMERIC(4,2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  ntcar
    (
    ass_no NUMERIC(10)  NOT NULL
    ass_dat TIMESTAMP NOT NULL
    ,ass_typ CHAR(2)
    ,chart NUMERIC(10) NOT NULL
    ,acc_no NUMERIC(10) NOT NULL
    ,visit_no NUMERIC(11,0)  NOT NULL
    ,frm_typ CHAR(6)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ass_no)
);



CREATE TABLE  dgdbmr
    (
    bmr_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,frm_no NUMERIC(10) NOT NULL
    ,frm CHAR(2)  NOT NULL
    ,gen_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,lmp_typ CHAR(2)  NOT NULL
    ,lmp_no NUMERIC(5) NOT NULL
    ,adj_info CHAR(22)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bmr_no)
);



CREATE TABLE  dgdbir
    (
    bir_no NUMERIC(10)  NOT NULL
    bmr_no NUMERIC(10) NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,dos_qty CHAR(10)
    ,usg CHAR(36)  NOT NULL
    ,itm1 CHAR(8)
    ,itm2 CHAR(8)
    ,itm3 CHAR(8)
    ,itm4 CHAR(8)
    ,mrk CHAR(2)
    ,qty_tot CHAR(10)  NOT NULL
    ,qty_prc NUMERIC(10) NOT NULL
    ,self CHAR(2)
    ,prt_nam CHAR(20)
    ,bar_cod CHAR(40)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bir_no)
);



CREATE TABLE  cmmtr
    (
    mtr_no NUMERIC(10)  NOT NULL
    lnk_typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,room CHAR(14)
    ,ord_dat DATE NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,can_typ NUMERIC(5) NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,doctor NUMERIC(10) NOT NULL
    ,receive CHAR(2)  NOT NULL
    ,cmt CHAR(600)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mtr_no)
);



CREATE TABLE  mrisrant
    (
    ant_num NUMERIC(10)  NOT NULL
    evt_no NUMERIC(10) NOT NULL
    ,id_no CHAR(20)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,reg_dat DATE NOT NULL
    ,cmp_dat DATE NOT NULL
    ,snd_man NUMERIC(10) NOT NULL
    ,snd_dat DATE NOT NULL
    ,cmt CHAR(100)  NOT NULL
    ,att CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ant_num)
);



CREATE TABLE  catkbd
    (
    ser_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,inr NUMERIC(5)
    ,sub_dsc CHAR(80)  NOT NULL
    ,dsc text NOT NULL
    ,emp_no NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  dcdnf10
    (
    dnf_no NUMERIC(10)  NOT NULL
    icd_cod CHAR(24)  NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,flg CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dnf_no)
);



CREATE TABLE  psdmses
    (
    ser_no NUMERIC(10)  NOT NULL
    emp_no NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,seq_no NUMERIC(10) NOT NULL
    ,dut_man NUMERIC(10) NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  psdmsesl
    (
    log_no NUMERIC(10)  NOT NULL
    ser_no NUMERIC(10) NOT NULL
    ,emp_no NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,seq_no NUMERIC(10) NOT NULL
    ,dut_man NUMERIC(10) NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_no)
);



CREATE TABLE  mmreq3
    (
    seq_no NUMERIC(10)  NOT NULL
    sed_no NUMERIC(10) NOT NULL
    ,evt_typ CHAR(6)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,evt_man NUMERIC(10) NOT NULL
    ,evt_tim TIMESTAMP NOT NULL
    ,evt_flg CHAR(40)  NOT NULL
    ,cmt text NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtl NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (seq_no)
);



CREATE TABLE  bmathinf
    (
    ath_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,typ CHAR(20)  NOT NULL
    ,emp_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ath_no)
);



CREATE TABLE  pbgesn
    (
    evt_no NUMERIC(10)  NOT NULL
    evt_typ CHAR(8)  NOT NULL
    ,evt_sou CHAR(60)  NOT NULL
    ,evt_val CHAR(60)  NOT NULL
    ,evt_rtp NUMERIC(10) NOT NULL
    ,evt_rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  dgdsp
    (
    rec_no NUMERIC(10)  NOT NULL
    bar_cod CHAR(24)  NOT NULL
    ,bar_typ CHAR(2)  NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,lmp_typ CHAR(2)
    ,lmp_no NUMERIC(5)
    ,tsc CHAR(2)  NOT NULL
    ,cmp_tim TIMESTAMP
    ,prn_tim TIMESTAMP
    ,chg_tim TIMESTAMP
    ,out_tim TIMESTAMP
    ,emp_man NUMERIC(10)
    ,dct_no NUMERIC(10) NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  pseepdat
    (
    eep_no NUMERIC(10) NOT NULL
    eep_nam CHAR(20)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,cmp_no CHAR(6)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  momclog
    (
    log_num NUMERIC(10)  NOT NULL
    fun_typ CHAR(8)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,ctl_cod CHAR(20)  NOT NULL
    ,log_sts CHAR(2)  NOT NULL
    ,log_txt text NOT NULL
    ,emp_no NUMERIC(10) NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,log_tim TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_num)
);



CREATE TABLE  zzgacn
    (
    gac_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,cod CHAR(14)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,nam CHAR(80)  NOT NULL
    ,nam_e CHAR(160)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (gac_no)
);



CREATE TABLE  ifdcd
    (
    ccp_no NUMERIC(10)  NOT NULL
    gac_no NUMERIC(10) NOT NULL
    ,level CHAR(2)  NOT NULL
    ,diag_cod CHAR(14)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ccp_no)
);



CREATE TABLE  ifdbd
    (
    ifd_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,cod CHAR(14)  NOT NULL
    ,nam CHAR(160)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ifd_no)
);



CREATE TABLE  mowpr
    (
    wpr_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,fun_typ CHAR(8)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,wpr_man NUMERIC(10) NOT NULL
    ,wpr_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (wpr_no)
);



CREATE TABLE  ossub
    (
    order_no NUMERIC(10) NOT NULL
    txt text NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (order_no)
);



CREATE TABLE  osobj
    (
    order_no NUMERIC(10) NOT NULL
    txt text NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (order_no)
);



CREATE TABLE  oscmt
    (
    order_no NUMERIC(10) NOT NULL
    txt text NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (order_no)
);



CREATE TABLE  ossublog
    (
    log_no NUMERIC(10)  NOT NULL
    order_no NUMERIC(10) NOT NULL
    ,txt text NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_no)
);



CREATE TABLE  osobjlog
    (
    log_no NUMERIC(10)  NOT NULL
    order_no NUMERIC(10) NOT NULL
    ,txt text NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_no)
);



CREATE TABLE  oscmtlog
    (
    log_no NUMERIC(10)  NOT NULL
    order_no NUMERIC(10) NOT NULL
    ,txt text NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_no)
);



CREATE TABLE  oransitl
    (
    evt_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,ans_ord NUMERIC(10) NOT NULL
    ,dat_s DATE NOT NULL
    ,thm_s NUMERIC(5) NOT NULL
    ,dat_e DATE NOT NULL
    ,thm_e NUMERIC(5) NOT NULL
    ,ans_dr1 NUMERIC(10)
    ,ans_dr2 NUMERIC(10)
    ,ans_dr3 NUMERIC(10)
    ,opr_typ CHAR(2)  NOT NULL
    ,o_i CHAR(2)  NOT NULL
    ,ane_typ CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  catmf
    (
    tmf_no NUMERIC(10)  NOT NULL
    cnr_no NUMERIC(10) NOT NULL
    ,tre_typ CHAR(4)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tmf_no)
);



CREATE TABLE  cartf
    (
    rtf_no NUMERIC(10)  NOT NULL
    tmf_no NUMERIC(10) NOT NULL
    ,cur_typ CHAR(4)  NOT NULL
    ,gy NUMERIC(10) NOT NULL
    ,fr NUMERIC(10) NOT NULL
    ,loc CHAR(240)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rtf_no)
);



CREATE TABLE  catdf
    (
    tdf_no NUMERIC(10)  NOT NULL
    cnr_no NUMERIC(10) NOT NULL
    ,tmf_no NUMERIC(10) NOT NULL
    ,txt text NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tdf_no)
);



CREATE TABLE  caast
    (
    ast_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,cas_typ CHAR(2)  NOT NULL
    ,ord_no NUMERIC(10) NOT NULL
    ,sta_man NUMERIC(10) NOT NULL
    ,sta_dat DATE NOT NULL
    ,can_typ CHAR(4)  NOT NULL
    ,sys_typ CHAR(8)  NOT NULL
    ,tnm_typ CHAR(4)  NOT NULL
    ,tumor CHAR(20)  NOT NULL
    ,node CHAR(20)  NOT NULL
    ,met CHAR(40)  NOT NULL
    ,stage CHAR(20)  NOT NULL
    ,summary CHAR(80)
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ast_no)
);



CREATE TABLE  caasim
    (
    sim_no NUMERIC(10)  NOT NULL
    eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,can_typ CHAR(4)  NOT NULL
    ,ver_no NUMERIC(5) NOT NULL
    ,tnm_typ CHAR(4)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sim_no)
);



CREATE TABLE  caasid
    (
    sid_no NUMERIC(10)  NOT NULL
    sim_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,as_itm CHAR(40)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sid_no)
);



CREATE TABLE  cacmf
    (
    cmf_no NUMERIC(10)  NOT NULL
    tmf_no NUMERIC(10) NOT NULL
    ,ptc_cod CHAR(14)  NOT NULL
    ,itm_cod CHAR(14)
    ,cur_typ CHAR(4)  NOT NULL
    ,cyc_num NUMERIC(10) NOT NULL
    ,cyc_unt NUMERIC(10) NOT NULL
    ,num NUMERIC(10) NOT NULL
    ,dsc CHAR(500)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cmf_no)
);



CREATE TABLE  mevtd
    (
    vtd_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,var_typ CHAR(4)  NOT NULL
    ,dsc text NOT NULL
    ,rec_man NUMERIC(10)
    ,tsc CHAR(2)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vtd_no)
);



CREATE TABLE  mopfr
    (
    evt_no NUMERIC(10)  NOT NULL
    act_sys CHAR(4)  NOT NULL
    ,act_typ CHAR(4)  NOT NULL
    ,lnk_typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,act_man NUMERIC(10) NOT NULL
    ,act_tim TIMESTAMP NOT NULL
    ,act_loc NUMERIC(5) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  mopfrpkg
    (
    itm_no NUMERIC(10)  NOT NULL
    pkg_no NUMERIC(10) NOT NULL
    ,evt_no NUMERIC(10) NOT NULL
    ,exe_loc NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  hccexrh
    (
    cdh_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,rep_typ CHAR(2)  NOT NULL
    ,typ CHAR(20)  NOT NULL
    ,yyymm CHAR(12)  NOT NULL
    ,div_cod CHAR(4)  NOT NULL
    ,icd_cod CHAR(24)  NOT NULL
    ,pos_nam CHAR(40)  NOT NULL
    ,exm_typ CHAR(12)  NOT NULL
    ,nhi_cod CHAR(24)  NOT NULL
    ,lab_nam CHAR(200)  NOT NULL
    ,lab_typ CHAR(300)  NOT NULL
    ,lab_val CHAR(120)  NOT NULL
    ,lab_unt CHAR(60)  NOT NULL
    ,lab_ref CHAR(200)  NOT NULL
    ,rpt_txt text NOT NULL
    ,rpt_typ CHAR(400)  NOT NULL
    ,opr_dat DATE NOT NULL
    ,exm_dat DATE NOT NULL
    ,rep_dat DATE NOT NULL
    ,crt_man NUMERIC(10) NOT NULL
    ,crt_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cdh_no)
);



CREATE TABLE  hccdcsh
    (
    cdh_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,typ CHAR(20)  NOT NULL
    ,hpt_cod CHAR(20)  NOT NULL
    ,adm_dat DATE NOT NULL
    ,dis_dat DATE NOT NULL
    ,fil_txt text NOT NULL
    ,crt_man NUMERIC(10) NOT NULL
    ,crt_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cdh_no)
);



CREATE TABLE  hccphmh
    (
    cdh_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,typ CHAR(20)  NOT NULL
    ,icd_cod CHAR(24)  NOT NULL
    ,tre_typ CHAR(20)  NOT NULL
    ,try_lvl CHAR(60)  NOT NULL
    ,yyymm CHAR(12)  NOT NULL
    ,opr_cnt CHAR(12)  NOT NULL
    ,admit_dat DATE NOT NULL
    ,tre_dat DATE NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,crt_man NUMERIC(10) NOT NULL
    ,crt_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cdh_no)
);



CREATE TABLE  hccetmh
    (
    cdh_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,typ CHAR(20)  NOT NULL
    ,icd_cod CHAR(24)  NOT NULL
    ,chr_dis CHAR(2)  NOT NULL
    ,etm_cod CHAR(24)  NOT NULL
    ,use_usg CHAR(40)  NOT NULL
    ,med_day NUMERIC(10) NOT NULL
    ,med_dsc CHAR(120)  NOT NULL
    ,med_cnt CHAR(12)  NOT NULL
    ,opr_dat DATE NOT NULL
    ,crt_man NUMERIC(10) NOT NULL
    ,crt_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cdh_no)
);



CREATE TABLE  mosysprm
    (
    rec_no NUMERIC(10)  NOT NULL
    eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,func_no CHAR(8)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,msg_txt CHAR(600)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  tddrgps4
    (
    mdc_cod CHAR(4)  NOT NULL
    seq_no NUMERIC(5) NOT NULL
    ,drg CHAR(10)  NOT NULL
    ,wgt NUMERIC(8,4)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mdc_cod,seq_no,eff_dat)
);



CREATE TABLE  dci10cn4
    (
    icd_cod CHAR(16)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,nhi_cod CHAR(18)  NOT NULL
    ,drg_cod CHAR(10)  NOT NULL
    ,qip_drg CHAR(8)  NOT NULL
    ,nam_e CHAR(510)  NOT NULL
    ,nam_c CHAR(510)  NOT NULL
    ,icd_typ CHAR(8)  NOT NULL
    ,sru_mrk NUMERIC(5) NOT NULL
    ,ifq_mrk CHAR(2)  NOT NULL
    ,crn_mrk CHAR(2)  NOT NULL
    ,crn_typ CHAR(12)  NOT NULL
    ,con_mrk CHAR(2)  NOT NULL
    ,con_typ NUMERIC(5) NOT NULL
    ,sex_lmt CHAR(2)  NOT NULL
    ,dag_lmt CHAR(2)  NOT NULL
    ,spc_typ CHAR(4)  NOT NULL
    ,min_age NUMERIC(5) NOT NULL
    ,max_age NUMERIC(5) NOT NULL
    ,std_days NUMERIC(5) NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (icd_cod)
);



CREATE TABLE  dci10kw4
    (
    key_word CHAR(40)  NOT NULL
    icd_cod CHAR(16)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (key_word,icd_cod)
);



CREATE TABLE  mocorif
    (
    cri_no NUMERIC(10)  NOT NULL
    ptc_cod CHAR(14)  NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,itm_nam CHAR(100)  NOT NULL
    ,tmt_cyc CHAR(2000)  NOT NULL
    ,idc_lst CHAR(510)  NOT NULL
    ,vfy_man NUMERIC(10)
    ,vfy_tim TIMESTAMP
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cri_no)
);



CREATE TABLE  mochgtyp
    (
    chg_no NUMERIC(10)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,voc_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5)
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (chg_no)
);



CREATE TABLE  moitmvoc
    (
    voc_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,itm_no CHAR(8)  NOT NULL
    ,nam CHAR(40)  NOT NULL
    ,grp_typ CHAR(6)
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (voc_no)
);



CREATE TABLE  movctrdf
    (
    vcc_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,rom_seq NUMERIC(10) NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,vcc_rsn CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vcc_no)
);



CREATE TABLE  tddrgcn4
    (
    drg_cod CHAR(10)  NOT NULL
    nam_e CHAR(240)  NOT NULL
    ,nam_c CHAR(240)  NOT NULL
    ,div_typ CHAR(2)  NOT NULL
    ,mrk CHAR(2)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (drg_cod)
);



CREATE TABLE  tddrgnfc4
    (
    drg_num NUMERIC(10)  NOT NULL
    drg_cod CHAR(10)  NOT NULL
    ,eff_ym NUMERIC(5) NOT NULL
    ,stp_ym NUMERIC(5) NOT NULL
    ,day_avg NUMERIC(5) NOT NULL
    ,amt_low NUMERIC(10) NOT NULL
    ,amt_hgh NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (drg_num)
);



CREATE TABLE  tdmdcbd4
    (
    mdc CHAR(4)  NOT NULL
    nam_e CHAR(160)  NOT NULL
    ,nam_c CHAR(80)  NOT NULL
    ,yy NUMERIC(5) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mdc)
);



CREATE TABLE  tdncbd4
    (
    mdc_num NUMERIC(10)  NOT NULL
    mdc CHAR(4)  NOT NULL
    ,eff_ym NUMERIC(5) NOT NULL
    ,stp_ym NUMERIC(5) NOT NULL
    ,rat_m_1 NUMERIC(4,2)  NOT NULL
    ,rat_m_2 NUMERIC(4,2)  NOT NULL
    ,rat_m_3 NUMERIC(4,2)  NOT NULL
    ,rat_p_1 NUMERIC(4,2)  NOT NULL
    ,rat_p_2 NUMERIC(4,2)  NOT NULL
    ,rat_p_3 NUMERIC(4,2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mdc_num)
);



CREATE TABLE  rfiambd
    (
    rfi_no NUMERIC(10)  NOT NULL
    rfi_id CHAR(100)  NOT NULL
    ,nam CHAR(100)  NOT NULL
    ,pwd CHAR(60)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,hpt CHAR(50)  NOT NULL
    ,area CHAR(24)  NOT NULL
    ,mail CHAR(200)  NOT NULL
    ,tel CHAR(200)  NOT NULL
    ,addr CHAR(400)  NOT NULL
    ,com_typ CHAR(2)  NOT NULL
    ,com_id CHAR(100)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rfi_no)
);



CREATE TABLE  eherm
    (
    erm_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,erm_man NUMERIC(10) NOT NULL
    ,erm_tim TIMESTAMP NOT NULL
    ,exe_typ CHAR(2)  NOT NULL
    ,sed_man NUMERIC(10) NOT NULL
    ,sed_tim TIMESTAMP NOT NULL
    ,sed_dsc CHAR(200)  NOT NULL
    ,exe_man NUMERIC(10) NOT NULL
    ,exe_tim TIMESTAMP NOT NULL
    ,exe_dsc CHAR(200)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (erm_no)
);



CREATE TABLE  eherd
    (
    erd_no NUMERIC(10)  NOT NULL
    erm_no NUMERIC(10) NOT NULL
    ,itm_typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,itm_val NUMERIC(10) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (erd_no)
);



CREATE TABLE  dgcdqm
    (
    ctl_no NUMERIC(10)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,ctl_typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,qty NUMERIC(7,1)
    ,cmt CHAR(1000)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ctl_no)
);



CREATE TABLE  dgcdqr
    (
    rec_no NUMERIC(10)  NOT NULL
    ctl_no NUMERIC(10) NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,dos_qty NUMERIC(7,1)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  tddrgab4
    (
    ser_no NUMERIC(10)  NOT NULL
    fym NUMERIC(10) NOT NULL
    ,tym NUMERIC(10) NOT NULL
    ,spr NUMERIC(10) NOT NULL
    ,sla NUMERIC(10) NOT NULL
    ,rat_b NUMERIC(4,3)  NOT NULL
    ,rat_c NUMERIC(4,3)  NOT NULL
    ,rat_m NUMERIC(4,3)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  xrcalist
    (
    evt_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,year NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rsn_typ CHAR(2)
    ,can_typ CHAR(4)  NOT NULL
    ,exe_dat DATE NOT NULL
    ,rpt_dat DATE NOT NULL
    ,rpt_man NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  osrfodp
    (
    rpy_no NUMERIC(10)  NOT NULL
    rfo_no NUMERIC(10) NOT NULL
    ,rpy_txt text NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rpy_no)
);



CREATE TABLE  osrfodr
    (
    rfo_no NUMERIC(10)  NOT NULL
    rfo_vsn NUMERIC(10) NOT NULL
    ,rfo_dct NUMERIC(10) NOT NULL
    ,rfo_tim TIMESTAMP NOT NULL
    ,rfo_rsn text NOT NULL
    ,frm_vsn NUMERIC(10) NOT NULL
    ,frm_dct NUMERIC(10) NOT NULL
    ,rpy_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rfo_no)
);



CREATE TABLE  tdh10ccd
    (
    ccd_no NUMERIC(10)  NOT NULL
    icd_cod_m CHAR(24)  NOT NULL
    ,icd_cod_c CHAR(24)  NOT NULL
    ,cnt NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ccd_no)
);



CREATE TABLE  modcui10
    (
    dcu_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,div_no NUMERIC(5) NOT NULL
    ,icd_cod CHAR(16)  NOT NULL
    ,cnt NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dcu_no)
);



CREATE TABLE  mrrmp
    (
    mrc_no NUMERIC(10)  NOT NULL
    fun_no CHAR(8)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,ver_no NUMERIC(5)
    ,txt text
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mrc_no)
);



CREATE TABLE  rgrup
    (
    rsn_no NUMERIC(10)  NOT NULL
    opd_er CHAR(2)  NOT NULL
    ,charg_typ CHAR(2)  NOT NULL
    ,f_r CHAR(2)  NOT NULL
    ,pt_typ CHAR(4)  NOT NULL
    ,sft CHAR(2)  NOT NULL
    ,week CHAR(2)  NOT NULL
    ,amt NUMERIC(5) NOT NULL
    ,eff_dat DATE
    ,stp_dat DATE
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rsn_no)
);



CREATE TABLE  mrqar1
    (
    mr_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,dat DATE NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,val CHAR(20)  NOT NULL
    ,fun_no CHAR(8)
    ,lnk_num NUMERIC(10)
    ,rtp NUMERIC(10)
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mr_no)
);



CREATE TABLE  emtmpq
    (
    emq_no VARCHAR(128)  NOT NULL
    emq_typ1 VARCHAR(48)  NOT NULL
    ,emq_typ2 VARCHAR(48)  NOT NULL
    ,lnk_no VARCHAR(128)  NOT NULL
    ,cmp_man NUMERIC(10) NOT NULL
    ,cmp_tim TIMESTAMP NOT NULL
    ,tsc VARCHAR(4)  NOT NULL
    ,tsf_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (emq_no)
);



CREATE TABLE  emtmpql
    (
    emq_no VARCHAR(128)  NOT NULL
    emq_typ1 VARCHAR(48)  NOT NULL
    ,emq_typ2 VARCHAR(48)  NOT NULL
    ,lnk_no VARCHAR(128)  NOT NULL
    ,cmp_man NUMERIC(10) NOT NULL
    ,cmp_tim TIMESTAMP NOT NULL
    ,tsc VARCHAR(4)  NOT NULL
    ,tsf_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (emq_no)
);



CREATE TABLE  mostts
    (
    stts_no NUMERIC(10)  NOT NULL
    lnk_num NUMERIC(10) NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,val NUMERIC(11,2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  qmolls
    (
    lls_no NUMERIC(10)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,oth_dsc text
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (lls_no)
);



CREATE TABLE  rgdiel
    (
    rde_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,clm_typ CHAR(4)  NOT NULL
    ,val CHAR(800)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rde_no)
);



CREATE TABLE  rgdrdie
    (
    rde_no NUMERIC(10)  NOT NULL
    dct_no NUMERIC(10) NOT NULL
    ,clm_typ CHAR(4)  NOT NULL
    ,v01 CHAR(40)  NOT NULL
    ,v02 CHAR(40)  NOT NULL
    ,v03 CHAR(40)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rde_no)
);



CREATE TABLE  rfebdi
    (
    rf_no NUMERIC(10)  NOT NULL
    rf_tr_no CHAR(32)
    ,id_no CHAR(20)  NOT NULL
    ,ctt_tel CHAR(32)
    ,ctt_nam CHAR(32)
    ,eff_dat DATE NOT NULL
    ,dat_up_tim TIMESTAMP NOT NULL
    ,rf_hpt_cod CHAR(20)  NOT NULL
    ,rf_hpt CHAR(30)  NOT NULL
    ,rf_prp_cod CHAR(2)  NOT NULL
    ,rf_prp CHAR(40)  NOT NULL
    ,rf_div_cod CHAR(4)  NOT NULL
    ,rf_div CHAR(40)  NOT NULL
    ,arr_dat DATE
    ,arr_div_cod CHAR(4)
    ,arr_div CHAR(40)
    ,rlt_dct CHAR(20)  NOT NULL
    ,rlt_dct_nam CHAR(40)
    ,rlt_div_cod CHAR(4)
    ,rlt_div CHAR(40)  NOT NULL
    ,sts CHAR(60)  NOT NULL
    ,stp_dat DATE NOT NULL
    ,ath_flg CHAR(4)  NOT NULL
    ,cnt_prc_mrk CHAR(200)  NOT NULL
    ,hpt_slf_no CHAR(46)
    ,ori_tr_no CHAR(32)
    ,acc_dat DATE
    ,rep_dat DATE
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rf_no)
);



CREATE TABLE  rfebdo
    (
    rf_no NUMERIC(10)  NOT NULL
    rf_tr_no CHAR(32)
    ,id_no CHAR(20)  NOT NULL
    ,ctt_tel CHAR(32)
    ,ctt_nam CHAR(32)
    ,eff_dat DATE NOT NULL
    ,dat_up_tim TIMESTAMP NOT NULL
    ,sou_dct_id CHAR(20)
    ,sou_dct CHAR(40)  NOT NULL
    ,sou_div_cod CHAR(4)
    ,sou_div CHAR(40)  NOT NULL
    ,rf_prp_cod CHAR(2)
    ,rf_prp CHAR(40)  NOT NULL
    ,rf_hpt_cod CHAR(20)
    ,rf_hpt CHAR(30)
    ,rf_div_cod CHAR(4)
    ,rf_div CHAR(40)
    ,arr_dat DATE
    ,arr_div_cod CHAR(4)
    ,arr_div CHAR(40)
    ,sts CHAR(60)
    ,stp_dat DATE NOT NULL
    ,ath_flg CHAR(4)  NOT NULL
    ,mdc_smr CHAR(200)  NOT NULL
    ,hpt_slf_no CHAR(46)
    ,ori_tr_no CHAR(32)
    ,acc_dat DATE
    ,rep_dat DATE
    ,cnt_prc_mrk CHAR(200)
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rf_no)
);



CREATE TABLE  lbdema
    (
    lbd_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,vsn NUMERIC(10) NOT NULL
    ,ord_no NUMERIC(10) NOT NULL
    ,lab_no NUMERIC(10) NOT NULL
    ,lnk_no CHAR(40)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,source CHAR(2)  NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,loc NUMERIC(10)
    ,chg_no NUMERIC(10)
    ,exe_man NUMERIC(10)
    ,exe_dat DATE
    ,exe_hm NUMERIC(10)
    ,dly_man NUMERIC(10)
    ,dly_dat DATE
    ,dly_hm NUMERIC(10)
    ,rcv_man NUMERIC(10)
    ,rcv_dat DATE
    ,rcv_hm NUMERIC(10)
    ,rev_man NUMERIC(10)
    ,rev_dat DATE
    ,rev_hm NUMERIC(10)
    ,pre_man NUMERIC(10)
    ,pre_rtt TIMESTAMP
    ,pre_dat DATE
    ,pay_man NUMERIC(10)
    ,pay_rtt TIMESTAMP
    ,pay_dat DATE
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (lbd_no)
);



CREATE TABLE  cgromdcr
    (
    rdc_no NUMERIC(10)  NOT NULL
    room CHAR(8)  NOT NULL
    ,bed CHAR(4)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tc CHAR(2)  NOT NULL
    ,rdc_fee NUMERIC(10) NOT NULL
    ,rsn_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rdc_no)
);



CREATE TABLE  cgtsrrf
    (
    rsn_no NUMERIC(10)  NOT NULL
    typ_cod CHAR(16)  NOT NULL
    ,itm_no NUMERIC(5) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rsn CHAR(510)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rsn_no)
);



CREATE TABLE  lbiisf
    (
    ser_no NUMERIC(10)  NOT NULL
    chg_cod CHAR(14)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,src CHAR(4)  NOT NULL
    ,typ CHAR(8)  NOT NULL
    ,val CHAR(20)
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  ehpvcrf
    (
    set_no NUMERIC(10)  NOT NULL
    cod CHAR(14)  NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,nam CHAR(300)  NOT NULL
    ,crt_man NUMERIC(10) NOT NULL
    ,ctt_dat DATE NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (set_no)
);



CREATE TABLE  udocr
    (
    ser_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,det_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rev_sts CHAR(4)  NOT NULL
    ,rev_man NUMERIC(10) NOT NULL
    ,rev_tim TIMESTAMP NOT NULL
    ,coment CHAR(60)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  cgvda
    (
    vda_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,clm_typ CHAR(4)  NOT NULL
    ,val CHAR(60)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,crt_man NUMERIC(10) NOT NULL
    ,crt_tim TIMESTAMP NOT NULL
    ,apv_man NUMERIC(10) NOT NULL
    ,apv_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (vda_no)
);



CREATE TABLE  dcidie
    (
    dci_no NUMERIC(10)  NOT NULL
    icd_cod CHAR(24)  NOT NULL
    ,cor_typ CHAR(4)  NOT NULL
    ,cor_cod CHAR(24)  NOT NULL
    ,val CHAR(200)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dci_no)
);



CREATE TABLE  dgcdqml
    (
    log_num NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,txt text
    ,log_man NUMERIC(10) NOT NULL
    ,log_tim TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_num)
);



CREATE TABLE  moocr
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,ord_dat DATE NOT NULL
    ,ord_man NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  padsc
    (
    pal_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,tse_sit1 CHAR(6)
    ,tse_sit2 CHAR(6)
    ,tse_drt1 CHAR(6)
    ,tse_drt2 CHAR(6)
    ,tse_end CHAR(6)
    ,tse_sit3 CHAR(6)
    ,tsc CHAR(2)
    ,oth_tis VARCHAR(200)
    ,oth_drt VARCHAR(200)
    ,oth_end VARCHAR(200)
    ,oth_tis3 VARCHAR(200)
    ,cmt VARCHAR(160)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pal_no)
);



CREATE TABLE  dgdiad
    (
    itr_no NUMERIC(10)  NOT NULL
    srv_cod CHAR(20)  NOT NULL
    ,srv_typ CHAR(2)  NOT NULL
    ,clt_cod CHAR(20)  NOT NULL
    ,clt_typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,src CHAR(2)  NOT NULL
    ,sev_rat CHAR(2)  NOT NULL
    ,ost CHAR(2)  NOT NULL
    ,doc_gde CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itr_no)
);



CREATE TABLE  dgdbde
    (
    bde_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(4)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,val CHAR(20)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bde_no)
);



CREATE TABLE  dgotxt
    (
    dsc_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(4)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,dsc text NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dsc_no)
);



CREATE TABLE  xrpodip
    (
    pdi_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,upl_tim TIMESTAMP NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pdi_no)
);



CREATE TABLE  bmptba
    (
    rlt_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,frm_no NUMERIC(10) NOT NULL
    ,acc_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rlt_no)
);



CREATE TABLE  rgdmd
    (
    md_no NUMERIC(10)  NOT NULL
    sd_no NUMERIC(10) NOT NULL
    ,sd_frm_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,dsc text NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (md_no)
);



CREATE TABLE  rgdsm
    (
    sd_no NUMERIC(10)  NOT NULL
    sd_frm_no NUMERIC(10) NOT NULL
    ,nam CHAR(100)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,lv_no NUMERIC(5)
    ,dsc CHAR(100)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sd_no)
);



CREATE TABLE  rgdrd
    (
    rd_no NUMERIC(10)  NOT NULL
    sd_no NUMERIC(10) NOT NULL
    ,rd_frm_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,rule text NOT NULL
    ,dsc CHAR(500)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rd_no)
);



CREATE TABLE  lbcodcmd
    (
    ser_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,cod CHAR(24)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,nam_s CHAR(40)  NOT NULL
    ,nam_f CHAR(60)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  cgpcmd
    (
    pcm_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,trn_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,crd_typ CHAR(2)  NOT NULL
    ,crd_no CHAR(40)  NOT NULL
    ,inv_no CHAR(100)
    ,epr_dat CHAR(20)  NOT NULL
    ,apv_no CHAR(20)  NOT NULL
    ,trn_amt NUMERIC(10,2)  NOT NULL
    ,term_id CHAR(20)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pcm_no)
);



CREATE TABLE  cgpcvr
    (
    pcv_no NUMERIC(10)  NOT NULL
    pcm_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)
    ,vsn NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,amt NUMERIC(10,2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pcv_no)
);



CREATE TABLE  mrlldat
    (
    ser_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  smlabrpt
    (
    ser_no NUMERIC(10)  NOT NULL
    sed_no NUMERIC(10) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,val CHAR(40)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  bmrup
    (
    brp_no NUMERIC(10)  NOT NULL
    charg_typ CHAR(2)  NOT NULL
    ,lnk_no CHAR(16)  NOT NULL
    ,val CHAR(100)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,acc_no NUMERIC(10) NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (brp_no)
);



CREATE TABLE  bmmakie
    (
    bme_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,val CHAR(100)  NOT NULL
    ,pre_days NUMERIC(5) NOT NULL
    ,cnt_man CHAR(40)  NOT NULL
    ,cnt_tel NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bme_no)
);



CREATE TABLE  icatfee
    (
    at_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,each_dat DATE NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,amt NUMERIC(6,2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (at_no)
);



CREATE TABLE  bmwrdcnt
    (
    ser_no NUMERIC(10)  NOT NULL
    dat DATE NOT NULL
    ,ward CHAR(6)  NOT NULL
    ,inp_cnt NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  motbd
    (
    ser_no NUMERIC(10)  NOT NULL
    typ CHAR(20)  NOT NULL
    ,frm_no NUMERIC(10) NOT NULL
    ,nam CHAR(120)  NOT NULL
    ,cmt CHAR(200)  NOT NULL
    ,eff_dat DATE
    ,stp_dat DATE
    ,eff_day NUMERIC(5)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  motrd
    (
    rec_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,ser_no NUMERIC(10) NOT NULL
    ,src CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,val CHAR(20)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  hccish
    (
    cdh_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,cdh_msg CHAR(600)  NOT NULL
    ,tsc CHAR(2)
    ,crt_man NUMERIC(10) NOT NULL
    ,crt_tim TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cdh_no)
);



CREATE TABLE  padscd
    (
    ser_no NUMERIC(10)  NOT NULL
    pal_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,typ CHAR(4)
    ,tse CHAR(6)
    ,other VARCHAR(200)
    ,tsc CHAR(2)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  exregrul
    (
    seq_no NUMERIC(10)  NOT NULL
    item_cod CHAR(20)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,eff_tim DATE NOT NULL
    ,stp_tim DATE NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (seq_no)
);



CREATE TABLE  oomtlrl
    (
    ser_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,itm CHAR(6)  NOT NULL
    ,res_dat DATE NOT NULL
    ,res_man NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  rrchgpar
    (
    par_no NUMERIC(10)  NOT NULL
    chg_typ NUMERIC(10) NOT NULL
    ,par_typ1 CHAR(12)  NOT NULL
    ,par_typ2 CHAR(12)  NOT NULL
    ,par_typ3 CHAR(12)  NOT NULL
    ,amt NUMERIC(15,4)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (par_no)
);



CREATE TABLE  hecm
    (
    cm_no NUMERIC(10)  NOT NULL
    bar_cod CHAR(24)  NOT NULL
    ,prj_no CHAR(24)  NOT NULL
    ,hec_no NUMERIC(10) NOT NULL
    ,wrk_area CHAR(2)  NOT NULL
    ,vsn NUMERIC(10) NOT NULL
    ,ocp_no CHAR(40)  NOT NULL
    ,dis_sts CHAR(2)  NOT NULL
    ,dis_cmt CHAR(60)  NOT NULL
    ,ana_sis NUMERIC(10) NOT NULL
    ,idc NUMERIC(10) NOT NULL
    ,author NUMERIC(10) NOT NULL
    ,intl CHAR(8)  NOT NULL
    ,dis_amt NUMERIC(10) NOT NULL
    ,o_amt NUMERIC(10) NOT NULL
    ,g_amt NUMERIC(10) NOT NULL
    ,c_amt NUMERIC(10) NOT NULL
    ,p_amt NUMERIC(10) NOT NULL
    ,pr_amt NUMERIC(10) NOT NULL
    ,phy_amt NUMERIC(10) NOT NULL
    ,oth_amt NUMERIC(10) NOT NULL
    ,charg_no NUMERIC(10) NOT NULL
    ,wte_sts CHAR(2)  NOT NULL
    ,rec_num CHAR(64)  NOT NULL
    ,acc_num CHAR(64)  NOT NULL
    ,off_num CHAR(64)  NOT NULL
    ,lnk_prj CHAR(64)  NOT NULL
    ,cmt CHAR(40)  NOT NULL
    ,lnk_no CHAR(64)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cm_no)
);



CREATE TABLE  hecsi
    (
    csi_no NUMERIC(10)  NOT NULL
    cm_no NUMERIC(10) NOT NULL
    ,sch_auo NUMERIC(10) NOT NULL
    ,acd CHAR(2)  NOT NULL
    ,sch_typ CHAR(2)  NOT NULL
    ,sch_nam CHAR(128)  NOT NULL
    ,charg_typ CHAR(2)  NOT NULL
    ,prs_amt NUMERIC(10) NOT NULL
    ,dvg_amt NUMERIC(10) NOT NULL
    ,rec_amt NUMERIC(10) NOT NULL
    ,act_amt NUMERIC(10) NOT NULL
    ,sym CHAR(14)  NOT NULL
    ,qty NUMERIC(10) NOT NULL
    ,loc NUMERIC(10) NOT NULL
    ,wte_sts CHAR(2)  NOT NULL
    ,rec_num CHAR(64)  NOT NULL
    ,acc_num CHAR(64)  NOT NULL
    ,off_num CHAR(64)  NOT NULL
    ,cmt CHAR(40)  NOT NULL
    ,lnk_no CHAR(64)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (csi_no)
);



CREATE TABLE  hecsd
    (
    csd_no NUMERIC(10)  NOT NULL
    csi_no NUMERIC(10) NOT NULL
    ,exm_chg CHAR(24)  NOT NULL
    ,charg_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(10) NOT NULL
    ,item_cod CHAR(14)  NOT NULL
    ,loc NUMERIC(10) NOT NULL
    ,qty NUMERIC(10) NOT NULL
    ,amt NUMERIC(10) NOT NULL
    ,cmt CHAR(40)  NOT NULL
    ,lnk_no CHAR(64)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (csd_no)
);



CREATE TABLE  erdisaster
    (
    rep_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,disaster_no CHAR(24)  NOT NULL
    ,report_tim TIMESTAMP NOT NULL
    ,report_typ CHAR(4)  NOT NULL
    ,trend CHAR(4)  NOT NULL
    ,trend_other CHAR(400)  NOT NULL
    ,eqt_use CHAR(6)  NOT NULL
    ,chk_level CHAR(8)
    ,chk_level_0 CHAR(2)
    ,send_typ CHAR(2)
    ,leave_tim TIMESTAMP NOT NULL
    ,del_flag CHAR(6)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rep_no)
);



CREATE TABLE  erunotim
    (
    rep_no NUMERIC(10)  NOT NULL
    report_tim TIMESTAMP NOT NULL
    ,report_119 CHAR(4)  NOT NULL
    ,wait_visit NUMERIC(10) NOT NULL
    ,wait_pushbed NUMERIC(10) NOT NULL
    ,wait_hospital NUMERIC(10) NOT NULL
    ,wait_icu NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rep_no)
);



CREATE TABLE  cghicc
    (
    rec_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,pt_typ CHAR(2)  NOT NULL
    ,chg_cod CHAR(24)  NOT NULL
    ,amt CHAR(18)  NOT NULL
    ,eff_dat CHAR(14)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,sts CHAR(2)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  moval2
    (
    ser_no NUMERIC(10)  NOT NULL
    lnk_num NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,val VARCHAR(200)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  progbd
    (
    ser_no NUMERIC(10)  NOT NULL
    org_no NUMERIC(10) NOT NULL
    ,org_nam CHAR(80)  NOT NULL
    ,zip NUMERIC(10)
    ,adr VARCHAR(120)  NOT NULL
    ,tel_no NUMERIC(10)
    ,fax_no NUMERIC(10)
    ,eml_no VARCHAR(120)
    ,hed_nam CHAR(24)
    ,brn_dat DATE
    ,tit_nam VARCHAR(80)  NOT NULL
    ,emp_cnt NUMERIC(5)
    ,car_cnt NUMERIC(5)
    ,ogt_no NUMERIC(5)
    ,rsp_seq NUMERIC(10) NOT NULL
    ,cnt_dm NUMERIC(5)
    ,frm_no NUMERIC(10)
    ,eff_dat DATE
    ,stp_dat DATE
    ,cmt VARCHAR(1020)
    ,rtp NUMERIC(10)
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  cgepkgi
    (
    pkg_no NUMERIC(10)  NOT NULL
    pkg_cod CHAR(14)  NOT NULL
    ,eff_dat DATE
    ,stp_dat DATE
    ,typ CHAR(4)  NOT NULL
    ,tsc CHAR(2)
    ,pkg_amt NUMERIC(10) NOT NULL
    ,cmt CHAR(160)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pkg_no)
);



CREATE TABLE  ifdpbc
    (
    bar_no NUMERIC(10)  NOT NULL
    seq_no NUMERIC(10) NOT NULL
    ,rec_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,pro_man NUMERIC(10) NOT NULL
    ,pro_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bar_no)
);



CREATE TABLE  bmdast
    (
    evt_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,typ CHAR(6)
    ,frm_no NUMERIC(10)
    ,eff_tim TIMESTAMP NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,div_no NUMERIC(10) NOT NULL
    ,old_dct NUMERIC(10) NOT NULL
    ,new_dct NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (evt_no)
);



CREATE TABLE  pssqibd
    (
    sqi_no NUMERIC(10)  NOT NULL
    itm_typ CHAR(2)  NOT NULL
    ,itm_num CHAR(6)  NOT NULL
    ,sfc_frm CHAR(2)  NOT NULL
    ,nhi_cod CHAR(24)  NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,chk_tsc CHAR(2)  NOT NULL
    ,pay_sfc CHAR(1200)  NOT NULL
    ,sfc_anl CHAR(1200)  NOT NULL
    ,chk_lic CHAR(2)  NOT NULL
    ,chk_ctf CHAR(2)  NOT NULL
    ,chk_prf CHAR(2)  NOT NULL
    ,chk_exe CHAR(2)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sqi_no)
);



CREATE TABLE  pssqrps
    (
    rps_no NUMERIC(10)  NOT NULL
    emp_no NUMERIC(10) NOT NULL
    ,itm_typ CHAR(2)  NOT NULL
    ,itm_num CHAR(6)  NOT NULL
    ,uld_sts CHAR(2)  NOT NULL
    ,rp_sts CHAR(2)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rps_no)
);



CREATE TABLE  mmecprrf
    (
    ser_no NUMERIC(10)  NOT NULL
    map_no NUMERIC(5) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,ecp_cod CHAR(14)  NOT NULL
    ,rec_typ CHAR(4)  NOT NULL
    ,rec_dpt NUMERIC(10) NOT NULL
    ,rec_no CHAR(100)  NOT NULL
    ,rec_knd CHAR(4)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  rgafdr
    (
    fdr_no NUMERIC(10)  NOT NULL
    fil_cod CHAR(60)  NOT NULL
    ,dsc CHAR(60)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (fdr_no)
);



CREATE TABLE  rgard
    (
    ard_no NUMERIC(10)  NOT NULL
    arm_no NUMERIC(10) NOT NULL
    ,fdr_no NUMERIC(10) NOT NULL
    ,val CHAR(510)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ard_no)
);



CREATE TABLE  rgarm
    (
    arm_no NUMERIC(10)  NOT NULL
    eff_dat DATE NOT NULL
    ,typ CHAR(20)  NOT NULL
    ,lnk_vsn NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (arm_no)
);



CREATE TABLE  sigdma
    (
    sirm_no NUMERIC(10)  NOT NULL
    ma_cod CHAR(40)  NOT NULL
    ,ma_nam CHAR(120)  NOT NULL
    ,spc_typ CHAR(6)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,eff_tim DATE NOT NULL
    ,stp_tim DATE
    ,cmt CHAR(510)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sirm_no)
);



CREATE TABLE  sigddef
    (
    gd_no NUMERIC(10)  NOT NULL
    ctl_tab CHAR(40)  NOT NULL
    ,ctl_fld_nam CHAR(40)  NOT NULL
    ,def_cod CHAR(40)  NOT NULL
    ,def_nam CHAR(400)  NOT NULL
    ,tsc CHAR(2)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (gd_no)
);



CREATE TABLE  sigdde
    (
    sird_no NUMERIC(10)  NOT NULL
    ma_cod CHAR(40)  NOT NULL
    ,det_cod CHAR(40)  NOT NULL
    ,det_nam CHAR(120)  NOT NULL
    ,rea_days CHAR(8)  NOT NULL
    ,ded_flg CHAR(2)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,cmt CHAR(510)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sird_no)
);



CREATE TABLE  dgpcm
    (
    mst_no NUMERIC(10)  NOT NULL
    eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,typ_sub CHAR(4)  NOT NULL
    ,tit CHAR(500)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (mst_no)
);



CREATE TABLE  dgpcd
    (
    det_no NUMERIC(10)  NOT NULL
    mst_no NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,msg text NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (det_no)
);



CREATE TABLE  molog
    (
    log_no NUMERIC(10)  NOT NULL
    lnk_num NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,val VARCHAR(200)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,emp_no NUMERIC(10) NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,loc_tim TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_no)
);



CREATE TABLE  moupbd
    (
    ser_no NUMERIC(10)  NOT NULL
    cod_typ CHAR(2)  NOT NULL
    ,cod CHAR(14)  NOT NULL
    ,pay_typ CHAR(2)  NOT NULL
    ,vit_typ CHAR(2)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,grp_id NUMERIC(5)
    ,use_pnt CHAR(4)
    ,sat_val CHAR(24)  NOT NULL
    ,end_val CHAR(24)  NOT NULL
    ,ret_val NUMERIC(5)
    ,lnk_num NUMERIC(10) NOT NULL
    ,rsn VARCHAR(1020)
    ,cnt_psn NUMERIC(10)
    ,tel VARCHAR(80)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cod_typ,cod,pay_typ,vit_typ,eff_tim)
);



CREATE TABLE  lbsperod
    (
    rec_no NUMERIC(10)  NOT NULL
    lab_no NUMERIC(10) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  bmnapl
    (
    ntf_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,exe_man VARCHAR(40)
    ,exe_tim TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ntf_no)
);



CREATE TABLE  moruq
    (
    ser_no NUMERIC(10)  NOT NULL
    rur_no NUMERIC(10) NOT NULL
    ,ord_no NUMERIC(10) NOT NULL
    ,depart NUMERIC(10)
    ,adm_dr NUMERIC(10) NOT NULL
    ,asg_dat DATE
    ,typ CHAR(2)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  bmvstrod
    (
    ser_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,room CHAR(8)  NOT NULL
    ,bed CHAR(4)  NOT NULL
    ,shift CHAR(2)  NOT NULL
    ,lnk_typ CHAR(2)
    ,id_no CHAR(40)  NOT NULL
    ,nam CHAR(100)  NOT NULL
    ,tel_no NUMERIC(10) NOT NULL
    ,born_dat DATE
    ,sex NUMERIC(5)
    ,relation NUMERIC(5)
    ,ent_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  mobar
    (
    bar_no NUMERIC(10)  NOT NULL
    bar_typ CHAR(6)  NOT NULL
    ,lnk_no NUMERIC(12,0)  NOT NULL
    ,act_typ CHAR(4)
    ,act_loc NUMERIC(5) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bar_no)
);



CREATE TABLE  mopmt
    (
    pmt_no NUMERIC(10)  NOT NULL
    pmt_dat DATE
    ,pmt_cod CHAR(16)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pmt_no)
);



CREATE TABLE  mopmtpkg
    (
    itm_no NUMERIC(10)  NOT NULL
    pmt_no NUMERIC(10) NOT NULL
    ,evt_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  pdpcitm
    (
    itm_no NUMERIC(10)  NOT NULL
    lnk_no CHAR(10)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,seq_no NUMERIC(10) NOT NULL
    ,nam CHAR(120)  NOT NULL
    ,val CHAR(40)  NOT NULL
    ,dat_f DATE
    ,dat_t DATE
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  pdpcrd
    (
    dtl_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,val CHAR(40)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dtl_no)
);



CREATE TABLE  moogm
    (
    grp_no NUMERIC(10)  NOT NULL
    typ CHAR(6)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (grp_no)
);



CREATE TABLE  moogi
    (
    itm_no NUMERIC(10)  NOT NULL
    grp_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  ntdie
    (
    rde_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,dt_own CHAR(2)  NOT NULL
    ,f_dat DATE NOT NULL
    ,f_meal CHAR(2)  NOT NULL
    ,clm_typ CHAR(4)  NOT NULL
    ,val CHAR(60)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rde_no)
);



CREATE TABLE  btsdm
    (
    bts_no NUMERIC(10)  NOT NULL
    dpt_no NUMERIC(10) NOT NULL
    ,frm_no NUMERIC(10) NOT NULL
    ,mak_tim TIMESTAMP NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,src CHAR(2)
    ,cate CHAR(2)
    ,typ CHAR(4)
    ,capacity NUMERIC(10)
    ,tsc CHAR(2)  NOT NULL
    ,res CHAR(2)
    ,res_dsc CHAR(240)
    ,crt_man NUMERIC(10) NOT NULL
    ,crt_tim TIMESTAMP NOT NULL
    ,cmt VARCHAR(128)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bts_no)
);



CREATE TABLE  btiod
    (
    bio_no NUMERIC(10)  NOT NULL
    bts_no NUMERIC(10) NOT NULL
    ,ref_no NUMERIC(10) NOT NULL
    ,bas_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,res CHAR(2)
    ,do_man NUMERIC(10)
    ,do_tim TIMESTAMP
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bio_no)
);



CREATE TABLE  btedf
    (
    edf_no NUMERIC(10)  NOT NULL
    bts_no NUMERIC(10) NOT NULL
    ,ord_no NUMERIC(10) NOT NULL
    ,pnt_usr NUMERIC(10)
    ,pnt_tim TIMESTAMP
    ,exe_man NUMERIC(10)
    ,exe_tim TIMESTAMP
    ,exe_tsc CHAR(2)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (edf_no)
);



CREATE TABLE  bteqd
    (
    ser_no NUMERIC(10)  NOT NULL
    eqd_no NUMERIC(10) NOT NULL
    ,etyp CHAR(4)  NOT NULL
    ,eqd_nam CHAR(40)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  btird
    (
    ser_no NUMERIC(10)  NOT NULL
    frm_no NUMERIC(10) NOT NULL
    ,col_num NUMERIC(10) NOT NULL
    ,frz_num NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,crt_man NUMERIC(10) NOT NULL
    ,crt_tim TIMESTAMP NOT NULL
    ,crt_typ CHAR(4)  NOT NULL
    ,cmt CHAR(80)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  rgvsnrel
    (
    rel_no NUMERIC(10)  NOT NULL
    sou_vsn NUMERIC(10) NOT NULL
    ,rel_vsn NUMERIC(10) NOT NULL
    ,typ NUMERIC(5) NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rel_no)
);



CREATE TABLE  rgovdie
    (
    scd_no NUMERIC(10)  NOT NULL
    wek_day CHAR(2)  NOT NULL
    ,sft CHAR(2)  NOT NULL
    ,room NUMERIC(5) NOT NULL
    ,stp_dat DATE NOT NULL
    ,clm_typ CHAR(6)  NOT NULL
    ,val CHAR(120)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (scd_no)
);



CREATE TABLE  rgrldie
    (
    scd_no NUMERIC(10)  NOT NULL
    visit_dat DATE NOT NULL
    ,sft CHAR(2)  NOT NULL
    ,room NUMERIC(5) NOT NULL
    ,clm_typ CHAR(6)  NOT NULL
    ,val CHAR(120)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (scd_no)
);



CREATE TABLE  rgrdiel
    (
    rrl_no NUMERIC(10)  NOT NULL
    room NUMERIC(10) NOT NULL
    ,clm_typ CHAR(4)  NOT NULL
    ,val CHAR(200)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rrl_no)
);



CREATE TABLE  rgcsdie
    (
    rcs_no NUMERIC(10)  NOT NULL
    mis_num NUMERIC(10) NOT NULL
    ,clm_typ CHAR(6)  NOT NULL
    ,val CHAR(60)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rcs_no)
);



CREATE TABLE  udocrd
    (
    ocd_no NUMERIC(10)  NOT NULL
    ser_no NUMERIC(10) NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,eva_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ocd_no)
);



CREATE TABLE  ossoalog
    (
    det_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,desc_cdc CHAR(510)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (det_no)
);



CREATE TABLE  hcwcl
    (
    ser_no NUMERIC(10)  NOT NULL
    ccd_no NUMERIC(10) NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,val CHAR(60)  NOT NULL
    ,tsc CHAR(2)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  cghtid
    (
    tid_no NUMERIC(10)  NOT NULL
    hsp_no CHAR(20)  NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,typ CHAR(8)  NOT NULL
    ,dis_rat NUMERIC(4,2)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (tid_no)
);



CREATE TABLE  eotrtriage
    (
    ahospitalid CHAR(20)  NOT NULL
    atriageid CHAR(26)  NOT NULL
    ,atriagetimes CHAR(8)  NOT NULL
    ,auserkeyinid CHAR(30)
    ,avisitno VARCHAR(52)  NOT NULL
    ,aarriveid CHAR(4)
    ,aphotopath VARCHAR(400)
    ,atemperature NUMERIC(4,1)
    ,abreath NUMERIC(4,0)
    ,apulse NUMERIC(4,0)
    ,asbp NUMERIC(4,0)
    ,adbp NUMERIC(4,0)
    ,aweight NUMERIC(5,2)
    ,aheight NUMERIC(5,2)
    ,asao2 NUMERIC(4,0)
    ,agcse CHAR(4)
    ,agcsv CHAR(4)
    ,agcsm CHAR(4)
    ,adepartmentid CHAR(20)
    ,asystemid CHAR(6)
    ,acomplaintid CHAR(10)
    ,ajudgeid CHAR(8)
    ,acomputelevel CHAR(2)
    ,afactitiouslevel CHAR(2)
    ,achangelevelnote TEXT
    ,anursenote TEXT
    ,afinallevel CHAR(2)
    ,apainlevel NUMERIC(4,0)
    ,aspecialcase CHAR(2)
    ,adangerturn CHAR(2)
    ,aepidemic CHAR(2)
    ,aisreferral CHAR(2)
    ,aisacute CHAR(2)
    ,apicturedata text
    ,apatientname VARCHAR(120)
    ,apatientsex CHAR(2)
    ,apatientage CHAR(20)
    ,arpupilreaction NUMERIC(4,1)
    ,arpupillreflection CHAR(4)
    ,alpupilreaction NUMERIC(4,1)
    ,alpupillreflection CHAR(4)
    ,aregdeptid CHAR(20)
    ,aprotectionname VARCHAR(120)
    ,aroomno CHAR(20)
    ,abedno CHAR(20)
    ,acreatedate TIMESTAMP
    ,acreateuserid CHAR(20)
    ,amodifydate TIMESTAMP
    ,amodifyuserid CHAR(20)
    ,acreatehospitalid CHAR(20)
    ,atakedrug VARCHAR(640)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ahospitalid,atriageid,atriagetimes)
);



CREATE TABLE  uddmr
    (
    dpm_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dpm_no)
);



CREATE TABLE  uddid
    (
    det_no NUMERIC(10)  NOT NULL
    dpm_no NUMERIC(10) NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,dpm_man NUMERIC(10) NOT NULL
    ,dpm_tim TIMESTAMP NOT NULL
    ,cfm_man NUMERIC(10) NOT NULL
    ,cfm_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (det_no)
);



CREATE TABLE  moowvr
    (
    ser_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,acc_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,mrk CHAR(40)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  moowvrl
    (
    log_no NUMERIC(10)  NOT NULL
    log_tim TIMESTAMP
    ,ser_no NUMERIC(10) NOT NULL
    ,ord_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,acc_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,mrk CHAR(40)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  osdcdb
    (
    dcd_no NUMERIC(10)  NOT NULL
    doctor NUMERIC(10) NOT NULL
    ,nhi_cod CHAR(24)  NOT NULL
    ,icd_cod CHAR(16)  NOT NULL
    ,qut_cnt NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (dcd_no)
);



CREATE TABLE  exexec2
    (
    rec_no NUMERIC(10)  NOT NULL
    evt_num NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,eff_tim TIMESTAMP
    ,emp_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  exexec
    (
    ser_no NUMERIC(10)  NOT NULL
    evt_num NUMERIC(10) NOT NULL
    ,ord_no NUMERIC(10)
    ,tc1 CHAR(2)
    ,tc2 CHAR(2)
    ,ane_typ CHAR(2)  NOT NULL
    ,cmt CHAR(160)
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  dgpobs
    (
    set_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,hsp_no CHAR(2)  NOT NULL
    ,set_flg1 CHAR(20)  NOT NULL
    ,set_flg2 CHAR(20)  NOT NULL
    ,set_flg3 CHAR(20)  NOT NULL
    ,set_flg4 CHAR(20)  NOT NULL
    ,set_flg5 CHAR(20)  NOT NULL
    ,set_flg6 CHAR(20)  NOT NULL
    ,set_flg7 CHAR(20)  NOT NULL
    ,set_flg8 CHAR(20)  NOT NULL
    ,set_flg9 CHAR(20)  NOT NULL
    ,set_flg10 CHAR(20)  NOT NULL
    ,dsc CHAR(256)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (set_no)
);



CREATE TABLE  cgcar
    (
    car_no NUMERIC(10)  NOT NULL
    frm_typ CHAR(6)  NOT NULL
    ,lnk_num CHAR(40)  NOT NULL
    ,chg_typ NUMERIC(5) NOT NULL
    ,org_no CHAR(20)  NOT NULL
    ,org_nam CHAR(80)  NOT NULL
    ,sou_amt NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,upy_amt NUMERIC(10) NOT NULL
    ,close_acc CHAR(2)  NOT NULL
    ,comp_acc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (car_no)
);



CREATE TABLE  moctb
    (
    bmk_no NUMERIC(10)  NOT NULL
    emp_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,nam CHAR(200)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bmk_no)
);



CREATE TABLE  mocti
    (
    itm_no NUMERIC(10)  NOT NULL
    bmk_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,tbl_nam CHAR(16)  NOT NULL
    ,itm CHAR(20)  NOT NULL
    ,nam CHAR(200)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (itm_no)
);



CREATE TABLE  rgdrcdie
    (
    rd_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,dsp_nam CHAR(20)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,typ_lnk NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rd_no)
);



CREATE TABLE  moiolog2
    (
    log_num NUMERIC(10)  NOT NULL
    fun_no CHAR(8)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,log_sts CHAR(2)  NOT NULL
    ,log_tim TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_num)
);



CREATE TABLE  moiolog3
    (
    log_num NUMERIC(10)  NOT NULL
    fun_no CHAR(8)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,log_sts CHAR(2)  NOT NULL
    ,log_tim TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_num)
);



CREATE TABLE  moiolog4
    (
    log_num NUMERIC(10)  NOT NULL
    fun_no CHAR(8)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,log_sts CHAR(2)  NOT NULL
    ,log_tim TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_num)
);



CREATE TABLE  moiolog5
    (
    log_num NUMERIC(10)  NOT NULL
    fun_no CHAR(8)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,emp_no NUMERIC(5) NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,log_sts CHAR(2)  NOT NULL
    ,log_tim TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (log_num)
);



CREATE TABLE  padscg
    (
    scg_no NUMERIC(10)  NOT NULL
    crt_dat DATE NOT NULL
    ,grp_no CHAR(24)  NOT NULL
    ,ord_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (scg_no)
);



CREATE TABLE  mrpnie
    (
    pbe_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,clm_typ CHAR(6)  NOT NULL
    ,val NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pbe_no)
);



CREATE TABLE  uddtg
    (
    grp_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (grp_no)
);



CREATE TABLE  udded
    (
    det_no NUMERIC(10)  NOT NULL
    grp_no NUMERIC(10) NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,exe_man NUMERIC(10) NOT NULL
    ,exe_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (det_no)
);



CREATE TABLE  moaar
    (
    aar_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,itm_typ CHAR(6)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rpt text
    ,rpt_dat DATE
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (aar_no)
);



CREATE TABLE  mopspf
    (
    pf_no NUMERIC(10)  NOT NULL
    emp_no NUMERIC(10) NOT NULL
    ,fun_no CHAR(8)  NOT NULL
    ,atr_no NUMERIC(10) NOT NULL
    ,atr_val VARCHAR(80)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pf_no)
);



CREATE TABLE  moarf
    (
    atr_no NUMERIC(10)  NOT NULL
    atr_nam VARCHAR(160)  NOT NULL
    ,msg VARCHAR(1020)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (atr_no)
);



CREATE TABLE  mosrpt
    (
    srp_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,itm_typ CHAR(6)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rpt text
    ,rpt_dat DATE
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (srp_no)
);



CREATE TABLE  dgmrkl
    (
    rec_no NUMERIC(10)  NOT NULL
    lnk_num NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rsn CHAR(2)
    ,rsn_dsc CHAR(400)
    ,sym CHAR(160)
    ,sym_dsc CHAR(1000)
    ,lev_sev CHAR(2)
    ,dat_so CHAR(4)
    ,so_dsc CHAR(1000)
    ,mrk_man NUMERIC(10)
    ,mrk_tim TIMESTAMP
    ,up_tim TIMESTAMP
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  cgnhded
    (
    ded_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,amt_min NUMERIC(10) NOT NULL
    ,amt_max NUMERIC(10) NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rf_amt NUMERIC(10) NOT NULL
    ,nrf_amt NUMERIC(10) NOT NULL
    ,snf_amt NUMERIC(10)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ded_no)
);



CREATE TABLE  motxt2
    (
    ser_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,sub VARCHAR(1020)
    ,obj VARCHAR(1020)
    ,ass VARCHAR(1020)
    ,cmt VARCHAR(1020)
    ,rpt_man NUMERIC(10)
    ,rpt_dat DATE
    ,rpt_hm NUMERIC(5)
    ,rpt_typ CHAR(8)
    ,txt_typ CHAR(6)
    ,rpt text
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  ordie
    (
    ode_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,val CHAR(60)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ode_no)
);



CREATE TABLE  padscm
    (
    pal_no NUMERIC(10)  NOT NULL
    ord_no NUMERIC(10) NOT NULL
    ,frm_no NUMERIC(10)
    ,seq_no NUMERIC(5) NOT NULL
    ,tse_sit CHAR(6)
    ,tsc CHAR(2)
    ,oth_tis VARCHAR(400)
    ,cmt VARCHAR(160)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pal_no)
);



CREATE TABLE  dtptvet
    (
    evt_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,visit_no NUMERIC(11,0)
    ,typ CHAR(4)
    ,tsc CHAR(2)
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
);



CREATE TABLE  capmcr
    (
    pmc_no NUMERIC(10)  NOT NULL
    cnr_no NUMERIC(10) NOT NULL
    ,rec_dat TIMESTAMP NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,rea_typ CHAR(4)  NOT NULL
    ,rea_oth CHAR(240)  NOT NULL
    ,dr_no NUMERIC(10) NOT NULL
    ,emp_no NUMERIC(10) NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pmc_no)
);



CREATE TABLE  cgroompd
    (
    ser_no NUMERIC(10)  NOT NULL
    class CHAR(2)  NOT NULL
    ,rank CHAR(2)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,fee_cod CHAR(30)  NOT NULL
    ,amt NUMERIC(10) NOT NULL
    ,cod CHAR(14)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  cgroompm
    (
    ser_no NUMERIC(10)  NOT NULL
    fee_cod CHAR(30)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,fee_nam CHAR(100)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  dgpcf
    (
    pcf_no NUMERIC(10)  NOT NULL
    drug_cod CHAR(14)  NOT NULL
    ,m_typ CHAR(6)  NOT NULL
    ,s_typ CHAR(14)  NOT NULL
    ,val CHAR(60)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (pcf_no)
);



CREATE TABLE  mosbldd
    (
    ser_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,pre_chart NUMERIC(10) NOT NULL
    ,pre_vsn NUMERIC(10) NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,lab_rpt CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  moblddbb
    (
    ser_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,bpd_n NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  estmmf
    (
    ser_no NUMERIC(10)  NOT NULL
    itm_no CHAR(6)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,pp_typ CHAR(4)  NOT NULL
    ,pp_no CHAR(14)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,remark VARCHAR(200)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  morrd
    (
    rec_no NUMERIC(10)  NOT NULL
    std_no NUMERIC(10) NOT NULL
    ,tch_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  dgdped
    (
    ser_no NUMERIC(10)  NOT NULL
    license_no CHAR(20)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,pre_lab CHAR(200)  NOT NULL
    ,ing_nam CHAR(400)  NOT NULL
    ,ing_cod CHAR(22)  NOT NULL
    ,con_desc CHAR(400)  NOT NULL
    ,content CHAR(20)  NOT NULL
    ,con_unit CHAR(100)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  dgfsob
    (
    ser_no NUMERIC(10)  NOT NULL
    license_no CHAR(20)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,ch_nam CHAR(400)  NOT NULL
    ,en_nam CHAR(400)  NOT NULL
    ,fs_lnk text NOT NULL
    ,ob_lnk text NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  dglnd
    (
    ser_no NUMERIC(10)  NOT NULL
    license_no CHAR(20)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,lt_sts CHAR(12)  NOT NULL
    ,lt_dat DATE NOT NULL
    ,lt_rsn CHAR(1000)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,isd_dat DATE NOT NULL
    ,typ CHAR(16)  NOT NULL
    ,old_ls CHAR(20)  NOT NULL
    ,cus_num CHAR(28)  NOT NULL
    ,ch_nam CHAR(400)  NOT NULL
    ,en_nam CHAR(400)  NOT NULL
    ,indicat text NOT NULL
    ,dos_typ CHAR(60)  NOT NULL
    ,package CHAR(1000)  NOT NULL
    ,drug_typ CHAR(160)  NOT NULL
    ,ctl_lv CHAR(40)  NOT NULL
    ,prin_com text NOT NULL
    ,app_nam CHAR(120)  NOT NULL
    ,app_ads CHAR(200)  NOT NULL
    ,app_num CHAR(20)  NOT NULL
    ,manu_nam CHAR(200)  NOT NULL
    ,manu_site CHAR(200)  NOT NULL
    ,manu_ads CHAR(200)  NOT NULL
    ,manu_cty CHAR(40)  NOT NULL
    ,process CHAR(160)  NOT NULL
    ,chg_dat DATE NOT NULL
    ,usg_dos text NOT NULL
    ,pack_bar CHAR(1000)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  dglned
    (
    ser_no NUMERIC(10)  NOT NULL
    license_no CHAR(20)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,ch_nam CHAR(400)  NOT NULL
    ,en_nam CHAR(400)  NOT NULL
    ,shape CHAR(20)  NOT NULL
    ,sp_dos CHAR(20)  NOT NULL
    ,color CHAR(40)  NOT NULL
    ,sp_sme CHAR(40)  NOT NULL
    ,notches CHAR(12)  NOT NULL
    ,phy_dim CHAR(160)  NOT NULL
    ,lab1 CHAR(60)  NOT NULL
    ,lab2 CHAR(60)  NOT NULL
    ,phy_lnk CHAR(400)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  dgpcatc
    (
    ser_no NUMERIC(10)  NOT NULL
    license_no CHAR(20)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,itm CHAR(4)  NOT NULL
    ,cod CHAR(20)  NOT NULL
    ,en_nam CHAR(1000)  NOT NULL
    ,ch_nam CHAR(1000)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  rgdrl
    (
    rl_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,dsc text NOT NULL
    ,lang CHAR(4)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rl_no)
);



CREATE TABLE  rgdrc
    (
    rc_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,bet CHAR(500)  NOT NULL
    ,aft CHAR(500)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rc_no)
);



CREATE TABLE  mrrst
    (
    sub_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,sub_yymm CHAR(10)  NOT NULL
    ,dct_no NUMERIC(10) NOT NULL
    ,sub_sts CHAR(2)  NOT NULL
    ,frm CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (sub_no)
);



CREATE TABLE  bmdie
    (
    bde_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,clm_typ CHAR(4)  NOT NULL
    ,val CHAR(60)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (bde_no)
);



CREATE TABLE  hcwcupl
    (
    ser_no NUMERIC(10)  NOT NULL
    ccd_no NUMERIC(10) NOT NULL
    ,wrt_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ser_no)
);



CREATE TABLE  cgqecdl
    (
    cdl_no NUMERIC(10)  NOT NULL
    trn_no NUMERIC(10) NOT NULL
    ,sou_typ CHAR(6)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)
    ,coment VARCHAR(1020)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (cdl_no)
);



CREATE TABLE  mocmd
    (
    cmd_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,frm CHAR(2)  NOT NULL
    ,func_no CHAR(8)  NOT NULL
    ,clm_typ CHAR(6)  NOT NULL
    ,val CHAR(60)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_mocmd PRIMARY KEY (cmd_no)

);



CREATE TABLE  bmpvt
    (
    pvt_no NUMERIC(10)  NOT NULL
    acc_no NUMERIC(10) NOT NULL
    ,room CHAR(8)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_bmpvt PRIMARY KEY (pvt_no)

);



CREATE TABLE  rgdrcd
    (
    rc_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,apr_typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,sft CHAR(2)  NOT NULL
    ,rul_cod CHAR(40)  NOT NULL
    ,dsc text NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_rgdrcd PRIMARY KEY (rc_no)

);



CREATE TABLE  cgoscm
    (
    osc_no NUMERIC(10)  NOT NULL
    lnk_no CHAR(20)  NOT NULL
    ,lnk_typ CHAR(4)  NOT NULL
    ,charg_amt NUMERIC(10) NOT NULL
    ,cash NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,rthm NUMERIC(5) NOT NULL
    ,rtl NUMERIC(5) NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_cgoscm_cdc PRIMARY KEY (osc_no)

);



CREATE TABLE  cgoscd
    (
    det_no NUMERIC(10)  NOT NULL
    osc_no NUMERIC(10) NOT NULL
    ,typ NUMERIC(5) NOT NULL
    ,amt NUMERIC(10) NOT NULL
    ,bill_c CHAR(4)  NOT NULL
    ,bill_n CHAR(40)  NOT NULL
    ,sheet_c CHAR(4)  NOT NULL
    ,sheet_n CHAR(20)  NOT NULL
    ,due_dat DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_cgoscd PRIMARY KEY (det_no)

);



CREATE TABLE  tcmsnc
    (
    his_vsn NUMERIC(10)  NOT NULL
    his_id CHAR(20)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,his_dat DATE NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_tcmsnc PRIMARY KEY (his_vsn)

);



CREATE TABLE  rfpar
    (
    evt_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,act_typ CHAR(6)  NOT NULL
    ,val CHAR(40)  NOT NULL
    ,act_man NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,act_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_rfpar PRIMARY KEY (evt_no)

);



CREATE TABLE  osdugdff
    (
    det_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,item_cod CHAR(14)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,usag CHAR(40)  NOT NULL
    ,tot_qty CHAR(10)  NOT NULL
    ,self_qty CHAR(10)  NOT NULL
    ,emg CHAR(2)  NOT NULL
    ,self CHAR(2)  NOT NULL
    ,chg CHAR(2)  NOT NULL
    ,prm_no NUMERIC(10) NOT NULL
    ,map_no NUMERIC(5) NOT NULL
    ,adv VARCHAR(1020)  NOT NULL
    ,icr_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_osdugdff PRIMARY KEY (det_no)

);



CREATE TABLE  dgdbicr
    (
    icr_no NUMERIC(10)  NOT NULL
    bmr_no NUMERIC(10) NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,usag CHAR(40)  NOT NULL
    ,qty_tot CHAR(10)  NOT NULL
    ,qty_prc NUMERIC(10) NOT NULL
    ,self CHAR(2)
    ,adv VARCHAR(1020)
    ,lng_mrk CHAR(2)
    ,lmp_typ CHAR(2)  NOT NULL
    ,lmp_no NUMERIC(5) NOT NULL
    ,bag_prn CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_dgdbicr PRIMARY KEY (icr_no)

);



CREATE TABLE  pbatl
    (
    dat DATE NOT NULL
    hpt_loc CHAR(2)
    ,typ1 CHAR(4)  NOT NULL
    ,itm CHAR(6)  NOT NULL
    ,val CHAR(40)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_pbatl PRIMARY KEY (dat,hpt_loc,typ1,itm)

);



CREATE TABLE  momblog
    (
    log_num NUMERIC(10)  NOT NULL
    fun_typ CHAR(8)  NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,log_sts CHAR(2)  NOT NULL
    ,log_txt text NOT NULL
    ,emp_no NUMERIC(10) NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,log_tim TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_momblog PRIMARY KEY (log_num)

);



CREATE TABLE  osdugitm
    (
    itm_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,item_cod CHAR(14)  NOT NULL
    ,loc NUMERIC(5) NOT NULL
    ,usag CHAR(40)  NOT NULL
    ,tot_qty CHAR(10)  NOT NULL
    ,self_qty CHAR(10)  NOT NULL
    ,emg CHAR(2)  NOT NULL
    ,self CHAR(2)  NOT NULL
    ,chg CHAR(2)  NOT NULL
    ,prm_no NUMERIC(10) NOT NULL
    ,map_no NUMERIC(5) NOT NULL
    ,adv VARCHAR(1020)  NOT NULL
    ,bag_prn CHAR(2)  NOT NULL
    ,del_rec_no NUMERIC(10) NOT NULL
    ,lamp_no CHAR(12)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_osdugitm PRIMARY KEY (itm_no)

);



CREATE TABLE  rgldie
    (
    rde_no NUMERIC(10)  NOT NULL
    clm_typ CHAR(4)  NOT NULL
    ,rd_no NUMERIC(10) NOT NULL
    ,val CHAR(200)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_rgldie PRIMARY KEY (rde_no)

);



CREATE TABLE  cgipar
    (
    evt_no NUMERIC(10)  NOT NULL
    evt_num NUMERIC(10) NOT NULL
    ,item_cod CHAR(14)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,dpt_typ CHAR(4)  NOT NULL
    ,rec_man NUMERIC(10) NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rev_man NUMERIC(10) NOT NULL
    ,rev_tim TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_cgipar PRIMARY KEY (evt_no)

);



CREATE TABLE  dgoutitm
    (
    ser_no NUMERIC(10)  NOT NULL
    mst_no NUMERIC(10) NOT NULL
    ,chg_cod CHAR(14)  NOT NULL
    ,dos_qty CHAR(10)
    ,dos_unt CHAR(10)
    ,usg CHAR(60)  NOT NULL
    ,acpc CHAR(8)
    ,route CHAR(8)
    ,tot_qty CHAR(12)  NOT NULL
    ,self_qty CHAR(12)  NOT NULL
    ,days CHAR(6)  NOT NULL
    ,unit CHAR(8)  NOT NULL
    ,tot CHAR(16)  NOT NULL
    ,self_tot CHAR(16)  NOT NULL
    ,mrk CHAR(2)
    ,adv VARCHAR(1020)
    ,desc_cdc VARCHAR(1020)
    ,lngd CHAR(4)
    ,dg_tsc CHAR(4)  NOT NULL
    ,lot_num CHAR(60)
    ,loc NUMERIC(10)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_dgoutitm PRIMARY KEY (ser_no)

);



CREATE TABLE  dgoutmst
    (
    mst_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,dug_dat DATE NOT NULL
    ,fil1 CHAR(2)  NOT NULL
    ,lmp_typ CHAR(2)  NOT NULL
    ,lmp_no NUMERIC(10) NOT NULL
    ,bmr_no NUMERIC(10) NOT NULL
    ,ord_typ NUMERIC(10) NOT NULL
    ,ord_lnk_no NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,ord_tim TIMESTAMP
    ,chg_tim TIMESTAMP
    ,out_tim TIMESTAMP
    ,emp_man NUMERIC(10)
    ,loc_no NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_dgoutmst PRIMARY KEY (mst_no)

);



CREATE TABLE  paabr
    (
    ser_no NUMERIC(10)  NOT NULL
    pal_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,val CHAR(300)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_paabr PRIMARY KEY (ser_no)

);



CREATE TABLE  mosoahfd
    (
    itm_no NUMERIC(10)  NOT NULL
    own_no CHAR(10)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,frm_no NUMERIC(10) NOT NULL
    ,nam VARCHAR(400)
    ,seq_no NUMERIC(5) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_mosoahfd PRIMARY KEY (itm_no)

);



CREATE TABLE  mormr
    (
    rec_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,ret_man NUMERIC(10) NOT NULL
    ,rcv_man NUMERIC(10) NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,rsn TEXT  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,ret_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  cgbdar
    (
    apv_no NUMERIC(10)  NOT NULL
    lnk_typ CHAR(4)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,apl_man NUMERIC(10) NOT NULL
    ,apl_tim TIMESTAMP
    ,apl_typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,pre_eff_dat DATE NOT NULL
    ,pre_stp_dat DATE NOT NULL
    ,apv_man NUMERIC(10) NOT NULL
    ,apv_tim TIMESTAMP
    ,apv_rlt CHAR(2)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_cgbdar PRIMARY KEY (apv_no)

);



CREATE TABLE  smrf
    (
    sed_no NUMERIC(10)  NOT NULL
    apl_man NUMERIC(10) NOT NULL
    ,tel_no NUMERIC(10) NOT NULL
    ,msg CHAR(400)  NOT NULL
    ,sed_tim TIMESTAMP NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,lnk_typ CHAR(2)  NOT NULL
    ,apl_tim TIMESTAMP NOT NULL
    ,apl_loc NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_smrf PRIMARY KEY (sed_no)

);



CREATE TABLE  dgdipr
    (
    rec_no NUMERIC(10)  NOT NULL
    det_no NUMERIC(10) NOT NULL
    ,sdr_man NUMERIC(5) NOT NULL
    ,sdr_tim TIMESTAMP NOT NULL
    ,sbd_no NUMERIC(10) NOT NULL
    ,bar_tim TIMESTAMP NOT NULL
    ,cfm_sts CHAR(2)
    ,cfm_man NUMERIC(5) NOT NULL
    ,cfm_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_dgdipr PRIMARY KEY (rec_no)

);



CREATE TABLE  moomm
    (
    mst_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,fun_typ CHAR(6)  NOT NULL
    ,typ CHAR(20)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rec_man NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_moomm PRIMARY KEY (mst_no)

);



CREATE TABLE  moomd
    (
    dtl_no NUMERIC(10)  NOT NULL
    mst_no NUMERIC(10) NOT NULL
    ,itm_no NUMERIC(10) NOT NULL
    ,itm_sts CHAR(2)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_moomd PRIMARY KEY (dtl_no)

);



CREATE TABLE  moomdd
    (
    dds_no NUMERIC(10)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,dat DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_moomdd PRIMARY KEY (dds_no)

);



CREATE TABLE  moomlls
    (
    lls_no NUMERIC(10)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(600)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_moomlls PRIMARY KEY (lls_no)

);



CREATE TABLE  moomls
    (
    ols_no NUMERIC(10)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(240)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_moomls PRIMARY KEY (ols_no)

);



CREATE TABLE  moomss
    (
    oss_no NUMERIC(10)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,oth_dsc CHAR(40)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_moomss PRIMARY KEY (oss_no)

);



CREATE TABLE  moomtr
    (
    ser_no NUMERIC(10)  NOT NULL
    lnk_num NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,val TEXT  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_moomtr PRIMARY KEY (ser_no)

);



CREATE TABLE  dgoutlot
    (
    ser_no NUMERIC(10)  NOT NULL
    itm_no NUMERIC(10) NOT NULL
    ,lot_num CHAR(60)  NOT NULL
    ,lot_qty NUMERIC(10) NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_dgoutlot PRIMARY KEY (ser_no)

);



CREATE TABLE  dgoutpar
    (
    ser_no NUMERIC(10)  NOT NULL
    mst_no NUMERIC(10) NOT NULL
    ,act_typ CHAR(2)  NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,tsc CHAR(2)
    ,act_man NUMERIC(10) NOT NULL
    ,act_tim TIMESTAMP
    ,act_loc NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_dgoutpar PRIMARY KEY (ser_no)

);



CREATE TABLE  pscontra
    (
    ctt_no NUMERIC(10)  NOT NULL
    emp_no NUMERIC(10) NOT NULL
    ,contra_no CHAR(6)
    ,f_dat DATE NOT NULL
    ,t_dat DATE NOT NULL
    ,coment CHAR(40)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_pscontra PRIMARY KEY (ctt_no)

);



CREATE TABLE  mopkgdif
    (
    ser_no NUMERIC(10)  NOT NULL
    pkg_no NUMERIC(10) NOT NULL
    ,clm_typ CHAR(4)  NOT NULL
    ,val CHAR(60)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_mopkgdif PRIMARY KEY (ser_no)

);



CREATE TABLE  rgdsmn
    (
    sd_no NUMERIC(10)  NOT NULL
    sd_frm_no NUMERIC(10) NOT NULL
    ,nam CHAR(100)  NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,lv_no NUMERIC(5) NOT NULL
    ,dsc CHAR(100)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_rgdsmn PRIMARY KEY (sd_no)

);



CREATE TABLE  rgdrdn
    (
    rd_no NUMERIC(10)  NOT NULL
    sd_no NUMERIC(10) NOT NULL
    ,rd_frm_no NUMERIC(10) NOT NULL
    ,typ CHAR(2)  NOT NULL
    ,rule text NOT NULL
    ,dsc CHAR(500)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_rgdrdn PRIMARY KEY (rd_no)

);



CREATE TABLE  rgdrcdn
    (
    rc_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,apr_typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,sft CHAR(2)  NOT NULL
    ,rul_cod CHAR(40)  NOT NULL
    ,dsc text NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_rgdrcdn PRIMARY KEY (rc_no)

);



CREATE TABLE  pasamf
    (
    psa_no NUMERIC(10)  NOT NULL
    pa_no CHAR(20)  NOT NULL
    ,src_loc CHAR(2)  NOT NULL
    ,oc_nam VARCHAR(160)
    ,src_typ CHAR(2)  NOT NULL
    ,src_typ_ot VARCHAR(160)
    ,afp_no NUMERIC(10) NOT NULL
    ,afp_date DATE NOT NULL
    ,ischarg CHAR(2)  NOT NULL
    ,reason VARCHAR(160)
    ,mt_no NUMERIC(10)
    ,pd_tim TIMESTAMP
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_pasamf PRIMARY KEY (psa_no)

);



CREATE TABLE  pasadf
    (
    ser_no NUMERIC(10)  NOT NULL
    psa_no NUMERIC(10) NOT NULL
    ,part CHAR(6)  NOT NULL
    ,ihc_no CHAR(10)  NOT NULL
    ,seq_no CHAR(6)  NOT NULL
    ,ihc_nam VARCHAR(120)  NOT NULL
    ,sr_i CHAR(2)
    ,sr_p NUMERIC(10)
    ,sq_bc CHAR(2)
    ,sq_oi CHAR(2)
    ,ctrl_i CHAR(2)
    ,ctrl_p NUMERIC(10)
    ,restain CHAR(2)
    ,display CHAR(2)
    ,remark VARCHAR(400)
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_pasadf PRIMARY KEY (ser_no)

);



CREATE TABLE  hcwcld
    (
    ser_no NUMERIC(10)  NOT NULL
    ccd_no NUMERIC(10) NOT NULL
    ,seq_no NUMERIC(5) NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,val CHAR(60)  NOT NULL
    ,tsc CHAR(2)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_hcwcld PRIMARY KEY (ser_no)

);



CREATE TABLE  momdymrk
    (
    mdy_no NUMERIC(10)  NOT NULL
    chart NUMERIC(10) NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,fun_typ CHAR(8)  NOT NULL
    ,val CHAR(400)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_momdymrk PRIMARY KEY (mdy_no)

);



CREATE TABLE  moprnrsn
    (
    rec_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,rsn CHAR(20)  NOT NULL
    ,emp_no NUMERIC(10) NOT NULL
    ,loc_no NUMERIC(5) NOT NULL
    ,log_tim TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_moprnrsn PRIMARY KEY (rec_no)

);



CREATE TABLE  moprnoth
    (
    oth_no NUMERIC(10)  NOT NULL
    rec_no NUMERIC(10) NOT NULL
    ,dsc CHAR(200)  NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_moprnoth PRIMARY KEY (oth_no)

);



CREATE TABLE  moefrd
    (
    det_no NUMERIC(10)  NOT NULL
    mst_no NUMERIC(10) NOT NULL
    ,lnk_typ CHAR(2)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,sts CHAR(2)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_moefrd PRIMARY KEY (det_no)

);



CREATE TABLE  moefrm
    (
    mst_no NUMERIC(10)  NOT NULL
    frm_no CHAR(40)  NOT NULL
    ,sts CHAR(2)
    ,rec_man NUMERIC(10) NOT NULL
    ,rec_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_moefrm PRIMARY KEY (mst_no)

);



CREATE TABLE  ntpsac
    (
    nt_no NUMERIC(10)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,amt NUMERIC(5) NOT NULL
    ,bkt_amt NUMERIC(5) NOT NULL
    ,lnh_amt NUMERIC(5) NOT NULL
    ,dnr_amt NUMERIC(5) NOT NULL
    ,rules CHAR(60)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_ntpsac PRIMARY KEY (nt_no)

);



CREATE TABLE  hcextwcr
    (
    ser_no NUMERIC(10)  NOT NULL
    typ CHAR(2)  NOT NULL
    ,his_id CHAR(40)  NOT NULL
    ,vsn NUMERIC(10) NOT NULL
    ,chart NUMERIC(10) NOT NULL
    ,his_dat DATE NOT NULL
    ,icc_ext CHAR(20)  NOT NULL
    ,icc_memo text NOT NULL
    ,icc_norm CHAR(200)
    ,icc_abnorm CHAR(200)
    ,tsc CHAR(2)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_hcextwcr PRIMARY KEY (ser_no)

);



CREATE TABLE  doolfm
    (
    ser_no NUMERIC(10)  NOT NULL
    lev_no NUMERIC(10) NOT NULL
    ,rel_no CHAR(40)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,fhm NUMERIC(5) NOT NULL
    ,stp_dat DATE NOT NULL
    ,thm NUMERIC(5) NOT NULL
    ,sts CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_doolfm PRIMARY KEY (ser_no)

);



CREATE TABLE  monotm
    (
    not_no NUMERIC(10) NOT NULL
    txt text
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  cggtrd
    (
    grp_no NUMERIC(10)  NOT NULL
    grp_cod CHAR(14)  NOT NULL
    ,grp_typ CHAR(2)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,detai_cod CHAR(14)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,det_typ CHAR(4)  NOT NULL
    ,seq_no NUMERIC(10) NOT NULL
    ,slf_qty NUMERIC(10) NOT NULL
    ,nhi_qty NUMERIC(10) NOT NULL
    ,inc_itm CHAR(2)  NOT NULL
    ,sco_app CHAR(2)  NOT NULL
    ,nrs_mrk CHAR(2)  NOT NULL
    ,pre_sts CHAR(2)  NOT NULL
    ,rsn_dsc CHAR(600)
    ,est_man NUMERIC(10) NOT NULL
    ,est_tim TIMESTAMP NOT NULL
    ,rev_man NUMERIC(10) NOT NULL
    ,rev_tim TIMESTAMP NOT NULL
    ,cfm_man NUMERIC(10) NOT NULL
    ,cfm_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_cggtrd PRIMARY KEY (grp_no)

);



CREATE TABLE  cggtrdl
    (
    log_no NUMERIC(10)  NOT NULL
    log_tim TIMESTAMP
    ,grp_no NUMERIC(10) NOT NULL
    ,grp_cod CHAR(14)  NOT NULL
    ,grp_typ CHAR(2)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,detai_cod CHAR(14)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,det_typ CHAR(4)  NOT NULL
    ,seq_no NUMERIC(10) NOT NULL
    ,slf_qty NUMERIC(10) NOT NULL
    ,nhi_qty NUMERIC(10) NOT NULL
    ,inc_itm CHAR(2)  NOT NULL
    ,sco_app CHAR(2)  NOT NULL
    ,nrs_mrk CHAR(2)  NOT NULL
    ,pre_sts CHAR(2)  NOT NULL
    ,rsn_dsc CHAR(600)
    ,est_man NUMERIC(10) NOT NULL
    ,est_tim TIMESTAMP NOT NULL
    ,rev_man NUMERIC(10) NOT NULL
    ,rev_tim TIMESTAMP NOT NULL
    ,cfm_man NUMERIC(10) NOT NULL
    ,cfm_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_cggtrdl PRIMARY KEY (log_no)

);



CREATE TABLE  dgdedf
    (
    ser_no NUMERIC(10)  NOT NULL
    cls_typ CHAR(4)  NOT NULL
    ,lnk_num NUMERIC(10) NOT NULL
    ,val CHAR(20)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_dgdedf PRIMARY KEY (ser_no)

);



CREATE TABLE  dgtpdf
    (
    itr_no NUMERIC(10)  NOT NULL
    srv_cod CHAR(20)  NOT NULL
    ,srv_typ CHAR(2)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,std_mrk CHAR(600)  NOT NULL
    ,adv CHAR(600)  NOT NULL
    ,oth_mrk CHAR(600)  NOT NULL
    ,com_tim NUMERIC(10) NOT NULL
    ,irr_tim NUMERIC(10) NOT NULL
    ,pur CHAR(2)  NOT NULL
    ,def_prm CHAR(2)  NOT NULL
    ,mon_frq NUMERIC(10) NOT NULL
    ,mon_typ CHAR(2)  NOT NULL
    ,mon_prm CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_dgtpdf PRIMARY KEY (itr_no)

);



CREATE TABLE  moplr
    (
    rec_no NUMERIC(10)  NOT NULL
    id_no CHAR(20)  NOT NULL
    ,typ CHAR(6)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,rec_sts VARCHAR(80)  NOT NULL
    ,rec_man NUMERIC(10) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (rec_no)
);



CREATE TABLE  dci10cnf
    (
    icd_cod CHAR(24)  NOT NULL
    typ CHAR(4)  NOT NULL
    ,nhi_cod CHAR(18)  NOT NULL
    ,eff_dat DATE NOT NULL
    ,stp_dat DATE NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,drg_cod CHAR(10)  NOT NULL
    ,qip_drg CHAR(12)  NOT NULL
    ,icd_ver CHAR(20)  NOT NULL
    ,nam_e CHAR(510)  NOT NULL
    ,nam_c CHAR(510)  NOT NULL
    ,icd_typ CHAR(8)  NOT NULL
    ,sru_mrk NUMERIC(5) NOT NULL
    ,ifq_mrk CHAR(2)  NOT NULL
    ,crn_mrk CHAR(2)  NOT NULL
    ,crn_typ CHAR(12)  NOT NULL
    ,con_mrk CHAR(2)  NOT NULL
    ,con_typ NUMERIC(5) NOT NULL
    ,sex_lmt CHAR(2)  NOT NULL
    ,dag_lmt CHAR(2)  NOT NULL
    ,spc_typ CHAR(4)  NOT NULL
    ,min_age NUMERIC(5) NOT NULL
    ,max_age NUMERIC(5) NOT NULL
    ,std_days NUMERIC(5) NOT NULL
    ,sru_lmt CHAR(2)  NOT NULL
    ,cmt CHAR(510)
    ,mrk_1 CHAR(24)
    ,mrk_2 CHAR(24)
    ,mrk_3 CHAR(510)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_dci10cnf PRIMARY KEY (icd_cod,eff_dat)

);



CREATE TABLE  dcicdmf
    (
    dci_no NUMERIC(10)  NOT NULL
    src_ver CHAR(20)  NOT NULL
    ,src_cod CHAR(24)  NOT NULL
    ,tgt_ver CHAR(20)  NOT NULL
    ,tgt_cod CHAR(24)  NOT NULL
    ,dfn_tag NUMERIC(5) NOT NULL
    ,mi_iht NUMERIC(5) NOT NULL
    ,cmt CHAR(510)
    ,mrk_1 CHAR(24)
    ,mrk_2 CHAR(24)
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_dcicdmf PRIMARY KEY (dci_no)

);



CREATE TABLE  bmnurnum
    (
    ser_no NUMERIC(10)  NOT NULL
    ward CHAR(6)  NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,stp_tim TIMESTAMP NOT NULL
    ,typ CHAR(4)  NOT NULL
    ,cnt NUMERIC(10) NOT NULL
    ,apl_man NUMERIC(10) NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_bmnurnum PRIMARY KEY (ser_no)

);



CREATE TABLE  mormp
    (
    rrc_no NUMERIC(10)  NOT NULL
    fun_no CHAR(8)  NOT NULL
    ,lnk_no NUMERIC(10) NOT NULL
    ,ver_no NUMERIC(5)
    ,txt text
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_mormp PRIMARY KEY (rrc_no)

);



CREATE TABLE  oostsrcd
    (
    ser_no NUMERIC(10)  NOT NULL
    visit_dat DATE NOT NULL
    ,sft CHAR(2)  NOT NULL
    ,room NUMERIC(5) NOT NULL
    ,sts_cod CHAR(6)  NOT NULL
    ,val CHAR(60)  NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_oostsrcd PRIMARY KEY (ser_no)

);



CREATE TABLE  eodiel
    (
    rde_no NUMERIC(10)  NOT NULL
    vsn NUMERIC(10) NOT NULL
    ,clm_typ CHAR(6)  NOT NULL
    ,txt text NOT NULL
    ,tsc CHAR(2)  NOT NULL
    ,rtp NUMERIC(10) NOT NULL
    ,rtd DATE NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,CONSTRAINT i1_eodiel PRIMARY KEY (rde_no)

);



CREATE TABLE  test_chinese_no_key
    (
    id NUMERIC(10)
    c CHAR(200)
    ,remark CHAR(200)
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,rowid_cdc INTEGER,    PRIMARY KEY(rowid_cdc)
);



CREATE TABLE  cmspr_2
    (
    spr_no NUMERIC(10)  NOT NULL
    lnk_no NUMERIC(10) NOT NULL
    ,frm CHAR(2)  NOT NULL
    ,cir_no NUMERIC(10) NOT NULL
    ,spr_typ CHAR(2)  NOT NULL
    ,eva_no NUMERIC(10) NOT NULL
    ,eff_man NUMERIC(5) NOT NULL
    ,eff_tim TIMESTAMP NOT NULL
    ,spr_sts CHAR(4)  NOT NULL
    ,spr_man NUMERIC(5)
    ,spr_tim TIMESTAMP
    ,pre_cnt NUMERIC(5) NOT NULL
    ,pre_nam CHAR(24)  NOT NULL
    ,pre_tim TIMESTAMP NOT NULL
    ,pre_dtr CHAR(24)  NOT NULL
    ,rtp NUMERIC(5) NOT NULL
    ,rtt TIMESTAMP NOT NULL
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (spr_no)
);



CREATE TABLE  motxt_test
    (
    ord_no NUMERIC(10) NOT NULL
    chart NUMERIC(10) NOT NULL
    ,sub VARCHAR(1020)
    ,obj VARCHAR(1020)
    ,ass VARCHAR(1020)
    ,cmt VARCHAR(1020)
    ,rpt_man NUMERIC(5)
    ,rpt_dat DATE
    ,rpt_hm NUMERIC(5)
    ,rpt_typ CHAR(8)
    ,rpt text
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (ord_no)
);



CREATE TABLE  test_chinese
    (
    id NUMERIC(10)
    c CHAR(200)
    ,remark CHAR(200)
    ,dt TIMESTAMP
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (id)
);
CREATE UNIQUE INDEX i1_mrpbd1 on mrpbd1 (chart)  ;
CREATE INDEX i2_mrpbd1 on mrpbd1 (nam)  ;
CREATE UNIQUE INDEX i3_mrpbd1 on mrpbd1 (id_no,typ)  ;
CREATE UNIQUE INDEX i4_mrpbd1 on mrpbd1 (tel_h,nam,typ)  ;
CREATE UNIQUE INDEX i1_ocoditem on ocoditem (charg_no,seq_no,item_cod)  ;
CREATE INDEX i2_ocoditem on ocoditem (item_cod, rtd,charg_no)  ;
CREATE UNIQUE INDEX i1_ocdesc on ocdesc (charg_no)  ;
CREATE INDEX i2_ocdesc on ocdesc (chart, visit_no)  ;
CREATE INDEX i3_ocdesc on ocdesc (rtd,rthm)  ;
CREATE UNIQUE INDEX i1_cgastitm on cgastitm (ast_cod)  ;
CREATE UNIQUE INDEX i1_cgbillgc on cgbillgc (group_cod,o_i,detai_cod)  ;
CREATE UNIQUE INDEX i1_cgcnc on cgcnc (typ)  ;
CREATE UNIQUE INDEX i1_cgcncc on cgcncc (collect_no,typ)  ;
CREATE UNIQUE INDEX i1_cgcoment on cgcoment (item_cod)  ;
CREATE UNIQUE INDEX i1_cgndmnam on cgndmnam (item_cod)  ;
CREATE UNIQUE INDEX i1_cgpar on cgpar (chart, visit_no,typ)  ;
CREATE UNIQUE INDEX i1_cgpfdcnt on cgpfdcnt (pt_typ,fee_typ)  ;
CREATE UNIQUE INDEX i1_cgptbd on cgptbd (pt_typ)  ;
CREATE UNIQUE INDEX i1_dgfomula on dgfomula (drug_cod,typ,seq_no)  ;
CREATE UNIQUE INDEX i1_dgjobdsp on dgjobdsp (dispense_typ,start_hhii)  ;
CREATE UNIQUE INDEX i1_dgnam on dgnam (drug_cod, seq_no)  ;
CREATE INDEX i2_dgnam on dgnam (nam)  ;
CREATE UNIQUE INDEX i1_glnprcn on glnprcn (cod)  ;
CREATE UNIQUE INDEX i1_mrocgprg on mrocgprg (chart)  ;
CREATE INDEX i2_mrocgprg on mrocgprg (rg_dat)  ;
CREATE UNIQUE INDEX i3_mrocgprg on mrocgprg (diag)  ;
CREATE UNIQUE INDEX i1_mromcn on mromcn (om_cod,seq_no)  ;
CREATE UNIQUE INDEX i1_mrpbd2 on mrpbd2 (chart)  ;
CREATE UNIQUE INDEX i1_mtnam on mtnam (mt_cod, seq_no)  ;
CREATE UNIQUE INDEX i1_psemprel on psemprel (emp_no,relat)  ;
CREATE UNIQUE INDEX i2_psemprel on psemprel (id_no)  ;
CREATE UNIQUE INDEX i1_psshcn on psshcn (cod)  ;
CREATE UNIQUE INDEX i1_rgrup on rgrup2 (opd_er, charg_typ,f_r,pt_typ)  ;
CREATE UNIQUE INDEX i1_ucogfunc on ucogfuncold (group_func_no,func_no)  ;
CREATE UNIQUE INDEX i1_cgdfrat on cgdfrat (item_cod)  ;
CREATE UNIQUE INDEX i1_cgroompf on cgroompf (class,rank,eff_dat)  ;
CREATE UNIQUE INDEX i1_cgroompp on cgroompp (class,rank)  ;
CREATE UNIQUE INDEX i1_icoditem on icoditem (charg_no,seq_no,item_cod)  ;
CREATE INDEX i2_icoditem on icoditem (item_cod, rtd,charg_no)  ;
CREATE UNIQUE INDEX i1_bmrmlvl on bmrmlvl (room,bed,eff_dat)  ;
CREATE UNIQUE INDEX i2_bmrmlvl on bmrmlvl (eff_dat,room,bed)  ;
CREATE UNIQUE INDEX i1_icglscon on icglscon (acc_no,item_cod)  ;
CREATE INDEX i1_icrolog on icrolog (acc_no)  ;
CREATE INDEX i2_icrolog on icrolog (td)  ;
CREATE UNIQUE INDEX i1_rfdata on rfdata (chart,visit_no)  ;
CREATE UNIQUE INDEX i1_icitmqty on icitmqty (acc_no,item_cod,fee_cod)  ;
CREATE UNIQUE INDEX i1_psdpatbd on psdpatbd (sub_h_no,unit_no)  ;
CREATE INDEX i1_icptclog on icptclog (acc_no)  ;
CREATE UNIQUE INDEX i1_cgpcs on cgpcs (chart, visit_no,typ)  ;
CREATE UNIQUE INDEX i1_mricddsc on mricddsc (icd_cod,seq_no)  ;
CREATE UNIQUE INDEX i1_ntpdrscn on ntpdrscn (cod)  ;
CREATE UNIQUE INDEX i1_ntpdrest on ntpdrest (acc_no,f_dat,f_meal)  ;
CREATE UNIQUE INDEX i1_ntpddesc on ntpddesc (acc_no,dt_own,f_dat,f_meal)  ;
CREATE UNIQUE INDEX i1_mrptdiag on mrptdiag (chart,visit_no,diag)  ;
CREATE INDEX i2_mrptdiag on mrptdiag (diag, visit_no)  ;
CREATE UNIQUE INDEX i1_pslicens on pslicens (emp_no,typ,typ_1,seq)  ;
CREATE UNIQUE INDEX i1_pssclcn on pssclcn (scl_no)  ;
CREATE UNIQUE INDEX i1_psdptbd on psdptbd (depart)  ;
CREATE UNIQUE INDEX i1_psdptitl on psdptitl (depart,titl)  ;
CREATE UNIQUE INDEX i1_cgcolect on cgcolect (collect_no)  ;
CREATE UNIQUE INDEX i2_cgcolect on cgcolect (chart,visit_no,collect_no)  ;
CREATE UNIQUE INDEX i3_cgcolect on cgcolect (rtd,collect_no)  ;
CREATE UNIQUE INDEX i1_pscmback on pscmback (emp_no,f_dat)  ;
CREATE UNIQUE INDEX i1_pstrain on pstrain (emp_no,f_dat)  ;
CREATE UNIQUE INDEX i1_psempscl on psempscl (emp_no,scl_no)  ;
CREATE UNIQUE INDEX i1_psephbcn on psephbcn (exp_hby,typ)  ;
CREATE INDEX i1_psexphby on psexphby (emp_no, exp_hby,typ)  ;
CREATE UNIQUE INDEX i1_pspripun on pspripun (emp_no,pp_dat)  ;
CREATE UNIQUE INDEX i1_psprodod on psprodod (emp_no,pre_od_dat)  ;
CREATE UNIQUE INDEX i1_psufbd on psufbd (typ)  ;
CREATE UNIQUE INDEX i1_psunifom on psunifom (emp_no,dat)  ;
CREATE UNIQUE INDEX i1_psscldpt on psscldpt (dpt_no)  ;
CREATE UNIQUE INDEX i1_pstitlt on pstitlt (emp_no,td)  ;
CREATE UNIQUE INDEX i1_ocmaoimt on ocmaoimt (item_cod,lp_seq)  ;
CREATE UNIQUE INDEX i1_psepbd2 on psepbd2 (emp_no)  ;
CREATE UNIQUE INDEX i1_zzrptbd on zzrptbd (typ,lp_seq)  ;
CREATE UNIQUE INDEX i2_zzrptbd on zzrptbd (progrm)  ;
CREATE UNIQUE INDEX i1_pscareer on pscareer (emp_no,f_dat)  ;
CREATE UNIQUE INDEX i1_ofvacat on ofvacat (emp_no,f_dat,f_hm)  ;
CREATE UNIQUE INDEX i1_psyrexam on psyrexam (yymm,emp_no)  ;
CREATE UNIQUE INDEX i1_psyrtot on psyrtot (emp_no)  ;
CREATE UNIQUE INDEX i1_pssalary on pssalary (emp_no)  ;
CREATE INDEX i1_icffamt on icffamt (acc_no, each_dat)  ;
CREATE INDEX i2_icffamt on icffamt (rtd, rthm)  ;
CREATE UNIQUE INDEX i1_erptbd on erptbd (chart,er_dat,er_thm)  ;
CREATE INDEX i2_erptbd on erptbd (er_dat)  ;
CREATE UNIQUE INDEX i1_uddisodf on uddisodf (acc_no,seq_no)  ;
CREATE INDEX i2_uddisodf on uddisodf (acc_no, item_cod)  ;
CREATE INDEX i1_uddologf on uddologf (acc_no, seq_no)  ;
CREATE UNIQUE INDEX i1_udductrf on udductrf (usagcod,div360,dap)  ;
CREATE INDEX i1_lbbookbr on lbbookbr (loc, borrower)  ;
CREATE INDEX i2_lbbookbr on lbbookbr (loc, acc_no)  ;
CREATE INDEX i3_lbbookbr on lbbookbr (loc, pre_dat)  ;
CREATE INDEX i1_gllauiff on gllauiff (gl_typ, appl_depart,seq_no)  ;
CREATE INDEX i2_gllauiff on gllauiff (chart)  ;
CREATE INDEX ix_1 on iofeem (typ,pt_typ, chart)  ;
CREATE UNIQUE INDEX i1_dgdesc1 on dgdesc1 (drug_cod)  ;
CREATE UNIQUE INDEX i1_osdesc on osdesc (order_no)  ;
CREATE UNIQUE INDEX i2_osdesc on osdesc (chart,visit_no desc)  ;
CREATE UNIQUE INDEX i1_ossoa on ossoa (order_no, seq_no)  ;
CREATE INDEX i1_ossoal on ossoal (order_no)  ;
CREATE UNIQUE INDEX i1_osditto on osditto (md_dr,ditto_no,seq_no)  ;
CREATE UNIQUE INDEX i1_lbbookbd on lbbookbd (loc,acc_no)  ;
CREATE INDEX i2_lbbookbd on lbbookbd (class_no, title)  ;
CREATE INDEX i3_lbbookbd on lbbookbd (vol_no, seq_no,title)  ;
CREATE INDEX i4_lbbookbd on lbbookbd (pubshr_no)  ;
CREATE INDEX i5_lbbookbd on lbbookbd (sou_loc)  ;
CREATE UNIQUE INDEX i_iaasmst1 on iaasmst (assets_no,assets_ser)  ;
CREATE INDEX i_iaasmst2 on iaasmst (supplier_no)  ;
CREATE INDEX i_iaasmst3 on iaasmst (user_no)  ;
CREATE UNIQUE INDEX i_iaassub1 on iaassub (assets_no,assets_ser,change_ser)  ;
CREATE INDEX i_iaassub2 on iaassub (assets_no, assets_ser)  ;
CREATE INDEX i_iaassub3 on iaassub (change_type)  ;
CREATE UNIQUE INDEX i_iaassup1 on iaassup (supplier_no)  ;
CREATE UNIQUE INDEX i_iaasuse1 on iaasuse (user_no)  ;
CREATE UNIQUE INDEX i1_lbjvbd on lbjvbd (loc,com_no)  ;
CREATE UNIQUE INDEX i2_lbjvbd on lbjvbd (f_vol_no,f_seq_no,title)  ;
CREATE INDEX i3_lbjvbd on lbjvbd (loc,f_vol_no, f_seq_no)  ;
CREATE UNIQUE INDEX i1_bmelidat on bmelidat (acc_no,seq_no)  ;
CREATE UNIQUE INDEX i1_mtdesc on mtdesc (mt_cod)  ;
CREATE UNIQUE INDEX meniidx on sysmenuitems (imenuname,itemnum)  ;
CREATE UNIQUE INDEX i1_cgpf on cgsiupf (item_cod, eff_dat)  ;
CREATE INDEX i2_cgpf on cgsiupf (eff_dat)  ;
CREATE UNIQUE INDEX i1_cgsiupp on cgsiupp (item_cod)  ;
CREATE UNIQUE INDEX icddata_1 on icddata (admit_dat,admit_hm,chart)  ;
CREATE UNIQUE INDEX icddata_2 on icddata (chart,discha_dat,discha_hm)  ;
CREATE UNIQUE INDEX i1_iclaudat on iclaudat (chart,in_dat,in_hm)  ;
CREATE UNIQUE INDEX i1_mrptccs on mrptccs (chart,diag,eff_dat desc)  ;
CREATE UNIQUE INDEX i1_dccontcb on dccontcb (dc_cod_m,dc_cod_a)  ;
CREATE UNIQUE INDEX i1_zzcodnam on zzcodnam (cod)  ;
CREATE UNIQUE INDEX i1_mrpobd on mrpobd (organ_no)  ;
CREATE UNIQUE INDEX i2_mrpobd on mrpobd (organ_nam)  ;
CREATE UNIQUE INDEX i1_rfdbd on rfdbd (hospital_no, doctor_no)  ;
CREATE UNIQUE INDEX i1_rgdata on rgdata (visit_no,seq_no)  ;
CREATE UNIQUE INDEX i2_rgdata on rgdata (chart,visit_no)  ;
CREATE UNIQUE INDEX i1_bmdrbac on bmdrbac (doctor)  ;
CREATE UNIQUE INDEX i1_mrcco on mrcco (chronic_no)  ;
CREATE UNIQUE INDEX i2_mrcco on mrcco (chart, doctor,stp_dat desc)  ;
CREATE UNIQUE INDEX i1_mrglcdcn on mrglcdcn (gl_cod)  ;
CREATE UNIQUE INDEX i1_mricdcn on mricdcn (icd_cod)  ;
CREATE INDEX i2_mricdcn on mricdcn (gl_cod, icd_cod)  ;
CREATE UNIQUE INDEX i1_cgndmdsc on cgndmdsc (item_cod)  ;
CREATE INDEX i1_rgrtl on rgrtl (chart,visit_dat)  ;
CREATE UNIQUE INDEX i1_cgrmod on cgrmod (rmo_no)  ;
CREATE UNIQUE INDEX i1_udmcwkds on udmcwkds (ward,dat)  ;
CREATE UNIQUE INDEX i1_glrccd on glrccd (id_no,refer_dat)  ;
CREATE UNIQUE INDEX i1_rfhbd on rfhbd (hospital_no)  ;
CREATE UNIQUE INDEX i2_rfhbd on rfhbd (nam_a)  ;
CREATE UNIQUE INDEX i1_mmivtcst on mmivtcst (giv_loc,req_loc,yy,item_cod,tc)  ;
CREATE INDEX i2_mmivtcst on mmivtcst (req_loc, item_cod,yy)  ;
CREATE INDEX ix290_1 on pspoffd (emp_no)  ;
CREATE INDEX ix290_2 on pspoffd (pre_dat)  ;
CREATE UNIQUE INDEX i1_oscnam on oscnam (map_no,typ,cod)  ;
CREATE UNIQUE INDEX i1_orroombd on orroombd (room)  ;
CREATE UNIQUE INDEX i1_oropday on oropday (room,week,shift,pri)  ;
CREATE UNIQUE INDEX i2_oropday on oropday (dr,week,shift,room)  ;
CREATE UNIQUE INDEX i1_orasrmcd on orasrmcd (room,chg_cod)  ;
CREATE UNIQUE INDEX i1_orexec on orexec (ord_no)  ;
CREATE INDEX i2_orexec on orexec (opr_dat, opr_shift,tc1,pri_typ,ord_no)  ;
CREATE INDEX i3_orexec on orexec (opr_dat, opr_shift,opr_room,pri_typ,opr_seq)  ;
CREATE UNIQUE INDEX i1_uclogin on uclogin (loc_id)  ;
CREATE UNIQUE INDEX i1_cgctrl on cgctrl (chg_cod,seq_no)  ;
CREATE INDEX i1_moexeloc on moexeloc (map_no)  ;
CREATE UNIQUE INDEX tableext1 on systableext (owner,tabname)  ;
CREATE UNIQUE INDEX columnext1 on syscolumnext (owner,tabname,colname)  ;
CREATE UNIQUE INDEX colformats1 on syscolformats (owner,tabname,colname,priority)  ;
CREATE INDEX colformats2 on syscolformats (owner,tabname,colname)  ;
CREATE UNIQUE INDEX colinput1 on syscolinput (owner,tabname,colname,attrname)  ;
CREATE INDEX colinput2 on syscolinput (owner, tabname,colname)  ;
CREATE UNIQUE INDEX colinclude1 on syscolinclude (owner,tabname,colname,priority)  ;
CREATE INDEX colinclude2 on syscolinclude (owner,tabname,colname)  ;
CREATE UNIQUE INDEX superview1 on syssuperviews (svwid)  ;
CREATE UNIQUE INDEX superview2 on syssuperviews (svwname)  ;
CREATE UNIQUE INDEX svwtables1 on syssvwtables (svwid,tabalias)  ;
CREATE UNIQUE INDEX svwtables2 on syssvwtables (svwid,tableseq)  ;
CREATE UNIQUE INDEX svwjoins1 on syssvwjoins (svwid,tabalias,jcolseq)  ;
CREATE UNIQUE INDEX svwaliases1 on syssvwaliases (svwid,tabalias,colname)  ;
CREATE UNIQUE INDEX svwaliases2 on syssvwaliases (svwid,colalias)  ;
CREATE INDEX svwaliases3 on syssvwaliases (svwid,colseq)  ;
CREATE UNIQUE INDEX svworder1 on syssvworder (svwid,seqno)  ;
CREATE UNIQUE INDEX svwauth1 on syssvwauth (svwid,username)  ;
CREATE UNIQUE INDEX svwformats1 on syssvwformats (svwid,colalias,priority)  ;
CREATE INDEX svwformats2 on syssvwformats (svwid,colalias)  ;
CREATE UNIQUE INDEX svwinput1 on syssvwinput (svwid,colalias,attrname)  ;
CREATE INDEX svwinput2 on syssvwinput (svwid, colalias)  ;
CREATE UNIQUE INDEX svwinclude1 on syssvwinclude (svwid,colalias,priority)  ;
CREATE INDEX svwinclude2 on syssvwinclude (svwid,colalias)  ;
CREATE INDEX i1_icdtfee on icdtfee (acc_no, each_dat)  ;
CREATE INDEX i2_icdtfee on icdtfee (rtd, rthm)  ;
CREATE UNIQUE INDEX ulist1 on sysulist (username)  ;
CREATE UNIQUE INDEX i1_rhexedsc on rhexedsc (job_no)  ;
CREATE UNIQUE INDEX i2_rhexedsc on rhexedsc (chart,visit_no,trp_dat,cki_hm)  ;
CREATE INDEX i3_rhexedsc on rhexedsc (charg_no)  ;
CREATE UNIQUE INDEX i1_xrbordat on xrbordat (apl_no)  ;
CREATE UNIQUE INDEX i2_xrbordat on xrbordat (chart,ret_dat desc,ret_hm)  ;
CREATE INDEX i3_xrbordat on xrbordat (bor_apl, bor_dat,bor_hm)  ;
CREATE UNIQUE INDEX i1_xrfilmst on xrfilmst (chart)  ;
CREATE UNIQUE INDEX i1_nhhicicn on nhhicicn (nh_cod,c_e)  ;
CREATE UNIQUE INDEX i1_rhexeitm on rhexeitm (job_no,chg_cod,pos)  ;
CREATE INDEX i2_rhexeitm on rhexeitm (trp_man)  ;
CREATE UNIQUE INDEX i1_stcgst on stcgst (charg_cod,stock_cod)  ;
CREATE UNIQUE INDEX i1_xritem on xritem (ord_no,chg_cod,dup_no,stock_cod)  ;
CREATE UNIQUE INDEX i1_astbd on astbd (ast_no)  ;
CREATE INDEX i2_astbd on astbd (hdl_man, nam_a)  ;
CREATE UNIQUE INDEX i1_asacsitm on asacsitm (ast_no,acs_seq)  ;
CREATE INDEX i2_asacsitm on asacsitm (loc_no)  ;
CREATE UNIQUE INDEX i1_asscdnam on asscdnam (ast_no,seq_no)  ;
CREATE UNIQUE INDEX i1_mooprcon on mooprcon (icd_cod)  ;
CREATE UNIQUE INDEX i2_mooprcon on mooprcon (division,seq_no,icd_cod)  ;
CREATE UNIQUE INDEX i1_mdvoc on mdvoc (own_no, map_no,voc_typ,seq_no)  ;
CREATE UNIQUE INDEX i1_rgovrl on rgovrl (room)  ;
CREATE UNIQUE INDEX i1_modoc on modoc (ord_no, frm_sys)  ;
CREATE UNIQUE INDEX i1_mdvoc1 on mdvoc1 (own_no,map_no,voc_typ,seq_no)  ;
CREATE UNIQUE INDEX i1_ucterml on ucterml (loc_id)  ;
CREATE UNIQUE INDEX i2_ucterml on ucterml (device_id)  ;
CREATE UNIQUE INDEX i1_ucolfunc on ucolfuncold (func_no)  ;
CREATE UNIQUE INDEX i1_paucdata on paucdata (pa_no,pa_typ)  ;
CREATE UNIQUE INDEX i2_paucdata on paucdata (rep_dat,id_no)  ;
CREATE UNIQUE INDEX i1_sttrms on sttrms (loc,stk_cod)  ;
CREATE UNIQUE INDEX i1_ositem on ositem (order_no,seq_no)  ;
CREATE INDEX i2_ositem on ositem (prm_no, map_no)  ;
CREATE INDEX i3_ositem on ositem (rtt,map_no)  ;
CREATE UNIQUE INDEX i1_nsipcl on nsipcl (chart,typ,ass_dat,ass_hm)  ;
CREATE UNIQUE INDEX i1_nsphw on nsphw (chart, msr_dat,msr_hm)  ;
CREATE UNIQUE INDEX i1_nspnvs on nspnvs (chart,msr_dat,msr_hm)  ;
CREATE UNIQUE INDEX i1_mrpar on mrpar (chart, rtt)  ;
CREATE UNIQUE INDEX i1_sepbd on sepbd (sep_no)  ;
CREATE UNIQUE INDEX i2_mrmrdir on mrmrdir (chart,dcg_dat,dcg_hm)  ;
CREATE UNIQUE INDEX i1_ofjbd on ofjbd (dpt_no, job_no)  ;
CREATE UNIQUE INDEX i1_ofjobdsp on ofjobdsp (dpt_no,job_no,dat,sft)  ;
CREATE INDEX i2_ofjobdsp on ofjobdsp (emp_no)  ;
CREATE UNIQUE INDEX i1_tgavou on tgavou (vou_dat,sub_h_no,typ,seq_no,item_no)  ;
CREATE UNIQUE INDEX ix713_1 on seril (num)  ;
CREATE UNIQUE INDEX i1_moapdn on moapdn (chart,visit_no,typ)  ;
CREATE UNIQUE INDEX i1_mrppsc on mrppsc (chart,sck_dat)  ;
CREATE INDEX i1_dgfmindx on dgfmindx (pc_12, pc_3,pc_sub1,pc_sub2,typ,nam)  ;
CREATE UNIQUE INDEX i1_dgfmproc on dgfmproc (pc_12,pc_3,pc_sub1,pc_sub2,nam_s)  ;
CREATE UNIQUE INDEX i1_pmmember on pmmember (id_no)  ;
CREATE UNIQUE INDEX i2_pmmember on pmmember (tel_h,nam)  ;
CREATE INDEX i3_pmmember on pmmember (emp_no)  ;
CREATE UNIQUE INDEX i1_nhtncic on nhtncic (itm_cod,dat_f)  ;
CREATE INDEX i2_nhtncic on nhtncic (nhi_cod)  ;
CREATE INDEX i3_nhtncic on nhtncic (dat_t)  ;
CREATE UNIQUE INDEX i1_dcicdcn on dcicdcn1 (icd_cod)  ;
CREATE UNIQUE INDEX i2_dcicdcn on dcicdcn1 (icd_typ,icd_cod)  ;
CREATE INDEX i3_dcicdcn on dcicdcn1 (drg_cod)  ;
CREATE UNIQUE INDEX i1_dcicddsc on dcicddsc (icd_cod,seq_no)  ;
CREATE UNIQUE INDEX i1_zzrrcn on zzrrcn (region_no)  ;
CREATE UNIQUE INDEX i1_nsiprd on nsiprd (acc_no)  ;
CREATE UNIQUE INDEX i1_rgovt on rgovt (wek_day, sft,room,stp_dat desc)  ;
CREATE INDEX i2_rgovt on rgovt (dct_no,wek_day, sft)  ;
CREATE INDEX i3_rgovt1 on rgovt (div_no, wek_day,sft)  ;
CREATE UNIQUE INDEX i1_rgctrl1 on rgctrl (visit_dat,sft,room)  ;
CREATE UNIQUE INDEX i2_rgctrl1 on rgctrl (visit_dat,sft,dct_no,stp)  ;
CREATE INDEX i3_rgctrl1 on rgctrl (visit_dat, sft,div_no,cur_cnt)  ;
CREATE UNIQUE INDEX i1_cpndsp on cpndsp (drg_cod,eff_dat,itm_cod)  ;
CREATE INDEX i1_rgnofee on rgnofee (visit_dat)  ;
CREATE UNIQUE INDEX i1_osinst on osinst (mapno,seq_no)  ;
CREATE INDEX i1_mrcharbr on mrcharbr (chart)  ;
CREATE INDEX i2_mrcharbr on mrcharbr (bor_dat, ret_mark)  ;
CREATE INDEX i3_mrcharbr on mrcharbr (borrower)  ;
CREATE INDEX i1_gactoa on gactoa (acc_cod)  ;
CREATE UNIQUE INDEX i2_gactoa on gactoa (chg_cod,pd_typ,nh_typ)  ;
CREATE UNIQUE INDEX i1_mrpbd3 on mrpbd3 (chart)  ;
CREATE INDEX i2_mrpbd3 on mrpbd3 (nam)  ;
CREATE UNIQUE INDEX i3_mrpbd3 on mrpbd3 (id_no)  ;
CREATE UNIQUE INDEX i4_mrpbd3 on mrpbd3 (tel_h,nam)  ;
CREATE UNIQUE INDEX i1_mrpbd4 on mrpbd4 (chart)  ;
CREATE UNIQUE INDEX i1_rhtibd on rhtibd (trp_itm)  ;
CREATE UNIQUE INDEX i1_rgmdcn on rgmdcn (division)  ;
CREATE UNIQUE INDEX i2_ucclicfg on ucclicfg (loc_no)  ;
CREATE INDEX i3_ucclicfg on ucclicfg (dep_no)  ;
CREATE UNIQUE INDEX i4_ucclicfg on ucclicfg (tcp_adr)  ;
CREATE UNIQUE INDEX i5_ucclicfg on ucclicfg (cmp_nam)  ;
CREATE UNIQUE INDEX i6_ucclicfg on ucclicfg (mac_adr)  ;
CREATE UNIQUE INDEX i1_bmfftran on bmfftran (acc_no,f_dat,f_hm)  ;
CREATE INDEX i2_bmfftran on bmfftran (f_dat, f_hm)  ;
CREATE INDEX i3_bmfftran on bmfftran (t_dat, room,bed)  ;
CREATE INDEX i1_bmfflog on bmfflog (acc_no, f_dat,f_hm)  ;
CREATE UNIQUE INDEX i2_mrvcsn on mrvcsn (chart,visit_no)  ;
CREATE INDEX i3_mrvcsn on mrvcsn (chart,card_yy, vsn_nh)  ;
CREATE INDEX i4_mrvcsn on mrvcsn (cg_rtp, cg_rtd,cg_rthm)  ;
CREATE INDEX i2_modsc on modsc (vsn,map_no, frm_no desc,tsc)  ;
CREATE INDEX i3_modsc on modsc (vsn,pre_dat, pre_hm,frm_no)  ;
CREATE INDEX i4_modsc on modsc (map_no,tsc,pre_dat desc,pre_hm desc)  ;
CREATE INDEX i5_modsc on modsc (exe_dat desc,map_no,exe_hm desc)  ;
CREATE INDEX i2_motxt on motxt (chart,rpt_dat desc,rpt_hm)  ;
CREATE INDEX i3_motxt on motxt (rpt_typ)  ;
CREATE INDEX i4_motxt on motxt (rpt_dat)  ;
CREATE INDEX i2_mopdd on mopdd (icd_cod, seq_no)  ;
CREATE INDEX i1_mower on mower (ord_no)  ;
CREATE INDEX i2_mower on mower (map_no,tsc)  ;
CREATE INDEX i2_mopar on mopar (act_dat, act_typ)  ;
CREATE UNIQUE INDEX i1_monot on monot3 (vsn, typ,seq_no)  ;
CREATE INDEX i2_moeps on moeps (map_no,eff_tim)  ;
CREATE INDEX i2_nsntwd on nsntwd (dat,wad)  ;
CREATE UNIQUE INDEX i1_pstitlcn on pstitlcn (titl)  ;
CREATE UNIQUE INDEX i1_bmptbd on bmptbd (acc_no)  ;
CREATE INDEX i2_bmptbd on bmptbd (admit_dat, admit_hm)  ;
CREATE INDEX i3_bmptbd on bmptbd (link_acc)  ;
CREATE UNIQUE INDEX i4_bmptbd on bmptbd (chart,tp_dat,tp_hm)  ;
CREATE INDEX i5_bmptbd on bmptbd (comp_acc)  ;
CREATE INDEX i6_bmptbd on bmptbd (a_dr1)  ;
CREATE INDEX i7_bmptbd on bmptbd (tp_dat, tp_hm)  ;
CREATE INDEX i8_bmptbd on bmptbd (rtd)  ;
CREATE UNIQUE INDEX i1_bmpobd on bmpobd (chart,admit_dat)  ;
CREATE INDEX i2_bmpobd on bmpobd (pre_dat)  ;
CREATE INDEX i3_bmpobd on bmpobd (dct1_no)  ;
CREATE INDEX i2_morprv on morprv (rpt_tim, rpt_man)  ;
CREATE UNIQUE INDEX i2_mosoah on mosoah (own_no,typ,nam)  ;
CREATE INDEX i2_nsidpr on nsidpr (pmg_dat, pmg_dr)  ;
CREATE INDEX i2_moexe on moexe (chart,chg_cod, exe_dat)  ;
CREATE INDEX i2_npdsc on npdsc (vsn,eff_dat desc)  ;
CREATE INDEX i3_npdsc on npdsc (nrs_dag, stp_dat)  ;
CREATE INDEX i2_npitm on npitm (nrs_cod, exe_sts,exe_dat)  ;
CREATE UNIQUE INDEX i1_dgdesc on dgdesc (drug_cod)  ;
CREATE INDEX i2_dgdesc on dgdesc (nam)  ;
CREATE INDEX i2_mrchtbor on mrchtbor (chart, dcg_dat)  ;
CREATE INDEX i3_mrchtbor on mrchtbor (ret_dat, bor_man)  ;
CREATE UNIQUE INDEX i1_mrumrdr on mrumrdr (evt_no,eff_dat)  ;
CREATE INDEX i2_prrbd on prrbd (nam,brn_dat)  ;
CREATE UNIQUE INDEX i3_prrbd on prrbd (tel_h, nam)  ;
CREATE UNIQUE INDEX i2_bcbemp on bcbemp (emp_no)  ;
CREATE UNIQUE INDEX i2_bcgcn on bcgcn (grp_nam)  ;
CREATE UNIQUE INDEX i2_bcmtn on bcmtn (dpt_no, msg_typ)  ;
CREATE UNIQUE INDEX i2_ucmsg on ucmsg (tbl_id, evt_no,msg_no)  ;
CREATE INDEX i3_ucmsg on ucmsg (sed_man, sed_tim)  ;
CREATE INDEX i4_ucmsg on ucmsg (rec_man, rec_tim)  ;
CREATE INDEX i5_ucmsg on ucmsg (exe_tim, rec_tim)  ;
CREATE UNIQUE INDEX sysmenidx on sysmenus (menuname)  ;
CREATE UNIQUE INDEX i1_dgdnc on dgdnc (hpt_loc, typ)  ;
CREATE INDEX i2_nsmss on nsmss (wrd,mtl_cod)  ;
CREATE INDEX i2_dcptbd on dcptbd (chart, dis_dat desc)  ;
CREATE INDEX i3_dcptbd on dcptbd (dis_dat desc)  ;
CREATE INDEX i4_dcptbd on dcptbd (div_no)  ;
CREATE INDEX i5_dcptbd on dcptbd (reg_no)  ;
CREATE INDEX i2_modct on modct (dct_no,seq_no, stp_dat desc,stp_hm)  ;
CREATE INDEX i3_modct on modct (div_no,seq_no, stp_dat desc,stp_hm)  ;
CREATE INDEX i2_tecttr on tecttr (vsn)  ;
CREATE INDEX i3_tecttr on tecttr (sub_tel,vsn)  ;
CREATE INDEX i2_tetbd on tetbd (loc_no)  ;
CREATE INDEX i3_tetbd on tetbd (nam)  ;
CREATE INDEX i4_tetbd on tetbd (sub_tel)  ;
CREATE INDEX i2_motdn on motdn (trn_tim)  ;
CREATE UNIQUE INDEX i1_nhdcn on nhdcn (drg_cod, eff_dat)  ;
CREATE INDEX i2_nhdcn on nhdcn (div_no,drg_cod)  ;
CREATE INDEX i2_hcbtm on hcbtm (idn)  ;
CREATE INDEX i2_hcvcd on hcvcd (vsn)  ;
CREATE INDEX i3_hcvcd on hcvcd (wrt_tim)  ;
CREATE INDEX i2_rosars on rosars (nam)  ;
CREATE INDEX i3_rosars on rosars (tel_no)  ;
CREATE INDEX i2_smreq on smreq (sed_tim)  ;
CREATE UNIQUE INDEX i2_nsntm on nsntm (mat_cod,chg_cod)  ;
CREATE UNIQUE INDEX i2_nentm on nentm (mat_cod, chg_cod)  ;
CREATE UNIQUE INDEX i1_garcbd1 on garcbd (rc)  ;
CREATE UNIQUE INDEX i2_garcbd1 on garcbd (level_no)  ;
CREATE INDEX i2_hcccd on hcccd (vsn)  ;
CREATE INDEX i3_hcccd on hcccd (wrt_tim)  ;
CREATE UNIQUE INDEX i1_dcdsc92 on dcdsc92 (icd_cod,seq_no)  ;
CREATE UNIQUE INDEX i1_dcicd92 on dcicd92 (icd_cod)  ;
CREATE UNIQUE INDEX i2_dcicd92 on dcicd92 (icd_typ,icd_cod)  ;
CREATE INDEX i3_dcicd92 on dcicd92 (drg_cod)  ;
CREATE UNIQUE INDEX i2_scpbd on scpbd (chart, scn_typ,stp_dat)  ;
CREATE INDEX i3_scpbd on scpbd (scn_typ, eff_dat desc)  ;
CREATE INDEX i2_sccer on sccer (pkg_cod, cfm_dat desc)  ;
CREATE UNIQUE INDEX i1_dcicdcn2 on dcicdcn (icd_cod)  ;
CREATE UNIQUE INDEX i2_dcicdcn2 on dcicdcn (icd_typ,icd_cod)  ;
CREATE INDEX i3_dcicdcn2 on dcicdcn (drg_cod)  ;
CREATE INDEX i2_cndcn on cndcn (dag_dat, dag_typ,tsc)  ;
CREATE INDEX i3_cndcn on cndcn (vsn)  ;
CREATE INDEX i2_cnssp on cnssp (cod)  ;
CREATE INDEX i1_ositeml on ositeml (order_no, rtt)  ;
CREATE UNIQUE INDEX i2_hcvch on hcvch (idn, wrt_tim)  ;
CREATE INDEX i3_hcvch on hcvch (idn,rec_tim)  ;
CREATE INDEX i2_hcpst on hcpst (ccd_no,typ)  ;
CREATE INDEX i2_pipvr on pipvr (inj_dat)  ;
CREATE INDEX i2_pibvr on pibvr (bat_no)  ;
CREATE INDEX i3_pibvr on pibvr (eff_dat)  ;
CREATE UNIQUE INDEX i1_psepbdat on psepbdat (emp_no)  ;
CREATE UNIQUE INDEX i2_psepbdat on psepbdat (emp_nam,birthday)  ;
CREATE INDEX i3_psepbdat on psepbdat (depart)  ;
CREATE INDEX i4_psepbdat on psepbdat (quit_dat)  ;
CREATE UNIQUE INDEX i2_mrumrt on mrumrt (reg_dat,evt_no)  ;
CREATE UNIQUE INDEX i3_mrumrt on mrumrt (chart,dcg_dat,dcg_hm)  ;
CREATE UNIQUE INDEX i4_mrumrt on mrumrt (snd_dat,evt_no)  ;
CREATE UNIQUE INDEX i1_icdesc on icdesc (charg_no)  ;
CREATE INDEX i2_icdesc on icdesc (acc_no,charg_no)  ;
CREATE INDEX i3_icdesc on icdesc (rtd,rthm)  ;
CREATE INDEX i2_tdheccd on tdheccd (icd_cod_m, cnt)  ;
CREATE INDEX i2_mrumrh on mrumrh (dct,pre_dat)  ;
CREATE INDEX i2_eheer on eheer (chart,frm, eer_tim)  ;
CREATE INDEX i2_teeamt on teeamt (tel_o)  ;
CREATE INDEX i3_teeamt on teeamt (tel_i)  ;
CREATE INDEX i2_mompc on mompc (src,typ, dct_no)  ;
CREATE UNIQUE INDEX i1_psctcont on psctcont (contra_no)  ;
CREATE INDEX i2_morcr on morcr (chart,eff_dat)  ;
CREATE INDEX i2_cgbqt2 on cgbqt2 (chart)  ;
CREATE INDEX i3_cgbqt2 on cgbqt2 (bqt_gov, eff_dat)  ;
CREATE INDEX i2_cgbqt on cgbqt (chart)  ;
CREATE INDEX i3_cgbqt on cgbqt (bqt_gov, eff_dat)  ;
CREATE INDEX i2_ospmh on ospmh (chart,typ)  ;
CREATE INDEX i2_mocrs on mocrs (vsn)  ;
CREATE INDEX i2_mrdnrosr on mrdnrosr (id_no, eff_dat)  ;
CREATE UNIQUE INDEX i2_dcdcr3 on dgdcr (vsn)  ;
CREATE INDEX i2_mrbatbor on mrbatbor (bat_num)  ;
CREATE INDEX i2_psdsdiv on psdsdiv (div_no)  ;
CREATE INDEX i2_eaeir1 on eaeir1 (chart)  ;
CREATE INDEX i2_eaeir2 on eaeir2 (rec_no, eva_no)  ;
CREATE INDEX i2_npfr on npfr (vsn,cls_typ, rec_tim desc,rec_sts)  ;
CREATE INDEX i2_nppahr on nppahr (chart, adm_dat)  ;
CREATE INDEX i2_nppecm on nppecm (chart, ect_seq)  ;
CREATE INDEX i2_nppohr on nppohr (chart, opr_dat)  ;
CREATE INDEX i2_mecmc on mecmc (acc_no)  ;
CREATE INDEX i3_mecmc on mecmc (met_tim)  ;
CREATE INDEX i2_mecmm on mecmm (cve_no)  ;
CREATE INDEX i2_meccr on meccr (acc_no,eff_tim)  ;
CREATE INDEX i3_meccr on meccr (cve_no)  ;
CREATE INDEX i2_mecms on mecms (sch_dat)  ;
CREATE INDEX i2_moccdi on moccdi (typ,itm_no, seq_no)  ;
CREATE UNIQUE INDEX i1_mocclog on mocclog (log_tim,typ,vsn)  ;
CREATE INDEX i2_mocclog on mocclog (vsn, typ)  ;
CREATE INDEX i2_cgctr on cgctr (chart)  ;
CREATE INDEX i3_cgctr on cgctr (tst_typ)  ;
CREATE INDEX i2_npdphra on npdphra (chart, ast_dat,ast_frm)  ;
CREATE INDEX i2_npfdhra on npfdhra (chart, ast_dat)  ;
CREATE INDEX i2_nppshra on nppshra (chart, ast_dat)  ;
CREATE INDEX i2_modcuicd on modcuicd (typ, div_no,icd_cod)  ;
CREATE INDEX i2_mmreq2 on mmreq2 (lnk_no1)  ;
CREATE INDEX i3_mmreq2 on mmreq2 (exe_tim desc,rcv_man)  ;
CREATE INDEX i2_npieb on npieb (div_no)  ;
CREATE INDEX i3_npieb on npieb (msr_no,det_no)  ;
CREATE INDEX i2_qmerm on qmerm (vsn)  ;
CREATE INDEX i3_qmerm on qmerm (frm_no)  ;
CREATE INDEX i2_qmged on qmged (rec_no,eva_no)  ;
CREATE INDEX i2_qmhss on qmhss (frm_no)  ;
CREATE INDEX i2_qmqrl on qmqrl (itm_no)  ;
CREATE UNIQUE INDEX i2_qmserd on qmserd (vsn)  ;
CREATE INDEX i2_qmsicr on qmsicr (vsn)  ;
CREATE INDEX i3_qmsicr on qmsicr (eff_dat)  ;
CREATE INDEX i2_moilar on moilar (acc_no, in_dat,in_hm)  ;
CREATE INDEX i2_moilari on moilari (icu_no)  ;
CREATE INDEX i2_mmcam on mmcam (typ,typ_no)  ;
CREATE INDEX i2_dgpar on dgpar (vsn)  ;
CREATE INDEX i3_dgpar on dgpar (chart,par_dat)  ;
CREATE INDEX i2_cgcid on cgcid (charg_no, seq_no)  ;
CREATE INDEX i2_meacr on meacr (lnk_no)  ;
CREATE INDEX i3_meacr on meacr (rcv_no)  ;
CREATE INDEX i2_mecmr on mecmr (lnk_no)  ;
CREATE INDEX i3_mecmr on mecmr (met_tim)  ;
CREATE INDEX i2_mecmp on mecmp (rcv_no)  ;
CREATE INDEX i2_megmc on megmc (rcv_no)  ;
CREATE INDEX i2_mesrr on mesrr (rcv_no)  ;
CREATE INDEX i2_emtemr on emtemr (emr_typ, lnk_no)  ;
CREATE INDEX i3_emtemr on emtemr (cmp_tim, tsc)  ;
CREATE INDEX i2_qmcpr on qmcpr (acc_no,typ)  ;
CREATE INDEX i3_moipar on moipar (act_dat, act_typ)  ;
CREATE INDEX i4_moipar on moipar (itm_no)  ;
CREATE INDEX i2_mocodi on mocodi (ptc_cod, seq_no)  ;
CREATE INDEX i3_mocodi on mocodi (itm_cod, ptc_cod)  ;
CREATE INDEX i4_mocodi on mocodi (ptc_cod, eff_tim)  ;
CREATE INDEX i2_moieb on moieb (rec_no,cls_typ)  ;
CREATE INDEX i2_mored on mored (vsn,cls_typ)  ;
CREATE INDEX i2_nperm on nperm (vsn,frq)  ;
CREATE INDEX i3_nperm on nperm (rec_tim, frq)  ;
CREATE INDEX i2_npiebom on npiebom (own_no, seq_no)  ;
CREATE INDEX i2_nprf on nprf (vsn,rec_tim)  ;
CREATE INDEX i2_npged on npged (rec_no,eva_no)  ;
CREATE INDEX i2_npnrl on npnrl (rec_typ, itm_no)  ;
CREATE INDEX i2_npqbd on npqbd (vsn,eff_tim)  ;
CREATE INDEX i2_oritmlog on oritmlog (opr_ord)  ;
CREATE INDEX i2_orexec2 on orexec2 (ord_no)  ;
CREATE INDEX i2_npsvr on npsvr (vsn,rec_tim)  ;
CREATE INDEX i2_sdmis on sdmis (rsc_num)  ;
CREATE INDEX i2_sdrule on sdrule (lnk_num)  ;
CREATE INDEX i3_sdrule on sdrule (eff_tim, stp_tim)  ;
CREATE INDEX i4_sdrule on sdrule (sat_val)  ;
CREATE INDEX i5_sdrule on sdrule (end_val)  ;
CREATE INDEX i2_sdcal on sdcal (mis_num, eff_tim)  ;
CREATE INDEX i3_sdcal on sdcal (lnk_num)  ;
CREATE INDEX i4_sdcal on sdcal (eff_tim, sub)  ;
CREATE INDEX i5_sdcal on sdcal (eff_tim, stp_tim,emp_no)  ;
CREATE INDEX i2_emerda on emerda (act_dat, emr_typ,map_no)  ;
CREATE INDEX i2_nppfdhra on nppfdhra (chart, ast_dat)  ;
CREATE INDEX i2_dglleqr on dglleqr (chart, chg_cod)  ;
CREATE INDEX i2_moicda on moicda (dpt_no)  ;
CREATE INDEX i2_molleqr on molleqr (vsn, chg_cod)  ;
CREATE INDEX i2_scptv on scptv (scp_no,ptv_dat)  ;
CREATE INDEX i2_mocodif on mocodif (cri_no, ptc_cod)  ;
CREATE INDEX i3_mocodif on mocodif (ptc_cod, seq_no)  ;
CREATE INDEX i4_mocodif on mocodif (itm_cod, ptc_cod)  ;
CREATE INDEX i5_mocodif on mocodif (ptc_cod, eff_tim)  ;
CREATE INDEX i2_qmcadrm on qmcadrm (vsn, rec_typ)  ;
CREATE INDEX i2_qmcadrd on qmcadrd (rec_no, eva_no)  ;
CREATE INDEX i2_uccwc on uccwc (ccp_no,crd_loc, crd_tim)  ;
CREATE INDEX i2_ucccp on ucccp (typ,cod)  ;
CREATE INDEX i3_ucccp on ucccp (typ,num)  ;
CREATE INDEX i2_ocoditm2 on ocoditm2 (charg_no, seq_no)  ;
CREATE INDEX i2_ucusb on ucusb (emp_no,fun_cod)  ;
CREATE UNIQUE INDEX i2_ofdedd on ofdedd (dat,dct)  ;
CREATE INDEX i2_psemrnsr on psemrnsr (emp_no)  ;
CREATE INDEX i2_mopcot on mopcot (vsn)  ;
CREATE INDEX i3_mopcot on mopcot (ord_dat, ptc_no)  ;
CREATE INDEX i2_npqtr on npqtr (nqu_no,eva_no)  ;
CREATE INDEX i2_npqtri on npqtri (qtr_no)  ;
CREATE INDEX i3_npqtri on npqtri (frm_no)  ;
CREATE INDEX i2_npqtrp on npqtrp (qtr_no)  ;
CREATE INDEX i3_npqtrp on npqtrp (frm_no)  ;
CREATE INDEX i2_npolls on npolls (cls_typ, itm_no)  ;
CREATE INDEX i1_mrsstmr on mrsstmr (vsn)  ;
CREATE UNIQUE INDEX i2_mrsensar on mrsensar (sst_no,eff_tim,aut_man)  ;
CREATE INDEX i2_emsndly on emsndly (dly_man)  ;
CREATE INDEX i2_bmwtbd on bmwtbd (dat)  ;
CREATE INDEX i2_moocn on moocn (chart,typ1, rec_tim desc)  ;
CREATE INDEX i3_moocn on moocn (rec_tim, vsn)  ;
CREATE INDEX i2_qmeierm on qmeierm (vsn)  ;
CREATE INDEX i3_qmeierm on qmeierm (sys_typ, itm_typ,est_tim)  ;
CREATE INDEX i2_qmeierd on qmeierd (est_no, eva_no)  ;
CREATE INDEX i1_eobeerptstatus on eobeerptstatus (avisitno)  ;
CREATE INDEX i1_eodierdischargent on eodierdischargent (avisitno)  ;
CREATE INDEX i1_eodierfinaldiag on eodierfinaldiag (avisitno)  ;
CREATE INDEX i1_ernursetpr on eosoernursetpr (avisitno)  ;
CREATE INDEX i1_eosoerpatientddesc on eosoerpatientddesc (avisitno)  ;
CREATE INDEX i1_eosoerpatientdiag on eosoerpatientdiag (avisitno)  ;
CREATE INDEX i1_eosoerpatientpdesc on eosoerpatientpdesc (avisitno)  ;
CREATE INDEX i1_eosoerpatientph on eosoerpatientph (avisitno)  ;
CREATE INDEX i1_eosoerpatientphl on eosoerpatientphl (avisitno)  ;
CREATE INDEX i1_eosoerpatientpot on eosoerpatientpot (avisitno)  ;
CREATE INDEX i2_eosoerpatientpot on eosoerpatientpot (achartno)  ;
CREATE INDEX i1_eosoerptobject on eosoerptobject (avisitno)  ;
CREATE INDEX i1_eosoerptobjectl on eosoerptobjectl (avisitno)  ;
CREATE INDEX i1_eosoerptocappic on eosoerptocappic (avisitno)  ;
CREATE INDEX i1_eosoerptodrawpic on eosoerptodrawpic (avisitno)  ;
CREATE INDEX i1_eosoerptprotocol on eosoerptprotocol (avisitno)  ;
CREATE INDEX i1_erptprotoco on eosoerptprotocol (ahospitalid,avisitno,aordertimes)  ;
CREATE INDEX i1_eosoerptsubject on eosoerptsubject (avisitno)  ;
CREATE INDEX i1_eosonursingwarning on eosonursingwarning (avisitno)  ;
CREATE INDEX i1_eosopainscore on eosopainscore (avisitno)  ;
CREATE INDEX i1_eososoapdataforhis on eososoapdataforhis (avisitno)  ;
CREATE INDEX i1_eososoapmaster on eososoapmaster (avisitno)  ;
CREATE INDEX i2_eososoapmaster on eososoapmaster (achartno)  ;
CREATE INDEX i1_eososoapuserlog on eososoapuserlog (avisitno)  ;
CREATE INDEX i1_eosoerptsubjectl on eosoerptsubjectl (avisitno)  ;
CREATE INDEX i1_eosoerpatientdiagl on eosoerpatientdiagl (avisitno)  ;
CREATE INDEX i1_eosoerrpatientdrug on eosoerrpatientdrug (avisitno)  ;
CREATE INDEX i1_eosoerrptdrugat on eosoerrptdrugat (avisitno)  ;
CREATE INDEX i1_eosoerrpatientlab on eosoerrpatientlab (avisitno)  ;
CREATE UNIQUE INDEX i2_ntgad on ntgad (ass_no, ass_typ,ass_seq)  ;
CREATE INDEX i2_ntgar on ntgar (ass_dat, chart)  ;
CREATE INDEX i2_mocmm on mocmm (vsn)  ;
CREATE INDEX i3_mocmm on mocmm (ord_no)  ;
CREATE INDEX i2_mocmi on mocmi (cnr_no,itm_no)  ;
CREATE INDEX i2_mofib on mofib (msr_no,det_no)  ;
CREATE INDEX i2_mooss on mooss (cls_typ, itm_no)  ;
CREATE INDEX i2_moolls on moolls (cls_typ, itm_no)  ;
CREATE INDEX i2_modds on modds (cls_typ, itm_no)  ;
CREATE INDEX i2_mootxt on mootxt (cls_typ, itm_no)  ;
CREATE UNIQUE INDEX i1_mools on mools (ols_no)  ;
CREATE INDEX i2_mools on mools (cls_typ, itm_no)  ;
CREATE INDEX i2_ifdpm on ifdpm (pmg_dat)  ;
CREATE INDEX i3_ifdpm on ifdpm (chart)  ;
CREATE INDEX i2_ifdpmi on ifdpmi (ifd_no, itm_no)  ;
CREATE INDEX i2_ifdpms on ifdpms (snd_dat)  ;
CREATE UNIQUE INDEX i1_cmcsd on cmcsd (chart, sub_seq)  ;
CREATE UNIQUE INDEX i1_cmcpird on cmcpird (chart,can_typ,pat_dat)  ;
CREATE UNIQUE INDEX i1_cmcesd on cmcesd (chart,can_typ,enr_dat,enr_typ)  ;
CREATE UNIQUE INDEX i1_cmcctd on cmcctd (chart,can_typ,tre_sta,tre_typ)  ;
CREATE INDEX i1_cmccad on cmccad (chart, adv_dat)  ;
CREATE INDEX i1_cmctfur on cmctfur (chart, can_typ)  ;
CREATE INDEX i1_cmched on cmched (chart, edu_dat)  ;
CREATE UNIQUE INDEX i2_cmtmppd on cmtmppd (mee_no,mee_dct)  ;
CREATE UNIQUE INDEX i2_cmtpcd on cmtpcd (tem_dct,can_typ)  ;
CREATE UNIQUE INDEX i2_rodipr on rodipr (chart,can_typ)  ;
CREATE UNIQUE INDEX i1_rocpsr on rocpsr (dia_no,dia_sta,dia_lev)  ;
CREATE INDEX i2_rotgr on rotgr (chart,tre_eff, can_typ)  ;
CREATE INDEX i2_rgstr on rostr (tre_no,xra_dat, oth_rad)  ;
CREATE INDEX i2_rosldtr on rosldtr (tre_no, tre_pos)  ;
CREATE INDEX i3_rosldtr on rosldtr (sum_dat, sum_dos)  ;
CREATE INDEX i2_rosdtter on rosdtter (sum_no, tre_seq)  ;
CREATE INDEX i2_rodtsr on rodtsr (tre_pos, pos_nam)  ;
CREATE INDEX i2_eoged on eoged (atriageid, eva_no)  ;
CREATE INDEX i2_momsg on momsg (sed_tim, rec_man)  ;
CREATE INDEX i3_momsg on momsg (chart,sed_tim desc)  ;
CREATE INDEX i4_momsg on momsg (rec_tim, rec_man)  ;
CREATE INDEX i2_mosmi on mosmi (lnk_no)  ;
CREATE INDEX i3_mosmi on mosmi (rec_tim, fun_typ,sht_typ,tsc)  ;
CREATE INDEX i2_mosdi on mosdi (mst_no)  ;
CREATE UNIQUE INDEX i2_roptar on roptar (chart,can_typ,pta_dat,pta_typ)  ;
CREATE INDEX i2_mrpsrdd on mrpsrdd (chart, spc_mrk)  ;
CREATE INDEX i2_moccirp on moccirp (itm_no, ptc_cod)  ;
CREATE INDEX i2_mocfl on mocfl (lnk_no,cfm_typ)  ;
CREATE INDEX i2_npieb2 on npieb2 (eva_no)  ;
CREATE UNIQUE INDEX i2_moicpm on moicpm (chg_cod,cmb_pst)  ;
CREATE UNIQUE INDEX i3_moicpm on moicpm (icp_cod)  ;
CREATE INDEX i2_udsdr on udsdr (chart)  ;
CREATE INDEX i3_udsdr on udsdr (exp_tim, tsc)  ;
CREATE INDEX i4_udsdr on udsdr (exp_tim, room,bed)  ;
CREATE INDEX i2_udsdd on udsdd (sdr_no)  ;
CREATE INDEX i3_udsdd on udsdd (itm_no)  ;
CREATE INDEX i2_udsddlog on udsddlog (det_no)  ;
CREATE INDEX i2_udsdbd on udsdbd (sbd_typ, ref_cod)  ;
CREATE UNIQUE INDEX i2_nherst on nherst (itm_cod,eff_dat)  ;
CREATE UNIQUE INDEX i2_nhudficd on nhudficd (typ,icd_f,eff_dat)  ;
CREATE INDEX i2_mrvrd on mrvrd (vsn)  ;
CREATE UNIQUE INDEX i2_nhietnms on nhietnms (itm_f,eff_dat)  ;
CREATE INDEX i2_ifdmr on ifdmr (pmg_dat)  ;
CREATE INDEX i3_ifdmr on ifdmr (chart)  ;
CREATE UNIQUE INDEX i2_mracbd on mracbd (id_no)  ;
CREATE INDEX i2_mocacdi on mocacdi (dtl_typ, lnk_no)  ;
CREATE INDEX i2_ocmcpgmd2 on ocmcpgmd2 (chart,use_dat)  ;
CREATE INDEX i3_ocmcpgmd2 on ocmcpgmd2 (rtd)  ;
CREATE INDEX i2_ocmcpgmd on ocmcpgmd (chart, use_dat)  ;
CREATE INDEX i3_ocmcpgmd on ocmcpgmd (rtd)  ;
CREATE UNIQUE INDEX i2_cmcg on cmcg (grp_id, cus_id)  ;
CREATE INDEX i2_mrrmdm on mrrmdm (chart)  ;
CREATE INDEX i3_mrrmdm on mrrmdm (did_no, typ)  ;
CREATE INDEX i2_moiolog2 on moiolog (lnk_num)  ;
CREATE INDEX i2_moqr2 on moqr (chart,log_tim desc)  ;
CREATE INDEX i2_sdcallog on sdcallog (evt_num)  ;
CREATE UNIQUE INDEX i2_tddrgab on tddrgab (fym,tym)  ;
CREATE INDEX i2_mopnmp on mopnmp (vsn)  ;
CREATE INDEX i3_mopnmp on mopnmp (rtt)  ;
CREATE INDEX i2_doolev on doolev (eff_dat, dct_no)  ;
CREATE INDEX i2_dolevoa on dolevoa (lev_no)  ;
CREATE UNIQUE INDEX i2_dolevwa on dolevwa (lev_no,eff_dat)  ;
CREATE INDEX i2_doolsp on doolsp (lnk_no)  ;
CREATE INDEX i2_lbplval on lbplval (chart)  ;
CREATE UNIQUE INDEX i2_nhtpgd on nhtpgd (grp,pos)  ;
CREATE UNIQUE INDEX i2_mtval on mtval (mt_cod, typ)  ;
CREATE INDEX i2_moeci on moeci (chg_cod)  ;
CREATE UNIQUE INDEX i1_bmbed on bmbed (room, bed)  ;
CREATE UNIQUE INDEX i4_bmbed on bmbed (acc_no)  ;
CREATE UNIQUE INDEX i5_bmbed on bmbed (chart, toilet)  ;
CREATE UNIQUE INDEX i6_bmbed on bmbed (pre_chart, toilet)  ;
CREATE INDEX i7_bmbed on bmbed (ward)  ;
CREATE INDEX i8_bmbed on bmbed (dpt_no)  ;
CREATE INDEX i2_moitm on moitm (ord_no,seq_no)  ;
CREATE INDEX i3_moitm on moitm (chg_cod, itm_no)  ;
CREATE INDEX i4_moitm on moitm (chg_no,itm_no)  ;
CREATE UNIQUE INDEX i2_mtbillgn on mtbillgn (grp_cod,nhi_cod)  ;
CREATE INDEX i2_npcmr on npcmr (emp_no,eff_tim)  ;
CREATE INDEX i2_npstcm on npstcm (stp_tim, dpt_no)  ;
CREATE INDEX i3_npstcm on npstcm (dpt_no, grp)  ;
CREATE INDEX i3_npgrb on npgrb (acc_no)  ;
CREATE INDEX i4_npgrb on npgrb (eff_tim, stp_tim,dpt_no)  ;
CREATE INDEX i2_npoxls on npoxls (cls_typ, itm_no)  ;
CREATE INDEX i2_cmtmpd on cmtmpd (mee_no, can_typ,chart)  ;
CREATE INDEX i3_cmtmpd on cmtmpd (chart)  ;
CREATE UNIQUE INDEX i2_cmctmr on cmctmr (mee_dat,mee_typ)  ;
CREATE UNIQUE INDEX i1_cmpipd on cmpipd (mpd_no,ind_dct)  ;
CREATE INDEX i2_moir on moir (typ,lnk_no)  ;
CREATE INDEX i3_moir on moir (frm_no)  ;
CREATE INDEX i2_dglmpr on dglmpr (lnk_no, rec_typ)  ;
CREATE INDEX i3_dglmpr on dglmpr (cmp_tim)  ;
CREATE INDEX i4_dglmpr on dglmpr (prn_tim)  ;
CREATE INDEX i2_npnsr on npnsr (cls_typ, itm_no)  ;
CREATE INDEX i2_pdpcr on pdpcr (chart,typ)  ;
CREATE INDEX i2_cgppi on cgppi (pkg_cod)  ;
CREATE UNIQUE INDEX i2_dci10cn on dci10cn (icd_typ,icd_cod)  ;
CREATE INDEX i3_dci10cn on dci10cn (drg_cod)  ;
CREATE INDEX i2_dcicdm on dcicdm (i09_cod)  ;
CREATE INDEX i3_dcicdm on dcicdm (i10_cod)  ;
CREATE INDEX i1_ooptmeet on ooptmeet (chart, visit_no)  ;
CREATE INDEX i1_ooptmret on ooptmret (chart, visit_no)  ;
CREATE UNIQUE INDEX i1_mrpbd99 on mrpbd99 (chart)  ;
CREATE INDEX i2_mrpbd99 on mrpbd99 (nam)  ;
CREATE UNIQUE INDEX i3_mrpbd99 on mrpbd99 (id_no)  ;
CREATE UNIQUE INDEX i4_mrpbd99 on mrpbd99 (tel_h,nam)  ;
CREATE UNIQUE INDEX i2_emrunset on emrunset (typ1,typ2)  ;
CREATE INDEX i2_mooir on mooir (chg_cod, typ)  ;
CREATE INDEX i2_pcvilned on pcvilned (acd_no)  ;
CREATE INDEX i3_pcvilned on pcvilned (itm_cod)  ;
CREATE INDEX i1_dgldap on dgldap (ord_no)  ;
CREATE INDEX i2_dgldap on dgldap (apt_dat)  ;
CREATE INDEX i2_npned on npned (ast_no)  ;
CREATE INDEX i2_mofulog on mofulog (lnk_num)  ;
CREATE INDEX i3_mofulog on mofulog (log_tim, fun_typ)  ;
CREATE INDEX i2_nhocmr on nhocmr (vsn)  ;
CREATE INDEX i3_nhocmr on nhocmr (id_no)  ;
CREATE UNIQUE INDEX i2_cgupbdm on cgupbdm (cod_typ,cod,grp_id)  ;
CREATE INDEX i3_cgupbdm on cgupbdm (rul_typ)  ;
CREATE INDEX i2_cgupbdr on cgupbdr (rul_no)  ;
CREATE INDEX i1_cmcpd on cmcpd (chart,psy_dat)  ;
CREATE UNIQUE INDEX i2_cmupl on cmupl (vsn, chart,icd_cod)  ;
CREATE INDEX i2_nppvlm on nppvlm (vsn)  ;
CREATE UNIQUE INDEX i2_dgprn on dgprn (drg_cod, seq_no)  ;
CREATE UNIQUE INDEX i2_dgdbd4 on dgdbd4 (drg_cod,typ,use_way,seq_no)  ;
CREATE UNIQUE INDEX i2_nhailsoe on nhailsoe (nhi_f,emp_no)  ;
CREATE INDEX i2_mrcnmqva on mrcnmqva (chart, eff_dat)  ;
CREATE INDEX i3_mrcnmqva on mrcnmqva (eff_dat, stp_dat)  ;
CREATE INDEX i4_mrcnmqva on mrcnmqva (eff_dat)  ;
CREATE UNIQUE INDEX i2_dgdibd on dgdibd (cod,itm,eff_dat)  ;
CREATE INDEX i2_mofht on mofht (fun_no)  ;
CREATE UNIQUE INDEX i2_mrpsdsc on mrpsdsc (chart,spc_mrk)  ;
CREATE UNIQUE INDEX i2_dcordmd on dcordmd (chg_cod,typ)  ;
CREATE INDEX i2_nhpnpit on nhpnpit (chart, nhi_cod,frm_no)  ;
CREATE INDEX i2_dcdccr on dcdccr (dcc_no, itm_no)  ;
CREATE INDEX i2_bmhrpc on bmhrpc (vsn)  ;
CREATE INDEX i2_dcdcc on dcdcc (dcc_tim, dcc_man)  ;
CREATE INDEX i3_dcdcc on dcdcc (dcc_tim, rpy_man)  ;
CREATE INDEX i2_dgadmcr on dgadmcr (chart)  ;
CREATE INDEX i3_dgadmcr on dgadmcr (par_no)  ;
CREATE UNIQUE INDEX i2_emumrt on emumrt (evt_no,typ)  ;
CREATE INDEX i2_dcdcd on dcdcd (div_no,typ)  ;
CREATE INDEX i2_mocrir on mocrir (typ1,lnk_no)  ;
CREATE INDEX i2_cgqtsr on cgqtsr (itm_no, qts_typ)  ;
CREATE INDEX i2_hdpgd on hdpgd (yyymm,grp)  ;
CREATE INDEX i2_cgdcdr on cgdcdr (ivc_no)  ;
CREATE INDEX i3_cgdcdr on cgdcdr (vsn)  ;
CREATE INDEX i2_npcrm on npcrm (vsn,typ)  ;
CREATE INDEX i3_npcrm on npcrm (vsn,lnk_no)  ;
CREATE INDEX i2_npcrd on npcrd (rec_no,eva_no)  ;
CREATE INDEX i2_mrpcr on mrpcr (vsn,cst_typ)  ;
CREATE INDEX i2_morsnm on morsnm (vsn,itm_no, typ_no)  ;
CREATE INDEX i2_morsndt on morsndt (rec_no)  ;
CREATE INDEX i2_qmatsarm on qmatsarm (vsn, lnk_no)  ;
CREATE INDEX i3_qmatsarm on qmatsarm (lnk_no)  ;
CREATE UNIQUE INDEX i2_qmatsari on qmatsari (rec_no,eva_no,ext_no)  ;
CREATE INDEX i2_dcdicdm on dcdicdm (div_no, i09_cod)  ;
CREATE INDEX i3_dcdicdm on dcdicdm (div_no, i10_cod)  ;
CREATE INDEX i2_cgpra on cgpra (vsn)  ;
CREATE INDEX i3_cgpra on cgpra (chg_tim)  ;
CREATE INDEX i2_mrirbm on mrirbm (rsh_no)  ;
CREATE INDEX i2_mrirbr on mrirbr (irb_cod)  ;
CREATE INDEX i2_qmacarm on qmacarm (vsn, ast_typ)  ;
CREATE INDEX i2_qmacai on qmacai (ast_no, itm_no)  ;
CREATE INDEX i2_moltxt on moltxt (cls_typ, lnk_no)  ;
CREATE INDEX i2_rgfstdat on rgfstdat (chart, frv_dat)  ;
CREATE INDEX i2_cmrcud on cmrcud (rep_dat1)  ;
CREATE INDEX i3_cmrcud on cmrcud (rep_dat2)  ;
CREATE INDEX i4_cmrcud on cmrcud (id_no)  ;
CREATE INDEX i2_cmncud on cmncud (id_no)  ;
CREATE INDEX i3_cmncud on cmncud (dia_dat)  ;
CREATE INDEX i1_cmcirtr on cmcirtr (chart, can_typ)  ;
CREATE UNIQUE INDEX i1_cmcdd on cmcdd (chart, can_typ)  ;
CREATE INDEX i1_cmctcrr on cmctcrr (chart, can_typ,cau_dat,cau_no)  ;
CREATE INDEX i2_cmctcrr on cmctcrr (sou_no, sou_typ)  ;
CREATE INDEX i1_cmcird on cmcird (chart, can_typ,ins_dat,ins_typ)  ;
CREATE INDEX i2_mofltstr on mofltstr (rec_typ, idx_str_1)  ;
CREATE INDEX i3_mofltstr on mofltstr (rec_typ, idx_str_2)  ;
CREATE INDEX i2_dcordmi on dcordmi (odm_no)  ;
CREATE INDEX i2_emogi on emogi (grp_no)  ;
CREATE INDEX i3_emogi on emogi (ord_no)  ;
CREATE INDEX i2_osdesclog on osdesclog (order_no)  ;
CREATE INDEX i3_osdesclog on osdesclog (dlr_no)  ;
CREATE INDEX i2_ositemlog on ositemlog (rec_no)  ;
CREATE INDEX i2_moimgm on moimgm (lnk_num)  ;
CREATE INDEX i3_moimgm on moimgm (upd_tim, typ)  ;
CREATE INDEX i2_moimgd on moimgd (rec_no)  ;
CREATE INDEX i3_moimgd on moimgd (rtt)  ;
CREATE INDEX i2_rpmmrd on rpmmrd (ord_no)  ;
CREATE INDEX i3_rpmmrd on rpmmrd (rec_man)  ;
CREATE UNIQUE INDEX i2_cgval on cgval (chg_cod, typ,eff_dat)  ;
CREATE UNIQUE INDEX i2_mrrdr on mrrdr (idn, icd_cod,i10_cod,eff_dat)  ;
CREATE INDEX i2_uddir on uddir (itm_no)  ;
CREATE INDEX i3_uddir on uddir (acc_no)  ;
CREATE INDEX i4_uddir on uddir (rec_dat)  ;
CREATE INDEX i5_uddir on uddir (rtt)  ;
CREATE INDEX i2_hccdh on hccdh (id_no,stp_dat)  ;
CREATE INDEX i3_hccdh on hccdh (crt_dat)  ;
CREATE INDEX i2_nhnicatc on nhnicatc (nhi_cod, eff_dat)  ;
CREATE INDEX i3_nhnicatc on nhnicatc (atc_cod, eff_dat)  ;
CREATE UNIQUE INDEX i2_rgscdv1 on rgscdv (visit_dat,sft,room,dct_no,div_no)  ;
CREATE UNIQUE INDEX i2_rgwscdv1 on rgwscdv (wek_day,sft,room,div_no,stp_dat desc)  ;
CREATE INDEX i1_moepdsc on moepdsc (vsn desc)  ;
CREATE INDEX i2_moepdsc on moepdsc (map_no, tsc,pre_dat desc,pre_hm desc)  ;
CREATE INDEX i3_moepdsc on moepdsc (exe_dat desc,map_no,exe_hm desc)  ;
CREATE INDEX i1_moepitm on moepitm (epd_no, seq_no)  ;
CREATE INDEX i2_moepitm on moepitm (chg_cod, epi_no)  ;
CREATE INDEX i1_eosoerpatientddesc2 on eosoerpatientddesc2 (avisitno)  ;
CREATE INDEX i1_eosoerpatientdiag2 on eosoerpatientdiag2 (avisitno)  ;
CREATE INDEX i1_eosoerpatientdiagl2 on eosoerpatientdiagl2 (avisitno)  ;
CREATE INDEX i2_mecr on mecr (met_tim)  ;
CREATE INDEX i2_mepr on mepr (met_no)  ;
CREATE INDEX i2_moipcl on moipcl (vsn)  ;
CREATE UNIQUE INDEX i3_moipcl on moipcl (chart,typ,itm,ass_dat,ass_hm)  ;
CREATE INDEX i2_peerm on peerm (chart,frq)  ;
CREATE INDEX i2_peged on peged (rec_no,eva_no)  ;
CREATE INDEX i2_peerl on peerl (rec_typ, itm_no)  ;
CREATE INDEX i2_fmmrimgd on fmmrimgd (rec_no)  ;
CREATE INDEX i3_fmmrimgd on fmmrimgd (uno)  ;
CREATE INDEX i2_fmmrimgm on fmmrimgm (lnk_num)  ;
CREATE INDEX i3_fmmrimgm on fmmrimgm (chart, sed_tim,typ1,typ2)  ;
CREATE INDEX i4_fmmrimgm on fmmrimgm (vsn)  ;
CREATE INDEX i5_fmmrimgm on fmmrimgm (oth_lnk)  ;
CREATE INDEX i2_mtoitg on mtoitg (typ,sts)  ;
CREATE INDEX i3_mtoitg on mtoitg (mt_cod)  ;
CREATE UNIQUE INDEX i2_nhuapi on nhuapi (chg_cod,nhi_cod,dat_f)  ;
CREATE INDEX i3_nhuapi on nhuapi (nhi_cod)  ;
CREATE INDEX i2_mtoibcr on mtoibcr (itm_no, seq_no)  ;
CREATE INDEX i3_mtoibcr on mtoibcr (lot_no)  ;
CREATE INDEX i2_fmmrimgl on fmmrimgl (det_no, imy_typ)  ;
CREATE INDEX i3_fmmrimgl on fmmrimgl (uno)  ;
CREATE INDEX i2_nhdin on nhdin (ing_cod, eff_dat)  ;
CREATE INDEX i2_mocfr on mocfr (lnk_no)  ;
CREATE INDEX i3_mocfr on mocfr (rtt,rtp)  ;
CREATE INDEX i2_dgparm on dgparm (vsn)  ;
CREATE INDEX i3_dgparm on dgparm (chart, par_dat)  ;
CREATE INDEX i2_dgpari on dgpari (par_no, itm_no)  ;
CREATE INDEX i2_cgcodctr on cgcodctr (chg_cod, typ)  ;
CREATE INDEX i2_mocmi2 on mocmi2 (sub_no, itm_no)  ;
CREATE INDEX i2_mocmm2 on mocmm2 (ord_no)  ;
CREATE INDEX i2_mootxt2 on mootxt2 (cls_typ, itm_no)  ;
CREATE INDEX i2_mooss2 on mooss2 (cls_typ, itm_no)  ;
CREATE INDEX i2d_mools2 on mools2 (cls_typ, itm_no)  ;
CREATE INDEX i2_modds2 on modds2 (cls_typ, itm_no)  ;
CREATE INDEX i2_moolls2 on moolls2 (cls_typ, itm_no)  ;
CREATE INDEX i2_ifdpmsi on ifdpmsi (sts_no, itm_no)  ;
CREATE UNIQUE INDEX i2_morur on morur (ord_no, map_no,vis_typ)  ;
CREATE INDEX i3_morur on morur (asg_dat, adm_dr,tsc)  ;
CREATE UNIQUE INDEX i2_pdctbd on pdctbd (typ,dat_f)  ;
CREATE UNIQUE INDEX i2_empoia on empoia (map_no,itm_cod,sht_typ)  ;
CREATE INDEX i2_nptjr on nptjr (ord_no)  ;
CREATE UNIQUE INDEX i3_nptjr on nptjr (bpd_n)  ;
CREATE INDEX i2_moctrl on moctrl (lnk_no)  ;
CREATE INDEX i3_moctrl on moctrl (log_tim, log_typ)  ;
CREATE UNIQUE INDEX i2_dci10fa on dci10fa (yyyymm,typ1,typ2,emp_no,div_no,i10_cod)  ;
CREATE INDEX i1_dccdspcs on dccdspcs (icd_cod)  ;
CREATE INDEX i2_cndcnr on cndcnr (dag_no)  ;
CREATE INDEX i3_cndcnr on cndcnr (apt_dat)  ;
CREATE UNIQUE INDEX i2_mrvci on mrvci (vsn, typ)  ;
CREATE UNIQUE INDEX i2_rfhbrd on rfhbrd (hsp_no,seq)  ;
CREATE INDEX i2_npotxt on npotxt (cls_typ, itm_no)  ;
CREATE INDEX i2_smdmola on smdmola (sub_no, yymm,div_no)  ;
CREATE INDEX i3_smdmola on smdmola (dct, typ)  ;
CREATE UNIQUE INDEX i2_monot2 on monot (vsn, typ,seq_no)  ;
CREATE INDEX i2_mrvts on mrvts (lnk_no)  ;
CREATE INDEX i2_ifdpmsr on ifdpmsr (sts_no)  ;
CREATE INDEX i2_scerm on scerm (erm_tim, scp_no)  ;
CREATE INDEX i2_scedf on scedf (erm_no,eva_no)  ;
CREATE INDEX i2_cgpap on cgpap (chart)  ;
CREATE INDEX i2_tdcctipc on tdcctipc (chg_cod, eff_dat)  ;
CREATE INDEX i2_mofnd on mofnd (mst_no)  ;
CREATE UNIQUE INDEX i2_nssmtc on nssmtc (wrd,typ)  ;
CREATE INDEX i2_mofnm on mofnm (lnk_no,itm)  ;
CREATE INDEX i3_mofnm on mofnm (rec_tim, itm)  ;
CREATE INDEX i2_cmrols on cmrols (res_no)  ;
CREATE INDEX i2_cmirm on cmirm (chart,can_typ, rpt_dat)  ;
CREATE INDEX i3_cmirm on cmirm (ord_dat)  ;
CREATE INDEX i2_cmird on cmird (con_no,itm_no, seq_no)  ;
CREATE UNIQUE INDEX i2_fofib on fofib (sys_no, msr_no,det_no,lnk_no)  ;
CREATE INDEX i2_fooss on fooss (ird_no)  ;
CREATE INDEX i2_fools on fools (ird_no)  ;
CREATE INDEX i2_foolls on foolls (ird_no)  ;
CREATE INDEX i2_footxt on footxt (ird_no)  ;
CREATE UNIQUE INDEX i2_tdccrdag on tdccrdag (icd_grp,icd_cod,eff_dat)  ;
CREATE UNIQUE INDEX i2_tdccrda on tdccrda (npd_cod,icd_grp,eff_dat)  ;
CREATE INDEX i2_fodds on fodds (ird_no)  ;
CREATE UNIQUE INDEX i2_ucapes on ucapes (user_id)  ;
CREATE INDEX i2_cmspr on cmspr (lnk_no,cir_no)  ;
CREATE INDEX i2_cmcrm on cmcrm (lnk_no,cir_no)  ;
CREATE INDEX i2_cmcrd on cmcrd (rec_no,eva_no)  ;
CREATE INDEX i2_cmpcr on cmpcr (chart)  ;
CREATE INDEX i3_cmpcr on cmpcr (vsn)  ;
CREATE INDEX i4_cmpcr on cmpcr (eff_dat)  ;
CREATE INDEX i5_cmpcr on cmpcr (stp_dat)  ;
CREATE INDEX i2_cgmie on cgmie (chg_cod, typ)  ;
CREATE INDEX i2_tddrgspm on tddrgspm (drg_cod_f, drg_cod_t)  ;
CREATE INDEX i2_tddrgspd on tddrgspd (mst_no)  ;
CREATE INDEX i3_tddrgspd on tddrgspd (icd_cod)  ;
CREATE INDEX i2_mrpbie on mrpbie (chart)  ;
CREATE UNIQUE INDEX i2_xrpdip on xrpdip (chart,acs_no)  ;
CREATE INDEX i2_hcpicc on hcpicc (icd_cod)  ;
CREATE INDEX i3_hcpicc on hcpicc (cod)  ;
CREATE INDEX i2_eaeiicm on eaeiicm (chart)  ;
CREATE INDEX i2_eaeiici on eaeiici (rec_no, eva_no)  ;
CREATE INDEX i2_eaeiicr on eaeiicr (rec_no)  ;
CREATE UNIQUE INDEX i2_nhtdaacd on nhtdaacd (chart,adm_dat,dcg_dat)  ;
CREATE INDEX i3_nhtdaacd on nhtdaacd (dcg_dat, dct_no)  ;
CREATE UNIQUE INDEX i2_cgqec on cgqec (chart, chg_cod)  ;
CREATE INDEX i2_cgqecd on cgqecd (qec_no, exe_dat)  ;
CREATE UNIQUE INDEX i2_cgdud on cgdud (chart, chg_cod,rec_typ)  ;
CREATE INDEX i1_dccdrc on dccdrc (frm_typ, cnc_no)  ;
CREATE INDEX i2_eoptbr on eoptbr (trg_tim)  ;
CREATE INDEX i3_eoptbr on eoptbr (vsn)  ;
CREATE INDEX i2_osppbr on osppbr (vsn)  ;
CREATE INDEX i2_ospptr on ospptr (rec_no)  ;
CREATE INDEX i2_ospprr on ospprr (rec_no)  ;
CREATE INDEX i2_ntird on ntird (ass_no,itm_no, seq_no)  ;
CREATE INDEX i2_ntrcr on ntrcr (acc_no)  ;
CREATE INDEX i3_ntrcr on ntrcr (rc_typ)  ;
CREATE INDEX i2_nteid on nteid (ass_no)  ;
CREATE INDEX i2_ntdwd on ntdwd (emp_no)  ;
CREATE INDEX i2_nttfnud on nttfnud (tub_cod)  ;
CREATE INDEX i2_mrwpr on mrwpr (lnk_no)  ;
CREATE UNIQUE INDEX i2_cgnhdud on cgnhdud (chart,nhi_cod,rec_typ)  ;
CREATE INDEX i2_cmrf on cmrf (vsn,rec_tim)  ;
CREATE INDEX i3_cmrf on cmrf (lnk_no)  ;
CREATE INDEX i2_hccexmh on hccexmh (id_no, stp_dat)  ;
CREATE INDEX i3_hccexmh on hccexmh (crt_dat)  ;
CREATE INDEX i2_hccoprh on hccoprh (id_no, stp_dat)  ;
CREATE INDEX i3_hccoprh on hccoprh (crt_dat)  ;
CREATE INDEX i2_hccdenh on hccdenh (id_no, stp_dat)  ;
CREATE INDEX i3_hccdenh on hccdenh (crt_dat)  ;
CREATE INDEX i2_hccalgh on hccalgh (id_no, upl_dat)  ;
CREATE INDEX i3_hccalgh on hccalgh (crt_dat)  ;
CREATE INDEX i2_nhcodecn on nhcodecn (typ, cod)  ;
CREATE UNIQUE INDEX i2_dgdfi on dgdfi (chg_cod, eff_tim)  ;
CREATE INDEX i2_rgdie on rgdie (vsn)  ;
CREATE UNIQUE INDEX i2_pfdpdsb on pfdpdsb (ord_no,itm_no,emp_no)  ;
CREATE INDEX i2_ntcar on ntcar (chart)  ;
CREATE INDEX i3_ntcar on ntcar (ass_dat)  ;
CREATE INDEX i2_dgdbmr on dgdbmr (vsn)  ;
CREATE INDEX i3_dgdbmr on dgdbmr (gen_tim)  ;
CREATE INDEX i2_dgdbir on dgdbir (bmr_no)  ;
CREATE INDEX i3_dgdbir on dgdbir (bar_cod)  ;
CREATE INDEX i2_cmmtr on cmmtr (lnk_no)  ;
CREATE INDEX i3_cmmtr on cmmtr (chart)  ;
CREATE INDEX i4_cmmtr on cmmtr (ord_dat)  ;
CREATE INDEX i2_mrisrant on mrisrant (evt_no)  ;
CREATE INDEX i3_mrisrant on mrisrant (cmp_dat)  ;
CREATE INDEX i4_mrisrant on mrisrant (id_no)  ;
CREATE INDEX i2_catkbd on catkbd (lnk_no)  ;
CREATE UNIQUE INDEX i2_dcdnf10 on dcdnf10 (icd_cod,typ)  ;
CREATE UNIQUE INDEX i2_psdmses on psdmses (emp_no,eff_dat,typ,seq_no)  ;
CREATE UNIQUE INDEX i2_mmreq3 on mmreq3 (sed_no, evt_typ)  ;
CREATE INDEX i3_mmreq3 on mmreq3 (rtt)  ;
CREATE INDEX i2_bmathinf on bmathinf (emp_no, acc_no)  ;
CREATE UNIQUE INDEX i3_bmathinf on bmathinf (acc_no,eff_tim,stp_tim,typ)  ;
CREATE UNIQUE INDEX i2_pbgesn on pbgesn (evt_typ,evt_sou)  ;
CREATE INDEX i2_dgdsp on dgdsp (chart)  ;
CREATE INDEX i3_dgdsp on dgdsp (out_tim)  ;
CREATE INDEX i4_dgdsp on dgdsp (bar_cod)  ;
CREATE UNIQUE INDEX i1_pseepdat on pseepdat (eep_no)  ;
CREATE INDEX i2_momclog on momclog (lnk_num)  ;
CREATE INDEX i3_momclog on momclog (ctl_cod, log_tim)  ;
CREATE INDEX i2_zzgacn on zzgacn (lnk_no)  ;
CREATE INDEX i3_zzgacn on zzgacn (cod)  ;
CREATE INDEX i2_ifdcd on ifdcd (gac_no)  ;
CREATE INDEX i3_ifdcd on ifdcd (diag_cod)  ;
CREATE INDEX i2_ifdbd on ifdbd (cod)  ;
CREATE INDEX i2_mowpr on mowpr (vsn)  ;
CREATE INDEX i3_mowpr on mowpr (wpr_tim)  ;
CREATE INDEX i4_mowpr on mowpr (lnk_no)  ;
CREATE INDEX i2_ossublog on ossublog (order_no)  ;
CREATE INDEX i2_osobjlog on osobjlog (order_no)  ;
CREATE INDEX i2_oscmtlog on oscmtlog (order_no)  ;
CREATE INDEX i2_oransitl on oransitl (ord_no)  ;
CREATE INDEX i3_oransitl on oransitl (ans_ord)  ;
CREATE INDEX i2_catmf on catmf (cnr_no)  ;
CREATE INDEX i2_cartf on cartf (tmf_no,cur_typ)  ;
CREATE INDEX i2_catdf on catdf (tmf_no)  ;
CREATE INDEX i2_caast on caast (chart)  ;
CREATE INDEX i2_caasid on caasid (sim_no)  ;
CREATE INDEX i2_cacmf on cacmf (tmf_no,cur_typ)  ;
CREATE INDEX i3_cacmf on cacmf (itm_cod)  ;
CREATE INDEX i2_mevtd on mevtd (lnk_no,typ)  ;
CREATE INDEX i2_mopfr on mopfr (act_tim)  ;
CREATE INDEX i3_mopfr on mopfr (lnk_no)  ;
CREATE INDEX i2_mopfrpkg on mopfrpkg (pkg_no)  ;
CREATE INDEX i3_mopfrpkg on mopfrpkg (evt_no)  ;
CREATE INDEX i2_hccexrh on hccexrh (id_no, rep_dat)  ;
CREATE INDEX i3_hccexrh on hccexrh (crt_dat)  ;
CREATE INDEX i2_hccdcsh on hccdcsh (id_no)  ;
CREATE INDEX i3_hccdcsh on hccdcsh (crt_dat)  ;
CREATE INDEX i2_hccphmh on hccphmh (id_no, stp_dat)  ;
CREATE INDEX i3_hccphmh on hccphmh (crt_dat)  ;
CREATE INDEX i2_hccetmh on hccetmh (id_no, opr_dat)  ;
CREATE INDEX i3_hccetmh on hccetmh (crt_dat)  ;
CREATE INDEX i2_mosysprm on mosysprm (eff_tim)  ;
CREATE UNIQUE INDEX i2_dci10cn4 on dci10cn4 (icd_typ,icd_cod)  ;
CREATE INDEX i3_dci10cn4 on dci10cn4 (drg_cod)  ;
CREATE INDEX i2_mocorif on mocorif (ptc_cod, tc,eff_tim)  ;
CREATE UNIQUE INDEX i2_mochgtyp on mochgtyp (chg_cod,voc_no)  ;
CREATE UNIQUE INDEX i1_moitmvoc on moitmvoc (itm_no)  ;
CREATE INDEX i2_movctrdf on movctrdf (chart)  ;
CREATE INDEX i3_movctrdf on movctrdf (lnk_num)  ;
CREATE UNIQUE INDEX i2_tddrgnfc4 on tddrgnfc4 (drg_cod,eff_ym)  ;
CREATE UNIQUE INDEX i2_tdncbd4 on tdncbd4 (mdc,eff_ym)  ;
CREATE UNIQUE INDEX i2_rfiambd on rfiambd (rfi_id,eff_dat,stp_dat)  ;
CREATE INDEX i2_eherm on eherm (vsn)  ;
CREATE INDEX i3_eherm on eherm (sed_tim)  ;
CREATE UNIQUE INDEX i2_eherd on eherd (erm_no, itm_typ)  ;
CREATE INDEX i3_eherd on eherd (lnk_no)  ;
CREATE INDEX i2_dgcdqm on dgcdqm (chg_cod, eff_dat)  ;
CREATE INDEX i3_dgcdqm on dgcdqm (chart, eff_dat)  ;
CREATE INDEX i2_dgcdqr on dgcdqr (ctl_no)  ;
CREATE INDEX i3_dgcdqr on dgcdqr (lnk_no)  ;
CREATE UNIQUE INDEX i2_tddrgab4 on tddrgab4 (fym,tym)  ;
CREATE INDEX i2_xrcalist on xrcalist (ord_no)  ;
CREATE INDEX i2_osrfodp on osrfodp (rfo_no)  ;
CREATE INDEX i2_osrfodr on osrfodr (rfo_vsn)  ;
CREATE INDEX i3_osrfodr on osrfodr (frm_vsn)  ;
CREATE INDEX i4_osrfodr on osrfodr (rpy_tim, rfo_dct)  ;
CREATE INDEX i5_osrfodr on osrfodr (rfo_tim, frm_dct)  ;
CREATE UNIQUE INDEX i2_tdh10ccd on tdh10ccd (icd_cod_m,icd_cod_c)  ;
CREATE INDEX i2_modcui10 on modcui10 (typ, div_no,icd_cod)  ;
CREATE INDEX i2_mrrmp on mrrmp (lnk_no)  ;
CREATE INDEX i3_mrrmp on mrrmp (rtt)  ;
CREATE UNIQUE INDEX i2_rgrup1 on rgrup (opd_er, charg_typ,f_r,pt_typ,sft,week,eff_dat)  ;
CREATE UNIQUE INDEX i2_mrqar1 on mrqar1 (chart,dat,typ)  ;
CREATE INDEX i2_emtmpq on emtmpq (emq_typ2)  ;
CREATE INDEX i2_emtmpql on emtmpql (lnk_no, cmp_tim,emq_typ1,emq_typ2)  ;
CREATE INDEX i3_emtmpql on emtmpql (cmp_tim, emq_typ1,emq_typ2)  ;
CREATE INDEX i2_mostts on mostts (lnk_num)  ;
CREATE INDEX i2_rgdiel on rgdiel (vsn)  ;
CREATE INDEX i2_rgdrdie on rgdrdie (dct_no)  ;
CREATE INDEX i2_rfebdi on rfebdi (id_no)  ;
CREATE INDEX i3_rfebdi on rfebdi (eff_dat)  ;
CREATE INDEX i4_rfebdi on rfebdi (rf_tr_no)  ;
CREATE INDEX i2_rfebdo on rfebdo (id_no)  ;
CREATE INDEX i3_rfebdo on rfebdo (eff_dat)  ;
CREATE INDEX i4_rfebdo on rfebdo (rf_tr_no)  ;
CREATE INDEX i2_lbdema on lbdema (chart)  ;
CREATE INDEX i3_lbdema on lbdema (exe_dat, tsc,typ)  ;
CREATE INDEX i4_lbdema on lbdema (exe_dat, chg_cod)  ;
CREATE INDEX i5_lbdema on lbdema (pre_dat)  ;
CREATE INDEX i6_lbdema on lbdema (pay_dat)  ;
CREATE UNIQUE INDEX i2_cgromdcr on cgromdcr (room,bed,eff_dat,stp_dat)  ;
CREATE UNIQUE INDEX i2_cgtsrrf on cgtsrrf (typ_cod,itm_no,eff_dat)  ;
CREATE UNIQUE INDEX i2_lbiisf on lbiisf (chg_cod,eff_tim,src,typ)  ;
CREATE UNIQUE INDEX i2_ehpvcrf on ehpvcrf (typ,cod)  ;
CREATE INDEX i2_udocr on udocr (det_no)  ;
CREATE INDEX i2_cgvda on cgvda (vsn)  ;
CREATE INDEX i3_cgvda on cgvda (crt_tim)  ;
CREATE INDEX i4_cgvda on cgvda (apv_tim)  ;
CREATE UNIQUE INDEX i2_dcidie on dcidie (icd_cod,cor_typ,val)  ;
CREATE INDEX i3_dcidie on dcidie (cor_cod)  ;
CREATE INDEX i2_dgcdqml on dgcdqml (lnk_no)  ;
CREATE INDEX i3_dgcdqml on dgcdqml (log_tim)  ;
CREATE INDEX i2_moocr on moocr (vsn,chg_cod)  ;
CREATE INDEX i2_padsc on padsc (ord_no)  ;
CREATE INDEX i2_dgdiad on dgdiad (srv_cod)  ;
CREATE INDEX i3_dgdiad on dgdiad (clt_cod)  ;
CREATE INDEX i2_dgdbde on dgdbde (lnk_num)  ;
CREATE INDEX i3_dgdbde on dgdbde (val)  ;
CREATE INDEX i2_dgotxt on dgotxt (cls_typ, lnk_num)  ;
CREATE INDEX i2_xrpodip on xrpodip (chart)  ;
CREATE INDEX i3_xrpodip on xrpodip (upl_tim)  ;
CREATE INDEX i2_bmptba on bmptba (chart)  ;
CREATE INDEX i3_bmptba on bmptba (acc_no)  ;
CREATE INDEX i4_bmptba on bmptba (frm_no)  ;
CREATE INDEX i2_rgdmd on rgdmd (sd_no)  ;
CREATE INDEX i2_rgdrd on rgdrd (sd_no)  ;
CREATE UNIQUE INDEX i2_lbcodcmd on lbcodcmd (typ,cod,stp_tim)  ;
CREATE INDEX i3_lbcodcmd on lbcodcmd (nam_s)  ;
CREATE INDEX i2_cgpcmd on cgpcmd (chart)  ;
CREATE INDEX i3_cgpcmd on cgpcmd (trn_tim)  ;
CREATE INDEX i2_cgpcvr on cgpcvr (pcm_no)  ;
CREATE INDEX i2_mrlldat on mrlldat (id_no)  ;
CREATE INDEX i3_mrlldat on mrlldat (lnk_no)  ;
CREATE INDEX i2_smlabrpt on smlabrpt (sed_no)  ;
CREATE INDEX i3_smlabrpt on smlabrpt (chart, chg_cod)  ;
CREATE INDEX i2_bmrup on bmrup (acc_no)  ;
CREATE UNIQUE INDEX i3_bmrup on bmrup (val)  ;
CREATE INDEX i2_bmmakie on bmmakie (eff_tim, typ,val)  ;
CREATE INDEX i3_bmmakie on bmmakie (acc_no)  ;
CREATE INDEX i2_icatfee on icatfee (acc_no)  ;
CREATE UNIQUE INDEX i2_bmwrdcnt on bmwrdcnt (dat,ward)  ;
CREATE INDEX i2_motbd on motbd (eff_dat, typ)  ;
CREATE INDEX i2_motrd on motrd (id_no)  ;
CREATE INDEX i3_motrd on motrd (lnk_no)  ;
CREATE INDEX i2_hccish on hccish (id_no)  ;
CREATE INDEX i2_padscd on padscd (pal_no)  ;
CREATE UNIQUE INDEX i2_exregrul on exregrul (typ,item_cod,eff_tim)  ;
CREATE INDEX i2_oomtlrl on oomtlrl (vsn)  ;
CREATE INDEX i3_oomtlrl on oomtlrl (res_dat, itm)  ;
CREATE UNIQUE INDEX i2_rrchgpar on rrchgpar (chg_typ,par_typ1,par_typ2,par_typ3)  ;
CREATE UNIQUE INDEX i2_hecm on hecm (bar_cod)  ;
CREATE INDEX i3_hecm on hecm (prj_no)  ;
CREATE INDEX i4_hecm on hecm (hec_no)  ;
CREATE INDEX i5_hecm on hecm (vsn)  ;
CREATE INDEX i6_hecm on hecm (ana_sis)  ;
CREATE INDEX i2_hecsi on hecsi (cm_no)  ;
CREATE INDEX i2_hecsd on hecsd (csi_no)  ;
CREATE INDEX i2_erdisaster on erdisaster (vsn)  ;
CREATE INDEX i3_erdisaster on erdisaster (report_tim)  ;
CREATE UNIQUE INDEX i2_moval2 on moval2 (lnk_num,seq_no,typ)  ;
CREATE INDEX i2_progbd on progbd (org_nam)  ;
CREATE INDEX i3_progbd on progbd (org_no)  ;
CREATE INDEX i4_progbd on progbd (eff_dat, stp_dat)  ;
CREATE INDEX i5_progbd on progbd (ogt_no)  ;
CREATE INDEX i2_cgepkgi on cgepkgi (pkg_cod)  ;
CREATE INDEX i2_ifdpbc on ifdpbc (rec_no)  ;
CREATE INDEX i2_bmdast on bmdast (acc_no, eff_tim)  ;
CREATE INDEX i3_bmdast on bmdast (acc_no, typ,frm_no)  ;
CREATE UNIQUE INDEX i2_pssqibd on pssqibd (itm_typ,itm_num,eff_dat)  ;
CREATE INDEX i2_pssqrps on pssqrps (itm_typ, itm_num,emp_no)  ;
CREATE INDEX i2_mmecprrf on mmecprrf (map_no, ecp_cod)  ;
CREATE INDEX i2_rgafdr on rgafdr (fil_cod)  ;
CREATE INDEX i2_rgard on rgard (arm_no)  ;
CREATE INDEX i2_rgarm on rgarm (eff_dat, typ)  ;
CREATE INDEX i3_rgarm on rgarm (lnk_vsn)  ;
CREATE UNIQUE INDEX i2_sigdma on sigdma (ma_cod,spc_typ)  ;
CREATE UNIQUE INDEX i2_sigddef on sigddef (ctl_tab,ctl_fld_nam,def_cod)  ;
CREATE UNIQUE INDEX i2_sigdde on sigdde (ma_cod,det_cod)  ;
CREATE INDEX i2_dgplatit on dgpcm (eff_tim, stp_tim,typ,typ_sub)  ;
CREATE INDEX i2_dgpladet on dgpcd (mst_no, eff_tim,stp_tim)  ;
CREATE INDEX i2_molog on molog (lnk_num, seq_no,typ)  ;
CREATE INDEX i2_moupbd on moupbd (ser_no)  ;
CREATE INDEX i3_moupbd on moupbd (cod,eff_tim, stp_tim)  ;
CREATE UNIQUE INDEX i2_lbsperod on lbsperod (lab_no,typ)  ;
CREATE INDEX i2_bmnapl on bmnapl (acc_no)  ;
CREATE UNIQUE INDEX i2_moruq on moruq (ord_no, rur_no,typ)  ;
CREATE INDEX i3_moruq on moruq (adm_dr)  ;
CREATE INDEX i4_moruq on moruq (asg_dat, typ,depart)  ;
CREATE INDEX i2_bmvstrod on bmvstrod (acc_no)  ;
CREATE INDEX i3_bmvstrod on bmvstrod (ent_tim)  ;
CREATE INDEX i4_bmvstrod on bmvstrod (id_no)  ;
CREATE INDEX i2_mobar on mobar (lnk_no,bar_typ)  ;
CREATE INDEX i2_mopmt on mopmt (pmt_dat, pmt_cod)  ;
CREATE INDEX i2_mopmtpkg on mopmtpkg (pmt_no)  ;
CREATE INDEX i3_mopmtpkg on mopmtpkg (evt_no)  ;
CREATE INDEX i2_pdpcitm on pdpcitm (lnk_no)  ;
CREATE INDEX i2_pdpcrd on pdpcrd (lnk_no)  ;
CREATE INDEX i2_moogi on moogi (grp_no)  ;
CREATE INDEX i3_moogi on moogi (lnk_no,typ)  ;
CREATE UNIQUE INDEX i1_ntdie on ntdie (acc_no, f_dat,dt_own,f_meal)  ;
CREATE INDEX i2_btsdm on btsdm (frm_no)  ;
CREATE INDEX i3_btsdm on btsdm (eff_tim)  ;
CREATE INDEX i2_btiod on btiod (bts_no)  ;
CREATE INDEX i3_btiod on btiod (do_tim)  ;
CREATE INDEX i1_btedf on btedf (bts_no)  ;
CREATE INDEX i2_btedf on btedf (ord_no)  ;
CREATE INDEX i3_btedf on btedf (exe_tim)  ;
CREATE UNIQUE INDEX i2_bteqd on bteqd (eqd_no, etyp)  ;
CREATE INDEX i2_btird on btird (frm_no)  ;
CREATE INDEX i2_rgvsnrel on rgvsnrel (sou_vsn)  ;
CREATE INDEX i3_rgvsnrel on rgvsnrel (rel_vsn)  ;
CREATE INDEX i2_rgovdie on rgovdie (wek_day, sft,room,stp_dat)  ;
CREATE INDEX i2_rgrldie on rgrldie (visit_dat, sft,room)  ;
CREATE INDEX i2_rgrdiel on rgrdiel (room)  ;
CREATE INDEX i2_rgcsdie on rgcsdie (mis_num)  ;
CREATE INDEX i2_udocrd on udocrd (ser_no)  ;
CREATE INDEX i2_ossoalog on ossoalog (rec_no)  ;
CREATE INDEX i2_hcwcl on hcwcl (ccd_no,typ)  ;
CREATE INDEX i2_cghtid on cghtid (hsp_no, typ,chg_cod,eff_tim)  ;
CREATE INDEX i1_eotrtriage on eotrtriage (avisitno)  ;
CREATE INDEX i2_eotrtriage on eotrtriage (auserkeyinid)  ;
CREATE INDEX i3_eotrtriage on eotrtriage (acreatedate)  ;
CREATE INDEX i2_uddmr on uddmr (vsn)  ;
CREATE INDEX i2_uddid on uddid (dpm_no)  ;
CREATE INDEX i3_uddid on uddid (lnk_no)  ;
CREATE INDEX i4_uddid on uddid (dpm_tim)  ;
CREATE INDEX i1_moowvr on moowvr (ord_no)  ;
CREATE INDEX i2_moowvr on moowvr (itm_no)  ;
CREATE INDEX i3_moowvr on moowvr (acc_no)  ;
CREATE INDEX i1_moowvrl on moowvrl (ord_no)  ;
CREATE INDEX i2_moowvrl on moowvrl (log_tim)  ;
CREATE UNIQUE INDEX i2_osdcdb on osdcdb (doctor,nhi_cod,icd_cod)  ;
CREATE INDEX i2_exexec2 on exexec2 (evt_num, typ)  ;
CREATE UNIQUE INDEX i2_exexec on exexec (evt_num)  ;
CREATE INDEX i2_dgpobs on dgpobs (eff_tim)  ;
CREATE UNIQUE INDEX i2_cgcar on cgcar (lnk_num, frm_typ,chg_typ)  ;
CREATE INDEX i3_cgcar on cgcar (eff_dat, org_nam)  ;
CREATE INDEX i2_moctb on moctb (emp_no)  ;
CREATE INDEX i2_mocti on mocti (bmk_no)  ;
CREATE INDEX i2_rgdrcdie on rgdrcdie (dsp_nam)  ;
CREATE INDEX i3_rgdrcdie on rgdrcdie (typ_lnk)  ;
CREATE INDEX i2_moiolog22 on moiolog2 (lnk_num)  ;
CREATE INDEX i2_moiolog3 on moiolog3 (lnk_num)  ;
CREATE INDEX i2_moiolog4 on moiolog4 (lnk_num)  ;
CREATE INDEX i2_moiolog5 on moiolog5 (lnk_num)  ;
CREATE INDEX i3_moiolog5 on moiolog5 (fun_no, log_tim)  ;
CREATE INDEX i2_padscg on padscg (grp_no)  ;
CREATE INDEX i3_padscg on padscg (ord_no)  ;
CREATE INDEX i2_mrpnie on mrpnie (chart)  ;
CREATE INDEX i3_mrpnie on mrpnie (val)  ;
CREATE INDEX i2_udded on udded (grp_no)  ;
CREATE INDEX i3_udded on udded (lnk_no)  ;
CREATE INDEX i4_udded on udded (exe_tim)  ;
CREATE INDEX i2_moaar on moaar (ord_no)  ;
CREATE INDEX i3_moaar on moaar (itm_typ, rtt)  ;
CREATE INDEX i2_mopspf on mopspf (emp_no)  ;
CREATE INDEX i3_mopspf on mopspf (eff_tim, stp_tim)  ;
CREATE INDEX i2_moarf on moarf (eff_tim, stp_tim)  ;
CREATE INDEX i2_mosrpt on mosrpt (ord_no)  ;
CREATE INDEX i3_mosrpt on mosrpt (itm_typ, rtt)  ;
CREATE INDEX i4_mosrpt on mosrpt (rpt_dat)  ;
CREATE UNIQUE INDEX i2_dgmrkl on dgmrkl (lnk_num,seq_no,typ)  ;
CREATE INDEX i3_dgmrkl on dgmrkl (up_tim)  ;
CREATE INDEX i4_dgmrkl on dgmrkl (mrk_tim)  ;
CREATE INDEX i2_cgnhded on cgnhded (typ, eff_dat,stp_dat)  ;
CREATE UNIQUE INDEX i2_motxt2 on motxt2 (ord_no,txt_typ)  ;
CREATE INDEX i3_motxt2 on motxt2 (chart, rpt_dat desc,rpt_hm)  ;
CREATE INDEX i4_motxt2 on motxt2 (rpt_dat)  ;
CREATE INDEX i2_ordie on ordie (ord_no)  ;
CREATE INDEX i2_padscm on padscm (ord_no)  ;
CREATE UNIQUE INDEX i2_dtptvet on dtptvet (chart,visit_no)  ;
CREATE INDEX i2_capmcr on capmcr (cnr_no)  ;
CREATE UNIQUE INDEX i2_cgroompd on cgroompd (class,rank,eff_dat,fee_cod)  ;
CREATE UNIQUE INDEX i2_cgroompm on cgroompm (fee_cod,eff_dat)  ;
CREATE INDEX i2_dgpcf on dgpcf (drug_cod, m_typ,s_typ)  ;
CREATE INDEX i2_mosbldd on mosbldd (chart)  ;
CREATE INDEX i3_mosbldd on mosbldd (pre_chart)  ;
CREATE INDEX i4_mosbldd on mosbldd (pre_vsn)  ;
CREATE INDEX i5_mosbldd on mosbldd (lnk_no)  ;
CREATE INDEX i2_moblddbb on moblddbb (lnk_no)  ;
CREATE INDEX i3_moblddbb on moblddbb (bpd_n)  ;
CREATE UNIQUE INDEX i2_estmmf on estmmf (itm_no,eff_dat,typ)  ;
CREATE INDEX i2_morrd on morrd (eff_dat, stp_dat,std_no)  ;
CREATE INDEX i3_morrd on morrd (eff_dat, stp_dat,tch_no)  ;
CREATE INDEX i2_dgdped on dgdped (license_no)  ;
CREATE INDEX i3_dgdped on dgdped (ing_nam)  ;
CREATE INDEX i4_dgdped on dgdped (ing_cod)  ;
CREATE INDEX i5_dgdped on dgdped (eff_tim)  ;
CREATE INDEX i2_dgfsob on dgfsob (license_no)  ;
CREATE INDEX i3_dgfsob on dgfsob (ch_nam)  ;
CREATE INDEX i4_dgfsob on dgfsob (en_nam)  ;
CREATE INDEX i5_dgfsob on dgfsob (eff_tim)  ;
CREATE INDEX i2_dglnd on dglnd (license_no)  ;
CREATE INDEX i3_dglnd on dglnd (manu_nam)  ;
CREATE INDEX i4_dglnd on dglnd (manu_site)  ;
CREATE INDEX i5_dglnd on dglnd (eff_tim)  ;
CREATE INDEX i2_dglned on dglned (license_no)  ;
CREATE INDEX i3_dglned on dglned (eff_tim)  ;
CREATE INDEX i2_dgpcatc on dgpcatc (license_no)  ;
CREATE INDEX i3_dgpcatc on dgpcatc (cod)  ;
CREATE INDEX i4_dgpcatc on dgpcatc (eff_tim)  ;
CREATE INDEX i2_rgdrl on rgdrl (lnk_no)  ;
CREATE INDEX i3_rgdrl on rgdrl (typ,eff_tim)  ;
CREATE INDEX i2_rgdrc on rgdrc (lnk_no)  ;
CREATE INDEX i3_rgdrc on rgdrc (typ,eff_tim)  ;
CREATE INDEX i2_mrrst on mrrst (sub_yymm, dct_no)  ;
CREATE INDEX i3_mrrst on mrrst (vsn)  ;
CREATE INDEX i2_bmdie on bmdie (acc_no)  ;
CREATE INDEX i2_hcwcupl on hcwcupl (ccd_no)  ;
CREATE INDEX i3_hcwcupl on hcwcupl (wrt_tim)  ;
CREATE INDEX i2_cgqecdl on cgqecdl (trn_no)  ;
CREATE INDEX i3_cgqecdl on cgqecdl (lnk_no)  ;
CREATE INDEX i2_mocmd on mocmd (lnk_no,frm, func_no)  ;
CREATE INDEX i3_mocmd on mocmd (stp_tim)  ;
CREATE INDEX i2_bmpvt on bmpvt (acc_no)  ;
CREATE INDEX i2_rgdrcd on rgdrcd (lnk_no)  ;
CREATE INDEX i3_rgdrcd on rgdrcd (eff_tim, typ,rul_cod)  ;
CREATE UNIQUE INDEX i1_cgoscm on cgoscm (lnk_no)  ;
CREATE UNIQUE INDEX i2_cgoscm on cgoscm (rtd,osc_no)  ;
CREATE UNIQUE INDEX i2_cgoscd on cgoscd (osc_no)  ;
CREATE INDEX i2_tcmsnc on tcmsnc (his_id)  ;
CREATE INDEX i3_tcmsnc on tcmsnc (his_dat)  ;
CREATE INDEX i2_rfpar on rfpar (act_tim, act_typ)  ;
CREATE INDEX i3_rfpar on rfpar (vsn)  ;
CREATE INDEX i2_osdugdff on osdugdff (lnk_no)  ;
CREATE INDEX i3_osdugdff on osdugdff (icr_no)  ;
CREATE INDEX i2_dgdbicr on dgdbicr (bmr_no)  ;
CREATE INDEX i3_dgdbicr on dgdbicr (rtt)  ;
CREATE INDEX i2_momblog on momblog (lnk_num)  ;
CREATE INDEX i3_momblog on momblog (log_tim, typ)  ;
CREATE INDEX i2_osdugitm on osdugitm (lnk_no)  ;
CREATE INDEX i3_osdugitm on osdugitm (del_rec_no)  ;
CREATE INDEX i2_rgldie on rgldie (rd_no)  ;
CREATE INDEX i2_cgipar on cgipar (evt_num)  ;
CREATE INDEX i3_cgipar on cgipar (item_cod, eff_dat)  ;
CREATE INDEX i2_dgoutitm on dgoutitm (mst_no)  ;
CREATE INDEX i3_dgoutitm on dgoutitm (rtt, chg_cod)  ;
CREATE INDEX i2_dgoutmst on dgoutmst (dug_dat, fil1,lmp_typ,lmp_no)  ;
CREATE INDEX i3_dgoutmst on dgoutmst (vsn)  ;
CREATE INDEX i4_dgoutmst on dgoutmst (ord_lnk_no, ord_typ)  ;
CREATE INDEX i5_dgoutmst on dgoutmst (ord_tim)  ;
CREATE INDEX i6_dgoutmst on dgoutmst (chg_tim)  ;
CREATE INDEX i7_dgoutmst on dgoutmst (out_tim)  ;
CREATE INDEX i2_paabr on paabr (pal_no)  ;
CREATE INDEX i3_paabr on paabr (rec_tim, typ)  ;
CREATE INDEX i2_mosoahfd on mosoahfd (own_no, typ)  ;
CREATE INDEX i2_mormr on mormr (lnk_no,typ)  ;
CREATE INDEX i3_mormr on mormr (ret_tim, rcv_man)  ;
CREATE INDEX i4_mormr on mormr (ret_tim, ret_man)  ;
CREATE INDEX i2_cgbdar on cgbdar (lnk_no, lnk_typ)  ;
CREATE INDEX i3_cgbdar on cgbdar (lnk_typ, apv_tim)  ;
CREATE INDEX i2_smrf on smrf (chart)  ;
CREATE INDEX i3_smrf on smrf (sed_tim,apl_man)  ;
CREATE INDEX i4_smrf on smrf (sed_tim,tel_no)  ;
CREATE INDEX i5_smrf on smrf (lnk_no,lnk_typ)  ;
CREATE INDEX i2_dgdipr on dgdipr (det_no)  ;
CREATE INDEX i3_dgdipr on dgdipr (sdr_tim)  ;
CREATE INDEX i4_dgdipr on dgdipr (bar_tim)  ;
CREATE INDEX i2_moomm on moomm (lnk_no,seq_no)  ;
CREATE INDEX i2_moomd on moomd (mst_no)  ;
CREATE INDEX i2_moomdd on moomdd (itm_no)  ;
CREATE INDEX i2_moomlls on moomlls (itm_no)  ;
CREATE INDEX i2_moomls on moomls (itm_no)  ;
CREATE INDEX i2_moomss on moomss (itm_no)  ;
CREATE UNIQUE INDEX i2_moomtr on moomtr (lnk_num,seq_no)  ;
CREATE INDEX i2_dgoutlot on dgoutlot (itm_no)  ;
CREATE INDEX i3_dgoutlot on dgoutlot (lot_num)  ;
CREATE INDEX i2_dgoutpar on dgoutpar (act_tim, act_typ)  ;
CREATE INDEX i3_dgoutpar on dgoutpar (mst_no)  ;
CREATE UNIQUE INDEX i2_pscontra on pscontra (emp_no,f_dat)  ;
CREATE INDEX i2_mopkgdif on mopkgdif (pkg_no)  ;
CREATE INDEX i2_rgdrdn on rgdrdn (sd_no)  ;
CREATE INDEX i2_rgdrcdn on rgdrcdn (lnk_no)  ;
CREATE INDEX i3_rgdrcdn on rgdrcdn (eff_tim, typ,rul_cod)  ;
CREATE INDEX i2_pasamf on pasamf (pa_no)  ;
CREATE INDEX i2_pasadf on pasadf (psa_no)  ;
CREATE INDEX i2_hcwcld on hcwcld (ccd_no, seq_no,typ)  ;
CREATE INDEX i2_momdymrk on momdymrk (chart,typ)  ;
CREATE INDEX i2_moprnrsn on moprnrsn (vsn)  ;
CREATE INDEX i3_moprnrsn on moprnrsn (log_tim, typ)  ;
CREATE INDEX i2_moprnoth on moprnoth (rec_no)  ;
CREATE INDEX i2_moefrd on moefrd (mst_no)  ;
CREATE INDEX i3_moefrd on moefrd (lnk_typ, lnk_no)  ;
CREATE INDEX i2_moefrm on moefrm (frm_no)  ;
CREATE INDEX i2_ntpsac on ntpsac (typ,amt)  ;
CREATE INDEX i2_hcextwcr on hcextwcr (his_id)  ;
CREATE INDEX i3_hcextwcr on hcextwcr (vsn)  ;
CREATE INDEX i4_hcextwcr on hcextwcr (chart)  ;
CREATE INDEX i5_hcextwcr on hcextwcr (his_dat)  ;
CREATE INDEX i2_doolfm on doolfm (lev_no)  ;
CREATE INDEX i3_doolfm on doolfm (rel_no)  ;
CREATE INDEX i1_monotm on monotm (not_no)  ;
CREATE INDEX i2_cggtrd on cggtrd (grp_cod)  ;
CREATE INDEX i3_cggtrd on cggtrd (detai_cod)  ;
CREATE INDEX i4_cggtrd on cggtrd (eff_tim, stp_tim)  ;
CREATE INDEX i2_cggtrdl on cggtrdl (grp_cod, log_tim)  ;
CREATE INDEX i2_dgdedf on dgdedf (lnk_num)  ;
CREATE INDEX i3_dgdedf on dgdedf (val)  ;
CREATE INDEX i2_dgtpdf on dgtpdf (srv_cod)  ;
CREATE INDEX i2_moplr on moplr (id_no)  ;
CREATE INDEX i3_moplr on moplr (lnk_no)  ;
CREATE INDEX i4_moplr on moplr (eff_tim, typ)  ;
CREATE INDEX i2_dci10cnf on dci10cnf (icd_typ, icd_cod)  ;
CREATE INDEX i3_dci10cnf on dci10cnf (icd_ver)  ;
CREATE UNIQUE INDEX i2_dcicdmf on dcicdmf (src_ver,src_cod,tgt_ver,tgt_cod)  ;
CREATE UNIQUE INDEX i2_bmnurnum on bmnurnum (ward,typ,stp_tim)  ;
CREATE INDEX i2_mormp on mormp (lnk_no)  ;
CREATE INDEX i3_mormp on mormp (rtt)  ;
CREATE INDEX i2_oostsrcd on oostsrcd (visit_dat, sft,room,sts_cod)  ;
CREATE INDEX i2_eodiel on eodiel (vsn)  ;
CREATE INDEX f_idx_motxt_1 ON motxt (ord_no);
CREATE INDEX f_idx_mopdd_2 ON mopdd (vsn);
CREATE INDEX f_idx_mopar_3 ON mopar (ord_no);
CREATE INDEX f_idx_moitmh_4 ON moitmh (dit_no);
CREATE INDEX f_idx_hcpst_5 ON hcpst (ccd_no);
CREATE INDEX f_idx_dgdcct_6 ON dgdcct (dcr_no);
CREATE INDEX f_idx_mopftr_7 ON mopftr (exm_no);
CREATE INDEX f_idx_npfrdi_8 ON npfrdi (rec_no);
CREATE INDEX f_idx_dgpad_9 ON dgpad (par_no);
CREATE INDEX f_idx_dgpadsc_10 ON dgpadsc (par_no);
CREATE INDEX f_idx_moitm_11 ON moitm (ord_no);
CREATE INDEX f_idx_dgpadr_12 ON dgpadr (dmc_no);
CREATE INDEX f_idx_moepitm_13 ON moepitm (epd_no);
