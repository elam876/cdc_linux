dbaccess -e hispcd <<!EOF
truncate table cgbqt2;
truncate table asacsitm;
truncate table bccbcr;
truncate table bmpobd;
load from cgbqt2.unl delimiter '	' insert into cgbqt2;
load from asacsitm.unl delimiter '	' insert into asacsitm;
load from bccbcr.unl delimiter '	' insert into bccbcr;
load from bmpobd.unl delimiter '	' insert into bmpobd;
!EOF
