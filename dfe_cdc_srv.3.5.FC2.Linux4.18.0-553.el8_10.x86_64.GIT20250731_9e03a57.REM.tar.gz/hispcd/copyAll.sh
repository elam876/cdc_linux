#!/usr/bin/env bash
PARALLEL=${1-10}
MODULE=applier
source cbUtil.set


while true
do
	find workSpace/baseDataQ/1 -type f \
		| sort -k5 -t\. \
		| xargs --no-run-if-empty -P $PARALLEL -n 1 copyText.sh 
	#if [ $? -ne 0 ]; then exit 1; fi
		
exit 0
	sleep 5
	find workSpace/baseDataQ/1 -type f |head -2|wc -l 0|grep -w 0
	if [ $? -eq 0 ]; then
		break;
	fi
done
