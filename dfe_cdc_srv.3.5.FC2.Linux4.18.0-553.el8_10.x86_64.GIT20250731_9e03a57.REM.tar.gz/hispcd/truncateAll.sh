getCfgContent $CB_PROJECT_DIR/config/DBS/1/repltab.cfg|awk '
{
	printf("truncate table %s;\n",$2);
}
' | sqlRun.sh
