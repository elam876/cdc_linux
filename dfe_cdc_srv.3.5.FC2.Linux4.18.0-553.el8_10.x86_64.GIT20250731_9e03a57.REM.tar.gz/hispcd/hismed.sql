






{ TABLE "informix".menpasr row size = 1038 number of columns = 8 index size = 0 }

create table "informix".menpasr 
  (
    chart integer not null ,
    visit_no integer not null ,
    dsc1 varchar(255) not null ,
    dsc2 varchar(255) not null ,
    dsc3 varchar(255) not null ,
    dsc4 varchar(255) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".menpasr from "public" as "informix";

{ TABLE "informix".memetrec row size = 355 number of columns = 12 index size = 13 }

create table "informix".memetrec 
  (
    dpt_no smallint not null ,
    typ smallint not null ,
    sub varchar(255) not null ,
    met_dat date not null ,
    met_hm smallint not null ,
    met_loc smallint not null ,
    met_cam char(12) not null ,
    rpt_man char(12) not null ,
    obj char(1) not null ,
    txt text,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".memetrec from "public" as "informix";


create unique index "informix".i1_memetrec on "informix".memetrec 
    (dpt_no,typ,met_dat) using btree ;


