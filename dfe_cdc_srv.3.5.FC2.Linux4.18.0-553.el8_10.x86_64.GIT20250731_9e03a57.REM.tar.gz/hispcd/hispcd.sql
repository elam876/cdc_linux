






{ TABLE "informix".mrpbd1 row size = 128 number of columns = 32 index size = 64 }

create table "informix".mrpbd1 
  (
    chart integer not null ,
    typ char(1) not null ,
    nam char(12) not null ,
    born_yy smallint not null ,
    born_mmdd smallint not null ,
    sex char(1) not null ,
    l_mark char(1) not null ,
    c_r_cod integer not null ,
    c_r_adrs char(34) not null ,
    domicile char(8) not null ,
    marr char(1) not null ,
    educ char(1) not null ,
    profes char(3) not null ,
    fil1 char(1) not null ,
    id_no char(10) not null ,
    tel_h integer not null ,
    tel_o integer not null ,
    bl_typ char(2) not null ,
    gl_typ char(2) not null ,
    pt_typ char(2) not null ,
    sp_typ char(2) not null ,
    sw_typ char(2) not null ,
    insured integer not null ,
    cer_no integer not null ,
    loc_o char(1) not null ,
    hpt_loc char(1) not null ,
    nv_times smallint not null ,
    bad_amt integer not null ,
    no_good char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".mrpbd1 from "public" as "informix";

{ TABLE "informix".ocoditem row size = 74 number of columns = 17 index size = 38 }

create table "informix".ocoditem 
  (
    charg_no integer not null ,
    seq_no smallint not null ,
    loc smallint not null ,
    tmp char(1) not null ,
    item_cod char(7) not null ,
    qty_prc integer,
    qty_tot char(5) not null ,
    usag char(20) not null ,
    self char(1) not null ,
    item_typ char(1) not null ,
    emg char(1) not null ,
    gl_cod smallint not null ,
    pt_cod smallint not null ,
    pr_amt decimal(9,1) not null ,
    gl_amt_p decimal(9,1) not null ,
    pt_amt decimal(9,1) not null ,
    rtd date not null 
  );

revoke all on "informix".ocoditem from "public" as "informix";

{ TABLE "informix".ocdesc row size = 51 number of columns = 18 index size = 36 }

create table "informix".ocdesc 
  (
    charg_no serial not null ,
    chart integer not null ,
    visit_no decimal(11,0),
    tmp char(1) not null ,
    fil_1 char(1) not null ,
    prescriptor smallint not null ,
    gl_amt integer not null ,
    gl_amt_p integer not null ,
    pt_amt integer not null ,
    collect_no integer not null ,
    fil_2 char(1) not null ,
    lamp_typ char(1) not null ,
    lamp_no smallint not null ,
    dispenser smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null ,
    rtl smallint not null 
  );

revoke all on "informix".ocdesc from "public" as "informix";

{ TABLE "informix".cgastitm row size = 59 number of columns = 7 index size = 7 }

create table "informix".cgastitm 
  (
    ast_cod smallint not null ,
    nam_a char(4) not null ,
    nam_f char(40) not null ,
    ast_amt decimal(7,2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".cgastitm from "public" as "informix";

{ TABLE "informix".cgbillgc row size = 29 number of columns = 9 index size = 20 }

create table "informix".cgbillgc 
  (
    group_cod char(7) not null ,
    o_i char(1) not null ,
    detai_cod char(7) not null ,
    gen_qty smallint not null ,
    gon_qty smallint not null ,
    lau_qty smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".cgbillgc from "public" as "informix";

{ TABLE "informix".cgcnc row size = 9 number of columns = 4 index size = 6 }

create table "informix".cgcnc 
  (
    typ char(1) not null ,
    no smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".cgcnc from "public" as "informix";

{ TABLE "informix".cgcncc row size = 31 number of columns = 8 index size = 11 }

create table "informix".cgcncc 
  (
    collect_no integer not null ,
    typ smallint not null ,
    amt integer not null ,
    bill_c char(2) not null ,
    bill_n decimal(16,0) not null ,
    sheet_c char(2) not null ,
    sheet_n integer not null ,
    due_dat date
  );

revoke all on "informix".cgcncc from "public" as "informix";

{ TABLE "informix".cgcoment row size = 86 number of columns = 2 index size = 12 }

create table "informix".cgcoment 
  (
    item_cod char(7) not null ,
    comment char(79) not null 
  );

revoke all on "informix".cgcoment from "public" as "informix";

{ TABLE "informix".cgndmnam row size = 109 number of columns = 6 index size = 12 }

create table "informix".cgndmnam 
  (
    item_cod char(7) not null ,
    unit char(4) not null ,
    nam char(90) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".cgndmnam from "public" as "informix";

{ TABLE "informix".cgpar row size = 43 number of columns = 14 index size = 18 }

create table "informix".cgpar 
  (
    chart integer not null ,
    visit_no decimal(11,0),
    typ smallint 
        default 0 not null ,
    amt integer not null ,
    author smallint not null ,
    reason char(1) not null ,
    pay_mod char(1) not null ,
    f_amt integer not null ,
    e_amt integer not null ,
    comp_no integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null ,
    rtl smallint not null 
  );

revoke all on "informix".cgpar from "public" as "informix";

{ TABLE "informix".cgpfdcnt row size = 18 number of columns = 7 index size = 9 }

create table "informix".cgpfdcnt 
  (
    pt_typ char(2) not null ,
    fee_typ smallint not null ,
    o_discnt decimal(3,2) not null ,
    i_discnt decimal(3,2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".cgpfdcnt from "public" as "informix";

{ TABLE "informix".cgptbd row size = 75 number of columns = 8 index size = 7 }

create table "informix".cgptbd 
  (
    pt_typ char(2) not null ,
    nam_a char(4) not null ,
    nam_f char(40) not null ,
    certific char(20) not null ,
    cash char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".cgptbd from "public" as "informix";

{ TABLE "informix".dgfomula row size = 89 number of columns = 5 index size = 13 }

create table "informix".dgfomula 
  (
    drug_cod char(5) not null ,
    typ char(1) not null ,
    seq_no smallint not null ,
    description char(80) not null ,
    tsc char(1) 
        default '1' not null 
  );

revoke all on "informix".dgfomula from "public" as "informix";

{ TABLE "informix".dgjobdsp row size = 15 number of columns = 7 index size = 8 }

create table "informix".dgjobdsp 
  (
    dispense_typ char(1) not null ,
    start_hhii smallint not null ,
    dis_qty smallint not null ,
    cycle smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".dgjobdsp from "public" as "informix";

{ TABLE "informix".dgnam row size = 48 number of columns = 5 index size = 56 }

create table "informix".dgnam 
  (
    drug_cod char(5) not null ,
    seq_no char(1) not null ,
    g_l char(1) not null ,
    pcs char(1) not null ,
    nam char(40) not null 
  );

revoke all on "informix".dgnam from "public" as "informix";

{ TABLE "informix".glnprcn row size = 87 number of columns = 5 index size = 6 }

create table "informix".glnprcn 
  (
    cod char(1) not null ,
    nam char(78) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".glnprcn from "public" as "informix";

{ TABLE "informix".mrocgprg row size = 46 number of columns = 22 index size = 25 }

create table "informix".mrocgprg 
  (
    chart integer not null ,
    rg_dat date not null ,
    evidenc_1 char(1) not null ,
    evidenc_2 char(1) not null ,
    evidenc_3 char(1) not null ,
    evidenc_4 char(1) not null ,
    patho_year smallint not null ,
    patho_no smallint not null ,
    init_dat date not null ,
    init_hos integer,
    diag smallint not null ,
    morphology smallint not null ,
    treat_1 char(1) not null ,
    treat_2 char(1) not null ,
    treat_3 char(1) not null ,
    treat_4 char(1) not null ,
    external char(1) not null ,
    sts char(1) not null ,
    h_w integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".mrocgprg from "public" as "informix";

{ TABLE "informix".mromcn row size = 92 number of columns = 6 index size = 9 }

create table "informix".mromcn 
  (
    om_cod smallint not null ,
    seq_no smallint not null ,
    nam char(80) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".mromcn from "public" as "informix";

{ TABLE "informix".mrpbd2 row size = 114 number of columns = 9 index size = 9 }

create table "informix".mrpbd2 
  (
    chart integer not null ,
    l_r_cod integer not null ,
    l_r_adrs char(34) not null ,
    tel_h2 integer 
        default 0 not null ,
    tel_a integer 
        default 0 not null ,
    eml_adrs char(50) 
        default '' not null ,
    l_typ char(2) not null ,
    l_insured integer not null ,
    husband_nam char(8) not null 
  );

revoke all on "informix".mrpbd2 from "public" as "informix";

{ TABLE "informix".mtnam row size = 98 number of columns = 3 index size = 13 }

create table "informix".mtnam 
  (
    mt_cod char(7) not null ,
    seq_no char(1) not null ,
    nam char(90) not null 
  );

revoke all on "informix".mtnam from "public" as "informix";

{ TABLE "informix".psemprel row size = 26 number of columns = 8 index size = 23 }

create table "informix".psemprel 
  (
    emp_no smallint not null ,
    relat char(1) not null ,
    fil_1 char(1) not null ,
    pt_typ char(2) not null ,
    id_no char(10) not null ,
    stop_dat date not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".psemprel from "public" as "informix";

{ TABLE "informix".psshcn row size = 38 number of columns = 8 index size = 7 }

create table "informix".psshcn 
  (
    cod smallint not null ,
    nam_a char(4),
    nam_f char(20),
    typ char(1),
    fil_1 char(1),
    lau_h_no integer,
    rtp smallint not null ,
    rtd date
  );

revoke all on "informix".psshcn from "public" as "informix";

{ TABLE "informix".rgrup2 row size = 15 number of columns = 8 index size = 10 }

create table "informix".rgrup2 
  (
    opd_er char(1) not null ,
    charg_typ char(1) not null ,
    f_r char(1) not null ,
    pt_typ char(2) not null ,
    amt smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".rgrup2 from "public" as "informix";

{ TABLE "informix".ucogfuncold row size = 18 number of columns = 6 index size = 13 }

create table "informix".ucogfuncold 
  (
    group_func_no char(4) not null ,
    func_no char(4) not null ,
    use_level char(2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".ucogfuncold from "public" as "informix";

{ TABLE "informix".cgdfrat row size = 10 number of columns = 2 index size = 12 }

create table "informix".cgdfrat 
  (
    item_cod char(7) not null ,
    df_rat decimal(3,2) not null 
  );

revoke all on "informix".cgdfrat from "public" as "informix";

{ TABLE "informix".cgroompf row size = 66 number of columns = 26 index size = 11 }

create table "informix".cgroompf 
  (
    class char(1) not null ,
    rank char(1) not null ,
    eff_dat date not null ,
    tc char(1) not null ,
    gonbau char(1) not null ,
    laubau char(1) not null ,
    gen_rf smallint not null ,
    gen_nf smallint not null ,
    gen_df smallint not null ,
    gen_dg smallint not null ,
    gon_rf smallint not null ,
    gon_nf smallint not null ,
    gon_df smallint not null ,
    gon_self smallint not null ,
    lau_rf smallint not null ,
    lau_nf smallint not null ,
    lau_df smallint not null ,
    lau_self smallint not null ,
    lau_dg_1_5 smallint not null ,
    lau_dg_6 smallint not null ,
    cod_rf char(7) 
        default '' not null ,
    cod_nf char(7) 
        default '' not null ,
    cod_df char(7) 
        default '' not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".cgroompf from "public" as "informix";

{ TABLE "informix".cgroompp row size = 45 number of columns = 23 index size = 7 }

create table "informix".cgroompp 
  (
    class char(1) not null ,
    rank char(1) not null ,
    eff_dat date not null ,
    tc char(1) not null ,
    gonbau char(1) not null ,
    laubau char(1) not null ,
    gen_rf smallint not null ,
    gen_nf smallint not null ,
    gen_df smallint not null ,
    gen_dg smallint not null ,
    gon_rf smallint not null ,
    gon_nf smallint not null ,
    gon_df smallint not null ,
    gon_self smallint not null ,
    lau_rf smallint not null ,
    lau_nf smallint not null ,
    lau_df smallint not null ,
    lau_self smallint not null ,
    lau_dg_1_5 smallint not null ,
    lau_dg_6 smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".cgroompp from "public" as "informix";

{ TABLE "informix".icoditem row size = 78 number of columns = 18 index size = 38 }

create table "informix".icoditem 
  (
    charg_no integer not null ,
    seq_no smallint not null ,
    loc smallint not null ,
    tmp char(1) not null ,
    item_cod char(7) not null ,
    qty_prc integer not null ,
    qty_tot char(5) not null ,
    qty_remain integer not null ,
    usag char(20) not null ,
    self char(1) not null ,
    item_typ char(1) not null ,
    emg char(1) not null ,
    gl_cod smallint not null ,
    pt_cod smallint not null ,
    pr_amt decimal(9,1) not null ,
    gl_amt_p decimal(9,1) not null ,
    pt_amt decimal(9,1) not null ,
    rtd date not null 
  );

revoke all on "informix".icoditem from "public" as "informix";

{ TABLE "informix".bmasgnl row size = 26 number of columns = 9 index size = 0 }

create table "informix".bmasgnl 
  (
    tp smallint not null ,
    td date not null ,
    thm smallint not null ,
    tl smallint not null ,
    tc char(2) not null ,
    chart integer not null ,
    room_o char(4) 
        default '' not null ,
    bed_o char(2) not null ,
    discha_dat date not null 
  );

revoke all on "informix".bmasgnl from "public" as "informix";

{ TABLE "informix".bmrmlvl row size = 20 number of columns = 8 index size = 30 }

create table "informix".bmrmlvl 
  (
    room char(4) 
        default '' not null ,
    bed char(2) not null ,
    eff_dat date not null ,
    class char(1) not null ,
    rank char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".bmrmlvl from "public" as "informix";

{ TABLE "informix".icglscon row size = 20 number of columns = 6 index size = 16 }

create table "informix".icglscon 
  (
    acc_no integer not null ,
    item_cod char(7) not null ,
    fil_1 char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".icglscon from "public" as "informix";

{ TABLE "informix".icrolog row size = 26 number of columns = 8 index size = 18 }

create table "informix".icrolog 
  (
    tp smallint not null ,
    td date not null ,
    thm smallint not null ,
    tl smallint not null ,
    acc_no integer not null ,
    col_no integer not null ,
    tim_chg_no integer not null ,
    ord_chg_no integer not null 
  );

revoke all on "informix".icrolog from "public" as "informix";

{ TABLE "informix".rfdata row size = 15 number of columns = 3 index size = 16 }

create table "informix".rfdata 
  (
    chart integer not null ,
    visit_no decimal(11,0),
    refer_hosp integer not null 
  );

revoke all on "informix".rfdata from "public" as "informix";

{ TABLE "informix".icitmqty row size = 31 number of columns = 7 index size = 18 }

create table "informix".icitmqty 
  (
    acc_no integer not null ,
    item_cod char(7) not null ,
    fee_cod smallint not null ,
    days smallint not null ,
    qty integer not null ,
    amt_pr decimal(9,1),
    amt_fil decimal(9,1)
  );

revoke all on "informix".icitmqty from "public" as "informix";

{ TABLE "informix".psdpatbd row size = 42 number of columns = 12 index size = 9 }

create table "informix".psdpatbd 
  (
    sub_h_no smallint not null ,
    unit_no smallint not null ,
    level_no smallint not null ,
    nam_a char(4) not null ,
    nam_f char(20) not null ,
    strenth smallint not null ,
    typ char(1) not null ,
    mark_pson char(1) not null ,
    mark_acc char(1) not null ,
    mark_med char(1) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".psdpatbd from "public" as "informix";

{ TABLE "informix".updicoi row size = 17 number of columns = 4 index size = 0 }

create table "informix".updicoi 
  (
    charg_no integer not null ,
    seq_no integer not null ,
    item_cod char(7) not null ,
    gl_cod smallint not null 
  );

revoke all on "informix".updicoi from "public" as "informix";

{ TABLE "informix".updocoi row size = 17 number of columns = 4 index size = 0 }

create table "informix".updocoi 
  (
    charg_no integer not null ,
    seq_no integer not null ,
    item_cod char(7) not null ,
    gl_cod smallint not null 
  );

revoke all on "informix".updocoi from "public" as "informix";

{ TABLE "informix".icptclog row size = 26 number of columns = 9 index size = 9 }

create table "informix".icptclog 
  (
    tp smallint not null ,
    td date not null ,
    thm smallint not null ,
    tl smallint not null ,
    acc_no integer not null ,
    gl_typ_o char(2) not null ,
    pt_typ_o char(4) 
        default '' not null ,
    gl_typ_n char(2) not null ,
    pt_typ_n char(4) 
        default '' not null 
  );

revoke all on "informix".icptclog from "public" as "informix";

{ TABLE "informix".cgpcs row size = 17 number of columns = 4 index size = 18 }

create table "informix".cgpcs 
  (
    chart integer not null ,
    visit_no decimal(11,0),
    typ smallint not null ,
    amt integer not null 
  );

revoke all on "informix".cgpcs from "public" as "informix";

{ TABLE "informix".mricddsc row size = 266 number of columns = 6 index size = 13 }

create table "informix".mricddsc 
  (
    icd_cod char(6) not null ,
    seq_no smallint not null ,
    descr char(250) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".mricddsc from "public" as "informix";

{ TABLE "informix".ntpdrscn row size = 54 number of columns = 8 index size = 7 }

create table "informix".ntpdrscn 
  (
    cod char(2) not null ,
    nam_c char(8) not null ,
    nam_e char(30) not null ,
    unit char(4) not null ,
    std smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".ntpdrscn from "public" as "informix";

{ TABLE "informix".ntpdrlog row size = 86 number of columns = 15 index size = 0 }

create table "informix".ntpdrlog 
  (
    acc_no integer not null ,
    f_dat date not null ,
    f_meal char(1) not null ,
    prescriptor smallint not null ,
    cod1 char(2) not null ,
    qty1 decimal(7,2) not null ,
    cod2 char(2) not null ,
    qty2 decimal(7,2) not null ,
    cod3 char(2) not null ,
    qty3 decimal(7,2) not null ,
    cod4 char(2) not null ,
    qty4 decimal(7,2) not null ,
    cod5 char(2) not null ,
    qty5 decimal(7,2) not null ,
    coment char(40) not null 
  );

revoke all on "informix".ntpdrlog from "public" as "informix";

{ TABLE "informix".ntpdrest row size = 86 number of columns = 15 index size = 14 }

create table "informix".ntpdrest 
  (
    acc_no integer not null ,
    f_dat date not null ,
    f_meal char(1) not null ,
    prescriptor smallint not null ,
    cod1 char(2) not null ,
    qty1 decimal(7,2) not null ,
    cod2 char(2) not null ,
    qty2 decimal(7,2) not null ,
    cod3 char(2) not null ,
    qty3 decimal(7,2) not null ,
    cod4 char(2) not null ,
    qty4 decimal(7,2) not null ,
    cod5 char(2) not null ,
    qty5 decimal(7,2) not null ,
    coment char(40) not null 
  );

revoke all on "informix".ntpdrest from "public" as "informix";

{ TABLE "informix".ntpddesc row size = 35 number of columns = 20 index size = 15 }

create table "informix".ntpddesc 
  (
    acc_no integer not null ,
    dt_own char(1) not null ,
    f_dat date not null ,
    f_meal char(1) not null ,
    f_tim smallint 
        default 0 not null ,
    t_dat date not null ,
    t_meal char(1) not null ,
    tc char(1) not null ,
    typ char(1) not null ,
    item char(1) not null ,
    bkt_itm char(1) 
        default '' not null ,
    lnh_itm char(1) 
        default '' not null ,
    dnr_itm char(1) 
        default '' not null ,
    vegetan char(1) not null ,
    avoid1 char(1) not null ,
    avoid2 char(1) not null ,
    avoid3 char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".ntpddesc from "public" as "informix";

{ TABLE "informix".ntpddlog row size = 35 number of columns = 20 index size = 0 }

create table "informix".ntpddlog 
  (
    acc_no integer not null ,
    dt_own char(1) not null ,
    f_dat date not null ,
    f_meal char(1) not null ,
    f_tim smallint 
        default 0 not null ,
    t_dat date not null ,
    t_meal char(1) not null ,
    tc char(1) not null ,
    typ char(1) not null ,
    item char(1) not null ,
    bkt_itm char(1) 
        default '' not null ,
    lnh_itm char(1) 
        default '' not null ,
    dnr_itm char(1) 
        default '' not null ,
    vegetan char(1) not null ,
    avoid1 char(1) not null ,
    avoid2 char(1) not null ,
    avoid3 char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".ntpddlog from "public" as "informix";

{ TABLE "informix".mrptdiag row size = 23 number of columns = 6 index size = 40 }

create table "informix".mrptdiag 
  (
    chart integer not null ,
    visit_no decimal(11,0),
    diag char(6) not null ,
    doctor smallint not null ,
    f_hhmm smallint not null ,
    t_hhmm smallint not null 
  );

revoke all on "informix".mrptdiag from "public" as "informix";

{ TABLE "informix".pslicens row size = 137 number of columns = 13 index size = 12 }

create table "informix".pslicens 
  (
    emp_no integer not null ,
    typ char(1) not null ,
    typ_1 char(1) 
        default '' not null ,
    seq char(1) not null ,
    nam char(40) 
        default '' not null ,
    cer_ch char(30) not null ,
    cer_no char(20) not null ,
    org_no integer 
        default 0 not null ,
    eff_dat date not null ,
    del_dat date not null ,
    coment char(20) not null ,
    rtp integer not null ,
    rtd date not null 
  );

revoke all on "informix".pslicens from "public" as "informix";

{ TABLE "informix".pssclcn row size = 32 number of columns = 5 index size = 7 }

create table "informix".pssclcn 
  (
    scl_no smallint not null ,
    nam_a char(4) not null ,
    nam_f char(20) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".pssclcn from "public" as "informix";

{ TABLE "informix".psdptbd row size = 50 number of columns = 9 index size = 7 }

create table "informix".psdptbd 
  (
    depart smallint not null ,
    nam_a char(12) not null ,
    nam_f char(20) not null ,
    level_no smallint not null ,
    u_depart smallint not null ,
    strenth smallint not null ,
    lp_seq smallint not null ,
    rtp integer not null ,
    rtd date not null 
  );

revoke all on "informix".psdptbd from "public" as "informix";

{ TABLE "informix".psdptitl row size = 314 number of columns = 8 index size = 9 }

create table "informix".psdptitl 
  (
    depart smallint not null ,
    titl char(2) not null ,
    strenth smallint not null ,
    diploma_l char(1) not null ,
    diploma_h char(1) not null ,
    qualifi char(300) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".psdptitl from "public" as "informix";

{ TABLE "informix".cgcolect row size = 39 number of columns = 11 index size = 42 }

create table "informix".cgcolect 
  (
    collect_no serial not null ,
    chart integer not null ,
    visit_no decimal(11,0),
    charg_amt integer not null ,
    cash integer not null ,
    vou_no smallint not null ,
    del_no integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null ,
    rtl smallint not null 
  );

revoke all on "informix".cgcolect from "public" as "informix";

{ TABLE "informix".pscmback row size = 46 number of columns = 11 index size = 11 }

create table "informix".pscmback 
  (
    emp_no smallint not null ,
    f_dat date not null ,
    t_dat date not null ,
    depart smallint not null ,
    titl char(2) not null ,
    rank smallint not null ,
    procs char(1) not null ,
    reason char(2) not null ,
    coment char(21) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".pscmback from "public" as "informix";

{ TABLE "informix".pstrain row size = 67 number of columns = 12 index size = 11 }

create table "informix".pstrain 
  (
    emp_no smallint not null ,
    f_dat date not null ,
    t_dat date not null ,
    typ char(1) not null ,
    contract char(1) not null ,
    hol_fee char(1) not null ,
    place char(4) not null ,
    scl_fee smallint not null ,
    trvl_fee smallint not null ,
    coment char(40) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".pstrain from "public" as "informix";

{ TABLE "informix".psempscl row size = 14 number of columns = 6 index size = 9 }

create table "informix".psempscl 
  (
    emp_no smallint not null ,
    scl_no smallint not null ,
    depart smallint not null ,
    grad_yy smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".psempscl from "public" as "informix";

{ TABLE "informix".psephbcn row size = 34 number of columns = 6 index size = 9 }

create table "informix".psephbcn 
  (
    exp_hby char(2) not null ,
    typ char(2) not null ,
    nam_a char(4) not null ,
    nam_f char(20) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".psephbcn from "public" as "informix";

{ TABLE "informix".psexphby row size = 24 number of columns = 7 index size = 13 }

create table "informix".psexphby 
  (
    emp_no integer not null ,
    exp_hby char(2) not null ,
    typ char(2) not null ,
    eff_dat date 
        default today not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    rtp integer not null ,
    rtd date not null 
  );

revoke all on "informix".psexphby from "public" as "informix";

{ TABLE "informix".pspripun row size = 34 number of columns = 7 index size = 11 }

create table "informix".pspripun 
  (
    emp_no smallint not null ,
    pp_dat date not null ,
    typ char(1) not null ,
    qty char(1) not null ,
    reason char(20) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".pspripun from "public" as "informix";

{ TABLE "informix".psprodod row size = 12 number of columns = 4 index size = 11 }

create table "informix".psprodod 
  (
    emp_no smallint not null ,
    pre_od_dat date not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".psprodod from "public" as "informix";

{ TABLE "informix".psufbd row size = 42 number of columns = 6 index size = 7 }

create table "informix".psufbd 
  (
    typ char(2) not null ,
    nam char(30) not null ,
    fee_s smallint not null ,
    fee_c smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".psufbd from "public" as "informix";

{ TABLE "informix".psunifom row size = 36 number of columns = 7 index size = 11 }

create table "informix".psunifom 
  (
    emp_no smallint not null ,
    dat date not null ,
    typ char(2) not null ,
    qty smallint not null ,
    coment char(20) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".psunifom from "public" as "informix";

{ TABLE "informix".psscldpt row size = 32 number of columns = 5 index size = 7 }

create table "informix".psscldpt 
  (
    dpt_no smallint not null ,
    nam_a char(4) not null ,
    nam_f char(20) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".psscldpt from "public" as "informix";

{ TABLE "informix".pstitlt row size = 136 number of columns = 12 index size = 13 }

create table "informix".pstitlt 
  (
    emp_no integer not null ,
    td date not null ,
    tsc_typ char(2) 
        default '' not null ,
    new_depart integer not null ,
    new_mas_cod char(8) 
        default '' not null ,
    new_titl char(2) not null ,
    new_fil_1 char(1) 
        default '' not null ,
    rank smallint not null ,
    n_r char(1) not null ,
    coment char(100) not null ,
    rtp integer not null ,
    rtd date not null 
  );

revoke all on "informix".pstitlt from "public" as "informix";

{ TABLE "informix".ocmaoimt row size = 15 number of columns = 4 index size = 14 }

create table "informix".ocmaoimt 
  (
    item_cod char(7) not null ,
    lp_seq smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".ocmaoimt from "public" as "informix";

{ TABLE "informix".psepbd2 row size = 38 number of columns = 12 index size = 7 }

create table "informix".psepbd2 
  (
    emp_no smallint not null ,
    underwrit_dat date not null ,
    tax_cnt smallint not null ,
    scl_no smallint not null ,
    dpt_no smallint not null ,
    introducer char(12) not null ,
    intrd_tel integer not null ,
    od_reason char(1) not null ,
    od_procs char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".psepbd2 from "public" as "informix";

{ TABLE "informix".zzrptbd row size = 138 number of columns = 12 index size = 25 }

create table "informix".zzrptbd 
  (
    typ char(1) not null ,
    lp_seq smallint not null ,
    nam char(50) not null ,
    loc char(20) not null ,
    copies smallint not null ,
    progrm char(12) not null ,
    secret char(1) not null ,
    author smallint not null ,
    maintainer smallint not null ,
    coment char(40) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".zzrptbd from "public" as "informix";

{ TABLE "informix".pscareer row size = 24 number of columns = 8 index size = 11 }

create table "informix".pscareer 
  (
    emp_no smallint not null ,
    organ_no integer not null ,
    depart smallint not null ,
    titl char(2) not null ,
    f_dat date not null ,
    t_dat date not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".pscareer from "public" as "informix";

{ TABLE "informix".tttmp row size = 4 number of columns = 1 index size = 0 }

create table "informix".tttmp 
  (
    chart integer
  );

revoke all on "informix".tttmp from "public" as "informix";

{ TABLE "informix".ofvacat row size = 22 number of columns = 8 index size = 13 }

create table "informix".ofvacat 
  (
    emp_no smallint not null ,
    typ char(2) not null ,
    f_dat date not null ,
    f_hm smallint not null ,
    t_dat date not null ,
    t_hm smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".ofvacat from "public" as "informix";

{ TABLE "informix".psyrexam row size = 154 number of columns = 16 index size = 11 }

create table "informix".psyrexam 
  (
    yymm smallint 
        default 0 not null ,
    emp_no integer,
    exam_1 decimal(4,1) not null ,
    exam_2 decimal(4,1) not null ,
    exam_3 decimal(4,1) not null ,
    ext decimal(4,1) 
        default 0.0,
    cmt char(100) 
        default '',
    thing_dat decimal(4,1) not null ,
    sick_dat decimal(4,1) not null ,
    lat_dat smallint not null ,
    absent_dat decimal(4,1) not null ,
    reward decimal(3,1) not null ,
    punish decimal(3,1) 
        default 0.0 not null ,
    stay decimal(4,1) not null ,
    stay_b decimal(4,1) 
        default 0.0 not null ,
    stay_q decimal(4,1) 
        default 0 not null 
  );

revoke all on "informix".psyrexam from "public" as "informix";

{ TABLE "informix".psyrtot row size = 14 number of columns = 5 index size = 7 }

create table "informix".psyrtot 
  (
    emp_no smallint not null ,
    stay_dat decimal(4,1) not null ,
    auto_tot decimal(4,1) not null ,
    auto_level smallint not null ,
    last_level smallint not null 
  );

revoke all on "informix".psyrtot from "public" as "informix";

{ TABLE "informix".pssalary row size = 16 number of columns = 5 index size = 7 }

create table "informix".pssalary 
  (
    emp_no smallint not null ,
    bas_sal integer not null ,
    year_add integer not null ,
    duty_add decimal(4,2) not null ,
    chief_add decimal(4,2) not null 
  );

revoke all on "informix".pssalary from "public" as "informix";

{ TABLE "informix".icffamt row size = 30 number of columns = 12 index size = 24 }

create table "informix".icffamt 
  (
    acc_no integer not null ,
    each_dat date not null ,
    rf smallint not null ,
    nf smallint not null ,
    df smallint not null ,
    dg smallint not null ,
    rf_self smallint not null ,
    nf_self smallint not null ,
    df_self smallint not null ,
    dg_self smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".icffamt from "public" as "informix";

{ TABLE "informix".erptbd row size = 269 number of columns = 38 index size = 24 }

create table "informix".erptbd 
  (
    chart integer not null ,
    er_dat date not null ,
    er_thm smallint not null ,
    division smallint not null ,
    sick_typ char(1) not null ,
    treat_tm char(20) not null ,
    diag1 char(8) not null ,
    diag2 char(8) not null ,
    diag3 char(8) not null ,
    diag_dr1 char(40) not null ,
    diag_dr2 char(40) not null ,
    com_div1 smallint not null ,
    com_thm1 char(11) 
        default '' not null ,
    arr_thm1 smallint not null ,
    com_div2 smallint not null ,
    com_thm2 char(11) 
        default '' not null ,
    arr_thm2 smallint not null ,
    com_div3 smallint not null ,
    com_thm3 char(11) 
        default '' not null ,
    arr_thm3 smallint not null ,
    hom_typ char(1) not null ,
    hom_tm char(11) 
        default '' not null ,
    treat char(11) 
        default '' not null ,
    roombed char(6) not null ,
    refer_h decimal(10,0) 
        default 0 not null ,
    rsn_h char(2) 
        default '' not null ,
    refer_g decimal(10,0) 
        default 0 not null ,
    rsn_g char(2) 
        default '' not null ,
    stay_see char(1) not null ,
    adm char(1) 
        default '' not null ,
    rtn char(1) 
        default '' not null ,
    rsn char(1) 
        default '' not null ,
    aad_no smallint 
        default 0 not null ,
    cmt char(20) 
        default '' not null ,
    nurse integer not null ,
    doctor integer not null ,
    rtp integer not null ,
    rtd date not null 
  );

revoke all on "informix".erptbd from "public" as "informix";

{ TABLE "informix".ttt1 row size = 7 number of columns = 1 index size = 0 }

create table "informix".ttt1 
  (
    item_no char(7)
  );

revoke all on "informix".ttt1 from "public" as "informix";

{ TABLE "informix".uddisodf row size = 121 number of columns = 29 index size = 27 }

create table "informix".uddisodf 
  (
    acc_no integer not null ,
    seq_no smallint not null ,
    ord_typ char(1) not null ,
    dc_typ char(1) not null ,
    dc_qty decimal(7,2) not null ,
    doctor smallint not null ,
    depart smallint not null ,
    item_cod char(7) not null ,
    qty_tot char(5) not null ,
    qty_prc decimal(7,2) not null ,
    usag char(15) not null ,
    loc smallint not null ,
    self char(1) not null ,
    start_dat date not null ,
    start_time smallint not null ,
    stop_dat date not null ,
    stop_time smallint not null ,
    qty_firstday decimal(7,2) not null ,
    qty_everyday decimal(7,2) not null ,
    last_usupd date not null ,
    last_usqty float not null ,
    high_price char(1) not null ,
    qty_highreq decimal(7,2) not null ,
    qty_nowown decimal(7,2) not null ,
    last_hiupd date not null ,
    last_hiqty float not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    rtl smallint not null 
  );

revoke all on "informix".uddisodf from "public" as "informix";

{ TABLE "informix".uddologf row size = 21 number of columns = 7 index size = 11 }

create table "informix".uddologf 
  (
    acc_no integer not null ,
    seq_no smallint not null ,
    log_typ char(1) not null ,
    new_seq_no smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    rtl smallint not null 
  );

revoke all on "informix".uddologf from "public" as "informix";

{ TABLE "informix".udductrf row size = 89 number of columns = 8 index size = 16 }

create table "informix".udductrf 
  (
    usagcod char(6) not null ,
    div360 char(1) not null ,
    dap char(4) not null ,
    nam char(20) not null ,
    i_time char(24) not null ,
    t_time char(24) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null 
  );

revoke all on "informix".udductrf from "public" as "informix";

{ TABLE "informix".lbbookbr row size = 28 number of columns = 8 index size = 37 }

create table "informix".lbbookbr 
  (
    loc integer not null ,
    borrower smallint not null ,
    acc_no integer not null ,
    bor_dat date not null ,
    pre_dat date not null ,
    ret_dat date not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".lbbookbr from "public" as "informix";

{ TABLE "informix".gllauiff row size = 96 number of columns = 26 index size = 20 }

create table "informix".gllauiff 
  (
    gl_typ char(2) not null ,
    appl_depart smallint not null ,
    seq_no smallint not null ,
    chart integer not null ,
    in_dat date not null ,
    out_dat date not null ,
    depart smallint not null ,
    fee_011 integer not null ,
    fee_012 integer not null ,
    fee_021 integer not null ,
    fee_022 integer not null ,
    fee_031 integer not null ,
    fee_032 integer not null ,
    fee_041 integer not null ,
    fee_042 integer not null ,
    fee_050 integer not null ,
    fee_060 integer not null ,
    fee_070 integer not null ,
    fee_081 integer not null ,
    fee_082 integer not null ,
    fee_090 integer not null ,
    fee_100 integer not null ,
    fee_110 integer not null ,
    fee_120 integer not null ,
    fee_130 integer not null ,
    rtd date
  );

revoke all on "informix".gllauiff from "public" as "informix";

{ TABLE "informix".iofeem row size = 116 number of columns = 32 index size = 11 }

create table "informix".iofeem 
  (
    typ char(1) not null ,
    pt_typ char(1),
    chart integer,
    in_dat date,
    out_dat date,
    doctor smallint,
    depart smallint,
    seq_no smallint,
    fee_01 integer,
    fee_02 integer,
    fee_03 integer,
    fee_04 integer,
    fee_05 integer,
    fee_06 integer,
    fee_07 integer,
    fee_08 integer,
    fee_09 integer,
    fee_10 integer,
    fee_11 integer,
    fee_12 integer,
    fee_13 integer,
    fee_14 integer,
    fee_15 integer,
    fee_16 integer,
    fee_17 integer,
    fee_18 integer,
    fee_19 integer,
    fee_20 integer,
    fee_21 integer,
    fee_22 integer,
    fee_23 integer,
    fee_24 integer
  );

revoke all on "informix".iofeem from "public" as "informix";

{ TABLE "informix".dgdesc1 row size = 127 number of columns = 32 index size = 10 }

create table "informix".dgdesc1 
  (
    drug_cod char(5) not null ,
    tc char(1) not null ,
    nam char(40) not null ,
    content char(25) not null ,
    pcs_self char(1) not null ,
    dis char(1) not null ,
    ud char(1) not null ,
    slot_no smallint not null ,
    gonbau char(1) not null ,
    laubau char(1) not null ,
    sale_typ char(1) not null ,
    price_typ char(1) not null ,
    sale_unit char(4) not null ,
    std_unit char(4) not null ,
    sal_std_r decimal(9,4) not null ,
    dose_unit char(4) not null ,
    use_typ char(2) not null ,
    shaking char(1) not null ,
    prn char(1) not null ,
    eat_typ_1 char(1) not null ,
    eat_typ_2 char(1) not null ,
    ac_pc char(1) not null ,
    m_n char(1) not null ,
    storage char(1) not null ,
    notice char(1) not null ,
    ap_safe_typ char(1) not null ,
    license_no integer not null ,
    orig_cntry char(3) not null ,
    orig_place char(3) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".dgdesc1 from "public" as "informix";

{ TABLE "informix".osdesc row size = 69 number of columns = 17 index size = 25 }

create table "informix".osdesc 
  (
    order_no serial not null ,
    chart integer not null ,
    visit_no decimal(11,0),
    division smallint not null ,
    doctor smallint not null ,
    gl_typ char(2) not null ,
    tmp char(1) not null ,
    lamp_typ char(1) not null ,
    lamp_no smallint not null ,
    ap_visit_no decimal(11,0),
    ret char(1) not null ,
    emg_rtt datetime year to second not null ,
    os_rtt datetime year to second not null ,
    oc_rtt datetime year to second not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    rtl smallint not null 
  );

revoke all on "informix".osdesc from "public" as "informix";

{ TABLE "informix".ossoa row size = 273 number of columns = 6 index size = 11 }

create table "informix".ossoa 
  (
    order_no integer not null ,
    seq_no smallint not null ,
    desc char(255),
    rtp smallint not null ,
    rtt datetime year to second not null ,
    rtl smallint not null 
  );

revoke all on "informix".ossoa from "public" as "informix";

{ TABLE "informix".ossoal row size = 273 number of columns = 6 index size = 9 }

create table "informix".ossoal 
  (
    order_no integer not null ,
    seq_no smallint not null ,
    desc char(255),
    rtp smallint not null ,
    rtt datetime year to second not null ,
    rtl smallint not null 
  );

revoke all on "informix".ossoal from "public" as "informix";

{ TABLE "informix".osditto row size = 116 number of columns = 12 index size = 15 }

create table "informix".osditto 
  (
    md_dr smallint not null ,
    ditto_no char(6) not null ,
    seq_no smallint not null ,
    desc char(60),
    item_cod char(7),
    usag char(20),
    tot_qty char(5),
    emg char(1),
    chg char(1),
    rtp smallint not null ,
    rtt datetime year to second not null ,
    rtl smallint
  );

revoke all on "informix".osditto from "public" as "informix";

{ TABLE "informix".lbbookbd row size = 124 number of columns = 17 index size = 168 }

create table "informix".lbbookbd 
  (
    loc integer not null ,
    acc_no integer not null ,
    class_no char(7) not null ,
    vol_no smallint not null ,
    seq_no smallint not null ,
    title char(60) not null ,
    author char(20) not null ,
    pub_year smallint not null ,
    pub_edit smallint not null ,
    pubshr_no smallint not null ,
    sou_lb char(1) not null ,
    sou_loc smallint not null ,
    in_date date not null ,
    amt integer not null ,
    com_no smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".lbbookbd from "public" as "informix";

{ TABLE "informix".iaasmst row size = 88 number of columns = 16 index size = 33 }

create table "informix".iaasmst 
  (
    assets_no decimal(6,0) not null ,
    assets_ser smallint not null ,
    assets_iname char(20) not null ,
    trans_date date not null ,
    unit char(4) not null ,
    quantity smallint not null ,
    trans_value decimal(12,2) not null ,
    basic_value decimal(10,2) not null ,
    add_value decimal(10,2) not null ,
    useful_life smallint not null ,
    month_dep decimal(10,2) not null ,
    accumu_dep decimal(12,2) not null ,
    supplier_no char(8) not null ,
    user_no integer not null ,
    last_dep_date date not null ,
    dpt_c smallint not null 
  );

revoke all on "informix".iaasmst from "public" as "informix";

{ TABLE "informix".iaassub row size = 22 number of columns = 7 index size = 30 }

create table "informix".iaassub 
  (
    assets_no decimal(6,0) not null ,
    assets_ser smallint not null ,
    change_ser smallint not null ,
    change_type char(1) not null ,
    change_date date not null ,
    change_value decimal(12,2) not null ,
    change_user smallint not null 
  );

revoke all on "informix".iaassub from "public" as "informix";

{ TABLE "informix".iaassup row size = 78 number of columns = 4 index size = 13 }

create table "informix".iaassup 
  (
    supplier_no char(8) not null ,
    suppli_name char(20),
    suppli_tel char(10) not null ,
    suppli_addr char(40)
  );

revoke all on "informix".iaassup from "public" as "informix";

{ TABLE "informix".iaasuse row size = 18 number of columns = 2 index size = 9 }

create table "informix".iaasuse 
  (
    user_no integer not null ,
    user_name char(14) not null 
  );

revoke all on "informix".iaasuse from "public" as "informix";

{ TABLE "informix".lbjvbd row size = 116 number of columns = 12 index size = 91 }

create table "informix".lbjvbd 
  (
    loc smallint not null ,
    com_no integer not null ,
    f_vol_no smallint not null ,
    f_seq_no smallint not null ,
    t_vol_no smallint not null ,
    t_seq_no smallint not null ,
    title char(60) not null ,
    sou_loc smallint not null ,
    in_date date not null ,
    remark char(30) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".lbjvbd from "public" as "informix";

{ TABLE "informix".bmelidat row size = 94 number of columns = 12 index size = 11 }

create table "informix".bmelidat 
  (
    acc_no integer not null ,
    seq_no smallint not null ,
    el_days smallint not null ,
    reason char(18) not null ,
    coment char(40) not null ,
    diag char(18) not null ,
    tc char(1) not null ,
    fil_1 char(1) not null ,
    fair char(1) not null ,
    apply char(1) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".bmelidat from "public" as "informix";

{ TABLE "informix".mtdesc row size = 113 number of columns = 16 index size = 12 }

create table "informix".mtdesc 
  (
    mt_cod char(7) not null ,
    tc char(1) not null ,
    unit_e char(4) not null ,
    unit_c char(4) not null ,
    typ char(1) not null ,
    sub_typ char(1) not null ,
    acc_typ char(2) 
        default '' not null ,
    pcs_self char(1) not null ,
    sal_typ char(1) not null ,
    pric_typ char(1) not null ,
    gonbau char(1) not null ,
    laubau char(1) not null ,
    nam char(80) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".mtdesc from "public" as "informix";

{ TABLE "informix".sysmenuitems row size = 143 number of columns = 5 index size = 27 }

create table "informix".sysmenuitems 
  (
    imenuname char(18),
    itemnum integer,
    mtext char(60),
    mtype char(1),
    progname char(60)
  );

revoke all on "informix".sysmenuitems from "public" as "informix";

{ TABLE "informix".cgsiupf row size = 111 number of columns = 47 index size = 25 }

create table "informix".cgsiupf 
  (
    item_cod char(7) not null ,
    tc char(1) not null ,
    eff_dat date not null ,
    loc smallint not null ,
    gonbau char(1) not null ,
    ng_reason char(1) not null ,
    gh char(1) not null ,
    laubau char(1) not null ,
    nl_reason char(1) not null ,
    p_typ char(1) not null ,
    o_lmt_gon smallint not null ,
    i_lmt_gon smallint not null ,
    o_lmt_lau smallint not null ,
    i_lmt_lau smallint not null ,
    high_price char(1) not null ,
    group_item char(1) not null ,
    cod_gen smallint not null ,
    cod_gon smallint not null ,
    cod_lau smallint not null ,
    e_rat_gen decimal(3,2) not null ,
    e_rat_gon decimal(3,2) not null ,
    e_rat_lau decimal(3,2) not null ,
    discnt_gen char(1) not null ,
    discnt_gon char(1) not null ,
    discnt_lau char(1) not null ,
    spe_cas char(1) not null ,
    mult_gon char(1) not null ,
    mult_lau char(1) not null ,
    up_gen decimal(9,2) not null ,
    up_gon decimal(9,2) not null ,
    up_lau decimal(9,2) not null ,
    ud_lmt smallint not null ,
    ud_round char(1) not null ,
    ud_nodis char(1) not null ,
    os_mapno smallint not null ,
    chg char(1) not null ,
    ppf_fg char(1) not null ,
    dos_sal_r1 smallint not null ,
    dos_sal_r2 smallint not null ,
    dos_qty char(5) not null ,
    usag char(13) not null ,
    use_typ char(2) not null ,
    ac_pc char(1) not null ,
    opiate char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".cgsiupf from "public" as "informix";

{ TABLE "informix".cgsiupp row size = 155 number of columns = 46 index size = 12 }

create table "informix".cgsiupp 
  (
    item_cod char(7) not null ,
    tc char(1) not null ,
    eff_dat date not null ,
    comment char(1) not null ,
    nam char(45) not null ,
    sal_unit char(4) not null ,
    dos_unit char(4) not null ,
    loc smallint not null ,
    test_drug char(1) not null ,
    gonbau char(1) not null ,
    ng_reason char(1) not null ,
    gh char(1) not null ,
    laubau char(1) not null ,
    nl_reason char(1) not null ,
    o_lmt_gon smallint not null ,
    i_lmt_gon smallint not null ,
    o_lmt_lau smallint not null ,
    i_lmt_lau smallint not null ,
    high_price char(1) not null ,
    group_item char(1) not null ,
    cod_gen smallint not null ,
    cod_gon smallint not null ,
    cod_lau smallint not null ,
    e_rat_gen decimal(3,2) not null ,
    e_rat_gon decimal(3,2) not null ,
    e_rat_lau decimal(3,2) not null ,
    discnt_gen char(1) not null ,
    discnt_gon char(1) not null ,
    discnt_lau char(1) not null ,
    spe_cas char(1) not null ,
    up_gen decimal(9,2) not null ,
    up_gon decimal(9,2) not null ,
    up_lau decimal(9,2) not null ,
    ud_lmt smallint not null ,
    ud_round char(1) not null ,
    ud_nodis char(1) not null ,
    os_mapno smallint not null ,
    chg char(1) not null ,
    ppf_fg char(1) not null ,
    dos_sal_r1 smallint not null ,
    dos_sal_r2 smallint not null ,
    dos_qty char(5) not null ,
    usag char(13) not null ,
    use_typ char(2) not null ,
    ac_pc char(1) not null ,
    opiate char(1) not null 
  );

revoke all on "informix".cgsiupp from "public" as "informix";

{ TABLE "informix".icddata row size = 107 number of columns = 30 index size = 30 }

create table "informix".icddata 
  (
    chart integer not null ,
    division smallint not null ,
    admit_dat date not null ,
    admit_hm smallint not null ,
    discha_dat date not null ,
    discha_hm smallint not null ,
    admit_window char(1) not null ,
    pt_typ char(2) not null ,
    discha_sts char(2) not null ,
    a_dr1 smallint not null ,
    a_dr2 smallint not null ,
    operator_1 smallint not null ,
    operator_2 smallint not null ,
    e_code char(6) not null ,
    m_code_1 char(6) not null ,
    m_code_2 char(6) not null ,
    v_code char(6) not null ,
    diag1 char(6) not null ,
    diag2 char(6) not null ,
    diag3 char(6) not null ,
    diag4 char(6) not null ,
    pathology char(1) not null ,
    operate_1 char(6) not null ,
    operate_2 char(6) not null ,
    operate_3 char(6) not null ,
    anesthesia char(1) not null ,
    born_typ char(1) not null ,
    baby_cond char(1) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".icddata from "public" as "informix";

{ TABLE "informix".iclaudat row size = 57 number of columns = 21 index size = 15 }

create table "informix".iclaudat 
  (
    chart integer not null ,
    in_dat date not null ,
    in_hm smallint not null ,
    in_dat_lau date not null ,
    admit_1_no char(2) not null ,
    admit_2_no integer not null ,
    appl_room_no char(4) 
        default '' not null ,
    appl_bed_no char(2) not null ,
    pre_dis_dat date not null ,
    fst_appl_dat integer not null ,
    sick_typ char(1) not null ,
    days_1 smallint not null ,
    days_2 smallint not null ,
    days_3 smallint not null ,
    days_4 smallint not null ,
    days_5 smallint not null ,
    days_6 smallint not null ,
    days_7 smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".iclaudat from "public" as "informix";

{ TABLE "informix".mrptccs row size = 28 number of columns = 9 index size = 19 }

create table "informix".mrptccs 
  (
    chart integer not null ,
    diag char(6) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    reason char(1) not null ,
    tc char(1) not null ,
    division smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".mrptccs from "public" as "informix";

{ TABLE "informix".dccontcb row size = 20 number of columns = 5 index size = 17 }

create table "informix".dccontcb 
  (
    dc_cod_m char(6) not null ,
    dc_cod_a char(6) not null ,
    cond_cod smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".dccontcb from "public" as "informix";

{ TABLE "informix".zzcodnam row size = 114 number of columns = 5 index size = 7 }

create table "informix".zzcodnam 
  (
    cod smallint not null ,
    nam_f char(100) not null ,
    nam_a char(6) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".zzcodnam from "public" as "informix";

{ TABLE "informix".mrpobd row size = 104 number of columns = 12 index size = 56 }

create table "informix".mrpobd 
  (
    organ_no decimal(10,0) not null ,
    organ_nam char(40) not null ,
    region_no smallint not null ,
    adrs char(30) not null ,
    head char(8) not null ,
    title char(1) not null ,
    typ char(1) not null ,
    tel_no integer not null ,
    fax_no integer not null ,
    copies smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".mrpobd from "public" as "informix";

{ TABLE "informix".rfdbd row size = 36 number of columns = 11 index size = 13 }

create table "informix".rfdbd 
  (
    hospital_no decimal(10,0) not null ,
    doctor_no smallint not null ,
    doctor_nam char(8) not null ,
    birthday date not null ,
    duty char(1) not null ,
    copies char(1) not null ,
    depart char(4) not null ,
    depart_m smallint not null ,
    depart_d smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".rfdbd from "public" as "informix";

{ TABLE "informix".rgdata row size = 159 number of columns = 38 index size = 30 }

create table "informix".rgdata 
  (
    chart integer not null ,
    visit_no decimal(11,0),
    seq_no smallint not null ,
    doctor smallint not null ,
    division_md smallint not null ,
    division_gl smallint not null ,
    gl_typ char(2) not null ,
    pt_typ char(2) not null ,
    charg_typ char(1) not null ,
    refer_h decimal(10,0) not null ,
    h_rank char(1) not null ,
    t_l char(1) not null ,
    a_c char(1) not null ,
    spe char(1) not null ,
    f_r char(1) not null ,
    mark char(1) not null ,
    comment char(4) not null ,
    visit_seq char(1) not null ,
    rg_deduct smallint not null ,
    haved_amt smallint not null ,
    chart_place char(1) not null ,
    print_dat date not null ,
    sp_typ char(1) not null ,
    drug_days smallint not null ,
    chronic char(1) not null ,
    gl_icd char(80) not null ,
    sick_typ char(1) not null ,
    permit char(1) not null ,
    rg_fee smallint not null ,
    dr_fee smallint not null ,
    dsp_fee smallint not null ,
    charg_no integer not null ,
    fil_1 char(1) not null ,
    fil_2 char(2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null ,
    rtl smallint not null 
  );

revoke all on "informix".rgdata from "public" as "informix";

{ TABLE "informix".bmdrbac row size = 16 number of columns = 7 index size = 7 }

create table "informix".bmdrbac 
  (
    division smallint not null ,
    doctor smallint not null ,
    own_cnt smallint not null ,
    bor_cnt smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rtl smallint not null 
  );

revoke all on "informix".bmdrbac from "public" as "informix";

{ TABLE "informix".mrcco row size = 41 number of columns = 9 index size = 30 }

create table "informix".mrcco 
  (
    chronic_no char(10) not null ,
    chart integer not null ,
    visit_no decimal(11,0),
    doctor smallint not null ,
    cnt smallint not null ,
    drug_days smallint not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtt datetime year to second not null 
  );

revoke all on "informix".mrcco from "public" as "informix";

{ TABLE "informix".mrglcdcn row size = 80 number of columns = 14 index size = 9 }

create table "informix".mrglcdcn 
  (
    gl_cod char(4) not null ,
    g_l char(1) not null ,
    chronic char(1) not null ,
    crn_typ smallint not null ,
    serious char(1) not null ,
    cont_cure char(1) not null ,
    cont_cond smallint not null ,
    nam_c char(50) not null ,
    typ smallint not null ,
    std_days smallint not null ,
    g_amt integer not null ,
    l_amt integer not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".mrglcdcn from "public" as "informix";

{ TABLE "informix".mricdcn row size = 192 number of columns = 19 index size = 26 }

create table "informix".mricdcn 
  (
    icd_cod char(6) not null ,
    gl_cod char(4) not null ,
    nam_c char(150) not null ,
    chronic char(1) not null ,
    crn_typ smallint not null ,
    serious char(1) not null ,
    cont_cure char(1) not null ,
    cont_cond smallint not null ,
    sex_limit char(1) not null ,
    diag_limit char(1) not null ,
    fil_1 char(1) not null ,
    age_f smallint not null ,
    age_t smallint not null ,
    std_days smallint not null ,
    g_amt integer not null ,
    l_amt integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".mricdcn from "public" as "informix";

{ TABLE "informix".cgndmdsc row size = 82 number of columns = 14 index size = 12 }

create table "informix".cgndmdsc 
  (
    item_cod char(7) not null ,
    tc char(1) not null ,
    unit char(4) not null ,
    nam char(50) not null ,
    gonbau char(1) not null ,
    laubau char(1) not null ,
    ps_gon char(1) not null ,
    ps_lau char(1) not null ,
    fct_typ char(2) not null ,
    dev_typ char(4) not null ,
    fil_2 smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".cgndmdsc from "public" as "informix";

{ TABLE "informix".rgrtl row size = 21 number of columns = 10 index size = 13 }

create table "informix".rgrtl 
  (
    tp smallint not null ,
    thm smallint not null ,
    t1 smallint not null ,
    tc1 char(1) not null ,
    tc2 char(1) not null ,
    visit_dat date not null ,
    shift char(1) not null ,
    doctor smallint not null ,
    seq_no smallint not null ,
    chart integer not null 
  );

revoke all on "informix".rgrtl from "public" as "informix";

{ TABLE "informix".cgrmod row size = 108 number of columns = 15 index size = 7 }

create table "informix".cgrmod 
  (
    rmo_no smallint not null ,
    nam_a char(8) not null ,
    nam_f char(50) 
        default '' not null ,
    ogt_cod char(10) 
        default '' not null ,
    dat_f date 
        default  '1899/12/31' not null ,
    dat_t date 
        default  '2025/12/31' not null ,
    pa_i_rat decimal(3,2) not null ,
    xr_i_rat decimal(3,2) not null ,
    lb_i_rat decimal(3,2) not null ,
    pa_o_rat decimal(3,2) not null ,
    xr_o_rat decimal(3,2) not null ,
    lb_o_rat decimal(3,2) not null ,
    rtp integer not null ,
    sup_no integer 
        default 0 not null ,
    rtd date not null 
  );

revoke all on "informix".cgrmod from "public" as "informix";

{ TABLE "informix".udmcwkds row size = 15 number of columns = 6 index size = 12 }

create table "informix".udmcwkds 
  (
    ward char(3) 
        default '' not null ,
    dat date not null ,
    mod char(1) not null ,
    mac_no char(1) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".udmcwkds from "public" as "informix";

{ TABLE "informix".glrccd row size = 50 number of columns = 9 index size = 19 }

create table "informix".glrccd 
  (
    id_no char(10) not null ,
    nam char(12) not null ,
    birthday date not null ,
    sample_dat date 
        default  '1899/12/31' not null ,
    refer_dat date not null ,
    hospital_no decimal(10,0) not null ,
    nh_seq char(2) not null ,
    rtp integer not null ,
    rtd date not null 
  );

revoke all on "informix".glrccd from "public" as "informix";

{ TABLE "informix".rfhbd row size = 232 number of columns = 23 index size = 24 }

create table "informix".rfhbd 
  (
    hospital_no decimal(10,0) not null ,
    nam_f char(50) 
        default '' not null ,
    nam_a char(8) not null ,
    zip smallint not null ,
    adrs char(30) not null ,
    tel_no integer not null ,
    fax_no integer not null ,
    eml_adr char(50) 
        default '' not null ,
    head char(8) not null ,
    head_tel integer 
        default 0 not null ,
    birthday date not null ,
    title char(1) not null ,
    rank char(1) not null ,
    relat char(1) not null ,
    remot char(1) not null ,
    copies smallint not null ,
    typ_1 char(1) not null ,
    typ_2 char(1) not null ,
    eff_dat date 
        default  '1899/12/31' not null ,
    stp_dat date 
        default  '1899/12/31' not null ,
    depart char(40) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".rfhbd from "public" as "informix";

{ TABLE "informix".mmivtcst row size = 62 number of columns = 17 index size = 35 }

create table "informix".mmivtcst 
  (
    yy smallint not null ,
    giv_loc smallint not null ,
    req_loc smallint not null ,
    item_cod char(7) not null ,
    tc char(1) not null ,
    qty01 integer not null ,
    qty02 integer not null ,
    qty03 integer not null ,
    qty04 integer not null ,
    qty05 integer not null ,
    qty06 integer not null ,
    qty07 integer not null ,
    qty08 integer not null ,
    qty09 integer not null ,
    qty10 integer not null ,
    qty11 integer not null ,
    qty12 integer not null 
  );

revoke all on "informix".mmivtcst from "public" as "informix";

{ TABLE "informix".pspoffd row size = 12 number of columns = 4 index size = 16 }

create table "informix".pspoffd 
  (
    emp_no smallint not null ,
    pre_dat date not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".pspoffd from "public" as "informix";

{ TABLE "informix".oscnam row size = 51 number of columns = 6 index size = 16 }

create table "informix".oscnam 
  (
    map_no smallint not null ,
    typ char(1) not null ,
    cod char(8) not null ,
    desc char(30) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null 
  );

revoke all on "informix".oscnam from "public" as "informix";

{ TABLE "informix".orroombd row size = 13 number of columns = 6 index size = 7 }

create table "informix".orroombd 
  (
    room char(2) not null ,
    rom_no smallint not null ,
    dev char(2) not null ,
    pri char(1) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".orroombd from "public" as "informix";

{ TABLE "informix".oropday row size = 15 number of columns = 7 index size = 24 }

create table "informix".oropday 
  (
    room char(2) not null ,
    week smallint not null ,
    shift char(1) not null ,
    pri smallint not null ,
    dr smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".oropday from "public" as "informix";

{ TABLE "informix".orasrmcd row size = 15 number of columns = 4 index size = 14 }

create table "informix".orasrmcd 
  (
    room char(2) not null ,
    chg_cod char(7) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".orasrmcd from "public" as "informix";

{ TABLE "informix".moitem row size = 28 number of columns = 8 index size = 18 }

create table "informix".moitem 
  (
    ord_no integer not null ,
    chg_cod char(7) not null ,
    dup_no smallint 
        default 0 not null ,
    pos1 char(3) 
        default '' not null ,
    pos2 char(3) 
        default '' not null ,
    pos3 char(3) 
        default '' not null ,
    tot_qty char(5) 
        default '' not null ,
    self char(1) 
        default '' not null ,
    primary key (ord_no,dup_no,chg_cod) 
  );

revoke all on "informix".moitem from "public" as "informix";

{ TABLE "informix".orexec row size = 71 number of columns = 34 index size = 42 }

create table "informix".orexec 
  (
    ord_no integer not null ,
    tc1 char(1) 
        default '0' not null ,
    tc2 char(1) 
        default '' not null ,
    opr_dr smallint not null ,
    opr_dr1 smallint 
        default 0 not null ,
    opr_dr2 smallint 
        default 0 not null ,
    opr_dr3 smallint 
        default 0 not null ,
    opr_dat date not null ,
    opr_shift char(1) not null ,
    api_room char(2) 
        default '' not null ,
    api_hm smallint 
        default 0 not null ,
    pre_dt smallint 
        default 0 not null ,
    bor_xr char(1) 
        default 'N' not null ,
    ane_typ char(1) not null ,
    pri_typ smallint not null ,
    opr_room char(2) not null ,
    opr_seq smallint 
        default 99 not null ,
    sta_nurse smallint 
        default 0 not null ,
    ane_nurse smallint 
        default 0 not null ,
    han_nurse smallint 
        default 0 not null ,
    permit_psn smallint 
        default 0 not null ,
    opr_cut char(1) 
        default '' not null ,
    asa_typ char(1) 
        default '' not null ,
    atn_hm smallint 
        default 0 not null ,
    atd_hm smallint 
        default 0 not null ,
    mnd_hm smallint 
        default 0 not null ,
    tmo_hm smallint 
        default 0 not null ,
    rip_hm smallint 
        default 0 not null ,
    sew_hm smallint 
        default 0 not null ,
    wait_hm smallint 
        default 0 not null ,
    stt_hm smallint 
        default 0 not null ,
    stp_hm smallint 
        default 0 not null ,
    quit_hm smallint 
        default 0 not null ,
    rtt datetime year to second 
        default current year to second not null 
  );

revoke all on "informix".orexec from "public" as "informix";

{ TABLE "informix".uclogin row size = 30 number of columns = 7 index size = 11 }

create table "informix".uclogin 
  (
    loc_id char(6) not null ,
    emp_no smallint not null ,
    group_func_no char(4) not null ,
    use_level char(2) not null ,
    func_no char(4) not null ,
    version char(4) not null ,
    rtt datetime year to second not null 
  );

revoke all on "informix".uclogin from "public" as "informix";

{ TABLE "informix".cgctrl row size = 107 number of columns = 9 index size = 14 }

create table "informix".cgctrl 
  (
    chg_cod char(7) not null ,
    seq_no smallint not null ,
    desc char(74) not null ,
    typ char(1) not null ,
    chk_cod char(7),
    f_val char(6),
    t_val char(6),
    eff_days smallint,
    tot_qty smallint
  );

revoke all on "informix".cgctrl from "public" as "informix";

{ TABLE "informix".moexeloc row size = 28 number of columns = 5 index size = 7 }

create table "informix".moexeloc 
  (
    map_no smallint not null ,
    loc smallint not null ,
    nam char(10) not null ,
    prn_loc char(6) not null ,
    rtt datetime year to second not null 
  );

revoke all on "informix".moexeloc from "public" as "informix";

{ TABLE "informix".systableext row size = 384 number of columns = 5 index size = 69 }

create table "informix".systableext 
  (
    owner char(32),
    tabname char(32),
    extowner char(32),
    tabalias char(32),
    remarks char(256)
  );

revoke all on "informix".systableext from "public" as "informix";

{ TABLE "informix".syscolumnext row size = 516 number of columns = 10 index size = 101 }

create table "informix".syscolumnext 
  (
    owner char(32),
    tabname char(32),
    colname char(32),
    extowner char(32),
    colalias char(32),
    collabel char(32),
    coltitle char(32),
    remarks char(256),
    subtype char(4),
    class char(32)
  );

revoke all on "informix".syscolumnext from "public" as "informix";

{ TABLE "informix".syscolformats row size = 875 number of columns = 16 index size = 204 }

create table "informix".syscolformats 
  (
    owner char(32),
    tabname char(32),
    colname char(32),
    extowner char(32),
    priority smallint,
    typeface char(64),
    fontsize smallint,
    fontstyle smallint,
    fontcolor integer,
    aidfa char(30),
    formatmask char(256),
    format4gl char(128),
    align char(1),
    case char(1),
    ruletype char(1),
    checktext char(256)
  );

revoke all on "informix".syscolformats from "public" as "informix";

{ TABLE "informix".syscolinput row size = 266 number of columns = 6 index size = 212 }

create table "informix".syscolinput 
  (
    owner char(32),
    tabname char(32),
    colname char(32),
    extowner char(32),
    attrname char(10),
    attrval char(128)
  );

revoke all on "informix".syscolinput from "public" as "informix";

{ TABLE "informix".syscolinclude row size = 259 number of columns = 8 index size = 204 }

create table "informix".syscolinclude 
  (
    owner char(32),
    tabname char(32),
    colname char(32),
    extowner char(32),
    priority smallint,
    extvalue char(64),
    intvalue char(64),
    range char(1)
  );

revoke all on "informix".syscolinclude from "public" as "informix";

{ TABLE "informix".syssuperviews row size = 140 number of columns = 4 index size = 46 }

create table "informix".syssuperviews 
  (
    svwid serial not null ,
    owner char(32),
    svwname char(32),
    remarks char(72)
  );

revoke all on "informix".syssuperviews from "public" as "informix";

{ TABLE "informix".syssvwtables row size = 242 number of columns = 10 index size = 54 }

create table "informix".syssvwtables 
  (
    svwid integer,
    tableseq integer,
    owner char(32),
    tabname char(32),
    masteralias char(32),
    cardinality char(1),
    usetype char(1),
    tabalias char(32),
    levelname char(32),
    remarks char(72)
  );

revoke all on "informix".syssvwtables from "public" as "informix";

{ TABLE "informix".syssvwjoins row size = 136 number of columns = 7 index size = 43 }

create table "informix".syssvwjoins 
  (
    svwid integer,
    tabalias char(32),
    jcolseq smallint,
    mastercol char(32),
    detailcol1 char(32),
    detailcol2 char(32),
    joinoperator char(2)
  );

revoke all on "informix".syssvwjoins from "public" as "informix";

{ TABLE "informix".syssvwaliases row size = 170 number of columns = 8 index size = 127 }

create table "informix".syssvwaliases 
  (
    svwid integer,
    tabalias char(32),
    colseq integer,
    colname char(32),
    colalias char(32),
    label char(32),
    title char(32),
    flag smallint
  );

revoke all on "informix".syssvwaliases from "public" as "informix";

{ TABLE "informix".syssvworder row size = 39 number of columns = 4 index size = 11 }

create table "informix".syssvworder 
  (
    svwid integer,
    seqno smallint,
    colalias char(32),
    sorttype char(1)
  );

revoke all on "informix".syssvworder from "public" as "informix";

{ TABLE "informix".syssvwauth row size = 66 number of columns = 8 index size = 41 }

create table "informix".syssvwauth 
  (
    svwid integer,
    username char(32),
    svwauth char(8),
    rowlimit integer,
    readlimit integer,
    readsperrowlimit float,
    elapsedtimelimit integer,
    isolationmode smallint
  );

revoke all on "informix".syssvwauth from "public" as "informix";

{ TABLE "informix".syssvwformats row size = 783 number of columns = 14 index size = 84 }

create table "informix".syssvwformats 
  (
    svwid integer,
    colalias char(32),
    priority smallint,
    typeface char(64),
    fontsize smallint,
    fontstyle smallint,
    fontcolor integer,
    aidfa char(30),
    formatmask char(256),
    format4gl char(128),
    align char(1),
    case char(1),
    ruletype char(1),
    checktext char(256)
  );

revoke all on "informix".syssvwformats from "public" as "informix";

{ TABLE "informix".syssvwinput row size = 174 number of columns = 4 index size = 92 }

create table "informix".syssvwinput 
  (
    svwid integer,
    colalias char(32),
    attrname char(10),
    attrval char(128)
  );

revoke all on "informix".syssvwinput from "public" as "informix";

{ TABLE "informix".syssvwinclude row size = 167 number of columns = 6 index size = 84 }

create table "informix".syssvwinclude 
  (
    svwid integer,
    colalias char(32),
    priority smallint,
    extvalue char(64),
    intvalue char(64),
    range char(1)
  );

revoke all on "informix".syssvwinclude from "public" as "informix";

{ TABLE "informix".icdtfee row size = 18 number of columns = 6 index size = 24 }

create table "informix".icdtfee 
  (
    acc_no integer not null ,
    each_dat date not null ,
    amt_gl smallint not null ,
    amt_self smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".icdtfee from "public" as "informix";

{ TABLE "informix".sysulist row size = 128 number of columns = 3 index size = 37 }

create table "informix".sysulist 
  (
    username char(32),
    svagrantor char(32),
    remarks char(64)
  );

revoke all on "informix".sysulist from "public" as "informix";

{ TABLE "informix".rhexedsc row size = 38 number of columns = 10 index size = 40 }

create table "informix".rhexedsc 
  (
    job_no serial not null ,
    chart integer not null ,
    visit_no decimal(11,0),
    trp_dat date not null ,
    api_hm smallint not null ,
    cki_hm smallint not null ,
    charg_no integer not null ,
    addr char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null 
  );

revoke all on "informix".rhexedsc from "public" as "informix";

{ TABLE "informix".xrbordat row size = 33 number of columns = 13 index size = 37 }

create table "informix".xrbordat 
  (
    apl_no serial not null ,
    frm_sys char(2) not null ,
    chart integer not null ,
    bor_rsn char(1) not null ,
    bor_apl smallint not null ,
    bor_man smallint not null ,
    bor_psn smallint not null ,
    bor_dat date not null ,
    bor_hm smallint not null ,
    ret_man smallint not null ,
    ret_psn smallint not null ,
    ret_dat date not null ,
    ret_hm smallint not null 
  );

revoke all on "informix".xrbordat from "public" as "informix";

{ TABLE "informix".xrfilmst row size = 18 number of columns = 6 index size = 9 }

create table "informix".xrfilmst 
  (
    chart integer not null ,
    pos char(4) not null ,
    loc smallint not null ,
    cnt smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".xrfilmst from "public" as "informix";

{ TABLE "informix".nhhicicn row size = 74 number of columns = 7 index size = 18 }

create table "informix".nhhicicn 
  (
    nh_cod char(12) not null ,
    c_e char(1) not null ,
    fil_1 char(1) not null ,
    nam char(50) not null ,
    unit char(4) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".nhhicicn from "public" as "informix";

{ TABLE "informix".rhexeitm row size = 53 number of columns = 21 index size = 26 }

create table "informix".rhexeitm 
  (
    job_no integer not null ,
    chg_cod char(7) not null ,
    pos char(3) not null ,
    trp_man smallint not null ,
    result char(1) not null ,
    trp_itm1 char(3) not null ,
    trp_hm_f1 smallint not null ,
    trp_hm_t1 smallint not null ,
    das_no1 smallint not null ,
    trp_itm2 char(3) not null ,
    trp_hm_f2 smallint not null ,
    trp_hm_t2 smallint not null ,
    das_no2 smallint not null ,
    trp_itm3 char(3) not null ,
    trp_hm_f3 smallint not null ,
    trp_hm_t3 smallint not null ,
    das_no3 smallint not null ,
    trp_itm4 char(3) not null ,
    trp_hm_f4 smallint not null ,
    trp_hm_t4 smallint not null ,
    das_no4 smallint not null 
  );

revoke all on "informix".rhexeitm from "public" as "informix";

{ TABLE "informix".mcconrec row size = 1043 number of columns = 9 index size = 16 }

create table "informix".mcconrec 
  (
    chart integer not null ,
    visit_no decimal(11,0),
    dsc1 varchar(255) 
        default '' not null ,
    dsc2 varchar(255) 
        default '' not null ,
    dsc3 varchar(255) 
        default '' not null ,
    dsc4 varchar(255) 
        default '' not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    rtl smallint not null ,
    primary key (chart,visit_no) 
  );

revoke all on "informix".mcconrec from "public" as "informix";

{ TABLE "informix".stcgst row size = 24 number of columns = 5 index size = 19 }

create table "informix".stcgst 
  (
    charg_cod char(7) not null ,
    stock_cod char(7) not null ,
    ratio_c_s decimal(5,1) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".stcgst from "public" as "informix";

{ TABLE "informix".xritem row size = 30 number of columns = 9 index size = 25 }

create table "informix".xritem 
  (
    ord_no integer not null ,
    chg_cod char(7) not null ,
    dup_no smallint not null ,
    stock_cod char(7) not null ,
    def_qty smallint not null ,
    dis_qty_m smallint not null ,
    dis_qty_h smallint not null ,
    dis_qty_p smallint not null ,
    dis_qty_z smallint not null 
  );

revoke all on "informix".xritem from "public" as "informix";

{ TABLE "informix".astbd row size = 154 number of columns = 31 index size = 22 }

create table "informix".astbd 
  (
    ast_no integer not null ,
    tc1 char(1),
    tc2 char(1),
    td date,
    nam_f varchar(30),
    nam_a char(6),
    cnt_unit char(4),
    brand char(10),
    mdl_siz char(16),
    s_no integer,
    manu_no smallint,
    sup_no smallint,
    price1 integer,
    price2 integer,
    vlu integer,
    in_dat date,
    lbl_loc smallint,
    use_dpt smallint,
    ast_ppy char(1),
    hdl_man smallint,
    loc_no char(6),
    pos char(4),
    nhd_typ char(6),
    bas_typ char(9),
    loc_typ smallint,
    typ_1 char(1),
    typ_2 char(1),
    mtn char(1),
    ast_old char(10),
    rtp smallint,
    rtd date
  );

revoke all on "informix".astbd from "public" as "informix";

{ TABLE "informix".asacsitm row size = 90 number of columns = 15 index size = 22 }

create table "informix".asacsitm 
  (
    ast_no integer,
    acs_seq smallint,
    acs_nam varchar(30),
    cnt_unit char(4),
    mdl_siz char(16),
    price1 integer,
    price2 integer,
    vlu integer,
    acs_typ char(1),
    qty smallint,
    hdl_man smallint,
    loc_no char(6),
    pos char(4),
    rtp smallint,
    rtd date
  );

revoke all on "informix".asacsitm from "public" as "informix";

{ TABLE "informix".asscdnam row size = 47 number of columns = 3 index size = 11 }

create table "informix".asscdnam 
  (
    ast_no integer not null ,
    seq_no smallint,
    nam varchar(40)
  );

revoke all on "informix".asscdnam from "public" as "informix";

{ TABLE "informix".mooprcon row size = 96 number of columns = 7 index size = 26 }

create table "informix".mooprcon 
  (
    division smallint not null ,
    seq_no smallint not null ,
    opr_cnam char(40) not null ,
    opr_enam char(40) not null ,
    icd_cod char(6) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".mooprcon from "public" as "informix";

{ TABLE "informix".mdvoc row size = 2123 number of columns = 15 index size = 13 }

create table "informix".mdvoc 
  (
    own_no smallint not null ,
    map_no smallint not null ,
    voc_typ char(2) not null ,
    seq_no smallint not null ,
    coment varchar(60),
    txt1 varchar(255),
    txt2 varchar(255),
    txt3 varchar(255),
    txt4 varchar(255),
    txt5 varchar(255),
    txt6 varchar(255),
    txt7 varchar(255),
    txt8 varchar(255),
    rtp smallint,
    rtd date
  );

revoke all on "informix".mdvoc from "public" as "informix";

{ TABLE "informix".rgovrl row size = 69 number of columns = 6 index size = 7 }

create table "informix".rgovrl 
  (
    room smallint not null ,
    loc char(30) not null ,
    loc_a char(30) 
        default '' not null ,
    prn char(1) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".rgovrl from "public" as "informix";

{ TABLE "informix".modoc row size = 62 number of columns = 3 index size = 11 }

create table "informix".modoc 
  (
    ord_no integer not null ,
    frm_sys char(2) not null ,
    dsc text not null 
  );

revoke all on "informix".modoc from "public" as "informix";

{ TABLE "informix".mdvoc1 row size = 131 number of columns = 8 index size = 13 }

create table "informix".mdvoc1 
  (
    own_no smallint not null ,
    map_no smallint not null ,
    voc_typ char(2) not null ,
    seq_no smallint not null ,
    coment varchar(60),
    txt text,
    rtp smallint,
    rtd date
  );

revoke all on "informix".mdvoc1 from "public" as "informix";

{ TABLE "informix".ucterml row size = 66 number of columns = 12 index size = 24 }

create table "informix".ucterml 
  (
    loc_id smallint not null ,
    loc_nam char(16) not null ,
    device_id char(12) not null ,
    print_id char(12) not null ,
    term_typ char(1) not null ,
    fil_1 char(1) not null ,
    func_no char(4) not null ,
    prog_nam char(8) not null ,
    cnt smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".ucterml from "public" as "informix";

{ TABLE "informix".ucolfuncold row size = 73 number of columns = 11 index size = 9 }

create table "informix".ucolfuncold 
  (
    func_no char(4) not null ,
    prog_nam char(10) not null ,
    prog_desc char(28) not null ,
    main_prog_nam char(10) not null ,
    ver_no char(6) not null ,
    ver_dat date not null ,
    prog_typ char(1) not null ,
    mtn_man smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".ucolfuncold from "public" as "informix";

{ TABLE "informix".paucdata row size = 41 number of columns = 9 index size = 29 }

create table "informix".paucdata 
  (
    pa_typ char(1) 
        default '' not null ,
    pa_no integer not null ,
    id_no char(10) not null ,
    nam char(10) not null ,
    birthday date not null ,
    rep_dat date not null ,
    rep_cod char(2) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".paucdata from "public" as "informix";

{ TABLE "informix".sttrms row size = 9 number of columns = 2 index size = 14 }

create table "informix".sttrms 
  (
    loc smallint not null ,
    stk_cod char(7) not null 
  );

revoke all on "informix".sttrms from "public" as "informix";

{ TABLE "informix".ositem row size = 72 number of columns = 20 index size = 37 }

create table "informix".ositem 
  (
    order_no integer not null ,
    seq_no smallint not null ,
    tc char(1) not null ,
    dc char(1) not null ,
    item_cod char(7) not null ,
    item_mark char(1) not null ,
    loc smallint not null ,
    usag char(20) not null ,
    tot_qty char(5) not null ,
    self_qty char(5) not null ,
    emg char(1) not null ,
    self char(1) not null ,
    chg char(1) not null ,
    prn_map char(1) not null ,
    ppf_no smallint not null ,
    prm_no integer not null ,
    map_no smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    rtl smallint not null 
  );

revoke all on "informix".ositem from "public" as "informix";

{ TABLE "informix".nsipcl row size = 19 number of columns = 7 index size = 16 }

create table "informix".nsipcl 
  (
    chart integer not null ,
    typ char(1) not null ,
    ass_dat date not null ,
    ass_hm smallint not null ,
    grd smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".nsipcl from "public" as "informix";

{ TABLE "informix".nsphw row size = 24 number of columns = 7 index size = 15 }

create table "informix".nsphw 
  (
    chart integer not null ,
    msr_dat date not null ,
    msr_hm smallint not null ,
    hgh decimal(4,1) not null ,
    wgh decimal(4,1) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".nsphw from "public" as "informix";

{ TABLE "informix".nspnvs row size = 30 number of columns = 12 index size = 15 }

create table "informix".nspnvs 
  (
    chart integer not null ,
    msr_dat date not null ,
    msr_hm smallint not null ,
    tpr decimal(3,1) not null ,
    mab smallint not null ,
    hrt smallint not null ,
    rpr smallint not null ,
    prs_h smallint not null ,
    prs_l smallint not null ,
    drh char(1) 
        default '' not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".nspnvs from "public" as "informix";

{ TABLE "informix".mrpar row size = 270 number of columns = 4 index size = 17 }

create table "informix".mrpar 
  (
    chart integer not null ,
    alg varchar(255) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null 
  );

revoke all on "informix".mrpar from "public" as "informix";

{ TABLE "informix".sepbd row size = 55 number of columns = 11 index size = 9 }

create table "informix".sepbd 
  (
    sep_no serial not null ,
    hospital_no decimal(10,0) not null ,
    old_chart char(8) not null ,
    nam char(12) not null ,
    sex char(1) not null ,
    born_yy smallint not null ,
    born_mmdd smallint not null ,
    id_no char(10) not null ,
    lab_dat date not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".sepbd from "public" as "informix";

{ TABLE "informix".seitem row size = 72 number of columns = 5 index size = 0 }

create table "informix".seitem 
  (
    sep_no integer not null ,
    tc char(1) not null ,
    chg_cod char(7) not null ,
    amt integer not null ,
    rpt text
  );

revoke all on "informix".seitem from "public" as "informix";

{ TABLE "informix".mrmrdir row size = 24 number of columns = 8 index size = 15 }

create table "informix".mrmrdir 
  (
    chart integer not null ,
    dcg_dat date not null ,
    dcg_hm smallint 
        default 0 not null ,
    lst_psn smallint not null ,
    lst_dat date not null ,
    loc smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".mrmrdir from "public" as "informix";

{ TABLE "informix".ofjbd row size = 54 number of columns = 7 index size = 9 }

create table "informix".ofjbd 
  (
    dpt_no smallint not null ,
    job_no smallint not null ,
    nam varchar(40) not null ,
    typ char(1) not null ,
    pns smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".ofjbd from "public" as "informix";

{ TABLE "informix".ofjobdsp row size = 18 number of columns = 8 index size = 21 }

create table "informix".ofjobdsp 
  (
    dpt_no smallint not null ,
    job_no smallint not null ,
    dat date not null ,
    sft char(1) not null ,
    emp_no smallint not null ,
    sts char(1) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".ofjobdsp from "public" as "informix";

{ TABLE "informix".tgavou row size = 94 number of columns = 16 index size = 16 }

create table "informix".tgavou 
  (
    vou_dat date not null ,
    sub_h_no char(1) not null ,
    typ char(2) not null ,
    seq_no smallint not null ,
    item_no smallint not null ,
    enter_dat date not null ,
    remark smallint not null ,
    fil_01 char(4) not null ,
    acc_cod char(6) not null ,
    amt integer not null ,
    rc smallint not null ,
    outlf_cod smallint not null ,
    outlf_desc varchar(50,1) not null ,
    project_no smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".tgavou from "public" as "informix";

{ TABLE "informix".seril row size = 4 number of columns = 1 index size = 9 }

create table "informix".seril 
  (
    num serial not null 
  );

revoke all on "informix".seril from "public" as "informix";

{ TABLE "informix".moapdn row size = 78 number of columns = 6 index size = 17 }

create table "informix".moapdn 
  (
    chart integer not null ,
    visit_no integer not null ,
    typ integer not null ,
    txt text not null ,
    rtp smallint not null ,
    rtt datetime year to second not null 
  );

revoke all on "informix".moapdn from "public" as "informix";

{ TABLE "informix".mrppsc row size = 15 number of columns = 3 index size = 13 }

create table "informix".mrppsc 
  (
    chart integer not null ,
    sck_dat date not null ,
    visit_no decimal(11,0)
  );

revoke all on "informix".mrppsc from "public" as "informix";

{ TABLE "informix".dgfmindx row size = 50 number of columns = 8 index size = 51 }

create table "informix".dgfmindx 
  (
    nam char(40) not null ,
    pc_12 char(2) not null ,
    pc_3 char(1) not null ,
    pc_sub1 char(1) not null ,
    pc_sub2 char(1) not null ,
    typ char(1) not null ,
    seq smallint not null ,
    pag_no smallint not null 
  );

revoke all on "informix".dgfmindx from "public" as "informix";

{ TABLE "informix".dgfmproc row size = 55 number of columns = 7 index size = 50 }

create table "informix".dgfmproc 
  (
    pc_12 char(2) not null ,
    pc_3 char(1) not null ,
    pc_sub1 char(1) not null ,
    pc_sub2 char(1) not null ,
    nam_s char(40) not null ,
    drug_cod char(5) not null ,
    main_pc_cod char(5) not null 
  );

revoke all on "informix".dgfmproc from "public" as "informix";

{ TABLE "informix".pmmember row size = 86 number of columns = 13 index size = 43 }

create table "informix".pmmember 
  (
    nam char(12) not null ,
    sex char(1) not null ,
    id_no char(10),
    pt_typ char(2) not null ,
    born_dat date not null ,
    tel_h integer not null ,
    tel_o integer not null ,
    reg_no integer not null ,
    adrs varchar(34) not null ,
    act_dat date not null ,
    emp_no smallint not null ,
    rtp smallint not null ,
    rtd smallint not null 
  );

revoke all on "informix".pmmember from "public" as "informix";

{ TABLE "informix".nhtncic row size = 44 number of columns = 8 index size = 42 }

create table "informix".nhtncic 
  (
    itm_cod char(7) not null ,
    dat_f date not null ,
    dat_t date not null ,
    nhi_cod char(12) not null ,
    nhi_up decimal(9,2) not null ,
    qty decimal(6,1) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".nhtncic from "public" as "informix";

{ TABLE "informix".dcicdcn1 row size = 302 number of columns = 20 index size = 34 }

create table "informix".dcicdcn1 
  (
    icd_cod char(6) not null ,
    nhi_cod char(6) not null ,
    drg_cod char(5) not null ,
    qip_drg char(3) 
        default '' not null ,
    nam_e varchar(255) not null ,
    icd_typ smallint not null ,
    sru_mrk char(1) not null ,
    crn_mrk char(1) not null ,
    crn_typ smallint not null ,
    con_mrk char(1) not null ,
    con_typ smallint not null ,
    sex_lmt char(1) not null ,
    dag_lmt char(1) not null ,
    fil_1 char(1) not null ,
    min_age smallint not null ,
    max_age smallint not null ,
    std_days smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".dcicdcn1 from "public" as "informix";

{ TABLE "informix".dcicddsc row size = 267 number of columns = 6 index size = 13 }

create table "informix".dcicddsc 
  (
    icd_cod char(6) not null ,
    seq_no smallint not null ,
    dsc varchar(250) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".dcicddsc from "public" as "informix";

{ TABLE "informix".zzrrcn row size = 36 number of columns = 7 index size = 9 }

create table "informix".zzrrcn 
  (
    region_no integer not null ,
    region_nam char(20) not null ,
    net_no smallint not null ,
    zip smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".zzrrcn from "public" as "informix";

{ TABLE "informix".nsiprdl row size = 14 number of columns = 5 index size = 0 }

create table "informix".nsiprdl 
  (
    tp smallint not null ,
    td date not null ,
    thm smallint not null ,
    acc_no integer not null ,
    dct_r smallint not null 
  );

revoke all on "informix".nsiprdl from "public" as "informix";

{ TABLE "informix".nsiprd row size = 12 number of columns = 4 index size = 9 }

create table "informix".nsiprd 
  (
    acc_no integer not null ,
    dct_r smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".nsiprd from "public" as "informix";

{ TABLE "informix".rgovt row size = 44 number of columns = 22 index size = 31 }

create table "informix".rgovt 
  (
    wek_day char(1) not null ,
    sft char(1) not null ,
    room smallint not null ,
    dct_no smallint not null ,
    div_no smallint not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    stp char(1) not null ,
    chg_typ char(1) not null ,
    lmt_typ char(1) not null ,
    typ char(1) not null ,
    lmt_no smallint not null ,
    fvt_lmt smallint 
        default 0 not null ,
    app_sat smallint not null ,
    fvt_sat smallint not null ,
    fvt_stp smallint not null ,
    vip_sat smallint not null ,
    vip_stp smallint not null ,
    sat_no smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".rgovt from "public" as "informix";

{ TABLE "informix".rgctrl row size = 53 number of columns = 28 index size = 39 }

create table "informix".rgctrl 
  (
    visit_dat date not null ,
    sft char(1) not null ,
    room smallint not null ,
    dct_no smallint not null ,
    div_no smallint not null ,
    stp char(1) not null ,
    chg_typ char(1) not null ,
    lmt_typ char(1) not null ,
    typ char(1) not null ,
    lim_no smallint not null ,
    fvt_lmt smallint 
        default 0 not null ,
    cur_cnt smallint not null ,
    rht_no smallint not null ,
    app_sat smallint not null ,
    app_no smallint not null ,
    fvt_sat smallint not null ,
    fvt_stp smallint not null ,
    fvt_no smallint not null ,
    vip_sat smallint not null ,
    vip_no smallint not null ,
    vip_stp smallint not null ,
    lon_no smallint not null ,
    sat_no smallint not null ,
    fil_1 char(1) not null ,
    fil_2 char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".rgctrl from "public" as "informix";

{ TABLE "informix".cpndsp row size = 34 number of columns = 8 index size = 21 }

create table "informix".cpndsp 
  (
    drg_cod char(5) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    itm_cod char(7) not null ,
    atb char(1) not null ,
    itm_1st char(7) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".cpndsp from "public" as "informix";

{ TABLE "informix".rgnofee row size = 36 number of columns = 7 index size = 9 }

create table "informix".rgnofee 
  (
    visit_dat date not null ,
    chart integer not null ,
    nam char(12) not null ,
    dummy1 char(4) not null ,
    dummy2 char(4) not null ,
    dummy3 char(4) not null ,
    amt integer not null 
  );

revoke all on "informix".rgnofee from "public" as "informix";

{ TABLE "informix".osinst row size = 406 number of columns = 11 index size = 9 }

create table "informix".osinst 
  (
    mapno smallint not null ,
    seq_no smallint not null ,
    nam char(20) not null ,
    gl_inst char(54) not null ,
    gen_inst char(54) not null ,
    color char(1) not null ,
    prt_no smallint not null ,
    soa char(1) not null ,
    coment varchar(255) not null ,
    sp_div char(4),
    sp_rpt char(10)
  );

revoke all on "informix".osinst from "public" as "informix";

{ TABLE "informix".mrcharbr row size = 26 number of columns = 10 index size = 26 }

create table "informix".mrcharbr 
  (
    borrower smallint not null ,
    bor_dat date not null ,
    chart integer not null ,
    vol_no char(2) not null ,
    bor_obj char(1) not null ,
    ret_mark char(1) not null ,
    ret_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".mrcharbr from "public" as "informix";

{ TABLE "informix".gactoa row size = 22 number of columns = 6 index size = 26 }

create table "informix".gactoa 
  (
    acc_cod char(6) not null ,
    chg_cod char(7) not null ,
    pd_typ char(1) not null ,
    nh_typ char(2) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".gactoa from "public" as "informix";

{ TABLE "informix".mrpbd3 row size = 127 number of columns = 31 index size = 62 }

create table "informix".mrpbd3 
  (
    chart integer not null ,
    nam char(12) not null ,
    born_yy smallint not null ,
    born_mmdd smallint not null ,
    sex char(1) not null ,
    l_mark char(1) not null ,
    c_r_cod integer not null ,
    c_r_adrs char(34) not null ,
    domicile char(8) not null ,
    marr char(1) not null ,
    educ char(1) not null ,
    profes char(3) not null ,
    fil1 char(1) not null ,
    id_no char(10) not null ,
    tel_h integer not null ,
    tel_o integer not null ,
    blood_typ char(2) not null ,
    gl_typ char(2) not null ,
    pt_typ char(2) not null ,
    sp_typ char(2) not null ,
    sw_typ char(2) not null ,
    insured integer not null ,
    cer_no integer not null ,
    loc_o char(1) not null ,
    loc_i char(1) not null ,
    nv_times smallint not null ,
    bad_amt integer not null ,
    no_good char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".mrpbd3 from "public" as "informix";

{ TABLE "informix".mrpbd4 row size = 56 number of columns = 6 index size = 9 }

create table "informix".mrpbd4 
  (
    chart integer not null ,
    l_r_cod integer not null ,
    l_r_adrs char(34) not null ,
    l_typ char(2) not null ,
    l_insured integer not null ,
    husband_nam char(8) not null 
  );

revoke all on "informix".mrpbd4 from "public" as "informix";

{ TABLE "informix".rhtibd row size = 73 number of columns = 10 index size = 8 }

create table "informix".rhtibd 
  (
    trp_itm char(3) not null ,
    nam_f char(45) not null ,
    nam_a char(8) not null ,
    chg_typ char(1) not null ,
    trp_typ char(1) not null ,
    dur_tim smallint not null ,
    ast_typ smallint not null ,
    nhi_cod char(5) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".rhtibd from "public" as "informix";

{ TABLE "informix".rgmdcn row size = 76 number of columns = 8 index size = 7 }

create table "informix".rgmdcn 
  (
    division smallint not null ,
    nam_a char(4) not null ,
    nam_f char(20) not null ,
    nam_e char(40) 
        default '' not null ,
    dpt_no smallint not null ,
    div_pho smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".rgmdcn from "public" as "informix";

{ TABLE "informix".ucclicfg row size = 438 number of columns = 23 index size = 112 }

create table "informix".ucclicfg 
  (
    loc_id char(6) not null ,
    cmp_nam char(12) not null ,
    loc_dsc char(30),
    loc_no smallint not null ,
    typ char(1) not null ,
    dep_no smallint not null ,
    mac_adr char(30) not null ,
    tcp_adr char(30) not null ,
    tc char(1) not null ,
    emp_no smallint not null ,
    tel_fun char(4) not null ,
    ctl_flg char(10) not null ,
    lgi_lvl char(1) 
        default '3' not null ,
    scr_ctl char(1) 
        default '1' not null ,
    err_cod smallint 
        default 0 not null ,
    tst_lvl char(1) 
        default '0' not null ,
    lpt_sts char(1) not null ,
    def_prt char(10) not null ,
    not_prt char(10) not null ,
    trd_prt char(10) 
        default '' not null ,
    mem_txt varchar(255) not null ,
    log_tim datetime year to second not null ,
    rtt datetime year to second not null ,
    primary key (loc_id) 
  );

revoke all on "informix".ucclicfg from "public" as "informix";

{ TABLE "informix".ucctrl row size = 92 number of columns = 18 index size = 7 }

create table "informix".ucctrl 
  (
    emp_no smallint not null ,
    dbs_pri char(10) not null ,
    hot_f1 char(4) not null ,
    hot_f2 char(4) not null ,
    hot_f3 char(4) not null ,
    hot_f4 char(4) not null ,
    hot_f5 char(4) not null ,
    hot_f6 char(4) not null ,
    hot_f7 char(4) not null ,
    hot_f8 char(4) not null ,
    hot_f9 char(4) not null ,
    hot_f10 char(4) not null ,
    bot_fun char(4) not null ,
    tc char(1) not null ,
    loc char(6) not null ,
    ctl_flg char(20) not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (emp_no) 
  );

revoke all on "informix".ucctrl from "public" as "informix";

{ TABLE "informix".bmfftran row size = 55 number of columns = 25 index size = 41 }

create table "informix".bmfftran 
  (
    acc_no integer not null ,
    f_dat date not null ,
    f_hm smallint not null ,
    t_dat date not null ,
    t_hm smallint not null ,
    room char(4) 
        default '' not null ,
    bed char(2) not null ,
    class char(1) not null ,
    rank char(1) not null ,
    care_level char(5) 
        default '' not null ,
    a_dr1 smallint not null ,
    a_dr2 smallint not null ,
    a_dr3 smallint not null ,
    a_dr4 smallint not null ,
    division smallint not null ,
    a_dr1_mod char(1) not null ,
    a_dr2_mod char(1) not null ,
    a_dr3_mod char(1) not null ,
    a_dr4_mod char(1) not null ,
    tc char(1) not null ,
    leav char(1) not null ,
    rtp smallint not null ,
    rtl smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".bmfftran from "public" as "informix";

{ TABLE "informix".bmfflog row size = 55 number of columns = 25 index size = 15 }

create table "informix".bmfflog 
  (
    acc_no integer not null ,
    f_dat date not null ,
    f_hm smallint not null ,
    t_dat date not null ,
    t_hm smallint not null ,
    room char(4) 
        default '' not null ,
    bed char(2) not null ,
    class char(1) not null ,
    rank char(1) not null ,
    care_level char(5) 
        default '' not null ,
    a_dr1 smallint not null ,
    a_dr2 smallint not null ,
    a_dr3 smallint not null ,
    a_dr4 smallint not null ,
    division smallint not null ,
    a_dr1_mod char(1) not null ,
    a_dr2_mod char(1) not null ,
    a_dr3_mod char(1) not null ,
    a_dr4_mod char(1) not null ,
    tc char(1) not null ,
    leav char(1) not null ,
    rtp smallint not null ,
    rtl smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".bmfflog from "public" as "informix";

{ TABLE "informix".mrvcsn row size = 60 number of columns = 15 index size = 58 }

create table "informix".mrvcsn 
  (
    vsn serial not null ,
    chart integer not null ,
    visit_no decimal(11,0),
    card_yy decimal(11,0),
    icc_no char(12) 
        default '' not null ,
    vsn_nh char(4) not null ,
    cas_typ char(2) not null ,
    sick_typ char(1) not null ,
    pay_typ char(3) not null ,
    cg_rtp smallint not null ,
    cg_rtd date not null ,
    cg_rthm smallint not null ,
    chk_rtp smallint not null ,
    chk_rtd integer not null ,
    seq_no_nh smallint not null ,
    primary key (vsn) 
  );

revoke all on "informix".mrvcsn from "public" as "informix";

{ TABLE "informix".modsc row size = 83 number of columns = 23 index size = 71 }

create table "informix".modsc 
  (
    ord_no serial not null ,
    vsn integer not null ,
    map_no smallint not null ,
    frm_no integer 
        default 0 not null ,
    div_no smallint not null ,
    ord_man smallint not null ,
    ord_dat date 
        default today not null ,
    ord_hm smallint 
        default 0 not null ,
    ord_loc smallint 
        default 0 not null ,
    tsc char(1) 
        default '1' not null ,
    usg varchar(18),
    sts char(1) 
        default 'N' not null ,
    exp_dat date 
        default  '1899/12/31' not null ,
    pre_dat date 
        default today not null ,
    pre_hm smallint 
        default 0 not null ,
    job_typ char(2) 
        default '' not null ,
    job_no integer 
        default 0 not null ,
    exe_man smallint 
        default 0 not null ,
    exe_dat date 
        default  '2025/12/31' not null ,
    exe_hm smallint 
        default 0 not null ,
    exe_wrd smallint 
        default 0 not null ,
    exe_loc smallint 
        default 0 not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ord_no) 
  );

revoke all on "informix".modsc from "public" as "informix";

{ TABLE "informix".motxt row size = 1100 number of columns = 11 index size = 42 }

create table "informix".motxt 
  (
    ord_no integer not null ,
    chart integer not null ,
    sub varchar(255),
    obj varchar(255),
    ass varchar(255),
    cmt varchar(255),
    rpt_man smallint 
        default 0 not null ,
    rpt_dat date 
        default  '1899/12/31' not null ,
    rpt_hm smallint 
        default 0 not null ,
    rpt_typ char(4) 
        default '' not null ,
    rpt text,
    primary key (ord_no) 
  );

revoke all on "informix".motxt from "public" as "informix";

{ TABLE "informix".mopdd row size = 286 number of columns = 8 index size = 39 }

create table "informix".mopdd 
  (
    vsn integer not null ,
    seq_no smallint not null ,
    eff_man smallint not null ,
    eff_dat date 
        default today not null ,
    icd_cod char(12) not null ,
    icd_dsc varchar(255) not null ,
    stp_man smallint 
        default 0 not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    primary key (vsn,seq_no) 
  );

revoke all on "informix".mopdd from "public" as "informix";

{ TABLE "informix".mower row size = 7 number of columns = 3 index size = 17 }

create table "informix".mower 
  (
    map_no smallint not null ,
    ord_no integer not null ,
    tsc char(1) 
        default '1' not null 
  );

revoke all on "informix".mower from "public" as "informix";

{ TABLE "informix".mopar row size = 30 number of columns = 10 index size = 28 }

create table "informix".mopar 
  (
    evt_no serial not null ,
    ord_no integer not null ,
    act_typ char(1) not null ,
    sts char(1) 
        default '' not null ,
    act_man smallint not null ,
    act_dat date 
        default today not null ,
    act_hm smallint 
        default 0 not null ,
    act_loc smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (evt_no) 
  );

revoke all on "informix".mopar from "public" as "informix";

{ TABLE "informix".monot3 row size = 80 number of columns = 7 index size = 15 }

create table "informix".monot3 
  (
    not_no integer 
        default 0 not null ,
    vsn integer not null ,
    typ integer not null ,
    seq_no smallint 
        default 0 not null ,
    txt text,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null 
  );

revoke all on "informix".monot3 from "public" as "informix";

{ TABLE "informix".moinst row size = 218 number of columns = 12 index size = 9 }

create table "informix".moinst 
  (
    map_no smallint not null ,
    seq_no smallint not null ,
    nam char(12) not null ,
    tit char(20) not null ,
    nhi_inst char(54) not null ,
    gen_inst char(54) not null ,
    prn_color char(1) not null ,
    pag_cnt smallint not null ,
    soa char(1) not null ,
    cmt text,
    prn_typ char(4),
    prn_nam char(10),
    primary key (map_no,seq_no) 
  );

revoke all on "informix".moinst from "public" as "informix";

{ TABLE "informix".nsntwdh row size = 22 number of columns = 8 index size = 16 }

create table "informix".nsntwdh 
  (
    rom char(4),
    bed char(2) not null ,
    tim char(1) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tem char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (rom,bed,tim,eff_dat) 
  );

revoke all on "informix".nsntwdh from "public" as "informix";

{ TABLE "informix".moeps row size = 433 number of columns = 44 index size = 33 }

create table "informix".moeps 
  (
    chg_cod char(7) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    nam varchar(45) not null ,
    map_no smallint not null ,
    loc smallint not null ,
    dos_qty char(5) not null ,
    dos_unt char(4) not null ,
    sal_unt char(4) not null ,
    dsr float 
        default 1.0000000000000000 not null ,
    usg varchar(18),
    use_way char(4) not null ,
    ctl_dug char(1) not null ,
    opd_lmt smallint not null ,
    ipd_lmt smallint not null ,
    day_lmt smallint not null ,
    nhi_ctl char(1) not null ,
    soa char(1) not null ,
    adv varchar(255),
    int_pnt char(1) not null ,
    use_pnt char(1) not null ,
    div_pnt char(1) not null ,
    dct_pnt char(1) not null ,
    cmt_pnt char(1) not null ,
    ord_own char(1) not null ,
    grp_itm char(1) not null ,
    hgh_upp char(1) not null ,
    gen_cod smallint not null ,
    nhi_cod smallint not null ,
    emg_rat decimal(3,2) not null ,
    gen_dis char(1) not null ,
    nhi_dis char(1) not null ,
    gen_upp decimal(9,2) not null ,
    nhi_upp decimal(9,2) not null ,
    nhi_rat decimal(9,2) not null ,
    rud_mrk char(1) not null ,
    odm_qty smallint not null ,
    nod_mrk char(1) not null ,
    fil_1 char(1) not null ,
    fil_2 char(1) not null ,
    fil_3 char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (chg_cod,eff_tim) 
  );

revoke all on "informix".moeps from "public" as "informix";

{ TABLE "informix".movoc row size = 401 number of columns = 9 index size = 25 }

create table "informix".movoc 
  (
    own_no integer not null ,
    map_no smallint not null ,
    voc_typ char(12),
    seq_no smallint not null ,
    cmt varchar(60),
    wod varchar(255),
    txt text,
    rtp integer 
        default 0 not null ,
    rtd date 
        default today not null ,
    primary key (own_no,map_no,voc_typ,seq_no) 
  );

revoke all on "informix".movoc from "public" as "informix";

{ TABLE "informix".udusgtim row size = 161 number of columns = 8 index size = 16 }

create table "informix".udusgtim 
  (
    usg_cod char(6) not null ,
    div_ped char(1) not null ,
    dap char(4) not null ,
    tim_i char(48) not null ,
    tim_t char(48) not null ,
    tim_o char(48) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (usg_cod,div_ped,dap) 
  );

revoke all on "informix".udusgtim from "public" as "informix";

{ TABLE "informix".nsntwd row size = 22 number of columns = 9 index size = 27 }

create table "informix".nsntwd 
  (
    dat date not null ,
    rom char(4),
    bed char(2) not null ,
    wad char(3) not null ,
    tem_d char(1) not null ,
    tem_e char(1) not null ,
    tem_n char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (dat,rom,bed) 
  );

revoke all on "informix".nsntwd from "public" as "informix";

{ TABLE "informix".dginter row size = 31 number of columns = 15 index size = 15 }

create table "informix".dginter 
  (
    srv_cod char(5) not null ,
    clt_cod char(5) not null ,
    sig_rat char(1) not null ,
    eff_rat char(1) not null ,
    ost char(1) not null ,
    sev_rat char(1) not null ,
    src char(1) not null ,
    ref_doc char(1) not null ,
    doc_rec char(1) not null ,
    int_typ char(2) not null ,
    mec_lnk smallint not null ,
    eff_lnk smallint not null ,
    sug_lnk smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (srv_cod,clt_cod) 
  );

revoke all on "informix".dginter from "public" as "informix";

{ TABLE "informix".dgintdoc row size = 66 number of columns = 5 index size = 9 }

create table "informix".dgintdoc 
  (
    int_typ char(2) not null ,
    doc_no smallint not null ,
    doc text,
    rtp smallint not null ,
    rtd date not null ,
    primary key (int_typ,doc_no) 
  );

revoke all on "informix".dgintdoc from "public" as "informix";

{ TABLE "informix".ucolfunc row size = 701 number of columns = 16 index size = 9 }

create table "informix".ucolfunc 
  (
    func_no char(4) not null ,
    prog_nam char(20) not null ,
    def_par varchar(128) not null ,
    prg_pth varchar(128) not null ,
    prog_desc varchar(250) not null ,
    mut_run char(1) not null ,
    tc char(1) not null ,
    hom_pth varchar(128),
    main_prog_nam char(10) not null ,
    ver_no char(12) not null ,
    ver_dat date not null ,
    prog_typ char(1) not null ,
    mtn_man smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null ,
    primary key (func_no) 
  );

revoke all on "informix".ucolfunc from "public" as "informix";

{ TABLE "informix".pstitlcn row size = 32 number of columns = 5 index size = 7 }

create table "informix".pstitlcn 
  (
    titl char(2) not null ,
    nam char(20) not null ,
    edu_pnt smallint not null ,
    rtp integer not null ,
    rtd date not null 
  );

revoke all on "informix".pstitlcn from "public" as "informix";

{ TABLE "informix".bmptbd row size = 156 number of columns = 49 index size = 83 }

create table "informix".bmptbd 
  (
    acc_no serial not null ,
    chart integer not null ,
    visit_no decimal(11,0),
    baby_mark char(1) not null ,
    admit_dat date not null ,
    admit_hm smallint not null ,
    gl_typ char(2) not null ,
    pt_typ char(2) not null ,
    admit_will char(1) not null ,
    admit_window char(1) not null ,
    link_acc decimal(11,0),
    sign_dr smallint not null ,
    diag1 char(12) not null ,
    diag2 char(12) not null ,
    diag3 char(12) not null ,
    id_copy char(1) not null ,
    medical_sheet char(1) not null ,
    room char(4) 
        default '' not null ,
    bed char(2) not null ,
    care_level char(5) 
        default '' not null ,
    a_dr1 smallint not null ,
    a_dr2 smallint not null ,
    a_dr3 smallint not null ,
    a_dr4 smallint not null ,
    division smallint not null ,
    tran_div date not null ,
    a_dr1_mod char(1) not null ,
    a_dr2_mod char(1) not null ,
    a_dr3_mod char(1) not null ,
    a_dr4_mod char(1) not null ,
    tc char(1) not null ,
    consent char(1) not null ,
    pre_days smallint not null ,
    ac_pp_amt integer not null ,
    acc_amt integer not null ,
    spe_tmp_amt integer not null ,
    gen_tmp_amt integer not null ,
    gl_tmp_amt integer not null ,
    credit_typ char(1) not null ,
    tp_dat date not null ,
    tp_hm smallint not null ,
    discha_sts char(2) not null ,
    close_acc char(1) not null ,
    comp_acc integer not null ,
    dsc_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null ,
    rtl smallint not null 
  );

revoke all on "informix".bmptbd from "public" as "informix";

{ TABLE "informix".bmpobd row size = 355 number of columns = 29 index size = 29 }

create table "informix".bmpobd 
  (
    chart integer not null ,
    tel_no integer not null ,
    pre_dat date not null ,
    adm_win char(1) not null ,
    adm_rsn char(1) not null ,
    sick_rank char(1) not null ,
    bed_class char(1) not null ,
    div1_no smallint not null ,
    div2_no smallint not null ,
    div3_no smallint not null ,
    dct1_no smallint not null ,
    dct2_no smallint not null ,
    dct3_no smallint not null ,
    icd1_cod char(12) not null ,
    icd2_cod char(12) not null ,
    icd3_cod char(12) not null ,
    drg_cod char(6) 
        default '' not null ,
    cmt varchar(255) not null ,
    isolat char(1) not null ,
    sts char(2),
    admit_dat date not null ,
    flt1 char(1) 
        default '' not null ,
    flt2 char(1) 
        default '' not null ,
    flt3 char(1) 
        default '' not null ,
    flt4 char(1) 
        default '' not null ,
    vsn integer 
        default 0 not null ,
    lnk_no integer 
        default 0 not null ,
    rtp smallint not null ,
    rtt datetime year to second not null 
  );

revoke all on "informix".bmpobd from "public" as "informix";

{ TABLE "informix".morprv row size = 144 number of columns = 10 index size = 34 }

create table "informix".morprv 
  (
    ord_no integer not null ,
    seq_no smallint 
        default 1 not null ,
    rpt_tim datetime year to second not null ,
    rpt text,
    rpt_typ char(4) 
        default '' not null ,
    rpt_man integer 
        default 0,
    mdf_typ char(3) 
        default '' not null ,
    oth_rsn varchar(50) 
        default '' not null ,
    rtp integer 
        default 0 not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ord_no,rpt_tim) 
  );

revoke all on "informix".morprv from "public" as "informix";

{ TABLE "informix".moitmh row size = 319 number of columns = 14 index size = 20 }

create table "informix".moitmh 
  (
    dit_no integer not null ,
    seq_no smallint not null ,
    chg_cod char(7) not null ,
    dos_qty char(5) 
        default '' not null ,
    usg varchar(18),
    itm1 char(4) 
        default '' not null ,
    itm2 char(4) 
        default '' not null ,
    itm3 char(4) 
        default '' not null ,
    itm4 char(4) 
        default '' not null ,
    nhi_qty decimal(5,1) 
        default 0.0 not null ,
    slf_qty decimal(5,1) 
        default 0.0 not null ,
    mrk char(1) 
        default '' not null ,
    adv varchar(255),
    atb char(1) 
        default '' not null ,
    primary key (dit_no,seq_no) 
  );

revoke all on "informix".moitmh from "public" as "informix";

{ TABLE "informix".mosoah row size = 888 number of columns = 10 index size = 120 }

create table "informix".mosoah 
  (
    dit_no serial not null ,
    own_no char(5) not null ,
    typ char(1) not null ,
    nam char(100) not null ,
    itm_no integer 
        default 0 not null ,
    seq_no smallint 
        default 0 not null ,
    sub varchar(255),
    obj varchar(255),
    ass varchar(255),
    rtd date 
        default today not null ,
    primary key (dit_no) 
  );

revoke all on "informix".mosoah from "public" as "informix";

{ TABLE "informix".nsidpr row size = 131 number of columns = 13 index size = 30 }

create table "informix".nsidpr 
  (
    chart integer not null ,
    typ char(6) not null ,
    sam_dat date not null ,
    sam char(7) not null ,
    cnt smallint not null ,
    pmg_dat date not null ,
    pmg_dr smallint not null ,
    rqt_dat date not null ,
    pmg_no char(10) not null ,
    rlt char(1) not null ,
    cmt varchar(80) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chart,typ,sam_dat) 
  );

revoke all on "informix".nsidpr from "public" as "informix";

{ TABLE "root".dcicdkw row size = 26 number of columns = 2 index size = 31 }

create table "root".dcicdkw 
  (
    key_word char(20) not null ,
    icd_cod char(6) not null ,
    primary key (key_word,icd_cod) 
  );

revoke all on "root".dcicdkw from "public" as "root";

{ TABLE "informix".mrssr row size = 66 number of columns = 10 index size = 43 }

create table "informix".mrssr 
  (
    idn char(10) not null ,
    icd_cod char(12),
    i10_cod char(12),
    icd_ver char(10) 
        default '' not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    ifq_mrk char(1) 
        default '' not null ,
    crd_no decimal(11,0) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (idn,icd_cod,i10_cod,eff_dat) 
  );

revoke all on "informix".mrssr from "public" as "informix";

{ TABLE "informix".cpoidc row size = 20 number of columns = 5 index size = 14 }

create table "informix".cpoidc 
  (
    itm_cod char(7) not null ,
    qty smallint not null ,
    drg_cod char(5) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (itm_cod,qty) 
  );

revoke all on "informix".cpoidc from "public" as "informix";

{ TABLE "informix".nshpbd row size = 35 number of columns = 17 index size = 9 }

create table "informix".nshpbd 
  (
    chart integer not null ,
    hdr_dat date not null ,
    epo_dat date not null ,
    hts char(1) not null ,
    typ char(1) not null ,
    typ_o char(6) not null ,
    wil char(1) not null ,
    cur char(1) not null ,
    bld_pas char(1) not null ,
    qty char(1) not null ,
    thm char(1) not null ,
    lqd char(1) not null ,
    wrk char(1) not null ,
    sts char(1) not null ,
    die_rsn char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chart) 
  );

revoke all on "informix".nshpbd from "public" as "informix";

{ TABLE "root".moutt row size = 172 number of columns = 8 index size = 27 }

create table "root".moutt 
  (
    usg char(18) not null ,
    map_no smallint not null ,
    div_no smallint not null ,
    tim1 char(48) not null ,
    tim2 char(48) not null ,
    tim3 char(48) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (usg,map_no,div_no) 
  );

revoke all on "root".moutt from "public" as "root";

{ TABLE "informix".moexe row size = 27 number of columns = 6 index size = 40 }

create table "informix".moexe 
  (
    vsn integer not null ,
    chart integer 
        default 0 not null ,
    chg_cod char(7) not null ,
    exe_dat date not null ,
    nhi_qty decimal(5,1) not null ,
    slf_qty decimal(5,1) not null ,
    primary key (vsn,chg_cod,exe_dat) 
  );

revoke all on "informix".moexe from "public" as "informix";

{ TABLE "informix".npndbd row size = 275 number of columns = 8 index size = 11 }

create table "informix".npndbd 
  (
    nrs_dag char(6) not null ,
    tsc char(1) 
        default '' not null ,
    nam varchar(255) not null ,
    car_tim1 smallint not null ,
    car_tim2 smallint not null ,
    car_tim3 smallint not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (nrs_dag) 
  );

revoke all on "informix".npndbd from "public" as "informix";

{ TABLE "informix".npntcn row size = 267 number of columns = 5 index size = 9 }

create table "informix".npntcn 
  (
    nrs_cod integer not null ,
    tsc char(1) 
        default '' not null ,
    nam varchar(255) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (nrs_cod) 
  );

revoke all on "informix".npntcn from "public" as "informix";

{ TABLE "informix".npdsc row size = 39 number of columns = 10 index size = 37 }

create table "informix".npdsc 
  (
    npn serial not null ,
    vsn integer not null ,
    nrs_dag char(6) not null ,
    tsc char(1) 
        default '1' not null ,
    ord_man smallint not null ,
    ord_dat date 
        default today not null ,
    eff_dat date not null ,
    stp_man smallint not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    rtt datetime year to second 
        default current year to second,
    primary key (npn) 
  );

revoke all on "informix".npdsc from "public" as "informix";

{ TABLE "informix".npitm row size = 23 number of columns = 8 index size = 25 }

create table "informix".npitm 
  (
    npn integer not null ,
    seq_no smallint not null ,
    nrs_cod integer not null ,
    eff_man smallint not null ,
    eff_dat date not null ,
    exe_man smallint 
        default 0 not null ,
    exe_dat date 
        default  '2025/12/31' not null ,
    exe_sts char(1) 
        default '' not null ,
    primary key (npn,seq_no) 
  );

revoke all on "informix".npitm from "public" as "informix";

{ TABLE "informix".npddi row size = 12 number of columns = 3 index size = 13 }

create table "informix".npddi 
  (
    nrs_dag char(6) not null ,
    seq_no smallint not null ,
    nrs_cod integer not null ,
    primary key (nrs_dag,seq_no) 
  );

revoke all on "informix".npddi from "public" as "informix";

{ TABLE "informix".mooso row size = 772 number of columns = 4 index size = 9 }

create table "informix".mooso 
  (
    vsn integer not null ,
    sub varchar(255),
    obj varchar(255),
    cmt varchar(255),
    primary key (vsn) 
  );

revoke all on "informix".mooso from "public" as "informix";

{ TABLE "informix".dgdesc row size = 473 number of columns = 35 index size = 55 }

create table "informix".dgdesc 
  (
    drug_cod char(5) not null ,
    tc char(1) not null ,
    nam char(40) not null ,
    content char(25) not null ,
    pcs_self char(1) not null ,
    dis char(1) not null ,
    ud char(1) not null ,
    slot_no smallint not null ,
    lng_ord char(1) not null ,
    laubau char(1) not null ,
    sale_typ char(1) not null ,
    price_typ char(1) not null ,
    sale_unit char(4) not null ,
    std_unit char(4) not null ,
    sal_std_r decimal(9,4) not null ,
    dose_unit char(4) not null ,
    use_typ char(2) not null ,
    shaking char(1) not null ,
    prn char(1) not null ,
    eat_typ_1 char(1) not null ,
    eat_typ_2 char(1) not null ,
    ac_pc char(1) not null ,
    m_n char(1) not null ,
    storage char(1) not null ,
    notice char(1) not null ,
    ap_safe_typ char(1) not null ,
    hgh_alt char(1) 
        default '' not null ,
    cln_way char(80) 
        default '' not null ,
    license_no char(11) not null ,
    orig_cntry char(3) not null ,
    orig_place varchar(255) not null ,
    sub_cod char(5) 
        default '' not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".dgdesc from "public" as "informix";

{ TABLE "informix".igdsc row size = 7 number of columns = 3 index size = 11 }

create table "informix".igdsc 
  (
    ord_no integer not null ,
    seq_no smallint not null ,
    rpt_img char(1) not null ,
    primary key (ord_no,seq_no) 
  );

revoke all on "informix".igdsc from "public" as "informix";

{ TABLE "informix".igetr row size = 121 number of columns = 27 index size = 9 }

create table "informix".igetr 
  (
    ord_no integer not null ,
    ane_typ char(1) not null ,
    tpe_no char(8),
    feq_use smallint,
    glc_c char(1),
    glc_a char(1),
    glc_i char(1),
    glc_b char(1),
    glc_p char(1),
    glc_h char(1),
    glc_ic char(1),
    phc char(1),
    vla char(1),
    amp_r char(1),
    amp_l char(1),
    muw_r char(1),
    muw_l char(1),
    phy char(1),
    per char(1),
    vtf_som char(1),
    vtf_mov char(1),
    ary_som char(1),
    ary_mov char(1),
    hyp char(1),
    cmt char(80),
    rtp smallint,
    rtd date 
        default today,
    primary key (ord_no) 
  );

revoke all on "informix".igetr from "public" as "informix";

{ TABLE "informix".mrchtbor row size = 37 number of columns = 12 index size = 24 }

create table "informix".mrchtbor 
  (
    evt_no serial not null ,
    bor_man smallint not null ,
    bor_psn smallint not null ,
    bor_dat date not null ,
    chart integer not null ,
    dcg_dat date not null ,
    bor_use char(1) not null ,
    pre_dat date not null ,
    ret_psn smallint not null ,
    ret_dat date not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".mrchtbor from "public" as "informix";

{ TABLE "informix".mrumrdr row size = 21 number of columns = 7 index size = 13 }

create table "informix".mrumrdr 
  (
    evt_no integer not null ,
    eff_dat date not null ,
    end_dat date not null ,
    dct smallint not null ,
    rsn char(1) not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".mrumrdr from "public" as "informix";

{ TABLE "informix".progt row size = 51 number of columns = 5 index size = 7 }

create table "informix".progt 
  (
    ogt_no smallint not null ,
    nam varchar(40) not null ,
    dpt_no smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ogt_no) 
  );

revoke all on "informix".progt from "public" as "informix";

{ TABLE "informix".prrbd row size = 416 number of columns = 18 index size = 57 }

create table "informix".prrbd 
  (
    idn char(10) not null ,
    nam char(12) not null ,
    sex char(1) not null ,
    brn_dat date 
        default  '1899/12/31' not null ,
    tel_h integer 
        default 0 not null ,
    tel_o integer 
        default 0 not null ,
    tel_b integer 
        default 0 not null ,
    eml_no varchar(30),
    crc_no integer not null ,
    crc_adr varchar(34) not null ,
    rrc_no integer not null ,
    ngb_no smallint not null ,
    rrc_adr varchar(34) not null ,
    prt_grp smallint 
        default 0 not null ,
    rsp_man smallint 
        default 0 not null ,
    cmt varchar(255),
    rtp smallint not null ,
    rtd date not null ,
    primary key (idn) 
  );

revoke all on "informix".prrbd from "public" as "informix";

{ TABLE "informix".prrog row size = 45 number of columns = 6 index size = 23 }

create table "informix".prrog 
  (
    idn char(10) not null ,
    org_no integer not null ,
    tit_nam varchar(20) not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (idn,org_no,stp_dat) 
  );

revoke all on "informix".prrog from "public" as "informix";

{ TABLE "informix".pbvac row size = 8 number of columns = 4 index size = 11 }

create table "informix".pbvac 
  (
    sys_id char(2) not null ,
    vac_dat date not null ,
    typ1 char(1) not null ,
    typ2 char(1) not null ,
    primary key (sys_id,vac_dat) 
  );

revoke all on "informix".pbvac from "public" as "informix";

{ TABLE "informix".dgdcr2 row size = 15 number of columns = 4 index size = 11 }

create table "informix".dgdcr2 
  (
    vsn integer not null ,
    con_typ smallint not null ,
    rtp smallint not null ,
    rtt datetime year to minute 
        default  datetime (1899-12-31 00:00) year to minute not null ,
    primary key (vsn,con_typ) 
  );

revoke all on "informix".dgdcr2 from "public" as "informix";

{ TABLE "informix".bcbemp row size = 6 number of columns = 2 index size = 16 }

create table "informix".bcbemp 
  (
    bbc_no integer not null ,
    emp_no smallint not null ,
    primary key (bbc_no) 
  );

revoke all on "informix".bcbemp from "public" as "informix";

{ TABLE "informix".bccbcr row size = 282 number of columns = 7 index size = 15 }

create table "informix".bccbcr 
  (
    emp_no smallint not null ,
    cal_tim datetime year to second not null ,
    cal_man smallint not null ,
    bbc_no integer not null ,
    msg varchar(255) not null ,
    rec_man smallint not null ,
    rec_tim datetime year to second not null ,
    primary key (emp_no,cal_tim) 
  );

revoke all on "informix".bccbcr from "public" as "informix";

{ TABLE "informix".bcgcn row size = 22 number of columns = 2 index size = 32 }

create table "informix".bcgcn 
  (
    grp_no smallint not null ,
    grp_nam char(20) not null ,
    primary key (grp_no) 
  );

revoke all on "informix".bcgcn from "public" as "informix";

{ TABLE "informix".bcgemp row size = 4 number of columns = 2 index size = 9 }

create table "informix".bcgemp 
  (
    grp_no smallint not null ,
    emp_no smallint not null ,
    primary key (grp_no,emp_no) 
  );

revoke all on "informix".bcgemp from "public" as "informix";

{ TABLE "informix".bcmcd row size = 87 number of columns = 3 index size = 11 }

create table "informix".bcmcd 
  (
    msg_typ integer not null ,
    seq_no smallint not null ,
    msg_dsc varchar(80) not null ,
    primary key (msg_typ,seq_no) 
  );

revoke all on "informix".bcmcd from "public" as "informix";

{ TABLE "informix".bcmtn row size = 26 number of columns = 3 index size = 20 }

create table "informix".bcmtn 
  (
    msg_typ serial not null ,
    dpt_no smallint not null ,
    typ_nam char(20) not null ,
    primary key (msg_typ) 
  );

revoke all on "informix".bcmtn from "public" as "informix";

{ TABLE "informix".momic row size = 11 number of columns = 6 index size = 14 }

create table "informix".momic 
  (
    map_no smallint not null ,
    loc_no smallint not null ,
    wek_day char(1) not null ,
    eff_hm smallint not null ,
    stp_hm smallint not null ,
    seq_no smallint not null ,
    primary key (map_no,loc_no,wek_day,stp_hm,seq_no) 
  );

revoke all on "informix".momic from "public" as "informix";

{ TABLE "informix".eraadrcn row size = 48 number of columns = 4 index size = 7 }

create table "informix".eraadrcn 
  (
    aad_no smallint not null ,
    nam char(40) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (aad_no) 
  );

revoke all on "informix".eraadrcn from "public" as "informix";

{ TABLE "informix".oledbversion row size = 32 number of columns = 4 index size = 0 }

create table "informix".oledbversion 
  (
    srvrver varchar(18),
    oledbver smallint,
    oleobjsmodtime datetime year to fraction(3),
    nullc char(1)
  );

revoke all on "informix".oledbversion from "public" as "informix";

{ TABLE "informix".oledbtabtypes row size = 26 number of columns = 3 index size = 12 }

create table "informix".oledbtabtypes 
  (
    typecode char(1),
    issystem varchar(5),
    typedesc varchar(18),
    primary key (typecode,issystem) 
  );

revoke all on "informix".oledbtabtypes from "public" as "informix";

{ TABLE "informix".oledbbmk row size = 21 number of columns = 7 index size = 10 }

create table "informix".oledbbmk 
  (
    tabtype char(1),
    fragmented smallint,
    withrowids smallint,
    hasbmk varchar(5),
    bmktype integer,
    bmkdtype smallint,
    bmkmaxlen integer,
    primary key (tabtype,fragmented,withrowids) 
  );

revoke all on "informix".oledbbmk from "public" as "informix";

{ TABLE "informix".oledbtypes row size = 302 number of columns = 19 index size = 9 }

create table "informix".oledbtypes 
  (
    typename varchar(128),
    datatype smallint,
    columnsize integer,
    literalprefix varchar(40),
    literalsuffix varchar(40),
    createparams varchar(18),
    isnullable varchar(5),
    casesensitive varchar(5),
    searchable integer,
    unsignedattribute varchar(5),
    fixedprecscale varchar(5),
    autouniquevalue varchar(5),
    minimumscale smallint,
    maximumscale smallint,
    islong varchar(5),
    bestmatch varchar(5),
    is_fixedlength varchar(5),
    xstid integer,
    udonly varchar(5),
    primary key (xstid) 
  );

revoke all on "informix".oledbtypes from "public" as "informix";

{ TABLE "informix".oledboleobjects row size = 336 number of columns = 6 index size = 200 }

create table "informix".oledboleobjects 
  (
    database varchar(32) not null ,
    owner varchar(32) not null ,
    name varchar(128) not null ,
    comadapter varchar(5) not null ,
    persiststorage varchar(5) not null ,
    progid varchar(128),
    primary key (database,owner,name) 
  );

revoke all on "informix".oledboleobjects from "public" as "informix";

{ TABLE "informix".oledbprivtypes row size = 24 number of columns = 3 index size = 6 }

create table "informix".oledbprivtypes 
  (
    code char(1),
    name varchar(16),
    is_grantable varchar(5),
    primary key (code) 
  );

revoke all on "informix".oledbprivtypes from "public" as "informix";

{ TABLE "informix".oledbconstrtypes row size = 30 number of columns = 4 index size = 6 }

create table "informix".oledbconstrtypes 
  (
    code char(1),
    name varchar(16),
    isprimary varchar(5),
    isunique varchar(5),
    primary key (code) 
  );

revoke all on "informix".oledbconstrtypes from "public" as "informix";

{ TABLE "informix".oledbconstrdefers row size = 21 number of columns = 5 index size = 12 }

create table "informix".oledbconstrdefers 
  (
    objstate char(1),
    isdeferred varchar(5),
    deferrable varchar(5),
    issystab varchar(5),
    code smallint,
    primary key (objstate,issystab) 
  );

revoke all on "informix".oledbconstrdefers from "public" as "informix";

{ TABLE "informix".oledbusagetypes row size = 37 number of columns = 2 index size = 23 }

create table "informix".oledbusagetypes 
  (
    tabname char(18),
    usagetype varchar(18),
    primary key (tabname) 
  );

revoke all on "informix".oledbusagetypes from "public" as "informix";

{ TABLE "informix".oledbordinals row size = 4 number of columns = 1 index size = 9 }

create table "informix".oledbordinals 
  (
    ordinal integer,
    primary key (ordinal) 
  );

revoke all on "informix".oledbordinals from "public" as "informix";

{ TABLE "informix".ucmsg row size = 574 number of columns = 17 index size = 77 }

create table "informix".ucmsg 
  (
    msg_no serial not null ,
    tbl_id char(8) not null ,
    fun_no char(4) not null ,
    evt_no integer not null ,
    tsc char(1) not null ,
    lvl char(1) not null ,
    cmt varchar(255) not null ,
    sed_man smallint not null ,
    sed_tim datetime year to minute not null ,
    sed_loc smallint not null ,
    lmt_dat date 
        default  '2025/12/31' not null ,
    rec_man smallint not null ,
    rec_tim datetime year to minute not null ,
    rec_loc smallint not null ,
    exe_tim datetime year to minute not null ,
    cfm_cmt varchar(255) not null ,
    rtt datetime year to minute 
        default current year to minute not null ,
    
    check (lmt_dat >= DATE (sed_tim ) ),
    
    check (rec_tim >= sed_tim ),
    primary key (msg_no) 
  );

revoke all on "informix".ucmsg from "public" as "informix";

{ TABLE "informix".mohint row size = 74 number of columns = 4 index size = 7 }

create table "informix".mohint 
  (
    dct_no smallint not null ,
    dsc text,
    see_tim datetime year to second not null ,
    rtt datetime year to second 
        default current year to second,
    primary key (dct_no) 
  );

revoke all on "informix".mohint from "public" as "informix";

{ TABLE "informix".dgprnctl row size = 20 number of columns = 2 index size = 15 }

create table "informix".dgprnctl 
  (
    def_prt char(10) not null ,
    swt_prt char(10) not null ,
    primary key (def_prt) 
  );

revoke all on "informix".dgprnctl from "public" as "informix";

{ TABLE "root".sysmenus row size = 78 number of columns = 2 index size = 23 }

create table "root".sysmenus 
  (
    menuname char(18),
    title char(60)
  );

revoke all on "root".sysmenus from "public" as "root";

{ TABLE "informix".dgdnc row size = 10 number of columns = 5 index size = 7 }

create table "informix".dgdnc 
  (
    hpt_loc char(1) not null ,
    typ char(1) not null ,
    cur_no smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".dgdnc from "public" as "informix";

{ TABLE "informix".nsmss row size = 43 number of columns = 8 index size = 23 }

create table "informix".nsmss 
  (
    wrd smallint not null ,
    itm_no smallint not null ,
    mtl_cod char(7) not null ,
    smt_no integer 
        default 0 not null ,
    qty smallint not null ,
    nam_a char(20) 
        default '',
    rtp smallint not null ,
    rtd date not null ,
    primary key (wrd,itm_no) 
  );

revoke all on "informix".nsmss from "public" as "informix";

{ TABLE "informix".dcptbd row size = 37 number of columns = 14 index size = 47 }

create table "informix".dcptbd 
  (
    vsn integer not null ,
    chart integer not null ,
    nhi_typ char(2) not null ,
    age smallint not null ,
    reg_no integer not null ,
    div_no smallint not null ,
    icu char(1) not null ,
    adm_dat date not null ,
    adm_win char(1) not null ,
    dis_dat date not null ,
    dis_sts char(2) not null ,
    ane_typ char(1) not null ,
    rtd date not null ,
    rtp smallint not null ,
    primary key (vsn) 
  );

revoke all on "informix".dcptbd from "public" as "informix";

{ TABLE "informix".modct row size = 32 number of columns = 10 index size = 47 }

create table "informix".modct 
  (
    vsn integer not null ,
    seq_no smallint not null ,
    div_no smallint not null ,
    dct_no smallint not null ,
    eff_dat date 
        default today not null ,
    eff_hm smallint 
        default 0 not null ,
    stp_dat date 
        default  '2010/12/31' not null ,
    stp_hm smallint 
        default 0 not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (vsn,stp_dat,stp_hm,seq_no) 
  );

revoke all on "informix".modct from "public" as "informix";

{ TABLE "informix".morsh row size = 259 number of columns = 2 index size = 0 }

create table "informix".morsh 
  (
    seq_no serial not null ,
    cmd char(255) not null 
  );

revoke all on "informix".morsh from "public" as "informix";

{ TABLE "root".tecico row size = 15 number of columns = 4 index size = 18 }

create table "root".tecico 
  (
    rec_tim datetime year to second 
        default current year to second not null ,
    sub_tel integer not null ,
    typ char(1) not null ,
    rtp smallint not null ,
    primary key (rec_tim,sub_tel,typ) 
  );

revoke all on "root".tecico from "public" as "root";

{ TABLE "root".tectsr row size = 28 number of columns = 11 index size = 16 }

create table "root".tectsr 
  (
    tel_loc char(4) not null ,
    wek_day char(1) not null ,
    sat_hhmm smallint not null ,
    stp_hhmm smallint not null ,
    eff_dat date not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    bas_qty smallint not null ,
    bas_unt char(1) not null ,
    amt smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (tel_loc,wek_day,sat_hhmm,stp_dat) 
  );

revoke all on "root".tectsr from "public" as "root";

{ TABLE "root".tecttr row size = 34 number of columns = 5 index size = 39 }

create table "root".tecttr 
  (
    sat_tim datetime year to second not null ,
    sub_tel integer not null ,
    vsn integer not null ,
    out_tel char(16) not null ,
    use_sec smallint not null ,
    primary key (sat_tim,sub_tel) 
  );

revoke all on "root".tecttr from "public" as "root";

{ TABLE "root".tetbd row size = 63 number of columns = 9 index size = 62 }

create table "root".tetbd 
  (
    sub_tel integer not null ,
    nam varchar(40) not null ,
    loc_no smallint not null ,
    cur_sts char(1) not null ,
    ctl_sts char(1) not null ,
    dpt_no smallint not null ,
    emp_no smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second
  );

revoke all on "root".tetbd from "public" as "root";

{ TABLE "informix".nhtpi row size = 29 number of columns = 7 index size = 23 }

create table "informix".nhtpi 
  (
    pkg_cod char(7) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    chg_cod char(7) not null ,
    typ char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (pkg_cod,eff_dat,chg_cod) 
  );

revoke all on "informix".nhtpi from "public" as "informix";

{ TABLE "informix".nhtppd row size = 24 number of columns = 5 index size = 16 }

create table "informix".nhtppd 
  (
    chart integer not null ,
    visit_no decimal(11,0) not null ,
    pkg_cod char(7) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chart,visit_no) 
  );

revoke all on "informix".nhtppd from "public" as "informix";

{ TABLE "informix".cgbai row size = 26 number of columns = 6 index size = 16 }

create table "informix".cgbai 
  (
    chg_cod char(7) not null ,
    eff_dat date 
        default today not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    bai_amt decimal(7,1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (chg_cod,eff_dat) 
  );

revoke all on "informix".cgbai from "public" as "informix";

{ TABLE "informix".dgusgdat row size = 100 number of columns = 9 index size = 0 }

create table "informix".dgusgdat 
  (
    usg_cod char(18) not null ,
    nam char(20) not null ,
    usg_dsc char(50) not null ,
    usg_typ char(1) not null ,
    frq_typ char(1) not null ,
    frq smallint not null ,
    cnt smallint not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".dgusgdat from "public" as "informix";

{ TABLE "informix".mocnam row size = 67 number of columns = 6 index size = 26 }

create table "informix".mocnam 
  (
    map_no smallint not null ,
    typ char(1) not null ,
    cod char(18) not null ,
    dsc char(40) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (map_no,typ,cod) 
  );

revoke all on "informix".mocnam from "public" as "informix";

{ TABLE "informix".motdn row size = 880 number of columns = 28 index size = 28 }

create table "informix".motdn 
  (
    vsn integer not null ,
    ord_no integer 
        default 0 not null ,
    trn_tim datetime year to minute not null ,
    old_div_no smallint not null ,
    old_dct_no smallint not null ,
    new_div_no smallint not null ,
    new_dct_no1 smallint not null ,
    new_dct_no2 smallint not null ,
    new_dct_no3 smallint not null ,
    new_dct_no4 smallint not null ,
    tsc char(1) not null ,
    txt_01 text,
    txt_02 text,
    txt_03 text,
    txt_04 text,
    txt_05 text,
    txt_06 text,
    txt_07 text,
    txt_08 text,
    txt_09 text,
    txt_10 text,
    txt_11 text,
    txt_12 text,
    txt_13 text,
    txt_14 text,
    txt_15 text,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (vsn,trn_tim) 
  );

revoke all on "informix".motdn from "public" as "informix";

{ TABLE "informix".cpcpv row size = 22 number of columns = 10 index size = 9 }

create table "informix".cpcpv 
  (
    itm_no integer not null ,
    var_no1 smallint not null ,
    var_no2 smallint not null ,
    var_no3 smallint not null ,
    elm_no1 smallint not null ,
    elm_no2 smallint not null ,
    elm_no3 smallint not null ,
    car_no1 smallint not null ,
    car_no2 smallint not null ,
    car_no3 smallint not null ,
    primary key (itm_no) 
  );

revoke all on "informix".cpcpv from "public" as "informix";

{ TABLE "informix".cpveccn row size = 48 number of columns = 4 index size = 7 }

create table "informix".cpveccn 
  (
    vec_no smallint not null ,
    nam char(40) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (vec_no) 
  );

revoke all on "informix".cpveccn from "public" as "informix";

{ TABLE "informix".dgads row size = 32 number of columns = 15 index size = 11 }

create table "informix".dgads 
  (
    hsp_no char(1) not null ,
    adj_dat date not null ,
    lmp_typ char(1) not null ,
    adj_man01 smallint not null ,
    adj_man02 smallint not null ,
    adj_man03 smallint not null ,
    adj_man04 smallint not null ,
    adj_man05 smallint not null ,
    adj_man06 smallint not null ,
    adj_man07 smallint not null ,
    adj_man08 smallint not null ,
    adj_man09 smallint not null ,
    adj_man10 smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (hsp_no,adj_dat,lmp_typ) 
  );

revoke all on "informix".dgads from "public" as "informix";

{ TABLE "informix".nhdcn row size = 247 number of columns = 17 index size = 26 }

create table "informix".nhdcn 
  (
    drg_cod char(5) not null ,
    eff_dat date not null ,
    div_no smallint not null ,
    nam char(98) not null ,
    nam_a char(40) 
        default '' not null ,
    amt_apl integer not null ,
    rat_max smallint not null ,
    amt_min integer not null ,
    day_low smallint not null ,
    day_hgh smallint not null ,
    amt_low integer not null ,
    amt_hgh integer not null ,
    rat_exe smallint not null ,
    apl_cod char(12) not null ,
    txt text,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".nhdcn from "public" as "informix";

{ TABLE "informix".hcbtm row size = 25 number of columns = 6 index size = 24 }

create table "informix".hcbtm 
  (
    chart integer not null ,
    btm_seq char(1) 
        default '1' not null ,
    idn char(10) not null ,
    brn_dat date not null ,
    rtp smallint 
        default 0 not null ,
    rtd date 
        default today not null ,
    primary key (chart) 
  );

revoke all on "informix".hcbtm from "public" as "informix";

{ TABLE "informix".hcvcd row size = 295 number of columns = 9 index size = 36 }

create table "informix".hcvcd 
  (
    vcd_no serial not null ,
    vsn integer not null ,
    icc_typ char(2) not null ,
    btm char(1) 
        default 'N' not null ,
    rcm char(1) 
        default '1' not null ,
    sam_id char(12) not null ,
    wrt_tim char(13) not null ,
    sfe_sign char(256) not null ,
    rtp smallint not null ,
    primary key (vcd_no) 
  );

revoke all on "informix".hcvcd from "public" as "informix";

{ TABLE "informix".rosars row size = 74 number of columns = 7 index size = 41 }

create table "informix".rosars 
  (
    idn char(10) not null ,
    nam char(12) not null ,
    hop_nam char(20) not null ,
    adm_dat date 
        default  '1899/12/31' not null ,
    dis_dat date 
        default  '1899/12/31' not null ,
    tel_no integer 
        default 0 not null ,
    cmt char(20) 
        default '' not null ,
    primary key (idn) 
  );

revoke all on "informix".rosars from "public" as "informix";

{ TABLE "informix".uciolog row size = 13 number of columns = 4 index size = 15 }

create table "informix".uciolog 
  (
    log_tim datetime year to second 
        default current year to second not null ,
    emp_no smallint not null ,
    loc_no smallint not null ,
    log_sts char(1) not null ,
    primary key (log_tim,emp_no) 
  );

revoke all on "informix".uciolog from "public" as "informix";

{ TABLE "informix".smreq row size = 190 number of columns = 8 index size = 22 }

create table "informix".smreq 
  (
    sed_no serial not null ,
    apl_man smallint not null ,
    tel_no integer not null ,
    msg char(159) 
        default '' not null ,
    sed_tim datetime year to second not null ,
    chg_man integer not null ,
    apl_tim datetime year to minute not null ,
    apl_loc smallint not null ,
    primary key (sed_no) 
  );

revoke all on "informix".smreq from "public" as "informix";

{ TABLE "root".nsntm row size = 29 number of columns = 8 index size = 35 }

create table "root".nsntm 
  (
    chg_cod char(7) not null ,
    typ char(4) not null ,
    mat_cod char(7) not null ,
    inc_itm char(1) not null ,
    min_qty smallint not null ,
    max_qty smallint not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (chg_cod,typ) 
  );

revoke all on "root".nsntm from "public" as "root";

{ TABLE "informix".nentm row size = 29 number of columns = 8 index size = 35 }

create table "informix".nentm 
  (
    chg_cod char(7) not null ,
    typ char(4) not null ,
    mat_cod char(7) not null ,
    inc_itm char(1) not null ,
    min_qty smallint not null ,
    max_qty smallint not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (chg_cod,typ) 
  );

revoke all on "informix".nentm from "public" as "informix";

{ TABLE "informix".garcbd row size = 46 number of columns = 9 index size = 20 }

create table "informix".garcbd 
  (
    rc smallint not null ,
    level_no char(8) not null ,
    nam_a char(6) not null ,
    nam_f char(20) not null ,
    typ char(1) not null ,
    seq_no smallint not null ,
    mark_gaon char(1) not null ,
    rtp smallint not null ,
    rtd date
  );

revoke all on "informix".garcbd from "public" as "informix";

{ TABLE "informix".hcccd row size = 29 number of columns = 6 index size = 36 }

create table "informix".hcccd 
  (
    ccd_no serial not null ,
    vsn integer not null ,
    icc_typ char(2) not null ,
    vsn_nh char(4) not null ,
    wrt_tim char(13) not null ,
    rtp smallint not null ,
    primary key (ccd_no) 
  );

revoke all on "informix".hcccd from "public" as "informix";

{ TABLE "informix".hcwcs row size = 274 number of columns = 5 index size = 9 }

create table "informix".hcwcs 
  (
    ccd_no integer not null ,
    btm char(1) 
        default 'N' not null ,
    rcm char(1) 
        default '1' not null ,
    sam_id char(12) not null ,
    sfe_sign char(256) not null ,
    primary key (ccd_no) 
  );

revoke all on "informix".hcwcs from "public" as "informix";

{ TABLE "informix".dcdsc92 row size = 267 number of columns = 6 index size = 13 }

create table "informix".dcdsc92 
  (
    icd_cod char(6) not null ,
    seq_no smallint not null ,
    dsc varchar(250) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".dcdsc92 from "public" as "informix";

{ TABLE "informix".dcicd92 row size = 301 number of columns = 20 index size = 34 }

create table "informix".dcicd92 
  (
    icd_cod char(6) not null ,
    nhi_cod char(6) not null ,
    drg_cod char(5) not null ,
    qip_drg char(3) not null ,
    nam_e char(255) not null ,
    icd_typ smallint not null ,
    sru_mrk char(1) not null ,
    crn_mrk char(1) not null ,
    crn_typ smallint not null ,
    con_mrk char(1) not null ,
    con_typ smallint not null ,
    sex_lmt char(1) not null ,
    dag_lmt char(1) not null ,
    fil_1 char(1) not null ,
    min_age smallint not null ,
    max_age smallint not null ,
    std_days smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".dcicd92 from "public" as "informix";

{ TABLE "informix".scpbd row size = 49 number of columns = 16 index size = 37 }

create table "informix".scpbd 
  (
    scp_no serial not null ,
    chart integer not null ,
    scn_typ char(3) not null ,
    hpt_loc char(1) 
        default '0' not null ,
    dct_no smallint not null ,
    eff_dat date 
        default today not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    dis_typ char(2) 
        default '' not null ,
    eff_rsn char(1) 
        default '' not null ,
    stp_rsn char(1) not null ,
    cle smallint not null ,
    cle_dat date 
        default  '1899/12/31' not null ,
    lst_dat date 
        default  '1899/12/31' not null ,
    lst_cod char(7) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (scp_no) 
  );

revoke all on "informix".scpbd from "public" as "informix";

{ TABLE "informix".sccer row size = 54 number of columns = 11 index size = 36 }

create table "informix".sccer 
  (
    scp_no integer not null ,
    vsn integer not null ,
    tsc char(1) not null ,
    pkg_cod char(7) not null ,
    ord_dat date not null ,
    ord_man smallint 
        default 0 not null ,
    cfm_mrk char(15) not null ,
    cfm_dat date 
        default  '1899/12/31' not null ,
    reg_dat date 
        default  '1899/12/31' not null ,
    exe_man smallint 
        default 0 not null ,
    rtt datetime year to minute 
        default current year to minute not null ,
    primary key (scp_no,pkg_cod,vsn) 
  );

revoke all on "informix".sccer from "public" as "informix";

{ TABLE "informix".scceibd row size = 35 number of columns = 5 index size = 14 }

create table "informix".scceibd 
  (
    pkg_cod char(7) not null ,
    seq_no smallint not null ,
    exe_nam char(20) 
        default '' not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (pkg_cod,seq_no) 
  );

revoke all on "informix".scceibd from "public" as "informix";

{ TABLE "informix".sccrd row size = 21 number of columns = 7 index size = 10 }

create table "informix".sccrd 
  (
    scn_typ char(3) not null ,
    seq_no smallint not null ,
    pkg_cod char(7) not null ,
    frq char(1) not null ,
    itv_day smallint not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (scn_typ,seq_no) 
  );

revoke all on "informix".sccrd from "public" as "informix";

{ TABLE "informix".ucofunl row size = 14 number of columns = 5 index size = 13 }

create table "informix".ucofunl 
  (
    emp_no smallint not null ,
    fun_no char(4) not null ,
    dpt_no smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (emp_no,fun_no,dpt_no) 
  );

revoke all on "informix".ucofunl from "public" as "informix";

{ TABLE "informix".dgtest row size = 22 number of columns = 7 index size = 16 }

create table "informix".dgtest 
  (
    chg_cod char(5) not null ,
    dct_no smallint not null ,
    chart integer not null ,
    pay_typ char(1) 
        default '' not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chg_cod,dct_no,chart) 
  );

revoke all on "informix".dgtest from "public" as "informix";

{ TABLE "informix".dcicdcn row size = 308 number of columns = 21 index size = 34 }

create table "informix".dcicdcn 
  (
    icd_cod char(6) not null ,
    nhi_cod char(6) not null ,
    drg_cod char(5) not null ,
    qip_drg char(3) not null ,
    nam_e char(255) not null ,
    icd_typ smallint not null ,
    sru_mrk smallint not null ,
    ifq_mrk char(1) 
        default '' not null ,
    crn_mrk char(1) not null ,
    crn_typ char(6) 
        default '' not null ,
    con_mrk char(1) not null ,
    con_typ smallint not null ,
    sex_lmt char(1) not null ,
    dag_lmt char(1) not null ,
    fil_1 char(2) 
        default '' not null ,
    min_age smallint not null ,
    max_age smallint not null ,
    std_days smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".dcicdcn from "public" as "informix";

{ TABLE "informix".cndcn row size = 87 number of columns = 11 index size = 30 }

create table "informix".cndcn 
  (
    dag_no serial not null ,
    vsn integer not null ,
    dag_dat date not null ,
    dag_typ smallint not null ,
    tsc char(1) not null ,
    div_no smallint not null ,
    dct_no smallint not null ,
    ord_man smallint not null ,
    dag_txt text,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (dag_no) 
  );

revoke all on "informix".cndcn from "public" as "informix";

{ TABLE "informix".cndrd row size = 140 number of columns = 5 index size = 7 }

create table "informix".cndrd 
  (
    itm_cod smallint not null ,
    dsc char(130) not null ,
    scr smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (itm_cod) 
  );

revoke all on "informix".cndrd from "public" as "informix";

{ TABLE "informix".cndss row size = 78 number of columns = 6 index size = 21 }

create table "informix".cndss 
  (
    own_no smallint not null ,
    dag_typ smallint not null ,
    nam char(12) not null ,
    dsc text not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (own_no,dag_typ,nam) 
  );

revoke all on "informix".cndss from "public" as "informix";

{ TABLE "informix".cnssp row size = 40 number of columns = 2 index size = 50 }

create table "informix".cnssp 
  (
    cod char(20) not null ,
    dsc char(20) not null ,
    primary key (dsc) 
  );

revoke all on "informix".cnssp from "public" as "informix";

{ TABLE "informix".xrrwdr row size = 45 number of columns = 13 index size = 15 }

create table "informix".xrrwdr 
  (
    typ char(3),
    map_no smallint not null ,
    chg_cod char(10),
    eff_dat date not null ,
    stp_dat date not null ,
    src char(1) not null ,
    wek_day char(1) not null ,
    sat_val smallint not null ,
    end_val smallint not null ,
    rpt_man integer 
        default 0 not null ,
    rpt_man2 integer,
    rtp integer 
        default 0 not null ,
    rtd date not null ,
    primary key (map_no,src,wek_day,eff_dat,sat_val) 
  );

revoke all on "informix".xrrwdr from "public" as "informix";

{ TABLE "informix".ositeml row size = 72 number of columns = 20 index size = 17 }

create table "informix".ositeml 
  (
    order_no integer not null ,
    seq_no smallint not null ,
    tc char(1) not null ,
    dc char(1) not null ,
    item_cod char(7) not null ,
    item_mark char(1) not null ,
    loc smallint not null ,
    usag char(20) not null ,
    tot_qty char(5) not null ,
    self_qty char(5) not null ,
    emg char(1) not null ,
    self char(1) not null ,
    chg char(1) not null ,
    prn_map char(1) not null ,
    ppf_no smallint not null ,
    prm_no integer not null ,
    map_no smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    rtl smallint not null 
  );

revoke all on "informix".ositeml from "public" as "informix";

{ TABLE "informix".oshint row size = 74 number of columns = 4 index size = 7 }

create table "informix".oshint 
  (
    dct_no smallint not null ,
    dsc text,
    see_tim datetime year to second 
        default  datetime (1899-12-31 00:00:00) year to second not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (dct_no) 
  );

revoke all on "informix".oshint from "public" as "informix";

{ TABLE "informix".hcvch row size = 52 number of columns = 9 index size = 59 }

create table "informix".hcvch 
  (
    his_no serial not null ,
    idn char(10) not null ,
    wrt_tim char(13) not null ,
    icc_typ char(2) not null ,
    vsn_nh char(4) not null ,
    btm char(1) 
        default '' not null ,
    rcm char(1) 
        default '1' not null ,
    hsp_no char(10) not null ,
    rec_tim datetime year to minute not null ,
    primary key (his_no) 
  );

revoke all on "informix".hcvch from "public" as "informix";

{ TABLE "informix".hcpst row size = 92 number of columns = 10 index size = 30 }

create table "informix".hcpst 
  (
    ccd_no integer not null ,
    seq_no smallint not null ,
    typ char(1) not null ,
    nhi_cod char(12) not null ,
    pos char(6) not null ,
    usg char(18) not null ,
    day smallint not null ,
    qty decimal(7,2) not null ,
    mrk char(2) not null ,
    pst_sign char(40) 
        default '' not null ,
    primary key (ccd_no,seq_no) 
  );

revoke all on "informix".hcpst from "public" as "informix";

{ TABLE "informix".pipvr row size = 57 number of columns = 11 index size = 43 }

create table "informix".pipvr 
  (
    chart integer not null ,
    tsc char(1) 
        default 'A' not null ,
    lnk_no integer 
        default 0 not null ,
    btm_seq char(1) not null ,
    idn char(10) not null ,
    inj_dat date 
        default  '1899/12/31' not null ,
    bat_no char(20),
    vac_seq char(1) not null ,
    exe_man integer not null ,
    rtp integer not null ,
    rtd date 
        default  '1899/12/31' not null ,
    primary key (chart,bat_no,vac_seq,inj_dat) 
  );

revoke all on "informix".pipvr from "public" as "informix";

{ TABLE "informix".pivbd row size = 70 number of columns = 2 index size = 0 }

create table "informix".pivbd 
  (
    vac_cod char(20),
    nam char(50) not null 
  );

revoke all on "informix".pivbd from "public" as "informix";

{ TABLE "informix".pibvr row size = 65 number of columns = 5 index size = 34 }

create table "informix".pibvr 
  (
    bat_no char(20),
    vac_cod char(20),
    slf_typ char(1) not null ,
    eff_dat date 
        default  '1899/12/31' not null ,
    vac_com char(20) not null 
  );

revoke all on "informix".pibvr from "public" as "informix";

{ TABLE "informix".moocl row size = 14 number of columns = 3 index size = 11 }

create table "informix".moocl 
  (
    ord_no integer not null ,
    dct_no smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ord_no,dct_no) 
  );

revoke all on "informix".moocl from "public" as "informix";

{ TABLE "informix".ucogfunc row size = 16 number of columns = 6 index size = 11 }

create table "informix".ucogfunc 
  (
    group_func_no smallint 
        default 0 not null ,
    func_no char(4) not null ,
    use_level char(2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null ,
    primary key (group_func_no,func_no) 
  );

revoke all on "informix".ucogfunc from "public" as "informix";

{ TABLE "informix".psepbdat row size = 50 number of columns = 17 index size = 42 }

create table "informix".psepbdat 
  (
    emp_no smallint not null ,
    emp_nam char(10) not null ,
    birthday date not null ,
    enter_dat date not null ,
    quit_dat date not null ,
    depart smallint not null ,
    division smallint not null ,
    titl char(2) not null ,
    rank smallint not null ,
    typ char(1) not null ,
    fil_1 char(1) not null ,
    group_func_no smallint 
        default 0 not null ,
    passwd integer not null ,
    err_times smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".psepbdat from "public" as "informix";

{ TABLE "informix".mopomr row size = 480 number of columns = 10 index size = 11 }

create table "informix".mopomr 
  (
    vsn integer not null ,
    seq_no smallint not null ,
    tsc char(1) not null ,
    rcd_dat date not null ,
    act_txt char(255) not null ,
    hpd_dat char(12) not null ,
    nct_txt char(180) not null ,
    rlt_dat char(12) not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (vsn,seq_no) 
  );

revoke all on "informix".mopomr from "public" as "informix";

{ TABLE "informix".rfhpwd row size = 26 number of columns = 4 index size = 11 }

create table "informix".rfhpwd 
  (
    hpt_no decimal(10,0) not null ,
    dct_no smallint not null ,
    pwd char(10) not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (hpt_no) 
  );

revoke all on "informix".rfhpwd from "public" as "informix";

{ TABLE "informix".dgdbd2 row size = 93 number of columns = 5 index size = 12 }

create table "informix".dgdbd2 
  (
    drg_cod char(5) not null ,
    typ char(2) not null ,
    txt char(80) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (drg_cod,typ) 
  );

revoke all on "informix".dgdbd2 from "public" as "informix";

{ TABLE "informix".mrumrt row size = 106 number of columns = 29 index size = 41 }

create table "informix".mrumrt 
  (
    evt_no serial not null ,
    reg_dat date not null ,
    reg_psn smallint not null ,
    chart integer not null ,
    dcg_dat date not null ,
    dcg_hm smallint 
        default 0 not null ,
    snd_dat date not null ,
    itm1 date not null ,
    itm2 date not null ,
    itm3 date not null ,
    itm4 date not null ,
    itm5 date not null ,
    itm6 date not null ,
    itm7 date not null ,
    itm8 date not null ,
    itm9 date not null ,
    itm10 date not null ,
    itm11 date 
        default  '1899/12/31' not null ,
    itm12 date 
        default  '1899/12/31' not null ,
    itm13 date 
        default  '1899/12/31' not null ,
    itm14 date 
        default  '1899/12/31' not null ,
    dct_r smallint not null ,
    pre_dat_r date not null ,
    don_dat_r date not null ,
    dct_v smallint not null ,
    pre_dat_v date not null ,
    don_dat_v date not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".mrumrt from "public" as "informix";

{ TABLE "informix".smdmolq row size = 12 number of columns = 6 index size = 11 }

create table "informix".smdmolq 
  (
    yymm smallint not null ,
    dct smallint not null ,
    typ char(2) not null ,
    qty_b smallint 
        default 0 not null ,
    qty_l smallint not null ,
    qty_a smallint not null ,
    primary key (yymm,dct,typ) 
  );

revoke all on "informix".smdmolq from "public" as "informix";

{ TABLE "informix".mmres row size = 16 number of columns = 3 index size = 19 }

create table "informix".mmres 
  (
    tel_no decimal(10,0) not null ,
    res_tim datetime year to second not null ,
    msg char(2) not null ,
    primary key (tel_no,res_tim) 
  );

revoke all on "informix".mmres from "public" as "informix";

{ TABLE "informix".mmcodctt row size = 136 number of columns = 4 index size = 7 }

create table "informix".mmcodctt 
  (
    sms_no smallint not null ,
    nam char(128) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (sms_no) 
  );

revoke all on "informix".mmcodctt from "public" as "informix";

{ TABLE "root".icdesc row size = 55 number of columns = 21 index size = 33 }

create table "root".icdesc 
  (
    charg_no serial not null ,
    acc_no integer not null ,
    gl_typ char(2) not null ,
    pt_typ char(2) not null ,
    room char(4) not null ,
    bed char(2) not null ,
    prescriptor smallint not null ,
    division_md smallint not null ,
    orddat smallint not null ,
    tmp char(1) not null ,
    gl_amt integer not null ,
    gl_amt_p integer not null ,
    pt_amt integer not null ,
    collect_no integer not null ,
    permit_rson char(1) not null ,
    lamp_typ char(1) not null ,
    lamp_no smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null ,
    rtl smallint not null 
  );

revoke all on "root".icdesc from "public" as "root";

{ TABLE "root".dcifqcb row size = 22 number of columns = 4 index size = 21 }

create table "root".dcifqcb 
  (
    icd_cod_m char(8) not null ,
    icd_cod_a char(8) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (icd_cod_m,icd_cod_a) 
  );

revoke all on "root".dcifqcb from "public" as "root";

{ TABLE "informix".ntdwm row size = 18 number of columns = 6 index size = 11 }

create table "informix".ntdwm 
  (
    dpt_no smallint not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    dtn_no smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (dpt_no,eff_dat) 
  );

revoke all on "informix".ntdwm from "public" as "informix";

{ TABLE "informix".mrpsr row size = 12 number of columns = 4 index size = 11 }

create table "informix".mrpsr 
  (
    chart integer not null ,
    spc_mrk smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chart,spc_mrk) 
  );

revoke all on "informix".mrpsr from "public" as "informix";

{ TABLE "informix".old_dcheccd row size = 16 number of columns = 3 index size = 17 }

create table "informix".old_dcheccd 
  (
    icd_cod_m char(6) not null ,
    icd_cod_c char(6) not null ,
    rtd date not null ,
    primary key (icd_cod_m,icd_cod_c) 
  );

revoke all on "informix".old_dcheccd from "public" as "informix";

{ TABLE "informix".ntpdadt row size = 24 number of columns = 9 index size = 17 }

create table "informix".ntpdadt 
  (
    acc_no integer not null ,
    dt_own char(1) not null ,
    f_dat date not null ,
    f_meal char(1) not null ,
    adt_mel char(1) not null ,
    adt_itm char(1) not null ,
    qty smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second,
    primary key (acc_no,dt_own,f_dat,f_meal,adt_mel,adt_itm) 
  );

revoke all on "informix".ntpdadt from "public" as "informix";

{ TABLE "informix".tddrgnfc row size = 25 number of columns = 8 index size = 12 }

create table "informix".tddrgnfc 
  (
    drg_cod char(5) not null ,
    eff_ym smallint not null ,
    stp_ym smallint not null ,
    day_avg smallint not null ,
    amt_low integer not null ,
    amt_hgh integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (drg_cod,eff_ym) 
  );

revoke all on "informix".tddrgnfc from "public" as "informix";

{ TABLE "informix".tdmdcbd row size = 130 number of columns = 6 index size = 7 }

create table "informix".tdmdcbd 
  (
    mdc char(2) not null ,
    nam_e char(80) not null ,
    nam_c char(40) not null ,
    yy smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (mdc) 
  );

revoke all on "informix".tdmdcbd from "public" as "informix";

{ TABLE "informix".tdncbd row size = 30 number of columns = 11 index size = 9 }

create table "informix".tdncbd 
  (
    mdc char(2) not null ,
    eff_ym smallint not null ,
    stp_ym smallint not null ,
    rat_m_1 decimal(3,2) not null ,
    rat_m_2 decimal(3,2) not null ,
    rat_m_3 decimal(3,2) not null ,
    rat_p_1 decimal(3,2) not null ,
    rat_p_2 decimal(3,2) not null ,
    rat_p_3 decimal(3,2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (mdc,eff_ym) 
  );

revoke all on "informix".tdncbd from "public" as "informix";

{ TABLE "informix".tddrgcn row size = 257 number of columns = 8 index size = 10 }

create table "informix".tddrgcn 
  (
    drg_cod char(5) not null ,
    nam_e char(120) not null ,
    nam_c char(120) not null ,
    div_typ char(1) not null ,
    mrk char(1) not null ,
    eff_dat date 
        default  '1899/12/31' not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (drg_cod) 
  );

revoke all on "informix".tddrgcn from "public" as "informix";

{ TABLE "informix".tdcctoc row size = 70 number of columns = 12 index size = 36 }

create table "informix".tdcctoc 
  (
    chg_cod char(7) not null ,
    opr_cod1 char(6) not null ,
    opr_cod2 char(6) not null ,
    opr_cod3 char(6) not null ,
    opr_cod4 char(6) not null ,
    bgn_dat date 
        default  '1899/12/31' not null ,
    tsc char(1) 
        default '' not null ,
    opr_cnt1 integer 
        default 0 not null ,
    pas_dat date 
        default  '1899/12/31' not null ,
    cmt char(20) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chg_cod,opr_cod1,opr_cod2,opr_cod3,opr_cod4) 
  );

revoke all on "informix".tdcctoc from "public" as "informix";

{ TABLE "informix".tdheccd row size = 20 number of columns = 4 index size = 32 }

create table "informix".tdheccd 
  (
    icd_cod_m char(6) not null ,
    icd_cod_c char(6) not null ,
    cnt integer not null ,
    rtd date not null ,
    primary key (icd_cod_m,icd_cod_c) 
  );

revoke all on "informix".tdheccd from "public" as "informix";

{ TABLE "informix".tdorc row size = 12 number of columns = 2 index size = 17 }

create table "informix".tdorc 
  (
    opr_cod1 char(6) not null ,
    opr_cod2 char(6) not null ,
    primary key (opr_cod1,opr_cod2) 
  );

revoke all on "informix".tdorc from "public" as "informix";

{ TABLE "informix".tdpdmdcr row size = 17 number of columns = 5 index size = 17 }

create table "informix".tdpdmdcr 
  (
    icd_cod char(6) not null ,
    mdc_cod char(2) not null ,
    tma char(1) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    primary key (icd_cod,mdc_cod,eff_dat) 
  );

revoke all on "informix".tdpdmdcr from "public" as "informix";

{ TABLE "informix".tddord row size = 20 number of columns = 8 index size = 16 }

create table "informix".tddord 
  (
    icd_cod char(6) not null ,
    typ char(1) not null ,
    sex_chk char(1) not null ,
    age_chk char(1) not null ,
    icd_chk char(1) not null ,
    opr_chk char(2) 
        default '' not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    primary key (icd_cod,typ,eff_dat) 
  );

revoke all on "informix".tddord from "public" as "informix";

{ TABLE "informix".tddrgjr1 row size = 42 number of columns = 13 index size = 18 }

create table "informix".tddrgjr1 
  (
    mdc_cod char(2) not null ,
    typ char(1) not null ,
    icd_cod char(6) not null ,
    jud_mrk char(1) not null ,
    jud_ref char(1) not null ,
    jud_cod char(1) not null ,
    age smallint not null ,
    drg1 char(5) not null ,
    drg2 char(5) not null ,
    drg3 char(5) not null ,
    drg4 char(5) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    primary key (mdc_cod,typ,icd_cod,eff_dat) 
  );

revoke all on "informix".tddrgjr1 from "public" as "informix";

{ TABLE "informix".tddrgjr2 row size = 45 number of columns = 12 index size = 23 }

create table "informix".tddrgjr2 
  (
    mdc_cod char(2) not null ,
    drg char(5) not null ,
    jud_ref char(1) not null ,
    icd_cod char(6) not null ,
    jud_cod char(1) not null ,
    age smallint not null ,
    drg1 char(5) not null ,
    drg2 char(5) not null ,
    drg3 char(5) not null ,
    drg4 char(5) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    primary key (mdc_cod,drg,jud_ref,icd_cod,eff_dat) 
  );

revoke all on "informix".tddrgjr2 from "public" as "informix";

{ TABLE "informix".tdccrd row size = 20 number of columns = 4 index size = 13 }

create table "informix".tdccrd 
  (
    npd_cod char(6) not null ,
    seq_no smallint not null ,
    icd_sat char(6) not null ,
    icd_end char(6) not null ,
    primary key (npd_cod,seq_no) 
  );

revoke all on "informix".tdccrd from "public" as "informix";

{ TABLE "informix".tdcnpd row size = 14 number of columns = 3 index size = 15 }

create table "informix".tdcnpd 
  (
    icd_cod char(6) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    primary key (icd_cod,eff_dat) 
  );

revoke all on "informix".tdcnpd from "public" as "informix";

{ TABLE "informix".tddrgps row size = 22 number of columns = 6 index size = 13 }

create table "informix".tddrgps 
  (
    mdc_cod char(2) not null ,
    seq_no smallint not null ,
    drg char(5) not null ,
    wgt decimal(8,4) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    primary key (mdc_cod,seq_no,eff_dat) 
  );

revoke all on "informix".tddrgps from "public" as "informix";

{ TABLE "informix".modcttgb row size = 18 number of columns = 6 index size = 11 }

create table "informix".modcttgb 
  (
    dct_no smallint not null ,
    eff_dat date not null ,
    eff_hm smallint not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (dct_no,eff_dat) 
  );

revoke all on "informix".modcttgb from "public" as "informix";

{ TABLE "informix".mrumrh row size = 21 number of columns = 7 index size = 27 }

create table "informix".mrumrh 
  (
    evt_no integer not null ,
    typ char(1) not null ,
    dct smallint not null ,
    pre_dat date not null ,
    don_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (evt_no,typ,dct,pre_dat) 
  );

revoke all on "informix".mrumrh from "public" as "informix";

{ TABLE "informix".osagr row size = 23 number of columns = 10 index size = 16 }

create table "informix".osagr 
  (
    chart integer not null ,
    visit_no decimal(11,0) not null ,
    asm_gad char(1) not null ,
    day_fre char(1) not null ,
    ngt_fre char(1) not null ,
    pef_bst char(1) not null ,
    pef_var char(1) not null ,
    act_ctl char(1) 
        default '' not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chart,visit_no) 
  );

revoke all on "informix".osagr from "public" as "informix";

{ TABLE "informix".eheer row size = 35 number of columns = 9 index size = 29 }

create table "informix".eheer 
  (
    eer_no serial not null ,
    chart integer not null ,
    frm integer not null ,
    eer_man smallint not null ,
    eer_tim datetime year to minute not null ,
    tsc char(1) 
        default 'A' not null ,
    scn char(3) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (eer_no) 
  );

revoke all on "informix".eheer from "public" as "informix";

{ TABLE "informix".ehvsr row size = 12 number of columns = 4 index size = 10 }

create table "informix".ehvsr 
  (
    eer_no integer not null ,
    vtl_itm char(1) not null ,
    way char(2),
    val decimal(6,3) not null ,
    primary key (eer_no,vtl_itm) 
  );

revoke all on "informix".ehvsr from "public" as "informix";

{ TABLE "informix".dgcdr row size = 23 number of columns = 7 index size = 14 }

create table "informix".dgcdr 
  (
    chart integer not null ,
    chg_cod char(5) not null ,
    div_no smallint not null ,
    dct_no smallint not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chart,chg_cod) 
  );

revoke all on "informix".dgcdr from "public" as "informix";

{ TABLE "informix".teeamt row size = 89 number of columns = 11 index size = 37 }

create table "informix".teeamt 
  (
    emp_no smallint not null ,
    eff_dat date not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    tel_o decimal(10,0) not null ,
    tel_i integer 
        default 0 not null ,
    typ_f char(1) not null ,
    typ char(1) not null ,
    rsn char(1) 
        default '' not null ,
    dsc char(60) 
        default '' not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (emp_no,eff_dat,tel_o) 
  );

revoke all on "informix".teeamt from "public" as "informix";

{ TABLE "informix".cgpcfamt row size = 31 number of columns = 8 index size = 18 }

create table "informix".cgpcfamt 
  (
    pt_typ char(2) not null ,
    chg_cod char(7) not null ,
    eff_dat date 
        default today not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    amt_o integer not null ,
    amt_i integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (pt_typ,chg_cod,eff_dat) 
  );

revoke all on "informix".cgpcfamt from "public" as "informix";

{ TABLE "informix".cgppi2 row size = 75 number of columns = 8 index size = 15 }

create table "informix".cgppi2 
  (
    pkg_cod char(6) not null ,
    nam char(50) not null ,
    eff_dat date 
        default today not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    typ char(1) not null ,
    pkg_amt integer not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (pkg_cod,eff_dat) 
  );

revoke all on "informix".cgppi2 from "public" as "informix";

{ TABLE "informix".zzccn row size = 80 number of columns = 5 index size = 7 }

create table "informix".zzccn 
  (
    cnt_cod char(2) not null ,
    nam char(20) not null ,
    nam_e char(52) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (cnt_cod) 
  );

revoke all on "informix".zzccn from "public" as "informix";

{ TABLE "informix".cgwfr row size = 26 number of columns = 7 index size = 9 }

create table "informix".cgwfr 
  (
    evt_num integer not null ,
    chg_cod char(7) not null ,
    eff_dat date not null ,
    dug_tsc char(1) not null ,
    mtr_tsc char(1) not null ,
    mdc_tsc char(1) not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (evt_num) 
  );

revoke all on "informix".cgwfr from "public" as "informix";

{ TABLE "informix".mompc row size = 31 number of columns = 10 index size = 18 }

create table "informix".mompc 
  (
    ser_no serial not null ,
    src char(1) not null ,
    typ char(1) not null ,
    chg_cod char(7) not null ,
    div_no smallint not null ,
    dct_no smallint not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".mompc from "public" as "informix";

{ TABLE "informix".osowsd row size = 51 number of columns = 7 index size = 16 }

create table "informix".osowsd 
  (
    chart integer not null ,
    visit_no decimal(11,0) not null ,
    chk_tim smallint not null ,
    vst_tim smallint not null ,
    cmt char(30) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chart,visit_no) 
  );

revoke all on "informix".osowsd from "public" as "informix";

{ TABLE "informix".osowss row size = 18 number of columns = 6 index size = 13 }

create table "informix".osowss 
  (
    eff_dat date not null ,
    stp_dat date not null ,
    eff_no smallint not null ,
    stp_no smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (eff_dat,stp_dat) 
  );

revoke all on "informix".osowss from "public" as "informix";

{ TABLE "informix".mrtrr row size = 16 number of columns = 4 index size = 21 }

create table "informix".mrtrr 
  (
    chart integer not null ,
    chg_cod char(7) not null ,
    rct_dat date not null ,
    rct_dsc char(1) not null ,
    primary key (chart,chg_cod,rct_dat,rct_dsc) 
  );

revoke all on "informix".mrtrr from "public" as "informix";

{ TABLE "informix".mrspp row size = 14 number of columns = 4 index size = 9 }

create table "informix".mrspp 
  (
    chart integer not null ,
    pwd integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chart) 
  );

revoke all on "informix".mrspp from "public" as "informix";

{ TABLE "informix".psctcont row size = 1071 number of columns = 7 index size = 8 }

create table "informix".psctcont 
  (
    contra_no char(3) 
        default '' not null ,
    contnt char(1000) not null ,
    secret char(1) not null ,
    typ char(1) not null ,
    cmt char(60) 
        default '' not null ,
    rtp smallint not null ,
    rtd date not null 
  );

revoke all on "informix".psctcont from "public" as "informix";

{ TABLE "informix".xrxtd row size = 22 number of columns = 5 index size = 19 }

create table "informix".xrxtd 
  (
    grp_cod char(7) not null ,
    chg_cod char(7) not null ,
    use_way char(2) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (grp_cod,chg_cod) 
  );

revoke all on "informix".xrxtd from "public" as "informix";

{ TABLE "informix".ifpil row size = 280 number of columns = 13 index size = 14 }

create table "informix".ifpil 
  (
    chart integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    dis_typ char(1) not null ,
    eff_rsn char(80) not null ,
    eff_man smallint not null ,
    ett datetime year to minute 
        default current year to minute,
    stp_rsn char(80) 
        default '' not null ,
    stp_man smallint not null ,
    stt datetime year to minute 
        default current year to minute,
    cmt char(80) 
        default '' not null ,
    rtp smallint not null ,
    rtt datetime year to minute 
        default current year to minute,
    primary key (chart,eff_dat,dis_typ) 
  );

revoke all on "informix".ifpil from "public" as "informix";

{ TABLE "informix".dgtxt row size = 65 number of columns = 3 index size = 14 }

create table "informix".dgtxt 
  (
    drg_cod char(7) not null ,
    typ char(2) not null ,
    dsc text not null ,
    primary key (drg_cod,typ) 
  );

revoke all on "informix".dgtxt from "public" as "informix";

{ TABLE "informix".dgdbd3 row size = 21 number of columns = 5 index size = 14 }

create table "informix".dgdbd3 
  (
    drg_cod char(7) not null ,
    typ char(2) not null ,
    val decimal(10,2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (drg_cod,typ) 
  );

revoke all on "informix".dgdbd3 from "public" as "informix";

{ TABLE "informix".cgrnc row size = 47 number of columns = 3 index size = 12 }

create table "informix".cgrnc 
  (
    typ smallint not null ,
    cod char(5) not null ,
    nam char(40) 
        default '' not null ,
    primary key (typ,cod) 
  );

revoke all on "informix".cgrnc from "public" as "informix";

{ TABLE "informix".ucudpr row size = 80 number of columns = 7 index size = 7 }

create table "informix".ucudpr 
  (
    emp_no smallint not null ,
    tel_o integer not null ,
    tel_bs smallint not null ,
    tel_bf decimal(10,0) not null ,
    tel_h integer not null ,
    adr char(60) not null ,
    agt smallint not null ,
    primary key (emp_no) 
  );

revoke all on "informix".ucudpr from "public" as "informix";

{ TABLE "informix".ospfer row size = 18 number of columns = 5 index size = 17 }

create table "informix".ospfer 
  (
    vsn integer not null ,
    edc_cod char(7) not null ,
    itm char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (vsn,edc_cod,itm) 
  );

revoke all on "informix".ospfer from "public" as "informix";

{ TABLE "informix".mrdrt row size = 12 number of columns = 3 index size = 17 }

create table "informix".mrdrt 
  (
    chart integer not null ,
    visit_no decimal(11,0) not null ,
    typ char(1) not null ,
    primary key (chart,visit_no,typ) 
  );

revoke all on "informix".mrdrt from "public" as "informix";

{ TABLE "informix".cgtxt row size = 65 number of columns = 3 index size = 14 }

create table "informix".cgtxt 
  (
    chg_cod char(7) not null ,
    typ char(2) not null ,
    dsc text not null ,
    primary key (chg_cod,typ) 
  );

revoke all on "informix".cgtxt from "public" as "informix";

{ TABLE "informix".morcr row size = 38 number of columns = 12 index size = 22 }

create table "informix".morcr 
  (
    rec_no serial not null ,
    chart integer not null ,
    eff_dat date 
        default today not null ,
    eff_hm smallint 
        default 0 not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    stp_hm smallint 
        default 0 not null ,
    dct_no smallint not null ,
    pgy_no smallint 
        default 0 not null ,
    pgd_no smallint 
        default 0 not null ,
    pts_no smallint 
        default 0 not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".morcr from "public" as "informix";

{ TABLE "informix".cgbit row size = 18 number of columns = 5 index size = 16 }

create table "informix".cgbit 
  (
    bqt_no integer not null ,
    chg_cod char(7) not null ,
    tsc char(1) not null ,
    qty smallint not null ,
    rtd date not null ,
    primary key (bqt_no,chg_cod) 
  );

revoke all on "informix".cgbit from "public" as "informix";

{ TABLE "informix".cgbqt2 row size = 35 number of columns = 9 index size = 29 }

create table "informix".cgbqt2 
  (
    bqt_no serial not null ,
    chart integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    bqt_gov char(2) not null ,
    bqt_amt integer not null ,
    acc_amt integer not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (bqt_no) 
  );

revoke all on "informix".cgbqt2 from "public" as "informix";

{ TABLE "informix".cgbqt row size = 43 number of columns = 11 index size = 29 }

create table "informix".cgbqt 
  (
    bqt_no serial not null ,
    chart integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    bqt_gov char(2) not null ,
    bqt_amt integer not null ,
    acc_amt integer not null ,
    dug_bqt_top integer 
        default 0 not null ,
    dug_bqt_acc integer 
        default 0 not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (bqt_no) 
  );

revoke all on "informix".cgbqt from "public" as "informix";

{ TABLE "informix".ospmh row size = 273 number of columns = 8 index size = 19 }

create table "informix".ospmh 
  (
    pmh_num serial not null ,
    tsc char(1) not null ,
    chart integer not null ,
    typ char(1) not null ,
    frv_prn char(1) not null ,
    dsc varchar(255) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (pmh_num) 
  );

revoke all on "informix".ospmh from "public" as "informix";

{ TABLE "informix".mogrpitm row size = 30 number of columns = 8 index size = 24 }

create table "informix".mogrpitm 
  (
    grp_cod char(7) not null ,
    sys char(1) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    dtl_cod char(7) not null ,
    typ char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (grp_cod,sys,eff_dat,dtl_cod) 
  );

revoke all on "informix".mogrpitm from "public" as "informix";

{ TABLE "informix".smdsolq row size = 12 number of columns = 6 index size = 11 }

create table "informix".smdsolq 
  (
    yymm smallint not null ,
    dct smallint not null ,
    typ char(2) not null ,
    qty_b smallint not null ,
    qty_l smallint not null ,
    qty_a smallint not null ,
    primary key (yymm,dct,typ) 
  );

revoke all on "informix".smdsolq from "public" as "informix";

{ TABLE "informix".mocrs row size = 23 number of columns = 7 index size = 18 }

create table "informix".mocrs 
  (
    sch_no serial not null ,
    vsn integer not null ,
    typ char(1) not null ,
    sch_dat1 integer not null ,
    sch_dat2 integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (sch_no) 
  );

revoke all on "informix".mocrs from "public" as "informix";

{ TABLE "informix".mrdnrosr row size = 31 number of columns = 7 index size = 28 }

create table "informix".mrdnrosr 
  (
    rec_no serial not null ,
    id_no char(10) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rec_sts char(1) not null ,
    rtp integer 
        default 0 not null ,
    rtd date not null ,
    primary key (rec_no) 
  );

revoke all on "informix".mrdnrosr from "public" as "informix";

{ TABLE "informix".mrdnrosc row size = 20 number of columns = 4 index size = 9 }

create table "informix".mrdnrosc 
  (
    vsn integer not null ,
    rec_no integer not null ,
    rcp integer 
        default 0 not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (vsn) 
  );

revoke all on "informix".mrdnrosc from "public" as "informix";

{ TABLE "informix".dgdcr row size = 137 number of columns = 12 index size = 18 }

create table "informix".dgdcr 
  (
    dcr_no serial not null ,
    vsn integer not null ,
    tsc char(1) not null ,
    con_typ char(1) 
        default '' not null ,
    con_man smallint not null ,
    con_tim char(1) not null ,
    con_dsc text,
    trc_man smallint not null ,
    trc_tim char(1) not null ,
    trc_dsc text,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (dcr_no) 
  );

revoke all on "informix".dgdcr from "public" as "informix";

{ TABLE "informix".dgdcct row size = 11 number of columns = 3 index size = 25 }

create table "informix".dgdcct 
  (
    dcr_no integer not null ,
    dug_cod char(5) not null ,
    con_typ smallint not null ,
    primary key (dcr_no,dug_cod,con_typ) 
  );

revoke all on "informix".dgdcct from "public" as "informix";

{ TABLE "informix".mopftm row size = 14 number of columns = 5 index size = 9 }

create table "informix".mopftm 
  (
    exm_no integer not null ,
    dct_no smallint not null ,
    dos_qty smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (exm_no) 
  );

revoke all on "informix".mopftm from "public" as "informix";

{ TABLE "informix".mopftr row size = 17 number of columns = 5 index size = 19 }

create table "informix".mopftr 
  (
    exm_no integer not null ,
    itm char(1) not null ,
    ref_val decimal(5,2) not null ,
    pre_mea decimal(5,2) not null ,
    pst_mea decimal(5,2) not null ,
    primary key (exm_no,itm) 
  );

revoke all on "informix".mopftr from "public" as "informix";

{ TABLE "informix".mrbatbor row size = 30 number of columns = 11 index size = 25 }

create table "informix".mrbatbor 
  (
    chart integer not null ,
    src_typ char(1) not null ,
    dat date not null ,
    tim smallint not null ,
    bor char(1) not null ,
    bor_man smallint not null ,
    bor_use char(1) not null ,
    tsc char(1) not null ,
    bat_num integer not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (chart,src_typ,dat,bor_man) 
  );

revoke all on "informix".mrbatbor from "public" as "informix";

{ TABLE "informix".qmamicr row size = 91 number of columns = 21 index size = 9 }

create table "informix".qmamicr 
  (
    vsn integer not null ,
    dct_no integer not null ,
    flf_nrs integer not null ,
    exp_iln char(1) not null ,
    ptn_frm char(1) not null ,
    fde_scr smallint not null ,
    fde_fix char(1) not null ,
    pan_scr smallint not null ,
    pln_way char(1) not null ,
    ner_tim datetime year to minute not null ,
    pel_tim datetime year to minute,
    arv_tim datetime year to minute not null ,
    dbl_tim datetime year to minute not null ,
    cpt_lsn char(1) not null ,
    pci_tmi char(1) not null ,
    pci_cbg char(1) not null ,
    cdc_drt char(1) not null ,
    dwt_tim datetime year to minute 
        default  datetime (2025-12-31 00:00) year to minute not null ,
    tit_dsc char(20) 
        default '' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (vsn) 
  );

revoke all on "informix".qmamicr from "public" as "informix";

{ TABLE "informix".qmamier row size = 100 number of columns = 20 index size = 9 }

create table "informix".qmamier 
  (
    vsn integer not null ,
    dct_no smallint not null ,
    flf_nrs smallint not null ,
    crd_num smallint 
        default 0 not null ,
    ctc_dgr char(1) not null ,
    adm_way char(1) not null ,
    atk_tim datetime year to minute not null ,
    arv_tim datetime year to minute not null ,
    ekg_tim datetime year to minute not null ,
    ncd_tim datetime year to minute 
        default  datetime (1899-12-31 00:00) year to minute not null ,
    nod_tim datetime year to minute 
        default  datetime (1899-12-31 00:00) year to minute not null ,
    ncn_tim datetime year to minute,
    ncp_tim datetime year to minute not null ,
    cda_tim datetime year to minute 
        default  datetime (1899-12-31 00:00) year to minute not null ,
    oda_tim datetime year to minute 
        default  datetime (1899-12-31 00:00) year to minute not null ,
    cna_tim datetime year to minute 
        default  datetime (1899-12-31 00:00) year to minute not null ,
    cpa_tim datetime year to minute 
        default  datetime (1899-12-31 00:00) year to minute not null ,
    emr_drt char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (vsn) 
  );

revoke all on "informix".qmamier from "public" as "informix";

{ TABLE "informix".qmamir2 row size = 17 number of columns = 5 index size = 12 }

create table "informix".qmamir2 
  (
    vsn integer not null ,
    itm_cls smallint not null ,
    sel_itm char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (vsn,itm_cls,sel_itm) 
  );

revoke all on "informix".qmamir2 from "public" as "informix";

{ TABLE "informix".qmothr row size = 116 number of columns = 5 index size = 11 }

create table "informix".qmothr 
  (
    vsn integer not null ,
    itm_no smallint not null ,
    oth_cmt char(100) 
        default '' not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (vsn,itm_no) 
  );

revoke all on "informix".qmothr from "public" as "informix";

{ TABLE "informix".osrec row size = 8 number of columns = 3 index size = 11 }

create table "informix".osrec 
  (
    order_no integer not null ,
    seq_no smallint not null ,
    rec_man smallint not null ,
    primary key (order_no,seq_no) 
  );

revoke all on "informix".osrec from "public" as "informix";

{ TABLE "informix".psdsdiv row size = 18 number of columns = 6 index size = 20 }

create table "informix".psdsdiv 
  (
    emp_no smallint not null ,
    div_no smallint not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (emp_no,div_no,eff_dat) 
  );

revoke all on "informix".psdsdiv from "public" as "informix";

{ TABLE "informix".pswtmd row size = 18 number of columns = 6 index size = 13 }

create table "informix".pswtmd 
  (
    div_no smallint not null ,
    emp_no smallint not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (div_no,emp_no,eff_dat) 
  );

revoke all on "informix".pswtmd from "public" as "informix";

{ TABLE "informix".eaieb row size = 74 number of columns = 5 index size = 9 }

create table "informix".eaieb 
  (
    eva_no integer not null ,
    div_no integer 
        default 0 not null ,
    eva_nam char(60) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (eva_no) 
  );

revoke all on "informix".eaieb from "public" as "informix";

{ TABLE "informix".eaeir1 row size = 94 number of columns = 17 index size = 18 }

create table "informix".eaeir1 
  (
    rec_no serial not null ,
    chart integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    eff_man smallint not null ,
    stp_man smallint not null ,
    stp_rsn char(1) 
        default '' not null ,
    ftr_nat char(1) not null ,
    mtr_nat char(1) not null ,
    ftr_edc char(1) not null ,
    mtr_edc char(1) not null ,
    cas_frm char(1) not null ,
    eva_hty char(1) not null ,
    eis_txt text not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".eaeir1 from "public" as "informix";

{ TABLE "informix".eaeir2 row size = 13 number of columns = 4 index size = 22 }

create table "informix".eaeir2 
  (
    itm_no serial not null ,
    rec_no integer not null ,
    eva_no integer not null ,
    tsc char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".eaeir2 from "public" as "informix";

{ TABLE "informix".eaeipr row size = 14 number of columns = 3 index size = 17 }

create table "informix".eaeipr 
  (
    rec_no integer not null ,
    rec_man smallint not null ,
    rec_tim datetime year to second not null ,
    primary key (rec_no,rec_tim) 
  );

revoke all on "informix".eaeipr from "public" as "informix";

{ TABLE "informix".npbfr row size = 81 number of columns = 13 index size = 9 }

create table "informix".npbfr 
  (
    vsn integer not null ,
    dty_nrs smallint not null ,
    flf_nrs smallint not null ,
    tsc char(1) not null ,
    adm_way char(1) not null ,
    mrt_sts char(1) not null ,
    rsd_sts char(1) not null ,
    edc_lvl char(1) not null ,
    ocp char(1) not null ,
    mlt char(1) 
        default '' not null ,
    fml_pdg text,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (vsn) 
  );

revoke all on "informix".npbfr from "public" as "informix";

{ TABLE "informix".npbfr2 row size = 18 number of columns = 6 index size = 13 }

create table "informix".npbfr2 
  (
    vsn integer not null ,
    itm_cls smallint not null ,
    tsc char(1) not null ,
    sel_itm char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (vsn,itm_cls,tsc,sel_itm) 
  );

revoke all on "informix".npbfr2 from "public" as "informix";

{ TABLE "informix".npfr row size = 40 number of columns = 10 index size = 29 }

create table "informix".npfr 
  (
    rec_no serial not null ,
    vsn integer not null ,
    cls_typ char(2) not null ,
    rec_sts char(1) 
        default '1' not null ,
    rec_tim datetime year to second not null ,
    rec_man smallint not null ,
    qty decimal(6,1) 
        default 0 not null ,
    itm_no integer not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".npfr from "public" as "informix";

{ TABLE "informix".npfrdi row size = 21 number of columns = 6 index size = 18 }

create table "informix".npfrdi 
  (
    di_no serial not null ,
    rec_no integer not null ,
    itm_no smallint not null ,
    tsc char(1) 
        default 'A' not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (di_no) 
  );

revoke all on "informix".npfrdi from "public" as "informix";

{ TABLE "informix".nposs row size = 25 number of columns = 3 index size = 10 }

create table "informix".nposs 
  (
    cls_typ char(1) not null ,
    itm_no integer not null ,
    oth_dsc char(20) not null ,
    primary key (cls_typ,itm_no) 
  );

revoke all on "informix".nposs from "public" as "informix";

{ TABLE "informix".npoth row size = 72 number of columns = 5 index size = 11 }

create table "informix".npoth 
  (
    vsn integer not null ,
    itm_no smallint not null ,
    oth_cmt char(60) 
        default '' not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (vsn,itm_no) 
  );

revoke all on "informix".npoth from "public" as "informix";

{ TABLE "informix".nppahr row size = 128 number of columns = 8 index size = 25 }

create table "informix".nppahr 
  (
    adm_no serial not null ,
    chart integer not null ,
    tsc char(1) not null ,
    adm_dat char(7) not null ,
    hpt_no decimal(10,0) not null ,
    adm_rsn char(100) 
        default '' not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (adm_no) 
  );

revoke all on "informix".nppahr from "public" as "informix";

{ TABLE "informix".nppecm row size = 57 number of columns = 12 index size = 20 }

create table "informix".nppecm 
  (
    ect_no serial not null ,
    chart integer not null ,
    tsc char(1) not null ,
    ect_seq smallint not null ,
    ect_nam char(12) not null ,
    ect_rlt1 char(12) 
        default '' not null ,
    ect_tlp1 integer not null ,
    ect_tlp2 integer not null ,
    ect_mbl1 integer not null ,
    ect_mbl2 integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ect_no) 
  );

revoke all on "informix".nppecm from "public" as "informix";

{ TABLE "informix".nppohr row size = 128 number of columns = 8 index size = 25 }

create table "informix".nppohr 
  (
    opr_no serial not null ,
    chart integer not null ,
    tsc char(1) not null ,
    opr_dat char(7) not null ,
    hpt_no decimal(10,0) not null ,
    opr_nam char(100) 
        default '' not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (opr_no) 
  );

revoke all on "informix".nppohr from "public" as "informix";

{ TABLE "informix".nprr row size = 64 number of columns = 6 index size = 9 }

create table "informix".nprr 
  (
    cls_typ char(2) not null ,
    itm_no smallint not null ,
    itm_nam char(50) 
        default '' not null ,
    itm_pct decimal(5,2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (cls_typ,itm_no) 
  );

revoke all on "informix".nprr from "public" as "informix";

{ TABLE "informix".mecmc row size = 111 number of columns = 13 index size = 30 }

create table "informix".mecmc 
  (
    cve_no serial not null ,
    acc_no integer not null ,
    cve_man smallint not null ,
    act_man smallint not null ,
    met_tim datetime year to minute not null ,
    met_loc char(16) not null ,
    tsc char(1) not null ,
    rpy_lmt smallint not null ,
    not_rec text,
    cls_tim datetime year to minute not null ,
    cls_rsn char(1) 
        default '' not null ,
    rtp smallint not null ,
    rtt datetime year to minute 
        default current year to minute not null ,
    primary key (cve_no) 
  );

revoke all on "informix".mecmc from "public" as "informix";

{ TABLE "informix".mecmm row size = 27 number of columns = 10 index size = 18 }

create table "informix".mecmm 
  (
    mbr_no serial not null ,
    cve_no integer not null ,
    typ char(1) not null ,
    pre_dpt smallint not null ,
    pre_man smallint not null ,
    tsc char(1) not null ,
    msg_sts char(2) not null ,
    exe_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to minute 
        default current year to minute not null ,
    primary key (mbr_no) 
  );

revoke all on "informix".mecmm from "public" as "informix";

{ TABLE "informix".meccr row size = 30 number of columns = 8 index size = 34 }

create table "informix".meccr 
  (
    ccr_no serial not null ,
    acc_no integer not null ,
    eff_tim datetime year to minute not null ,
    cse_rul char(1) not null ,
    tsc char(1) not null ,
    cve_no integer not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (ccr_no) 
  );

revoke all on "informix".meccr from "public" as "informix";

{ TABLE "informix".mecms row size = 21 number of columns = 9 index size = 18 }

create table "informix".mecms 
  (
    sch_no serial not null ,
    sch_dat date not null ,
    typ char(1) not null ,
    dpt_no smallint not null ,
    emp_no smallint not null ,
    seq char(1) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (sch_no) 
  );

revoke all on "informix".mecms from "public" as "informix";

{ TABLE "informix".moccdi row size = 20 number of columns = 8 index size = 21 }

create table "informix".moccdi 
  (
    ccd_no serial not null ,
    typ char(1) not null ,
    itm_no integer not null ,
    seq_no smallint not null ,
    tsc char(1) not null ,
    itm char(2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ccd_no) 
  );

revoke all on "informix".moccdi from "public" as "informix";

{ TABLE "informix".mrlet row size = 16 number of columns = 5 index size = 9 }

create table "informix".mrlet 
  (
    chart integer not null ,
    ent_dat date not null ,
    ent_tim smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chart) 
  );

revoke all on "informix".mrlet from "public" as "informix";

{ TABLE "informix".nhocmd row size = 16 number of columns = 5 index size = 11 }

create table "informix".nhocmd 
  (
    div_no smallint not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (div_no,eff_dat) 
  );

revoke all on "informix".nhocmd from "public" as "informix";

{ TABLE "informix".nhocmp row size = 24 number of columns = 5 index size = 19 }

create table "informix".nhocmp 
  (
    id_no char(10) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (id_no,eff_dat) 
  );

revoke all on "informix".nhocmp from "public" as "informix";

{ TABLE "informix".nppm row size = 23 number of columns = 8 index size = 17 }

create table "informix".nppm 
  (
    chart integer not null ,
    eff_dat date not null ,
    eff_hm smallint 
        default 0 not null ,
    rsn char(1) not null ,
    tsc char(1) not null ,
    rec_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to minute 
        default current year to minute,
    primary key (chart,eff_dat,eff_hm,rsn,tsc) 
  );

revoke all on "informix".nppm from "public" as "informix";

{ TABLE "informix".mocclog row size = 18 number of columns = 4 index size = 34 }

create table "informix".mocclog 
  (
    log_tim datetime year to second 
        default current year to second not null ,
    emp_no smallint not null ,
    vsn integer not null ,
    typ integer not null 
  );

revoke all on "informix".mocclog from "public" as "informix";

{ TABLE "informix".icpab row size = 28 number of columns = 11 index size = 11 }

create table "informix".icpab 
  (
    map_no smallint not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    typ char(1) not null ,
    oln_acd char(1) 
        default '2' not null ,
    pst_acd char(1) 
        default '2' not null ,
    pnt_in char(1) not null ,
    pnt_out char(1) not null ,
    lnk_num integer not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (map_no,eff_dat) 
  );

revoke all on "informix".icpab from "public" as "informix";

{ TABLE "informix".cgctr row size = 40 number of columns = 9 index size = 24 }

create table "informix".cgctr 
  (
    rec_no serial not null ,
    chart integer not null ,
    visit_no decimal(11,0) not null ,
    tst_typ char(1) not null ,
    val_old char(8) 
        default '' not null ,
    val_new char(8) 
        default '' not null ,
    rtp smallint not null ,
    rtd date not null ,
    rtl smallint not null ,
    primary key (rec_no) 
  );

revoke all on "informix".cgctr from "public" as "informix";

{ TABLE "informix".npdphra row size = 40 number of columns = 23 index size = 23 }

create table "informix".npdphra 
  (
    ast_no serial not null ,
    chart integer not null ,
    ast_dat date not null ,
    ast_tim smallint not null ,
    ast_nrs smallint not null ,
    ast_frm char(1) not null ,
    tsc char(1) 
        default '' not null ,
    age char(1) not null ,
    sen_gcs char(1) not null ,
    emv char(3) not null ,
    liv_adl char(1) not null ,
    lmb_fun char(1) not null ,
    nrp_adm char(1) not null ,
    use_rpt char(1) not null ,
    enm char(1) not null ,
    cut_cab char(1) not null ,
    car_abt char(1) not null ,
    car_typ char(1) not null ,
    lng_tub char(1) not null ,
    ast_rcv char(1) not null ,
    rsn_rcv char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ast_no) 
  );

revoke all on "informix".npdphra from "public" as "informix";

{ TABLE "informix".npfdhra row size = 31 number of columns = 16 index size = 22 }

create table "informix".npfdhra 
  (
    ast_no serial not null ,
    chart integer not null ,
    ast_dat date not null ,
    ast_tim smallint not null ,
    ast_nrs smallint not null ,
    tsc char(1) 
        default '' not null ,
    age char(1) not null ,
    fd_hst char(1) not null ,
    sns_sts char(1) not null ,
    act_sts char(1) not null ,
    ntt_sts char(1) not null ,
    sen_hnd char(1) not null ,
    slf_knw char(1) not null ,
    use_dug char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ast_no) 
  );

revoke all on "informix".npfdhra from "public" as "informix";

{ TABLE "informix".nppshra row size = 29 number of columns = 14 index size = 22 }

create table "informix".nppshra 
  (
    ast_no serial not null ,
    chart integer not null ,
    ast_dat date not null ,
    ast_tim smallint not null ,
    ast_nrs smallint not null ,
    tsc char(1) 
        default '' not null ,
    fee_lvl char(1) not null ,
    hum_lvl char(1) not null ,
    act_pwr char(1) not null ,
    trn_pwr char(1) not null ,
    ntt_sts char(1) not null ,
    fcn_cut char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ast_no) 
  );

revoke all on "informix".nppshra from "public" as "informix";

{ TABLE "informix".modcuicd row size = 24 number of columns = 7 index size = 24 }

create table "informix".modcuicd 
  (
    dcu_no serial not null ,
    typ char(2) not null ,
    div_no smallint not null ,
    icd_cod char(6) not null ,
    cnt integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (dcu_no) 
  );

revoke all on "informix".modcuicd from "public" as "informix";

{ TABLE "informix".nhdaig row size = 30 number of columns = 4 index size = 17 }

create table "informix".nhdaig 
  (
    nhi_cod char(12) not null ,
    grp_cod char(12) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (nhi_cod) 
  );

revoke all on "informix".nhdaig from "public" as "informix";

{ TABLE "informix".nhdpaipr row size = 36 number of columns = 8 index size = 33 }

create table "informix".nhdpaipr 
  (
    id_no char(10) not null ,
    apl_dat date not null ,
    grp_cod char(12) not null ,
    pos char(2) not null ,
    typ char(1) 
        default 'Y' not null ,
    sts char(1) 
        default 'A' not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (id_no,apl_dat,grp_cod,pos) 
  );

revoke all on "informix".nhdpaipr from "public" as "informix";

{ TABLE "informix".hcpirr row size = 18 number of columns = 4 index size = 17 }

create table "informix".hcpirr 
  (
    id_no char(10) not null ,
    typ char(2) not null ,
    rrd date not null ,
    rtp smallint not null ,
    primary key (id_no,typ) 
  );

revoke all on "informix".hcpirr from "public" as "informix";

{ TABLE "informix".modibd row size = 174 number of columns = 7 index size = 19 }

create table "informix".modibd 
  (
    cod char(7) not null ,
    itm char(3) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    nam char(150) 
        default '' not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (cod,itm,eff_dat) 
  );

revoke all on "informix".modibd from "public" as "informix";

{ TABLE "informix".mmreq2 row size = 160 number of columns = 10 index size = 32 }

create table "informix".mmreq2 
  (
    sed_no integer not null ,
    rcv_man smallint not null ,
    typ char(1) not null ,
    lnk_no1 integer not null ,
    lnk_no2 integer not null ,
    nrs_man smallint not null ,
    nrs_tim datetime year to minute not null ,
    exe_tim datetime year to minute not null ,
    exe_rsn char(1) not null ,
    cmt char(128) not null ,
    primary key (sed_no) 
  );

revoke all on "informix".mmreq2 from "public" as "informix";

{ TABLE "informix".npieb row size = 280 number of columns = 8 index size = 38 }

create table "informix".npieb 
  (
    eva_no serial not null ,
    div_no smallint not null ,
    msr_no char(9) not null ,
    det_no char(8) not null ,
    tbl_rel char(1) not null ,
    eva_nam char(250) 
        default '' not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (eva_no) 
  );

revoke all on "informix".npieb from "public" as "informix";

{ TABLE "informix".qmerm row size = 33 number of columns = 9 index size = 27 }

create table "informix".qmerm 
  (
    rec_no serial not null ,
    vsn integer not null ,
    frm_no integer not null ,
    frm char(1) not null ,
    tsc char(1) not null ,
    rec_tim datetime year to minute not null ,
    rec_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".qmerm from "public" as "informix";

{ TABLE "informix".qmged row size = 13 number of columns = 4 index size = 22 }

create table "informix".qmged 
  (
    itm_no serial not null ,
    rec_no integer not null ,
    eva_no integer not null ,
    eva_sts char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".qmged from "public" as "informix";

{ TABLE "informix".qmhss row size = 36 number of columns = 22 index size = 18 }

create table "informix".qmhss 
  (
    hss_no serial not null ,
    frm_no integer not null ,
    typ char(1) not null ,
    tsc char(1) not null ,
    hss_1a char(1) not null ,
    hss_1b char(1) not null ,
    hss_1c char(1) not null ,
    hss_2 char(1) not null ,
    hss_3 char(1) not null ,
    hss_4 char(1) not null ,
    hss_5a char(1) not null ,
    hss_5b char(1) not null ,
    hss_6a char(1) not null ,
    hss_6b char(1) not null ,
    hss_7 char(1) not null ,
    hss_8 char(1) not null ,
    hss_9 char(1) not null ,
    hss_10 char(1) not null ,
    hss_11 char(1) not null ,
    mrs char(1) 
        default '' not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (hss_no) 
  );

revoke all on "informix".qmhss from "public" as "informix";

{ TABLE "informix".qmols row size = 124 number of columns = 2 index size = 9 }

create table "informix".qmols 
  (
    itm_no integer not null ,
    oth_dsc char(120),
    primary key (itm_no) 
  );

revoke all on "informix".qmols from "public" as "informix";

{ TABLE "informix".qmoss row size = 24 number of columns = 2 index size = 9 }

create table "informix".qmoss 
  (
    itm_no integer not null ,
    oth_dsc char(20) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".qmoss from "public" as "informix";

{ TABLE "informix".qmqrl row size = 18 number of columns = 4 index size = 18 }

create table "informix".qmqrl 
  (
    log_no serial not null ,
    itm_no integer not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (log_no) 
  );

revoke all on "informix".qmqrl from "public" as "informix";

{ TABLE "informix".qmserd row size = 160 number of columns = 34 index size = 18 }

create table "informix".qmserd 
  (
    rec_no serial not null ,
    vsn integer not null ,
    tsc char(1) not null ,
    crd_num smallint 
        default 0 not null ,
    ill_tim datetime year to minute not null ,
    arv_tim datetime year to minute not null ,
    fds_tim datetime year to minute 
        default  datetime (1899-12-31 00:00) year to minute not null ,
    cva_3hr char(1) not null ,
    gcs char(3) not null ,
    tpt char(5) not null ,
    pls smallint not null ,
    btr smallint not null ,
    sps char(5) not null ,
    dps char(5) not null ,
    cto_tim datetime year to minute not null ,
    cte_tim datetime year to minute not null ,
    tmb_rgl char(1) not null ,
    ndv char(1) not null ,
    nte_tim datetime year to minute not null ,
    ndv_tim datetime year to minute not null ,
    eok_tim datetime year to minute not null ,
    ijt_tpa char(1) not null ,
    rtm_tim datetime year to minute not null ,
    atm_tim datetime year to minute not null ,
    lbo_tim datetime year to minute not null ,
    lbr_tim datetime year to minute not null ,
    tpa_tim datetime year to minute not null ,
    ijt_tim datetime year to minute not null ,
    tpa_bds char(5) not null ,
    tpa_tds char(5) not null ,
    bld char(1) not null ,
    lnk_no integer not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".qmserd from "public" as "informix";

{ TABLE "informix".qmsicr row size = 36 number of columns = 16 index size = 27 }

create table "informix".qmsicr 
  (
    rec_no serial not null ,
    vsn integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    stp_rsn char(1) not null ,
    lpd char(1) not null ,
    ecg char(1) not null ,
    acl_in char(1) not null ,
    trb_in char(1) not null ,
    dsd_in char(1) not null ,
    acl_out char(1) not null ,
    trb_out char(1) not null ,
    dsd_out char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".qmsicr from "public" as "informix";

{ TABLE "informix".moilar row size = 237 number of columns = 13 index size = 24 }

create table "informix".moilar 
  (
    icu_no serial not null ,
    acc_no integer not null ,
    in_dat date not null ,
    in_hm smallint not null ,
    room char(4) not null ,
    bed char(2) not null ,
    rec_days smallint not null ,
    dct_man smallint not null ,
    rcd_man smallint not null ,
    tsc char(1) not null ,
    sol_mtd char(200) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (icu_no) 
  );

revoke all on "informix".moilar from "public" as "informix";

{ TABLE "informix".moilaod row size = 104 number of columns = 2 index size = 9 }

create table "informix".moilaod 
  (
    itm_no integer not null ,
    oth_dsc char(100) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".moilaod from "public" as "informix";

{ TABLE "informix".moilari row size = 23 number of columns = 7 index size = 18 }

create table "informix".moilari 
  (
    itm_no serial not null ,
    icu_no integer not null ,
    tsc char(1) not null ,
    typ char(1) not null ,
    itm char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (itm_no) 
  );

revoke all on "informix".moilari from "public" as "informix";

{ TABLE "informix".mmcai row size = 44 number of columns = 9 index size = 18 }

create table "informix".mmcai 
  (
    itm_no serial not null ,
    set_no integer not null ,
    itm_typ smallint not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    val_hgh char(5) not null ,
    val_low char(5) not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (set_no,itm_typ,eff_tim) 
  );

revoke all on "informix".mmcai from "public" as "informix";

{ TABLE "informix".mmcap row size = 32 number of columns = 7 index size = 18 }

create table "informix".mmcap 
  (
    set_no integer not null ,
    ctt_typ smallint not null ,
    ctt_man smallint not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (set_no,ctt_typ,eff_tim) 
  );

revoke all on "informix".mmcap from "public" as "informix";

{ TABLE "informix".mmcam row size = 37 number of columns = 9 index size = 19 }

create table "informix".mmcam 
  (
    set_no serial not null ,
    typ char(1) not null ,
    typ_no integer not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    eff_man smallint not null ,
    stp_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (set_no) 
  );

revoke all on "informix".mmcam from "public" as "informix";

{ TABLE "informix".dgpar row size = 27 number of columns = 8 index size = 31 }

create table "informix".dgpar 
  (
    par_no serial not null ,
    chart integer 
        default 0 not null ,
    vsn integer not null ,
    tsc char(1) 
        default '' not null ,
    drg_dat date not null ,
    par_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (par_no) 
  );

revoke all on "informix".dgpar from "public" as "informix";

{ TABLE "informix".dgpad row size = 18 number of columns = 6 index size = 20 }

create table "informix".dgpad 
  (
    par_no integer not null ,
    seq_no smallint not null ,
    rlt char(1) not null ,
    cod char(5) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (par_no,seq_no) 
  );

revoke all on "informix".dgpad from "public" as "informix";

{ TABLE "informix".dgpadsc row size = 73 number of columns = 6 index size = 20 }

create table "informix".dgpadsc 
  (
    par_no integer not null ,
    seq_no smallint not null ,
    rlt char(1) not null ,
    dsc char(60) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (par_no,seq_no) 
  );

revoke all on "informix".dgpadsc from "public" as "informix";

{ TABLE "informix".smedos row size = 16 number of columns = 6 index size = 11 }

create table "informix".smedos 
  (
    yymm integer not null ,
    dct smallint not null ,
    qty_o smallint not null ,
    qty_t smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (yymm,dct) 
  );

revoke all on "informix".smedos from "public" as "informix";

{ TABLE "informix".mrqar row size = 20 number of columns = 4 index size = 15 }

create table "informix".mrqar 
  (
    chart integer not null ,
    dat date not null ,
    typ char(2) not null ,
    val char(10),
    primary key (chart,dat,typ) 
  );

revoke all on "informix".mrqar from "public" as "informix";

{ TABLE "informix".oscphc row size = 63 number of columns = 14 index size = 9 }

create table "informix".oscphc 
  (
    cph_no serial not null ,
    vsn integer not null ,
    tsc char(1) not null ,
    typ char(1) not null ,
    hgh decimal(4,1) not null ,
    wgh decimal(3,1) not null ,
    hc decimal(3,1) not null ,
    hlt_est char(1) not null ,
    grw_est char(1) not null ,
    bdy_chk char(1) not null ,
    dvp_est char(1) not null ,
    spc_mrk char(30) 
        default '' not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (vsn) 
  );

revoke all on "informix".oscphc from "public" as "informix";

{ TABLE "informix".oscphaitm row size = 7 number of columns = 2 index size = 12 }

create table "informix".oscphaitm 
  (
    cph_no integer not null ,
    cod char(3) not null ,
    primary key (cph_no,cod) 
  );

revoke all on "informix".oscphaitm from "public" as "informix";

{ TABLE "informix".cgnam row size = 95 number of columns = 5 index size = 14 }

create table "informix".cgnam 
  (
    chg_cod char(7) not null ,
    typ char(2) not null ,
    nam char(80) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chg_cod,typ) 
  );

revoke all on "informix".cgnam from "public" as "informix";

{ TABLE "informix".moval row size = 12 number of columns = 4 index size = 11 }

create table "informix".moval 
  (
    lnk_num integer not null ,
    seq_no smallint not null ,
    typ char(2) not null ,
    val integer not null ,
    primary key (lnk_num,seq_no) 
  );

revoke all on "informix".moval from "public" as "informix";

{ TABLE "informix".cgcid row size = 33 number of columns = 6 index size = 20 }

create table "informix".cgcid 
  (
    cid_no serial not null ,
    charg_no integer not null ,
    seq_no smallint not null ,
    vit_typ char(1) not null ,
    rec_typ char(2) not null ,
    rec_dat char(20) not null ,
    primary key (cid_no) 
  );

revoke all on "informix".cgcid from "public" as "informix";

{ TABLE "informix".meacr row size = 101 number of columns = 13 index size = 27 }

create table "informix".meacr 
  (
    acr_no serial not null ,
    src char(1) 
        default 'I',
    lnk_no integer not null ,
    tsc char(1) not null ,
    acr_man smallint not null ,
    acr_rul char(1) not null ,
    acr_dsc char(60) 
        default '' not null ,
    acr_tim datetime year to minute not null ,
    tch_cse char(1) 
        default '' not null ,
    rcv_no integer not null ,
    rcv_tim datetime year to minute not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (acr_no) 
  );

revoke all on "informix".meacr from "public" as "informix";

{ TABLE "informix".mecmr row size = 114 number of columns = 13 index size = 30 }

create table "informix".mecmr 
  (
    rcv_no serial not null ,
    src char(1) 
        default 'I',
    lnk_no integer not null ,
    hst_man smallint 
        default 0 not null ,
    cvn_man smallint not null ,
    met_loc char(20) not null ,
    met_txt text,
    met_tim datetime year to minute not null ,
    tsc char(1) not null ,
    cls_rsn char(1) 
        default '' not null ,
    cls_tim datetime year to minute not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (rcv_no) 
  );

revoke all on "informix".mecmr from "public" as "informix";

{ TABLE "informix".mecmp row size = 41 number of columns = 9 index size = 18 }

create table "informix".mecmp 
  (
    psn_no serial not null ,
    rcv_no integer not null ,
    pre_man char(10),
    exe_man char(10),
    typ char(2) 
        default '' not null ,
    eat char(1) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (psn_no) 
  );

revoke all on "informix".mecmp from "public" as "informix";

{ TABLE "informix".megmc row size = 22 number of columns = 8 index size = 18 }

create table "informix".megmc 
  (
    rcd_no serial not null ,
    rcv_no integer not null ,
    tsc char(1) not null ,
    days smallint not null ,
    est char(1) not null ,
    sgt char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (rcd_no) 
  );

revoke all on "informix".megmc from "public" as "informix";

{ TABLE "informix".mesrr row size = 75 number of columns = 24 index size = 18 }

create table "informix".mesrr 
  (
    rcd_no serial not null ,
    rcv_no integer not null ,
    sex char(1) 
        default '' not null ,
    age char(1) 
        default '' not null ,
    typ char(20) 
        default '' not null ,
    mut_div char(1) 
        default '' not null ,
    tsc char(1) not null ,
    dct_atd char(1) not null ,
    nrs_atd char(1) not null ,
    oth_atd char(1) not null ,
    oth_psn char(20) not null ,
    pat_lis char(1) not null ,
    dtl_see char(1) not null ,
    pfn_abt char(1) not null ,
    trt_ste char(1) not null ,
    asp_pvt char(1) not null ,
    idl_hdl char(1) not null ,
    cpl_hdl char(1) not null ,
    cms_dos char(1) 
        default '' not null ,
    cms_pud char(1) 
        default '' not null ,
    cms_utp char(1) 
        default '' not null ,
    cms_ncp char(1) 
        default '' not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (rcd_no) 
  );

revoke all on "informix".mesrr from "public" as "informix";

{ TABLE "informix".emtemr row size = 39 number of columns = 9 index size = 34 }

create table "informix".emtemr 
  (
    emr_no serial not null ,
    emr_typ char(2) not null ,
    lnk_no integer not null ,
    cmp_man smallint not null ,
    cmp_tim datetime year to second not null ,
    tsc char(1) not null ,
    tsf_tim datetime year to second not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (emr_no) 
  );

revoke all on "informix".emtemr from "public" as "informix";

{ TABLE "informix".qmcpr row size = 19 number of columns = 5 index size = 19 }

create table "informix".qmcpr 
  (
    rcd_no serial not null ,
    acc_no integer not null ,
    typ char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rcd_no) 
  );

revoke all on "informix".qmcpr from "public" as "informix";

{ TABLE "informix".moipar row size = 30 number of columns = 10 index size = 28 }

create table "informix".moipar 
  (
    evt_no serial not null ,
    itm_no integer not null ,
    act_typ char(1) not null ,
    sts char(1) 
        default '' not null ,
    act_man smallint not null ,
    act_dat date 
        default today not null ,
    act_hm smallint 
        default 0 not null ,
    act_loc smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (evt_no) 
  );

revoke all on "informix".moipar from "public" as "informix";

{ TABLE "informix".mocdtc row size = 25 number of columns = 6 index size = 20 }

create table "informix".mocdtc 
  (
    itm_cod1 char(7) not null ,
    itm_cod2 char(7) not null ,
    tc char(1) not null ,
    ratio decimal(6,2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (itm_cod1,itm_cod2,tc) 
  );

revoke all on "informix".mocdtc from "public" as "informix";

{ TABLE "informix".mocori row size = 578 number of columns = 7 index size = 12 }

create table "informix".mocori 
  (
    ptc_cod char(7) not null ,
    tc char(1) not null ,
    itm_nam char(50) not null ,
    tmt_cyc char(255) not null ,
    idc_lst char(255) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (ptc_cod) 
  );

revoke all on "informix".mocori from "public" as "informix";

{ TABLE "informix".mocodi row size = 309 number of columns = 28 index size = 62 }

create table "informix".mocodi 
  (
    ptc_no serial not null ,
    ptc_cod char(7) not null ,
    seq_no smallint not null ,
    typ char(1) not null ,
    itm_cod char(7) not null ,
    itm_grp char(1) not null ,
    eff_tim datetime year to second not null ,
    stp_tim datetime year to second not null ,
    dos_qty char(5) not null ,
    dos_unt char(5) not null ,
    use_usg char(6) not null ,
    day smallint not null ,
    dly_day smallint not null ,
    way char(6) not null ,
    spd char(30) not null ,
    cmt char(160) 
        default '' not null ,
    drp_cod char(7) not null ,
    int_drp char(1) not null ,
    drp_way char(2) not null ,
    dlt_vlm char(5) not null ,
    dlt_unt char(5) not null ,
    max_qty char(5) not null ,
    one_qty char(5) not null ,
    llg_qty char(5) not null ,
    low_dlt char(5) not null ,
    hgh_dlt char(5) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (ptc_no) 
  );

revoke all on "informix".mocodi from "public" as "informix";

{ TABLE "informix".mocdqo row size = 29 number of columns = 7 index size = 17 }

create table "informix".mocdqo 
  (
    itm_cod char(7) not null ,
    low_qty char(5) not null ,
    hgh_qty char(5) not null ,
    tc char(1) not null ,
    inc_qty char(5) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (itm_cod,low_qty) 
  );

revoke all on "informix".mocdqo from "public" as "informix";

{ TABLE "informix".moppr row size = 17 number of columns = 5 index size = 15 }

create table "informix".moppr 
  (
    rec_tim datetime year to second 
        default current year to second not null ,
    emp_no smallint not null ,
    fun_no char(4) not null ,
    loc_no smallint not null ,
    rec_typ char(1) not null ,
    primary key (rec_tim,emp_no) 
  );

revoke all on "informix".moppr from "public" as "informix";

{ TABLE "informix".dgingc row size = 66 number of columns = 9 index size = 32 }

create table "informix".dgingc 
  (
    dug_cod char(7) not null ,
    ing char(20) not null ,
    tsc char(1) not null ,
    tot decimal(10,3) not null ,
    tot_unt char(10) not null ,
    vlm decimal(6,1) not null ,
    vlm_unt char(10) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (dug_cod,ing) 
  );

revoke all on "informix".dgingc from "public" as "informix";

{ TABLE "informix".mools3 row size = 105 number of columns = 3 index size = 10 }

create table "informix".mools3 
  (
    itm_no integer not null ,
    cls_typ char(1) not null ,
    oth_dsc char(100) not null ,
    primary key (itm_no,cls_typ) 
  );

revoke all on "informix".mools3 from "public" as "informix";

{ TABLE "informix".moieb row size = 22 number of columns = 8 index size = 19 }

create table "informix".moieb 
  (
    itm_no serial not null ,
    rec_no integer not null ,
    cls_typ char(1) not null ,
    itm char(1) not null ,
    val char(1) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (itm_no) 
  );

revoke all on "informix".moieb from "public" as "informix";

{ TABLE "informix".mored row size = 21 number of columns = 7 index size = 19 }

create table "informix".mored 
  (
    rec_no serial not null ,
    vsn integer not null ,
    cls_typ char(1) not null ,
    rsn char(1) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".mored from "public" as "informix";

{ TABLE "informix".cgflag row size = 24 number of columns = 7 index size = 18 }

create table "informix".cgflag 
  (
    chg_cod char(7) not null ,
    typ char(2) not null ,
    eff_dat date not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    sts char(1) not null ,
    rtp smallint 
        default 0 not null ,
    rtd date 
        default  '1899/12/31' not null ,
    primary key (chg_cod,typ,eff_dat) 
  );

revoke all on "informix".cgflag from "public" as "informix";

{ TABLE "informix".nperm row size = 37 number of columns = 9 index size = 32 }

create table "informix".nperm 
  (
    rec_no serial not null ,
    vsn integer not null ,
    frq char(1) not null ,
    tsc char(1) not null ,
    lnk_no integer 
        default 0 not null ,
    rec_tim datetime year to minute not null ,
    rec_man integer not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".nperm from "public" as "informix";

{ TABLE "informix".npdds row size = 9 number of columns = 3 index size = 10 }

create table "informix".npdds 
  (
    cls_typ char(1) not null ,
    itm_no integer not null ,
    dat date not null ,
    primary key (cls_typ,itm_no) 
  );

revoke all on "informix".npdds from "public" as "informix";

{ TABLE "informix".npiebom row size = 18 number of columns = 6 index size = 27 }

create table "informix".npiebom 
  (
    eva_no integer not null ,
    typ char(1) not null ,
    own_no char(5) not null ,
    seq_no smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (eva_no,typ,own_no) 
  );

revoke all on "informix".npiebom from "public" as "informix";

{ TABLE "informix".npols row size = 125 number of columns = 3 index size = 10 }

create table "informix".npols 
  (
    cls_typ char(1) not null ,
    itm_no integer not null ,
    oth_dsc char(120) not null ,
    primary key (cls_typ,itm_no) 
  );

revoke all on "informix".npols from "public" as "informix";

{ TABLE "informix".nprf row size = 89 number of columns = 9 index size = 26 }

create table "informix".nprf 
  (
    rec_no serial not null ,
    vsn integer not null ,
    nqu_no integer 
        default 0 not null ,
    rec_man smallint not null ,
    rec_tim datetime year to second not null ,
    rec_sts char(1) not null ,
    rec_txt text not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".nprf from "public" as "informix";

{ TABLE "informix".npder row size = 10 number of columns = 4 index size = 13 }

create table "informix".npder 
  (
    nqu_no integer not null ,
    typ char(1) not null ,
    eva_no integer not null ,
    eva_sts char(1) not null ,
    primary key (nqu_no,eva_no) 
  );

revoke all on "informix".npder from "public" as "informix";

{ TABLE "informix".npged row size = 13 number of columns = 4 index size = 22 }

create table "informix".npged 
  (
    itm_no serial not null ,
    rec_no integer not null ,
    eva_no integer not null ,
    eva_sts char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".npged from "public" as "informix";

{ TABLE "informix".npnrl row size = 19 number of columns = 5 index size = 19 }

create table "informix".npnrl 
  (
    log_no serial not null ,
    rec_typ char(1) not null ,
    itm_no integer not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (log_no) 
  );

revoke all on "informix".npnrl from "public" as "informix";

{ TABLE "informix".npqbd row size = 42 number of columns = 11 index size = 25 }

create table "informix".npqbd 
  (
    nqu_no serial not null ,
    vsn integer not null ,
    frm_no integer 
        default 0 not null ,
    eff_man smallint not null ,
    eff_tim datetime year to minute not null ,
    tsc char(1) not null ,
    typ char(1) not null ,
    stp_man smallint not null ,
    stp_tim datetime year to minute not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (nqu_no) 
  );

revoke all on "informix".npqbd from "public" as "informix";

{ TABLE "informix".oritmlog row size = 34 number of columns = 12 index size = 18 }

create table "informix".oritmlog 
  (
    ord_no integer not null ,
    opr_ord integer not null ,
    dat_s date not null ,
    thm_s smallint not null ,
    dat_e date not null ,
    thm_e smallint not null ,
    mark char(1) not null ,
    opr_typ char(1) not null ,
    o_i char(1) not null ,
    ane_typ char(1) 
        default '' not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (ord_no) 
  );

revoke all on "informix".oritmlog from "public" as "informix";

{ TABLE "informix".orexec2 row size = 30 number of columns = 8 index size = 18 }

create table "informix".orexec2 
  (
    rec_no serial not null ,
    ord_no integer not null ,
    typ char(1) not null ,
    eff_tim datetime year to second 
        default current year to second,
    emp_no smallint not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".orexec2 from "public" as "informix";

{ TABLE "informix".cgidcv row size = 28 number of columns = 8 index size = 18 }

create table "informix".cgidcv 
  (
    chg_cod char(7) not null ,
    typ char(2) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    way char(1) not null ,
    val integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chg_cod,typ,eff_dat) 
  );

revoke all on "informix".cgidcv from "public" as "informix";

{ TABLE "informix".cgidct row size = 168 number of columns = 5 index size = 7 }

create table "informix".cgidct 
  (
    typ char(2) not null ,
    nam char(60) not null ,
    cmt char(100) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (typ) 
  );

revoke all on "informix".cgidct from "public" as "informix";

{ TABLE "informix".npsvr row size = 43 number of columns = 9 index size = 26 }

create table "informix".npsvr 
  (
    rec_no serial not null ,
    vsn integer not null ,
    itm_no integer not null ,
    val char(10) not null ,
    rec_tim datetime year to second not null ,
    rec_man smallint not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".npsvr from "public" as "informix";

{ TABLE "informix".npsvir row size = 132 number of columns = 6 index size = 9 }

create table "informix".npsvir 
  (
    itm_no integer not null ,
    itm_nam char(100) not null ,
    itm_unt char(12) 
        default '' not null ,
    lvl char(10) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (itm_no) 
  );

revoke all on "informix".npsvir from "public" as "informix";

{ TABLE "informix".sdrsc row size = 51 number of columns = 9 index size = 9 }

create table "informix".sdrsc 
  (
    rsc_num serial not null ,
    rsc_typ smallint not null ,
    ppt_no integer not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    nam char(20) not null ,
    sts char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (rsc_num) 
  );

revoke all on "informix".sdrsc from "public" as "informix";

{ TABLE "informix".sdmis row size = 61 number of columns = 6 index size = 18 }

create table "informix".sdmis 
  (
    mis_num serial not null ,
    rsc_num integer not null ,
    nam char(45) not null ,
    cst_tim smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (mis_num) 
  );

revoke all on "informix".sdmis from "public" as "informix";

{ TABLE "informix".sdrule row size = 50 number of columns = 9 index size = 67 }

create table "informix".sdrule 
  (
    rul_num serial not null ,
    lnk_num integer not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    typ char(2) not null ,
    sat_val char(10) not null ,
    end_val char(10) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (rul_num) 
  );

revoke all on "informix".sdrule from "public" as "informix";

{ TABLE "informix".sdcal row size = 1060 number of columns = 13 index size = 87 }

create table "informix".sdcal 
  (
    evt_num serial not null ,
    tsc char(1) not null ,
    sub char(20) not null ,
    lnk_typ char(1) not null ,
    lnk_num integer not null ,
    mis_num integer not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    emp_no smallint not null ,
    pmt char(1) not null ,
    coment char(1000) 
        default '' not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (evt_num) 
  );

revoke all on "informix".sdcal from "public" as "informix";

{ TABLE "informix".emerda row size = 39 number of columns = 10 index size = 23 }

create table "informix".emerda 
  (
    emr_no serial not null ,
    act_dat date not null ,
    emr_typ char(3) 
        default '' not null ,
    map_no smallint not null ,
    his_cnt integer not null ,
    hte_cnt integer not null ,
    emr_cnt integer not null ,
    snt_cnt integer not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (emr_no) 
  );

revoke all on "informix".emerda from "public" as "informix";

{ TABLE "informix".nppfdhra row size = 29 number of columns = 14 index size = 22 }

create table "informix".nppfdhra 
  (
    ast_no serial not null ,
    chart integer not null ,
    ast_dat date not null ,
    ast_tim smallint not null ,
    ast_nrs smallint not null ,
    tsc char(1) not null ,
    age char(1) not null ,
    dis_fac char(1) not null ,
    fd_hst char(1) not null ,
    env_fct char(1) not null ,
    or_sts char(1) not null ,
    use_dug char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ast_no) 
  );

revoke all on "informix".nppfdhra from "public" as "informix";

{ TABLE "informix".dglleqr row size = 30 number of columns = 8 index size = 25 }

create table "informix".dglleqr 
  (
    evt_no serial not null ,
    chart integer not null ,
    chg_cod char(7) not null ,
    tc char(1) not null ,
    ord_dat date not null ,
    ord_man smallint not null ,
    exe_qty decimal(5,1) not null ,
    rtd date not null ,
    primary key (evt_no) 
  );

revoke all on "informix".dglleqr from "public" as "informix";

{ TABLE "informix".moicda row size = 456 number of columns = 8 index size = 16 }

create table "informix".moicda 
  (
    icd_no serial not null ,
    dpt_no smallint not null ,
    icd_nam char(255) not null ,
    icd_cod char(128) not null ,
    icd_acd text,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (icd_no) 
  );

revoke all on "informix".moicda from "public" as "informix";

{ TABLE "informix".molleqr row size = 30 number of columns = 8 index size = 25 }

create table "informix".molleqr 
  (
    evt_no serial not null ,
    vsn integer not null ,
    chg_cod char(7) not null ,
    tc char(1) not null ,
    ord_dat date not null ,
    ord_man smallint not null ,
    exe_qty decimal(5,1) not null ,
    rtd date not null ,
    primary key (evt_no) 
  );

revoke all on "informix".molleqr from "public" as "informix";

{ TABLE "informix".mrptar row size = 30 number of columns = 8 index size = 9 }

create table "informix".mrptar 
  (
    apl_no serial not null ,
    typ char(1) not null ,
    lnk_no integer not null ,
    tsc char(1) not null ,
    apl_man smallint not null ,
    apl_tim datetime year to second not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (apl_no) 
  );

revoke all on "informix".mrptar from "public" as "informix";

{ TABLE "informix".scptv row size = 22 number of columns = 7 index size = 22 }

create table "informix".scptv 
  (
    ptv_no serial not null ,
    scp_no integer not null ,
    ptv_dat date not null ,
    tsc char(1) not null ,
    ptv_rlt char(3) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (ptv_no) 
  );

revoke all on "informix".scptv from "public" as "informix";

{ TABLE "informix".mocodif row size = 316 number of columns = 31 index size = 78 }

create table "informix".mocodif 
  (
    ptc_no serial not null ,
    cri_no integer not null ,
    ptc_cod char(7) not null ,
    seq_no smallint not null ,
    seq_mrk char(1) 
        default '' not null ,
    typ char(1) not null ,
    itm_cod char(7) not null ,
    itm_grp char(1) not null ,
    eff_tim datetime year to second not null ,
    stp_tim datetime year to second not null ,
    dos_qty char(5) not null ,
    dos_unt char(5) not null ,
    use_usg char(6) not null ,
    day smallint not null ,
    dly_day smallint not null ,
    way char(6) not null ,
    spd char(30) not null ,
    inj_spd smallint 
        default 0 not null ,
    cmt char(160) not null ,
    drp_cod char(7) not null ,
    int_drp char(1) not null ,
    drp_way char(2) not null ,
    dlt_vlm char(5) not null ,
    dlt_unt char(5) not null ,
    max_qty char(5) not null ,
    one_qty char(5) not null ,
    llg_qty char(5) not null ,
    low_dlt char(5) not null ,
    hgh_dlt char(5) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (ptc_no) 
  );

revoke all on "informix".mocodif from "public" as "informix";

{ TABLE "informix".bmval row size = 11 number of columns = 3 index size = 11 }

create table "informix".bmval 
  (
    acc_no integer not null ,
    typ char(2) not null ,
    val decimal(7,2) 
        default 0 not null ,
    primary key (acc_no,typ) 
  );

revoke all on "informix".bmval from "public" as "informix";

{ TABLE "informix".qmcadrm row size = 30 number of columns = 8 index size = 20 }

create table "informix".qmcadrm 
  (
    rec_no serial not null ,
    vsn integer not null ,
    rec_typ char(2) not null ,
    tsc char(1) not null ,
    rec_tim datetime year to minute not null ,
    rec_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".qmcadrm from "public" as "informix";

{ TABLE "informix".qmcadrd row size = 13 number of columns = 4 index size = 22 }

create table "informix".qmcadrd 
  (
    itm_no serial not null ,
    rec_no integer not null ,
    eva_no integer not null ,
    eva_sts char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".qmcadrd from "public" as "informix";

{ TABLE "informix".uccwc row size = 28 number of columns = 7 index size = 27 }

create table "informix".uccwc 
  (
    rec_no serial not null ,
    ccp_no integer not null ,
    crd_loc char(1) not null ,
    crd_tim datetime year to second not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".uccwc from "public" as "informix";

{ TABLE "informix".ucccp row size = 27 number of columns = 6 index size = 33 }

create table "informix".ucccp 
  (
    ccp_no serial not null ,
    typ char(1) not null ,
    cod char(10) not null ,
    num smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (ccp_no) 
  );

revoke all on "informix".ucccp from "public" as "informix";

{ TABLE "informix".ocoditm2 row size = 10 number of columns = 3 index size = 20 }

create table "informix".ocoditm2 
  (
    cit_no serial not null ,
    charg_no integer not null ,
    seq_no smallint not null ,
    primary key (cit_no) 
  );

revoke all on "informix".ocoditm2 from "public" as "informix";

{ TABLE "informix".ucusb row size = 43 number of columns = 8 index size = 20 }

create table "informix".ucusb 
  (
    rec_no serial not null ,
    emp_no smallint not null ,
    fun_cod char(4) not null ,
    itm_nam char(20) not null ,
    tsc char(1) not null ,
    seq_no smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".ucusb from "public" as "informix";

{ TABLE "informix".ofdedd row size = 20 number of columns = 7 index size = 20 }

create table "informix".ofdedd 
  (
    ser_no serial not null ,
    dat date not null ,
    dct smallint not null ,
    rdr smallint not null ,
    nsp smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".ofdedd from "public" as "informix";

{ TABLE "informix".psemrnsr row size = 17 number of columns = 6 index size = 16 }

create table "informix".psemrnsr 
  (
    evt_no serial not null ,
    emp_no smallint not null ,
    qit_dat date not null ,
    sgn_sts char(1) 
        default 'N' not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (evt_no) 
  );

revoke all on "informix".psemrnsr from "public" as "informix";

{ TABLE "informix".mopadr row size = 143 number of columns = 7 index size = 9 }

create table "informix".mopadr 
  (
    anc_no serial not null ,
    ptc_no integer not null ,
    val integer not null ,
    rsn char(120) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (anc_no) 
  );

revoke all on "informix".mopadr from "public" as "informix";

{ TABLE "informix".mopcot row size = 36 number of columns = 10 index size = 31 }

create table "informix".mopcot 
  (
    ptc_no serial not null ,
    vsn integer not null ,
    ptc_cod char(7) not null ,
    ord_dat date not null ,
    ord_hm smallint not null ,
    tsc char(1) not null ,
    pre_cot smallint not null ,
    cur_cot smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (ptc_no) 
  );

revoke all on "informix".mopcot from "public" as "informix";

{ TABLE "informix".eobaaccount row size = 222 number of columns = 12 index size = 25 }

create table "informix".eobaaccount 
  (
    ahospitalid char(10) not null ,
    aemployeeid char(10) not null ,
    arightfingerprint text,
    aleftfingerprint text,
    aaccountid char(10) not null ,
    apassword char(32),
    aeditnum decimal(2,0),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aemployeeid) 
  );

revoke all on "informix".eobaaccount from "public" as "informix";

{ TABLE "informix".eobaaccountrights row size = 84 number of columns = 16 index size = 35 }

create table "informix".eobaaccountrights 
  (
    ahospitalid char(10) not null ,
    aaccountid char(10) not null ,
    ascreenid char(10) not null ,
    acannew char(1),
    acanupdate char(1),
    acandelete char(1),
    acanquery char(1),
    acanprint char(1),
    acansign char(1),
    acanqueryall char(1),
    acanprintall char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aaccountid,ascreenid) 
  );

revoke all on "informix".eobaaccountrights from "public" as "informix";

{ TABLE "informix".eobaarrivehospital row size = 68 number of columns = 8 index size = 17 }

create table "informix".eobaarrivehospital 
  (
    ahospitalid char(10) not null ,
    aarriveid char(2) not null ,
    arrivename char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aarriveid) 
  );

revoke all on "informix".eobaarrivehospital from "public" as "informix";

{ TABLE "informix".eobabulletinboard row size = 1745 number of columns = 13 index size = 19 }

create table "informix".eobabulletinboard 
  (
    aid char(4) not null ,
    ahospitalid char(10) not null ,
    abulletintype char(2),
    atitle lvarchar(160),
    acontent lvarchar(1500),
    astartdate datetime year to second,
    aenddate datetime year to second,
    aistop char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (aid,ahospitalid) 
  );

revoke all on "informix".eobabulletinboard from "public" as "informix";

{ TABLE "informix".eobadivisionrights row size = 84 number of columns = 16 index size = 35 }

create table "informix".eobadivisionrights 
  (
    ahospitalid char(10) not null ,
    adivisionid char(10) not null ,
    ascreenid char(10) not null ,
    acannew char(1),
    acanupdate char(1),
    acandelete char(1),
    acanquery char(1),
    acanprint char(1),
    acansign char(1),
    acanqueryall char(1),
    acanprintall char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,adivisionid,ascreenid) 
  );

revoke all on "informix".eobadivisionrights from "public" as "informix";

{ TABLE "informix".eobahospital row size = 650 number of columns = 22 index size = 15 }

create table "informix".eobahospital 
  (
    ahospitalid char(10) not null ,
    achinesename varchar(100),
    aenglishname varchar(100),
    aabbrname varchar(30),
    alevelid char(1),
    anhihospitalid char(10),
    auniformno char(8),
    ataxno char(9),
    asuperintend char(30),
    atel char(20),
    afax char(20),
    aemail varchar(50),
    aweb varchar(50),
    azipcode char(3),
    aaddress varchar(100),
    aisheadhospital char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    apicturedata text,
    primary key (ahospitalid) 
  );

revoke all on "informix".eobahospital from "public" as "informix";

{ TABLE "informix".eobahospitallevel row size = 79 number of columns = 8 index size = 6 }

create table "informix".eobahospitallevel 
  (
    alevelid char(1) not null ,
    alevelname varchar(30),
    anhiapplyid char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (alevelid) 
  );

revoke all on "informix".eobahospitallevel from "public" as "informix";

{ TABLE "informix".eobanhihospital row size = 309 number of columns = 16 index size = 15 }

create table "informix".eobanhihospital 
  (
    anhihospitalid char(10) not null ,
    anhihospitalname varchar(100),
    abranch char(2),
    aaddress varchar(100),
    atelid char(5),
    atel char(20),
    aspecialtype char(2),
    ahospitaltype char(2),
    anhihospitaltype varchar(10),
    aterminatedate datetime year to second,
    aisteaching char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (anhihospitalid) 
  );

revoke all on "informix".eobanhihospital from "public" as "informix";

{ TABLE "informix".eobascreen row size = 83 number of columns = 14 index size = 25 }

create table "informix".eobascreen 
  (
    ahospitalid char(10) not null ,
    ascreenid char(10) not null ,
    ascreenname varchar(10),
    ahasnew char(1),
    ahasupdate char(1),
    ahasdelete char(1),
    ahasquery char(1),
    ahasprint char(1),
    ahassign char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,ascreenid) 
  );

revoke all on "informix".eobascreen from "public" as "informix";

{ TABLE "informix".eobasystemlog row size = 44 number of columns = 6 index size = 9 }

create table "informix".eobasystemlog 
  (
    ano serial not null ,
    ahospitalid char(10),
    aaccountid char(10),
    ascreenid char(10),
    alogtype char(2),
    alogdatetime datetime year to second,
    primary key (ano) 
  );

revoke all on "informix".eobasystemlog from "public" as "informix";

{ TABLE "informix".eobatrdetaillist row size = 73 number of columns = 10 index size = 19 }

create table "informix".eobatrdetaillist 
  (
    ano integer not null ,
    ahospitalid char(10) not null ,
    acid char(5),
    atid char(4),
    attasjudgeid char(4),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ano,ahospitalid) 
  );

revoke all on "informix".eobatrdetaillist from "public" as "informix";

{ TABLE "informix".eobatriagecc row size = 256 number of columns = 9 index size = 10 }

create table "informix".eobatriagecc 
  (
    aid char(5) not null ,
    asid char(3),
    achinesename varchar(100),
    aenglishname varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (aid) 
  );

revoke all on "informix".eobatriagecc from "public" as "informix";

{ TABLE "informix".eobatriagejudge row size = 382 number of columns = 10 index size = 9 }

create table "informix".eobatriagejudge 
  (
    aid char(4) not null ,
    achinesename lvarchar(160),
    aenglishname lvarchar(160),
    arank5 char(1),
    amark char(5),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (aid) 
  );

revoke all on "informix".eobatriagejudge from "public" as "informix";

{ TABLE "informix".eobatriagerule row size = 79 number of columns = 15 index size = 8 }

create table "informix".eobatriagerule 
  (
    aid char(3) not null ,
    aitem1 char(3),
    alow1 decimal(4,1),
    ahigh1 decimal(3,0),
    aitem2 char(3),
    alow2 decimal(4,1),
    ahigh2 decimal(3,0),
    aitem3 char(3),
    alow3 decimal(4,1),
    ahigh3 decimal(3,0),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (aid) 
  );

revoke all on "informix".eobatriagerule from "public" as "informix";

{ TABLE "informix".eobatriagesystem row size = 261 number of columns = 9 index size = 8 }

create table "informix".eobatriagesystem 
  (
    aid char(3) not null ,
    achinesename varchar(100),
    aenglishname varchar(100),
    adepartmentid char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (aid) 
  );

revoke all on "informix".eobatriagesystem from "public" as "informix";

{ TABLE "informix".eodebodysystem row size = 512 number of columns = 13 index size = 15 }

create table "informix".eodebodysystem 
  (
    atraumaid char(5) not null ,
    asystemid char(5) not null ,
    achinesename varchar(50),
    aenglishname varchar(100),
    adiseasecname varchar(50),
    adiseaseename varchar(100),
    asymptomcname varchar(50),
    asymptomename varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (atraumaid,asystemid) 
  );

revoke all on "informix".eodebodysystem from "public" as "informix";

{ TABLE "informix".eodedocumentlog row size = 326 number of columns = 11 index size = 17 }

create table "informix".eodedocumentlog 
  (
    ahospitalid char(10) not null ,
    anoid char(2) not null ,
    anoname varchar(50),
    areturnzero char(1),
    apresentno char(15),
    amark varchar(200),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,anoid) 
  );

revoke all on "informix".eodedocumentlog from "public" as "informix";

{ TABLE "informix".eodesystemconfig row size = 217 number of columns = 9 index size = 25 }

create table "informix".eodesystemconfig 
  (
    ahospitalid char(10) not null ,
    asystemid char(10) not null ,
    asystemdescription varchar(100),
    asystemvalue char(50),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,asystemid) 
  );

revoke all on "informix".eodesystemconfig from "public" as "informix";

{ TABLE "informix".eotrnursephrase row size = 377 number of columns = 9 index size = 33 }

create table "informix".eotrnursephrase 
  (
    ahospitalid char(10) not null ,
    atypeid char(2) not null ,
    aphraseid char(16) not null ,
    aphrasecontent lvarchar(300),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atypeid,aphraseid) 
  );

revoke all on "informix".eotrnursephrase from "public" as "informix";

{ TABLE "informix".eotrtriagedanger row size = 117 number of columns = 24 index size = 32 }

create table "informix".eotrtriagedanger 
  (
    ahospitalid char(10) not null ,
    atriageid char(13) not null ,
    atriagetimes char(4) not null ,
    avisitno varchar(13),
    aitema "informix".boolean,
    aitemb "informix".boolean,
    aitemc "informix".boolean,
    aitemd "informix".boolean,
    aiteme "informix".boolean,
    aitemf "informix".boolean,
    aitemg "informix".boolean,
    aitemh "informix".boolean,
    aitemi "informix".boolean,
    aitemj "informix".boolean,
    aitemk "informix".boolean,
    aiteml "informix".boolean,
    aitemm "informix".boolean,
    aitemn "informix".boolean,
    aitemo "informix".boolean,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atriageid,atriagetimes) 
  );

revoke all on "informix".eotrtriagedanger from "public" as "informix";

{ TABLE "informix".eotrtriagereferral row size = 4105 number of columns = 13 index size = 32 }

create table "informix".eotrtriagereferral 
  (
    ahospitalid char(10) not null ,
    atriageid char(13) not null ,
    atriagetimes char(4) not null ,
    avisitno varchar(13),
    areferralorgid char(10),
    auserinputorg lvarchar(4000),
    areferralreason char(3),
    ahasreferralpaper "informix".boolean,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atriageid,atriagetimes) 
  );

revoke all on "informix".eotrtriagereferral from "public" as "informix";

{ TABLE "informix".eotrtrlevelcount row size = 88 number of columns = 13 index size = 23 }

create table "informix".eotrtrlevelcount 
  (
    ahospitalid char(10) not null ,
    adate char(8) not null ,
    alevel1 integer,
    alevel2 integer,
    alevel3 integer,
    alevel4 integer,
    alevel5 integer,
    alevel0 integer,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,adate) 
  );

revoke all on "informix".eotrtrlevelcount from "public" as "informix";

{ TABLE "informix".eotrtrspecialcase row size = 147 number of columns = 21 index size = 32 }

create table "informix".eotrtrspecialcase 
  (
    ahospitalid char(10) not null ,
    atriageid char(13) not null ,
    atriagetimes char(4) not null ,
    avisitno varchar(13),
    aitema "informix".boolean,
    aitemb "informix".boolean,
    aitemc "informix".boolean,
    aitemd "informix".boolean,
    aiteme "informix".boolean,
    aitemf "informix".boolean,
    adateitema datetime year to second,
    adateitemb datetime year to second,
    adateitemc datetime year to second,
    adateitemd datetime year to second,
    adateiteme datetime year to second,
    adateitemf datetime year to second,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atriageid,atriagetimes) 
  );

revoke all on "informix".eotrtrspecialcase from "public" as "informix";

{ TABLE "informix".npqtr row size = 15 number of columns = 5 index size = 22 }

create table "informix".npqtr 
  (
    qtr_no serial not null ,
    nqu_no integer not null ,
    typ char(2) not null ,
    eva_no integer not null ,
    eva_sts char(1) not null ,
    primary key (qtr_no) 
  );

revoke all on "informix".npqtr from "public" as "informix";

{ TABLE "informix".npqtri row size = 41 number of columns = 10 index size = 27 }

create table "informix".npqtri 
  (
    qti_no serial not null ,
    qtr_no integer not null ,
    frm_no integer not null ,
    ord_man smallint not null ,
    ord_tim datetime year to minute not null ,
    sts char(1) not null ,
    exe_man smallint not null ,
    exe_tim datetime year to minute not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (qti_no) 
  );

revoke all on "informix".npqtri from "public" as "informix";

{ TABLE "informix".npqtrp row size = 53 number of columns = 13 index size = 27 }

create table "informix".npqtrp 
  (
    qtp_no serial not null ,
    qtr_no integer not null ,
    frm_no integer not null ,
    ord_man smallint not null ,
    ord_tim datetime year to minute not null ,
    eva_sts char(1) not null ,
    pre_tim datetime year to minute not null ,
    eva_tim datetime year to minute not null ,
    eva_man smallint not null ,
    eva_rlt char(1) not null ,
    eva_dsc integer not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (qtp_no) 
  );

revoke all on "informix".npqtrp from "public" as "informix";

{ TABLE "informix".npolls row size = 309 number of columns = 4 index size = 19 }

create table "informix".npolls 
  (
    lls_no serial not null ,
    cls_typ char(1) not null ,
    itm_no integer not null ,
    oth_dsc char(300) not null ,
    primary key (lls_no) 
  );

revoke all on "informix".npolls from "public" as "informix";

{ TABLE "informix".mrsencas row size = 16 number of columns = 5 index size = 10 }

create table "informix".mrsencas 
  (
    sst_no integer not null ,
    cas_typ char(1) not null ,
    tc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (sst_no,cas_typ) 
  );

revoke all on "informix".mrsencas from "public" as "informix";

{ TABLE "informix".mrsstmr row size = 38 number of columns = 8 index size = 18 }

create table "informix".mrsstmr 
  (
    sst_no serial not null ,
    vsn integer not null ,
    eff_tim datetime year to second not null ,
    stp_tim datetime year to second not null ,
    eff_man smallint not null ,
    stp_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (sst_no) 
  );

revoke all on "informix".mrsstmr from "public" as "informix";

{ TABLE "informix".mrsensar row size = 116 number of columns = 8 index size = 28 }

create table "informix".mrsensar 
  (
    aut_no serial not null ,
    sst_no integer not null ,
    aut_man smallint not null ,
    eff_tim datetime year to second not null ,
    stp_tim datetime year to second not null ,
    aut_rsn char(80) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (aut_no) 
  );

revoke all on "informix".mrsensar from "public" as "informix";

{ TABLE "ap11".eobapersonalconfig row size = 187 number of columns = 10 index size = 35 }

create table "ap11".eobapersonalconfig 
  (
    ahospitalid char(10) not null ,
    aemployeeid char(10) not null ,
    asystemid char(10) not null ,
    asystemdescription varchar(100),
    asystemvalue char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aemployeeid,asystemid) 
  );

revoke all on "ap11".eobapersonalconfig from "public" as "ap11";

{ TABLE "ap11".eoteteacher row size = 97 number of columns = 8 index size = 25 }

create table "ap11".eoteteacher 
  (
    ahospitalid char(10) not null ,
    aid char(10) not null ,
    aname varchar(30),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aid) 
  );

revoke all on "ap11".eoteteacher from "public" as "ap11";

{ TABLE "ap11".eobaemployee row size = 922 number of columns = 36 index size = 25 }

create table "ap11".eobaemployee 
  (
    ahospitalid char(10) not null ,
    aemployeeid char(10) not null ,
    aemployeeidno char(15),
    adivisionid char(10),
    aprofessionid char(3),
    apositionid char(5),
    aemployeename varchar(30),
    aenglishname varchar(30),
    abegindate datetime year to second,
    aenddate datetime year to second,
    abirthday datetime year to second,
    asex char(1),
    abloodid char(2),
    aphotopath varchar(100),
    amaritalstatus char(1),
    atel char(20),
    amobile char(20),
    ahospitalphone char(20),
    ahigheducational varchar(50),
    azipcode char(3),
    aaddress varchar(100),
    aregisterzipcode char(3),
    aregisteraddress varchar(100),
    aemail varchar(50),
    acontactname varchar(30),
    acontactrelation varchar(30),
    acontacttel char(20),
    acontactmobile char(20),
    acontactaddresszip char(3),
    acontactaddress varchar(100),
    apicturedata text,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aemployeeid) 
  );

revoke all on "ap11".eobaemployee from "public" as "ap11";

{ TABLE "ap11".eosopersonalconfig row size = 206 number of columns = 23 index size = 25 }

create table "ap11".eosopersonalconfig 
  (
    ahospitalid char(10) not null ,
    aemployeeid char(10) not null ,
    aafilter varchar(20),
    aasequence varchar(20),
    aasearchmode char(1),
    apfilter varchar(50),
    apsequence varchar(30),
    apsearchmode char(1),
    aisminimizeina char(1),
    aisminimizeinp char(1),
    aisminimizeins char(1),
    aisminimizeino char(1),
    aafontsize char(2),
    apfontsize char(2),
    asfontsize char(2),
    aofontsize char(2),
    assearchmode char(1),
    aosearchmode char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aemployeeid) 
  );

revoke all on "ap11".eosopersonalconfig from "public" as "ap11";

{ TABLE "informix".emsndly row size = 25 number of columns = 8 index size = 16 }

create table "informix".emsndly 
  (
    dly_no serial not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tc char(1) not null ,
    dly_man smallint not null ,
    rsn char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (dly_no) 
  );

revoke all on "informix".emsndly from "public" as "informix";

{ TABLE "informix".eowtpt row size = 16 number of columns = 4 index size = 7 }

create table "informix".eowtpt 
  (
    division smallint not null ,
    vsn integer not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (division) 
  );

revoke all on "informix".eowtpt from "public" as "informix";

{ TABLE "informix".eobldmsg row size = 71 number of columns = 5 index size = 9 }

create table "informix".eobldmsg 
  (
    msg_num serial not null ,
    msg text not null ,
    sts char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (msg_num) 
  );

revoke all on "informix".eobldmsg from "public" as "informix";

{ TABLE "informix".bmwtbd row size = 29 number of columns = 11 index size = 18 }

create table "informix".bmwtbd 
  (
    wbd_num serial not null ,
    acc_no integer not null ,
    dat date not null ,
    hm smallint not null ,
    class char(1) not null ,
    wbd_wrd char(3) not null ,
    sts char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null ,
    rtl smallint not null ,
    primary key (wbd_num) 
  );

revoke all on "informix".bmwtbd from "public" as "informix";

{ TABLE "informix".moocn row size = 95 number of columns = 12 index size = 42 }

create table "informix".moocn 
  (
    rec_no serial not null ,
    chart integer not null ,
    vsn integer not null ,
    lnk_no integer 
        default 0 not null ,
    typ1 char(1) not null ,
    typ2 smallint not null ,
    tsc char(1) not null ,
    rec_man smallint not null ,
    rec_tim datetime year to minute not null ,
    txt text,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".moocn from "public" as "informix";

{ TABLE "informix".qmeierm row size = 31 number of columns = 9 index size = 33 }

create table "informix".qmeierm 
  (
    est_no serial not null ,
    vsn integer not null ,
    sys_typ char(2) not null ,
    itm_typ char(1) not null ,
    tsc char(1) not null ,
    est_tim datetime year to minute not null ,
    est_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (est_no) 
  );

revoke all on "informix".qmeierm from "public" as "informix";

{ TABLE "informix".qmeierd row size = 13 number of columns = 4 index size = 22 }

create table "informix".qmeierd 
  (
    itm_no serial not null ,
    est_no integer not null ,
    eva_no integer not null ,
    eva_sts char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".qmeierd from "public" as "informix";

{ TABLE "informix".eotrtriageepidemic row size = 298 number of columns = 15 index size = 32 }

create table "informix".eotrtriageepidemic 
  (
    ahospitalid char(10) not null ,
    atriageid char(13) not null ,
    atriagetimes char(4) not null ,
    avisitno varchar(13),
    aitema "informix".boolean,
    aitemb "informix".boolean,
    aitemc "informix".boolean,
    aitemd "informix".boolean,
    aiteme "informix".boolean,
    aquarantine varchar(200),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atriageid,atriagetimes) 
  );

revoke all on "informix".eotrtriageepidemic from "public" as "informix";

{ TABLE "informix".eobabedexpand row size = 118 number of columns = 17 index size = 35 }

create table "informix".eobabedexpand 
  (
    ahospitalid char(10) not null ,
    aroomno char(10) not null ,
    abedno char(10) not null ,
    ailltype char(1),
    aisnhibed char(1),
    aisudbed char(1),
    aguaranteefund decimal(6,0),
    aext char(5),
    acalculatebedrate char(1),
    abedopendate datetime year to second,
    abedclosedate datetime year to second,
    avisitno char(13),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aroomno,abedno) 
  );

revoke all on "informix".eobabedexpand from "public" as "informix";

{ TABLE "informix".eobabedmap row size = 94 number of columns = 12 index size = 35 }

create table "informix".eobabedmap 
  (
    ahospitalid char(10) not null ,
    aroomno char(10) not null ,
    abedno char(10) not null ,
    aisfix char(1),
    aishorizontal char(1),
    alocationleft float,
    alocationtop float,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aroomno,abedno) 
  );

revoke all on "informix".eobabedmap from "public" as "informix";

{ TABLE "informix".eobaroommap row size = 381 number of columns = 15 index size = 25 }

create table "informix".eobaroommap 
  (
    ahospitalid char(10) not null ,
    aroomno char(10) not null ,
    amapname varchar(100),
    aftppath varchar(100),
    alocationleft float,
    alocationtop float,
    awidth float,
    aheight float,
    acolor char(25),
    apicturedata text,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aroomno) 
  );

revoke all on "informix".eobaroommap from "public" as "informix";

{ TABLE "informix".eobeerptstatus row size = 243 number of columns = 12 index size = 27 }

create table "informix".eobeerptstatus 
  (
    aid integer not null ,
    ahospitalid char(10),
    avisitno char(13),
    achartno char(15),
    astatustypeid char(2),
    astatusid char(2),
    astatus varchar(150),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (aid) 
  );

revoke all on "informix".eobeerptstatus from "public" as "informix";

{ TABLE "informix".eobepatientstatus row size = 262 number of columns = 10 index size = 19 }

create table "informix".eobepatientstatus 
  (
    ahospitalid char(10) not null ,
    astatusid char(2) not null ,
    atypeid char(2) not null ,
    achinesename varchar(100),
    aenglishname varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,astatusid,atypeid) 
  );

revoke all on "informix".eobepatientstatus from "public" as "informix";

{ TABLE "informix".eodecommontime row size = 168 number of columns = 9 index size = 26 }

create table "informix".eodecommontime 
  (
    ahospitalid char(10) not null ,
    atimeid char(6) not null ,
    atimetypeid char(5) not null ,
    aenglishname varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atimeid,atimetypeid) 
  );

revoke all on "informix".eodecommontime from "public" as "informix";

{ TABLE "informix".eodecomtimevalue row size = 173 number of columns = 10 index size = 28 }

create table "informix".eodecomtimevalue 
  (
    ahospitalid char(10) not null ,
    aid integer not null ,
    atimeid char(6) not null ,
    atimevalueid char(6) not null ,
    aenglishname varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    unique (aid) ,
    primary key (ahospitalid,aid) 
  );

revoke all on "informix".eodecomtimevalue from "public" as "informix";

{ TABLE "informix".eodecontinent row size = 203 number of columns = 8 index size = 10 }

create table "informix".eodecontinent 
  (
    acontinentid char(5) not null ,
    achinesename varchar(50),
    aenglishname varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (acontinentid) 
  );

revoke all on "informix".eodecontinent from "public" as "informix";

{ TABLE "informix".eodecontinentarea row size = 208 number of columns = 9 index size = 15 }

create table "informix".eodecontinentarea 
  (
    acontinentid char(5) not null ,
    aareaid char(5) not null ,
    achinesename varchar(50),
    aenglishname varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (acontinentid,aareaid) 
  );

revoke all on "informix".eodecontinentarea from "public" as "informix";

{ TABLE "informix".eodecountry row size = 216 number of columns = 10 index size = 23 }

create table "informix".eodecountry 
  (
    acontinentid char(5) not null ,
    aareaid char(5) not null ,
    acountryid char(8) not null ,
    achinesename varchar(50),
    aenglishname varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (acontinentid,aareaid,acountryid) 
  );

revoke all on "informix".eodecountry from "public" as "informix";

{ TABLE "informix".eodestatustype row size = 260 number of columns = 9 index size = 17 }

create table "informix".eodestatustype 
  (
    ahospitalid char(10) not null ,
    atypeid char(2) not null ,
    achinesename varchar(100),
    aenglishname varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atypeid) 
  );

revoke all on "informix".eodestatustype from "public" as "informix";

{ TABLE "informix".eodierdischargent row size = 32095 number of columns = 16 index size = 46 }

create table "informix".eodierdischargent 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    atriagecontent lvarchar(4000),
    aexceptionalfound lvarchar(4000),
    aadmissiondiag lvarchar(4000),
    amaintreatment lvarchar(4000),
    asuggestions lvarchar(4000),
    ahealthnotices lvarchar(4000),
    aleavereasonid char(2),
    aleavereasondesc lvarchar(4000),
    amedicalhistory lvarchar(4000),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno) 
  );

revoke all on "informix".eodierdischargent from "public" as "informix";

{ TABLE "informix".eodierfinaldiag row size = 81 number of columns = 10 index size = 51 }

create table "informix".eodierfinaldiag 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    asequenceno char(5) not null ,
    aicdid char(6),
    achieficdid char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,asequenceno) 
  );

revoke all on "informix".eodierfinaldiag from "public" as "informix";

{ TABLE "informix".eodihealthnotice row size = 2346 number of columns = 9 index size = 302 }

create table "informix".eodihealthnotice 
  (
    ahospitalid char(10) not null ,
    adepartmentid varchar(30) not null ,
    atitle varchar(255) not null ,
    acontent lvarchar(2000),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,adepartmentid,atitle) 
  );

revoke all on "informix".eodihealthnotice from "public" as "informix";

{ TABLE "informix".eosobodysystemicd9 row size = 93 number of columns = 11 index size = 42 }

create table "informix".eosobodysystemicd9 
  (
    ahospitalid char(10) not null ,
    adepartmentid char(10) not null ,
    asystemid char(5) not null ,
    aicd9id char(12),
    atraumaid char(5) not null ,
    aitemno char(5) not null ,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,adepartmentid,asystemid,aicd9id) 
  );

revoke all on "informix".eosobodysystemicd9 from "public" as "informix";

{ TABLE "informix".eosocomallergytype row size = 161 number of columns = 8 index size = 19 }

create table "informix".eosocomallergytype 
  (
    ahospitalid char(10) not null ,
    atypeid char(4) not null ,
    atypename varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atypeid) 
  );

revoke all on "informix".eosocomallergytype from "public" as "informix";

{ TABLE "informix".eosocomdepartment row size = 69 number of columns = 9 index size = 27 }

create table "informix".eosocomdepartment 
  (
    ahospitalid char(10) not null ,
    aid char(10) not null ,
    acommontype char(2) not null ,
    aispublic char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aid,acommontype) 
  );

revoke all on "informix".eosocomdepartment from "public" as "informix";

{ TABLE "informix".eosocomdrugdetail row size = 135 number of columns = 15 index size = 55 }

create table "informix".eosocomdrugdetail 
  (
    ahospitalid char(10) not null ,
    adepartmentid char(10) not null ,
    agroupid char(15) not null ,
    adrugid char(15) not null ,
    aunit char(10),
    afrequencyid char(10),
    ameals decimal(3,0),
    arouteid char(10),
    aday decimal(3,0),
    atotalquantity decimal(3,0),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,adepartmentid,agroupid,adrugid) 
  );

revoke all on "informix".eosocomdrugdetail from "public" as "informix";

{ TABLE "informix".eosocommedicalvoc row size = 165 number of columns = 10 index size = 19 }

create table "informix".eosocommedicalvoc 
  (
    ahospitalid char(10) not null ,
    aid serial not null ,
    avocabularyname varchar(80),
    asnomedid char(20),
    ausenum integer,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aid) 
  );

revoke all on "informix".eosocommedicalvoc from "public" as "informix";

{ TABLE "informix".eosocommonallergy row size = 222 number of columns = 11 index size = 25 }

create table "informix".eosocommonallergy 
  (
    ahospitalid char(10) not null ,
    aallergytypeid char(5) not null ,
    aallergyid char(5) not null ,
    achinesename varchar(50),
    aenglishname varchar(100),
    ausenum integer,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aallergytypeid,aallergyid) 
  );

revoke all on "informix".eosocommonallergy from "public" as "informix";

{ TABLE "informix".eosocommondrug row size = 151 number of columns = 18 index size = 55 }

create table "informix".eosocommondrug 
  (
    ahospitalid char(10) not null ,
    adepartmentid char(10) not null ,
    adrugtypeid char(10) not null ,
    adrugid char(15) not null ,
    asequenceno char(5) not null ,
    aisgroup char(1),
    aunit varchar(10),
    afrequencyid char(10),
    ameals decimal(5,2),
    arouteid char(10),
    aday decimal(3,0),
    atotalquantity decimal(10,2),
    amapno char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,adepartmentid,adrugtypeid,adrugid,asequenceno)  constraint 
              "informix".pk_eosocommondrug
  );

revoke all on "informix".eosocommondrug from "public" as "informix";

{ TABLE "informix".eosocommonexam row size = 114 number of columns = 12 index size = 50 }

create table "informix".eosocommonexam 
  (
    ahospitalid char(10) not null ,
    adepartmentid char(10) not null ,
    aexamtypeid char(10) not null ,
    aexamid char(15) not null ,
    aquantity decimal(3,0),
    afrequencyid char(10),
    amapno char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,adepartmentid,aexamtypeid,aexamid) 
  );

revoke all on "informix".eosocommonexam from "public" as "informix";

{ TABLE "informix".eosocommonicd9 row size = 92 number of columns = 11 index size = 41 }

create table "informix".eosocommonicd9 
  (
    ahospitalid char(10) not null ,
    adepartmentid char(10) not null ,
    atypeid char(4) not null ,
    aicd9id char(12),
    atraumaid char(5) not null ,
    aitemno char(5),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,adepartmentid,atypeid,aicd9id) 
  );

revoke all on "informix".eosocommonicd9 from "public" as "informix";

{ TABLE "informix".eosocommonicd9type row size = 171 number of columns = 9 index size = 19 }

create table "informix".eosocommonicd9type 
  (
    ahospitalid char(10) not null ,
    atypeid char(4) not null ,
    adepartmentid char(10),
    atypename varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atypeid) 
  );

revoke all on "informix".eosocommonicd9type from "public" as "informix";

{ TABLE "informix".eosocommonlab row size = 124 number of columns = 13 index size = 50 }

create table "informix".eosocommonlab 
  (
    ahospitalid char(10) not null ,
    adepartmentid char(10) not null ,
    alabtypeid char(10) not null ,
    alabid char(15) not null ,
    aquantity decimal(3,0),
    aspecimentypeid char(10),
    afrequencyid char(10),
    amapno char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,adepartmentid,alabtypeid,alabid) 
  );

revoke all on "informix".eosocommonlab from "public" as "informix";

{ TABLE "informix".eosocommonlabtype row size = 97 number of columns = 8 index size = 25 }

create table "informix".eosocommonlabtype 
  (
    ahospitalid char(10) not null ,
    alabtypeid char(10) not null ,
    alabtypename varchar(30),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,alabtypeid) 
  );

revoke all on "informix".eosocommonlabtype from "public" as "informix";

{ TABLE "informix".eosocommonsymptom row size = 248 number of columns = 13 index size = 31 }

create table "informix".eosocommonsymptom 
  (
    ahospitalid char(10) not null ,
    atraumaid char(5) not null ,
    asystemid char(5) not null ,
    asymptomid char(6) not null ,
    achinesename varchar(50),
    aenglishname varchar(100),
    asnomedid char(20),
    ausenum integer,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atraumaid,asystemid,asymptomid) 
  );

revoke all on "informix".eosocommonsymptom from "public" as "informix";

{ TABLE "informix".eosocommontype row size = 172 number of columns = 10 index size = 29 }

create table "informix".eosocommontype 
  (
    ahospitalid char(10) not null ,
    atypeid char(4) not null ,
    adepartmentid char(10) not null ,
    atypename char(100),
    aclassification char(2),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atypeid,adepartmentid) 
  );

revoke all on "informix".eosocommontype from "public" as "informix";

{ TABLE "informix".eosocomprocedure row size = 114 number of columns = 12 index size = 50 }

create table "informix".eosocomprocedure 
  (
    ahospitalid char(10) not null ,
    adepartmentid char(10) not null ,
    aproceduretypeid char(10) not null ,
    aprocedureid char(15) not null ,
    aquantity decimal(3,0),
    afrequencyid char(10),
    amapno char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,adepartmentid,aproceduretypeid,aprocedureid)  constraint 
              "informix".pk_eosocommonproce
  );

revoke all on "informix".eosocomprocedure from "public" as "informix";

{ TABLE "informix".eosodrugfirstday row size = 32 number of columns = 5 index size = 9 }

create table "informix".eosodrugfirstday 
  (
    itemno integer not null ,
    orderno integer not null ,
    visitno char(13) not null ,
    priceno char(7) not null ,
    firstdayqty decimal(5,1) 
        default 0 not null ,
    primary key (itemno) 
  );

revoke all on "informix".eosodrugfirstday from "public" as "informix";

{ TABLE "informix".eosodrugtype row size = 177 number of columns = 9 index size = 25 }

create table "informix".eosodrugtype 
  (
    ahospitalid char(10) not null ,
    adrugtypeid char(10) not null ,
    adrugtypename char(50),
    atypeenglishname varchar(60),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,adrugtypeid) 
  );

revoke all on "informix".eosodrugtype from "public" as "informix";

{ TABLE "informix".eosoernursetpr row size = 123 number of columns = 23 index size = 27 }

create table "informix".eosoernursetpr 
  (
    aid serial not null ,
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    atemperature decimal(3,1),
    abreath decimal(3,0),
    apulse decimal(3,0),
    asbp decimal(3,0),
    adbp decimal(3,0),
    aweight decimal(5,2),
    asao2 decimal(3,0),
    agcse char(1),
    agcsv char(1),
    agcsm char(1),
    abloodsugar char(5),
    aother1 char(5),
    aother2 char(5),
    aother3 char(5),
    aother4 char(5),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (aid) 
  );

revoke all on "informix".eosoernursetpr from "public" as "informix";

{ TABLE "informix".eosoerpatientddesc row size = 139 number of columns = 12 index size = 50 }

create table "informix".eosoerpatientddesc 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    aadescription text,
    aflag char(1),
    astatus char(1),
    ahisgetdate datetime year to second,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes) 
  );

revoke all on "informix".eosoerpatientddesc from "public" as "informix";

{ TABLE "informix".eosoerpatientdiag row size = 107 number of columns = 17 index size = 55 }

create table "informix".eosoerpatientdiag 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    aitemno integer,
    aicd9id char(12) not null ,
    achieficd9id char(1),
    agreatill char(1),
    aflag char(1),
    astatus char(1),
    awordstyle char(1),
    ahisgetdate datetime year to second,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerpatientdiag from "public" as "informix";

{ TABLE "informix".eosoerpatientpdesc row size = 139 number of columns = 12 index size = 50 }

create table "informix".eosoerpatientpdesc 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    apdescription text,
    aflag char(1),
    astatus char(1),
    ahisgetdate datetime year to second,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes) 
  );

revoke all on "informix".eosoerpatientpdesc from "public" as "informix";

{ TABLE "informix".eosoerpatientph row size = 2176 number of columns = 15 index size = 55 }

create table "informix".eosoerpatientph 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    aitemno integer,
    atitle varchar(80),
    acontent lvarchar(2000),
    aflag char(1),
    astatus char(1),
    ahisgetdate datetime year to second,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerpatientph from "public" as "informix";

{ TABLE "informix".eosoerpatientphl row size = 2172 number of columns = 15 index size = 27 }

create table "informix".eosoerpatientphl 
  (
    ano serial not null ,
    ahospitalid char(10),
    avisitno char(13),
    aordertimes char(4),
    asequenceno char(5),
    aitemno integer,
    atitle varchar(80),
    acontent lvarchar(2000),
    aflag char(1),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ano) 
  );

revoke all on "informix".eosoerpatientphl from "public" as "informix";

{ TABLE "informix".eosoerpatientpot row size = 40 number of columns = 5 index size = 55 }

create table "informix".eosoerpatientpot 
  (
    avsn integer not null ,
    aordertimes char(4) not null ,
    aordno integer not null ,
    achartno char(15),
    avisitno char(13),
    primary key (avsn,aordertimes,aordno) 
  );

revoke all on "informix".eosoerpatientpot from "public" as "informix";

{ TABLE "informix".eosoerptobject row size = 2176 number of columns = 15 index size = 55 }

create table "informix".eosoerptobject 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    aitemno integer,
    atitle varchar(80),
    acontent lvarchar(2000),
    aflag char(1),
    astatus char(1),
    ahisgetdate datetime year to second,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerptobject from "public" as "informix";

{ TABLE "informix".eosoerptobjectl row size = 2172 number of columns = 15 index size = 27 }

create table "informix".eosoerptobjectl 
  (
    ano serial not null ,
    ahospitalid char(10),
    avisitno char(13),
    aordertimes char(4),
    asequenceno char(5),
    aitemno integer,
    atitle varchar(80),
    acontent lvarchar(2000),
    aflag char(1),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ano) 
  );

revoke all on "informix".eosoerptobjectl from "public" as "informix";

{ TABLE "informix".eosoerptocappic row size = 291 number of columns = 14 index size = 101 }

create table "informix".eosoerptocappic 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    aimagefiles varchar(50),
    abodypartid varchar(100),
    astatus char(1),
    aflag char(1),
    ahisgetdate datetime year to second,
    apicturedata text,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,aimagefiles) 
  );

revoke all on "informix".eosoerptocappic from "public" as "informix";

{ TABLE "informix".eosoerptodrawpic row size = 398 number of columns = 16 index size = 101 }

create table "informix".eosoerptodrawpic 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    aimagefile varchar(50) not null ,
    abodypart varchar(100),
    astatus char(1),
    aflag char(1),
    abackgroundfile text,
    abgimagefile varchar(50),
    apicturedata text,
    ahisgetdate datetime year to second,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,aimagefile) 
  );

revoke all on "informix".eosoerptodrawpic from "public" as "informix";

{ TABLE "informix".eosoerptprotocol row size = 280 number of columns = 12 index size = 59 }

create table "informix".eosoerptprotocol 
  (
    aid integer not null ,
    ahospitalid char(10),
    avisitno char(13),
    aordertimes char(4),
    aprotocolname varchar(100),
    ahtmlname varchar(100),
    aflag char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (aid) 
  );

revoke all on "informix".eosoerptprotocol from "public" as "informix";

{ TABLE "informix".eosoerptsubject row size = 4098 number of columns = 15 index size = 55 }

create table "informix".eosoerptsubject 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    aitemno integer,
    achiefcomplaint lvarchar(2000),
    apresentillness lvarchar(2000),
    aflag char(1),
    astatus char(1),
    ahisgetdate datetime year to second,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerptsubject from "public" as "informix";

{ TABLE "informix".eosonhiicallergy row size = 257 number of columns = 9 index size = 30 }

create table "informix".eosonhiicallergy 
  (
    ahospitalid char(10),
    achartno char(15),
    allergy1 varchar(50),
    allergy2 varchar(50),
    allergy3 varchar(50),
    allergy4 varchar(50),
    acreatedate datetime year to second,
    acreateuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,achartno) 
  );

revoke all on "informix".eosonhiicallergy from "public" as "informix";

{ TABLE "informix".eosonursingwarning row size = 488 number of columns = 12 index size = 50 }

create table "informix".eosonursingwarning 
  (
    ahospitalid char(10) not null ,
    asequenceno char(4) not null ,
    avisitno char(13) not null ,
    acontent lvarchar(400),
    anurseid char(10),
    aisread char(1),
    aisdelete char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,asequenceno,avisitno) 
  );

revoke all on "informix".eosonursingwarning from "public" as "informix";

{ TABLE "informix".eosooccupation row size = 203 number of columns = 8 index size = 10 }

create table "informix".eosooccupation 
  (
    aoccupationid char(5) not null ,
    achinesename varchar(50),
    aenglishname varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (aoccupationid) 
  );

revoke all on "informix".eosooccupation from "public" as "informix";

{ TABLE "informix".eosoodrawiistroke row size = 2112 number of columns = 11 index size = 50 }

create table "informix".eosoodrawiistroke 
  (
    ahospitalid char(10) not null ,
    ainfoid varchar(30) not null ,
    astrokeindex char(4) not null ,
    astrokewh char(3),
    astrokecolor char(15),
    astrokepoints lvarchar(2000),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,ainfoid,astrokeindex) 
  );

revoke all on "informix".eosoodrawiistroke from "public" as "informix";

{ TABLE "informix".eosoodrawingiitext row size = 2117 number of columns = 13 index size = 50 }

create table "informix".eosoodrawingiitext 
  (
    ahospitalid char(10) not null ,
    ainfoid varchar(30) not null ,
    auiindex char(4) not null ,
    auitext lvarchar(2000),
    auifontsize char(3),
    auifontcolor char(10),
    auifontleft char(5),
    auifonttop char(5),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,ainfoid,auiindex) 
  );

revoke all on "informix".eosoodrawingiitext from "public" as "informix";

{ TABLE "informix".eosopainscore row size = 75 number of columns = 9 index size = 50 }

create table "informix".eosopainscore 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    apainscore char(2),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes) 
  );

revoke all on "informix".eosopainscore from "public" as "informix";

{ TABLE "informix".eososoapdataforhis row size = 10085 number of columns = 12 index size = 50 }

create table "informix".eososoapdataforhis 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asubject lvarchar(2000),
    aobject lvarchar(2000),
    aassessment lvarchar(2000),
    aplan lvarchar(4000),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes) 
  );

revoke all on "informix".eososoapdataforhis from "public" as "informix";

{ TABLE "informix".eososoapmaster row size = 429 number of columns = 16 index size = 70 }

create table "informix".eososoapmaster 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    apgyid char(10),
    avsid char(10),
    apgydate datetime year to second,
    aispgyedit char(1),
    achartno char(15),
    aorderstatus char(1),
    ahisgetdate datetime year to second,
    aemrpdfpath lvarchar(300),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes) 
  );

revoke all on "informix".eososoapmaster from "public" as "informix";

{ TABLE "informix".eososoapuserlog row size = 97 number of columns = 12 index size = 27 }

create table "informix".eososoapuserlog 
  (
    aid serial not null ,
    ahospitalid char(10),
    aaccountid char(10),
    alogtype char(2),
    alogdatetime datetime year to second,
    avisitno char(13),
    aordertimes char(4),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (aid) 
  );

revoke all on "informix".eososoapuserlog from "public" as "informix";

{ TABLE "informix".eosotempconsult row size = 2120 number of columns = 11 index size = 46 }

create table "informix".eosotempconsult 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    adepartmentid char(10),
    adoctorid char(10),
    asubjectid char(10),
    aconsultcontent lvarchar(2000),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atemplateid) 
  );

revoke all on "informix".eosotempconsult from "public" as "informix";

{ TABLE "informix".eosotempdiagnosis row size = 108 number of columns = 12 index size = 53 }

create table "informix".eosotempdiagnosis 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    asequenceno char(5) not null ,
    aicd9id char(12) not null ,
    achiefcomplaints char(1),
    agreatill char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    typ char(2) 
        default '09' not null ,
    primary key (ahospitalid,atemplateid,asequenceno,typ) 
  );

revoke all on "informix".eosotempdiagnosis from "public" as "informix";

{ TABLE "informix".eosotemplateadesc row size = 145 number of columns = 9 index size = 48 }

create table "informix".eosotemplateadesc 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    aadescription text,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    typ char(2) 
        default '09' not null ,
    primary key (ahospitalid,atemplateid,typ) 
  );

revoke all on "informix".eosotemplateadesc from "public" as "informix";

{ TABLE "informix".eosotemplatedrug row size = 173 number of columns = 20 index size = 51 }

create table "informix".eosotemplatedrug 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    asequenceno char(5) not null ,
    adrugid char(15),
    aunit char(10),
    afrequencyid char(10),
    ameals decimal(5,2),
    arouteid char(10),
    aisprivateexpense char(1),
    aday decimal(3,0),
    atotalquantity decimal(10,2),
    aisgrand char(1),
    ahasattach char(1),
    aflowrapid char(10),
    amapno char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atemplateid,asequenceno) 
  );

revoke all on "informix".eosotemplatedrug from "public" as "informix";

{ TABLE "informix".eosotemplatedrugat row size = 132 number of columns = 13 index size = 66 }

create table "informix".eosotemplatedrugat 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    asequenceno char(5) not null ,
    adrugid char(15) not null ,
    ameals decimal(5,2),
    aisprivateexpense char(1),
    aunit char(10),
    amapno char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atemplateid,asequenceno,adrugid) 
  );

revoke all on "informix".eosotemplatedrugat from "public" as "informix";

{ TABLE "informix".eosotemplateexam row size = 1147 number of columns = 18 index size = 51 }

create table "informix".eosotemplateexam 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    asequenceno char(5) not null ,
    aexamid char(15),
    aquantity decimal(3,0),
    apartid char(10),
    adirection char(1),
    aisurgent char(1),
    aisprivateexpense char(1),
    aisportable char(1),
    areason lvarchar(1000),
    afrequencyid char(10),
    amapno char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atemplateid,asequenceno) 
  );

revoke all on "informix".eosotemplateexam from "public" as "informix";

{ TABLE "informix".eosotemplatelab row size = 142 number of columns = 15 index size = 51 }

create table "informix".eosotemplatelab 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    asequenceno char(5) not null ,
    alabid char(15),
    aquantity decimal(3,0),
    aspecimentypeid char(10),
    aisurgent char(1),
    aisprivateexpense char(1),
    afrequencyid char(10),
    amapno char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atemplateid,asequenceno) 
  );

revoke all on "informix".eosotemplatelab from "public" as "informix";

{ TABLE "informix".eosotemplatemaster row size = 131 number of columns = 13 index size = 46 }

create table "informix".eosotemplatemaster 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    asystemid char(5),
    adepartmentid char(10),
    adoctorid char(10),
    asubjectid char(10),
    adocumentid char(5),
    ausenum integer,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atemplateid) 
  );

revoke all on "informix".eosotemplatemaster from "public" as "informix";

{ TABLE "informix".eosotemplateobject row size = 2126 number of columns = 10 index size = 51 }

create table "informix".eosotemplateobject 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    asequenceno char(5) not null ,
    atitle varchar(30),
    acontent lvarchar(2000),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atemplateid,asequenceno) 
  );

revoke all on "informix".eosotemplateobject from "public" as "informix";

{ TABLE "informix".eosotemplatepdesc row size = 143 number of columns = 8 index size = 46 }

create table "informix".eosotemplatepdesc 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    adescription text,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atemplateid) 
  );

revoke all on "informix".eosotemplatepdesc from "public" as "informix";

{ TABLE "informix".eosotemplateph row size = 2126 number of columns = 10 index size = 51 }

create table "informix".eosotemplateph 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    asequenceno char(5) not null ,
    atitle varchar(30),
    acontent lvarchar(2000),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atemplateid,asequenceno) 
  );

revoke all on "informix".eosotemplateph from "public" as "informix";

{ TABLE "informix".eosotempmaterial row size = 131 number of columns = 13 index size = 51 }

create table "informix".eosotempmaterial 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    asequenceno char(5) not null ,
    amaterialid char(15),
    aquantity decimal(3,0),
    aisprivateexpense char(1) 
        default 'n',
    afrequencyid char(10),
    amapno char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atemplateid,asequenceno) 
  );

revoke all on "informix".eosotempmaterial from "public" as "informix";

{ TABLE "informix".eosotempprocedure row size = 343 number of columns = 16 index size = 66 }

create table "informix".eosotempprocedure 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    asequenceno char(5) not null ,
    aprocedureid char(15) not null ,
    aquantity decimal(3,0),
    apartid char(10),
    adescription varchar(200),
    aisurgent char(1),
    aisprivateexpense char(1),
    afrequencyid char(10),
    amapno char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atemplateid,asequenceno,aprocedureid) 
  );

revoke all on "informix".eosotempprocedure from "public" as "informix";

{ TABLE "informix".eosotempsubject row size = 4098 number of columns = 10 index size = 51 }

create table "informix".eosotempsubject 
  (
    ahospitalid char(10) not null ,
    atemplateid varchar(30) not null ,
    asequenceno char(5) not null ,
    achiefcomplaint lvarchar(2000),
    apresentillness lvarchar(2000),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,atemplateid,asequenceno) 
  );

revoke all on "informix".eosotempsubject from "public" as "informix";

{ TABLE "informix".eosotimetype row size = 203 number of columns = 8 index size = 10 }

create table "informix".eosotimetype 
  (
    atimetypeid char(5) not null ,
    achinesename varchar(50),
    aenglishname varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (atimetypeid) 
  );

revoke all on "informix".eosotimetype from "public" as "informix";

{ TABLE "informix".eosoerptsubjectl row size = 4094 number of columns = 15 index size = 27 }

create table "informix".eosoerptsubjectl 
  (
    ano serial not null ,
    ahospitalid char(10),
    avisitno char(13),
    aordertimes char(4),
    asequenceno char(5),
    aitemno integer,
    achiefcomplaint lvarchar(2000),
    apresentillness lvarchar(2000),
    aflag char(1),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ano) 
  );

revoke all on "informix".eosoerptsubjectl from "public" as "informix";

{ TABLE "ars".eobaspecimentype row size = 168 number of columns = 9 index size = 25 }

create table "ars".eobaspecimentype 
  (
    ahospitalid char(10) not null ,
    aspecimentypeid char(10) not null ,
    aspecimentypename varchar(50),
    atypeenglishname varchar(50),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,aspecimentypeid) 
  );

revoke all on "ars".eobaspecimentype from "public" as "ars";

{ TABLE "informix".eotrtrpasthistory row size = 16959 number of columns = 47 index size = 31 }

create table "informix".eotrtrpasthistory 
  (
    ahospitalid char(10) not null ,
    auserkeyinid varchar(15) not null ,
    achartno varchar(15),
    aitema "informix".boolean,
    aitemb "informix".boolean,
    aitemc "informix".boolean,
    aitemd "informix".boolean,
    aiteme "informix".boolean,
    aitemf "informix".boolean,
    aitemg "informix".boolean,
    aitemh "informix".boolean,
    aitemi "informix".boolean,
    aitemj "informix".boolean,
    aitemk "informix".boolean,
    aiteml "informix".boolean,
    aitemm "informix".boolean,
    aitemn "informix".boolean,
    aitemo "informix".boolean,
    aitemp "informix".boolean,
    aitemq "informix".boolean,
    aitemr "informix".boolean,
    aitems "informix".boolean,
    aitemt "informix".boolean,
    aitemu "informix".boolean,
    aitemv "informix".boolean,
    aitemw "informix".boolean,
    aitemx "informix".boolean,
    aheartother varchar(100),
    adigestionother varchar(100),
    aurinaryother varchar(100),
    acancerother varchar(100),
    abreathingother varchar(100),
    ametabolismother varchar(100),
    acentralother char(100),
    allother char(100),
    atetanustype char(1) 
        default '',
    aitemaa "informix".boolean,
    aitemy "informix".boolean,
    aallergya lvarchar(4000),
    aallergyb lvarchar(4000),
    aallergyc lvarchar(4000),
    aallergyd lvarchar(4000),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,auserkeyinid) 
  );

revoke all on "informix".eotrtrpasthistory from "public" as "informix";

{ TABLE "informix".eosoerpatientdiagl row size = 99 number of columns = 13 index size = 27 }

create table "informix".eosoerpatientdiagl 
  (
    ano serial not null ,
    ahospitalid char(10),
    avisitno char(13),
    aordertimes char(4),
    asequenceno char(5),
    aitemno integer,
    aicd9id char(12) not null ,
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ano) 
  );

revoke all on "informix".eosoerpatientdiagl from "public" as "informix";

{ TABLE "informix".eosoerrptsubject row size = 4098 number of columns = 15 index size = 37 }

create table "informix".eosoerrptsubject 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    aitemno integer,
    achiefcomplaint lvarchar(2000),
    apresentillness lvarchar(2000),
    aflag char(1),
    astatus char(1),
    ahisgetdate datetime year to second,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerrptsubject from "public" as "informix";

{ TABLE "informix".eosoerrpatientph row size = 2170 number of columns = 14 index size = 37 }

create table "informix".eosoerrpatientph 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    aitemno integer,
    atitle lvarchar(80),
    acontent lvarchar(2000),
    aflag char(1),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerrpatientph from "public" as "informix";

{ TABLE "informix".eosoerrptobject row size = 2170 number of columns = 14 index size = 37 }

create table "informix".eosoerrptobject 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    aitemno integer,
    atitle lvarchar(80),
    acontent lvarchar(2000),
    aflag char(1),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerrptobject from "public" as "informix";

{ TABLE "informix".eosoerrptodrawp row size = 390 number of columns = 15 index size = 83 }

create table "informix".eosoerrptodrawp 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    aimagefile varchar(50) not null ,
    abodypart varchar(100),
    astatus char(1),
    aflag char(1),
    apicturedata text,
    abackgroundfile text,
    abgimagefile varchar(50),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,aimagefile) 
  );

revoke all on "informix".eosoerrptodrawp from "public" as "informix";

{ TABLE "informix".eosoerrptocappic row size = 283 number of columns = 13 index size = 83 }

create table "informix".eosoerrptocappic 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    aimagefile varchar(50) not null ,
    abodypart varchar(100),
    astatus char(1),
    aflag char(1),
    apicturedata text,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,aimagefile) 
  );

revoke all on "informix".eosoerrptocappic from "public" as "informix";

{ TABLE "informix".eosoerrpatientdiag row size = 98 number of columns = 15 index size = 37 }

create table "informix".eosoerrpatientdiag 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    aitemno integer,
    aicd9id char(12) not null ,
    achieficd9id char(1),
    agreatill char(1),
    aflag char(1),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerrpatientdiag from "public" as "informix";

{ TABLE "informix".eosoerrptddesc row size = 2078 number of columns = 11 index size = 32 }

create table "informix".eosoerrptddesc 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    aadescription lvarchar(2000),
    aflag char(1),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes) 
  );

revoke all on "informix".eosoerrptddesc from "public" as "informix";

{ TABLE "informix".eosoerrptpdesc row size = 2078 number of columns = 11 index size = 32 }

create table "informix".eosoerrptpdesc 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    apdescription lvarchar(2000),
    aflag char(1),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes) 
  );

revoke all on "informix".eosoerrptpdesc from "public" as "informix";

{ TABLE "informix".eosoerrpatientdrug row size = 393 number of columns = 29 index size = 55 }

create table "informix".eosoerrpatientdrug 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    adrugid char(15),
    adrugdescription varchar(200),
    ameals decimal(5,2),
    aunit char(10),
    afrequencyid char(10),
    arouteid char(10),
    aday decimal(5,2),
    atotalquantity decimal(10,2),
    aexecutestatus char(1),
    aisprivateexpense char(1),
    aisgrind char(1) 
        default 'N',
    aisattach char(1) 
        default 'N',
    aflowrapid char(10),
    areadreporttime datetime year to second,
    areadreportdoctor char(10),
    agetdrugno char(10),
    astationid char(10),
    aisshow char(1) 
        default 'Y',
    aflag char(1),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerrpatientdrug from "public" as "informix";

{ TABLE "informix".eosoerrptdrugat row size = 148 number of columns = 18 index size = 70 }

create table "informix".eosoerrptdrugat 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    adrugid char(15) not null ,
    ameals decimal(5,2),
    aunit char(10),
    afrequencyid char(10),
    arouteid char(10),
    aday decimal(5,2),
    atotalquantity decimal(10,2),
    aflowrapid char(10),
    aisprivateexpense char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno,adrugid) 
  );

revoke all on "informix".eosoerrptdrugat from "public" as "informix";

{ TABLE "informix".eosoerrpatientlab row size = 2172 number of columns = 27 index size = 55 }

create table "informix".eosoerrpatientlab 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    alabid char(15),
    aquantity decimal(3,0),
    aspecimentypeid char(10),
    aisurgent char(1),
    astationid char(10),
    aprice decimal(6,0),
    agetspecimentime datetime year to second,
    aspecimendelivert datetime year to second,
    areportfinishtime datetime year to second,
    areadreporttime datetime year to second,
    areadreportdoctor char(10),
    aisprivateexpense char(1) 
        default 'N',
    aexecutestatus char(1) 
        default '0',
    aisshow char(1) 
        default 'Y',
    aexstatus char(1) 
        default '0',
    aflag char(1),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    alabdescription lvarchar(2000),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerrpatientlab from "public" as "informix";

{ TABLE "informix".eosoerrpatientexam row size = 6377 number of columns = 31 index size = 37 }

create table "informix".eosoerrpatientexam 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    aexamid char(15),
    aquantity decimal(3,0),
    apartid char(10),
    adirection char(1),
    aisurgent char(1),
    areasons lvarchar(2000),
    areasono lvarchar(2000),
    areasona lvarchar(2000),
    aexstatus char(1) 
        default '0',
    aexecutestatus char(1) 
        default '0',
    aisprivateexpense char(1) 
        default 'N',
    aportable char(1),
    atoexamtime datetime year to second,
    aexamfinishtime datetime year to second,
    areportfinishtime datetime year to second,
    areadreporttime datetime year to second,
    areadreportdoctor char(10),
    astationid char(10),
    aisshow char(1) 
        default 'Y',
    aflag char(1),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    aexamdescription varchar(200),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerrpatientexam from "public" as "informix";

{ TABLE "informix".eosoerrpatientproc row size = 2200 number of columns = 28 index size = 37 }

create table "informix".eosoerrpatientproc 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    aprocedureid char(15),
    adescription lvarchar(2000),
    aquantity decimal(3,0),
    apartid char(10),
    aexecutestatus char(1) 
        default '0',
    aisprivateexpense char(1) 
        default 'N',
    aisurgent char(1),
    aprocstarttime datetime year to second,
    aprocfinishtime datetime year to second,
    areadreporttime datetime year to second,
    areadreportdoctor char(10),
    aconsultno char(13),
    afinishdoctorid char(10),
    aphoneanswerdate datetime year to second,
    aphoneansweruserid char(10),
    astationid char(10),
    aisshow char(1) 
        default 'Y',
    aflag char(1),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerrpatientproc from "public" as "informix";

{ TABLE "informix".eosoerrpatientmtl row size = 110 number of columns = 16 index size = 37 }

create table "informix".eosoerrpatientmtl 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    amaterialid char(15),
    aquantity decimal(3,0),
    astationid char(10),
    aadvancenotice char(1),
    aisprivateexpense char(1) 
        default 'N',
    aflag char(1),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerrpatientmtl from "public" as "informix";

{ TABLE "informix".eobebedtransfer row size = 132 number of columns = 14 index size = 33 }

create table "informix".eobebedtransfer 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    asequenceno char(5) not null ,
    aoldroomno char(10),
    aoldbedno char(10),
    anewroomno char(10),
    anewbedno char(10),
    atransferdate datetime year to second,
    atransferempid char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,asequenceno) 
  );

revoke all on "informix".eobebedtransfer from "public" as "informix";

{ TABLE "informix".ntgad row size = 76 number of columns = 8 index size = 22 }

create table "informix".ntgad 
  (
    des_no serial not null ,
    ass_no integer not null ,
    ass_typ char(2) 
        default '' not null ,
    ass_seq smallint not null ,
    nut_itm smallint not null ,
    nut_cmt text not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (des_no) 
  );

revoke all on "informix".ntgad from "public" as "informix";

{ TABLE "informix".ntgar row size = 153 number of columns = 11 index size = 22 }

create table "informix".ntgar 
  (
    ass_no serial not null ,
    ass_dat date not null ,
    chart integer not null ,
    room char(4) not null ,
    bed char(3) not null ,
    hgt decimal(5,1) not null ,
    wgt decimal(5,1) not null ,
    ord char(60) not null ,
    ord_cmt char(60) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ass_no) 
  );

revoke all on "informix".ntgar from "public" as "informix";

{ TABLE "informix".mocmm row size = 36 number of columns = 10 index size = 27 }

create table "informix".mocmm 
  (
    cnr_no serial not null ,
    vsn integer not null ,
    ord_no integer 
        default 0 not null ,
    sys_typ char(2) not null ,
    itm_typ char(2) not null ,
    tsc char(1) not null ,
    cnr_tim datetime year to minute not null ,
    cnr_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (cnr_no) 
  );

revoke all on "informix".mocmm from "public" as "informix";

{ TABLE "informix".mocmi row size = 13 number of columns = 4 index size = 22 }

create table "informix".mocmi 
  (
    evt_no serial not null ,
    cnr_no integer not null ,
    itm_no integer not null ,
    itm_sts char(1) not null ,
    primary key (evt_no) 
  );

revoke all on "informix".mocmi from "public" as "informix";

{ TABLE "informix".mofib row size = 280 number of columns = 8 index size = 31 }

create table "informix".mofib 
  (
    itm_no serial not null ,
    div_no smallint not null ,
    msr_no char(9) not null ,
    det_no char(8) not null ,
    tbl_rel char(1) not null ,
    itm_nam char(250) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (itm_no) 
  );

revoke all on "informix".mofib from "public" as "informix";

{ TABLE "informix".mooss row size = 29 number of columns = 4 index size = 19 }

create table "informix".mooss 
  (
    oss_no serial not null ,
    cls_typ char(1) not null ,
    itm_no integer not null ,
    oth_dsc char(20) not null ,
    primary key (oss_no) 
  );

revoke all on "informix".mooss from "public" as "informix";

{ TABLE "informix".moolls row size = 309 number of columns = 4 index size = 19 }

create table "informix".moolls 
  (
    lls_no serial not null ,
    cls_typ char(1) not null ,
    itm_no integer not null ,
    oth_dsc char(300) not null ,
    primary key (lls_no) 
  );

revoke all on "informix".moolls from "public" as "informix";

{ TABLE "informix".modds row size = 13 number of columns = 4 index size = 19 }

create table "informix".modds 
  (
    dds_no serial not null ,
    cls_typ char(1) not null ,
    itm_no integer not null ,
    dat date not null ,
    primary key (dds_no) 
  );

revoke all on "informix".modds from "public" as "informix";

{ TABLE "informix".mootxt row size = 65 number of columns = 4 index size = 19 }

create table "informix".mootxt 
  (
    txt_no serial not null ,
    cls_typ char(1) not null ,
    itm_no integer not null ,
    oth_dsc text not null ,
    primary key (txt_no) 
  );

revoke all on "informix".mootxt from "public" as "informix";

{ TABLE "informix".mools row size = 129 number of columns = 4 index size = 19 }

create table "informix".mools 
  (
    ols_no serial not null  disabled ,
    cls_typ char(1) not null  disabled ,
    itm_no integer not null  disabled ,
    oth_dsc char(120) not null  disabled 
  );

revoke all on "informix".mools from "public" as "informix";

{ TABLE "informix".zztblupd row size = 48 number of columns = 2 index size = 45 }

create table "informix".zztblupd 
  (
    tbl_nam char(40) not null ,
    last_upd datetime year to second not null ,
    primary key (tbl_nam) 
  );

revoke all on "informix".zztblupd from "public" as "informix";

{ TABLE "informix".ifdpm row size = 23 number of columns = 8 index size = 27 }

create table "informix".ifdpm 
  (
    ifd_no serial not null ,
    chart integer not null ,
    div_no smallint not null ,
    drg_dct smallint not null ,
    pmg_dat date not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ifd_no) 
  );

revoke all on "informix".ifdpm from "public" as "informix";

{ TABLE "informix".ifdpmi row size = 13 number of columns = 4 index size = 22 }

create table "informix".ifdpmi 
  (
    rec_no serial not null ,
    ifd_no integer not null ,
    itm_no integer not null ,
    itm_sts char(1) not null ,
    primary key (rec_no) 
  );

revoke all on "informix".ifdpmi from "public" as "informix";

{ TABLE "informix".ifdpms row size = 34 number of columns = 9 index size = 18 }

create table "informix".ifdpms 
  (
    sts_no serial not null ,
    rec_no integer not null ,
    snd_dat date not null ,
    tsc char(1) 
        default '' not null ,
    exm_rlt char(1) not null ,
    pmg_no char(13) not null ,
    mng_sts char(1) not null ,
    rtp smallint 
        default 0 not null ,
    rtd date 
        default today not null ,
    primary key (sts_no) 
  );

revoke all on "informix".ifdpms from "public" as "informix";

{ TABLE "informix".cmcbd row size = 321 number of columns = 33 index size = 9 }

create table "informix".cmcbd 
  (
    chart integer not null ,
    inc_yea smallint not null ,
    nat_ion char(10) not null ,
    edu_lev char(1) not null ,
    lan_edu char(1) not null ,
    lan_oth char(10) not null ,
    mar_sta char(1) not null ,
    job_sta char(1) not null ,
    job_oth char(10) not null ,
    eco_sta char(1) not null ,
    hv decimal(5,1) not null ,
    wv decimal(5,1) not null ,
    dri_hab char(1) not null ,
    dri_cap char(20) 
        default '' not null ,
    dro_yea char(20) 
        default '' not null ,
    drl_yea char(20) 
        default '' not null ,
    smo_hab char(1) not null ,
    smo_cap char(20) 
        default '' not null ,
    smo_yea char(20) 
        default '' not null ,
    smn_yea char(20) 
        default '' not null ,
    are_hab char(1) not null ,
    are_cap char(20) 
        default '' not null ,
    are_yea char(20) 
        default '' not null ,
    arn_yea char(20) 
        default '' not null ,
    con_nao char(10) not null ,
    con_teo char(30) not null ,
    con_reo char(1) not null ,
    con_nas char(10) not null ,
    con_tes char(30) not null ,
    con_res char(1) not null ,
    lmp_cod char(1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (chart) 
  );

revoke all on "informix".cmcbd from "public" as "informix";

{ TABLE "informix".cmcsd row size = 66 number of columns = 7 index size = 20 }

create table "informix".cmcsd 
  (
    sub_no serial not null ,
    chart integer not null ,
    sub_seq smallint not null ,
    sub_oth char(30) not null ,
    sub_yea char(20) 
        default '' not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (sub_no) 
  );

revoke all on "informix".cmcsd from "public" as "informix";

{ TABLE "informix".cmcpird row size = 218 number of columns = 20 index size = 24 }

create table "informix".cmcpird 
  (
    pat_no serial not null ,
    chart integer not null ,
    can_typ smallint not null ,
    pat_dat date not null ,
    his_typ char(1) not null ,
    his_oth char(40) not null ,
    org_dif char(1) not null ,
    org_oth char(40) not null ,
    siz_hei decimal(6,2) not null ,
    siz_wei decimal(6,2) not null ,
    sur_mar char(1) not null ,
    lym_nod char(1) not null ,
    lym_cnt smallint not null ,
    lym_dit smallint not null ,
    dis_met char(1) not null ,
    dis_cmt char(50) not null ,
    inv_pos char(1) not null ,
    inv_cmt char(50) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (pat_no) 
  );

revoke all on "informix".cmcpird from "public" as "informix";

{ TABLE "informix".cmcesd row size = 25 number of columns = 10 index size = 25 }

create table "informix".cmcesd 
  (
    enr_no serial not null ,
    chart integer not null ,
    can_typ smallint not null ,
    enr_dat date not null ,
    enr_typ char(1) not null ,
    enr_rea char(1) not null ,
    enr_emp smallint not null ,
    sgn_sts char(1) 
        default 'N' not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (enr_no) 
  );

revoke all on "informix".cmcesd from "public" as "informix";

{ TABLE "informix".cmcctd row size = 105 number of columns = 15 index size = 26 }

create table "informix".cmcctd 
  (
    tre_no serial not null ,
    chart integer not null ,
    can_typ smallint not null ,
    tre_sta date not null ,
    tre_end date not null ,
    tre_typ smallint not null ,
    tre_po1 char(4) not null ,
    tre_po2 char(4) not null ,
    tre_po3 char(4) not null ,
    tre_po4 char(4) not null ,
    dos_qty decimal(7,2) not null ,
    dos_tot smallint not null ,
    dos_cmt text not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (tre_no) 
  );

revoke all on "informix".cmcctd from "public" as "informix";

{ TABLE "informix".cmccad row size = 74 number of columns = 10 index size = 22 }

create table "informix".cmccad 
  (
    adv_no serial not null ,
    chart integer not null ,
    adv_dat date not null ,
    adv_tis smallint not null ,
    adv_tie smallint not null ,
    age_str char(1) not null ,
    adv_ide char(1) not null ,
    adv_cmt char(50) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (adv_no) 
  );

revoke all on "informix".cmccad from "public" as "informix";

{ TABLE "informix".cmctfur row size = 29 number of columns = 11 index size = 20 }

create table "informix".cmctfur 
  (
    tfu_no serial not null ,
    chart integer not null ,
    can_typ smallint not null ,
    tfu_typ char(1) not null ,
    fol_dat date not null ,
    nex_dat date not null ,
    nex_int char(1) not null ,
    fol_emp smallint not null ,
    fol_flg char(1) 
        default '' not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (tfu_no) 
  );

revoke all on "informix".cmctfur from "public" as "informix";

{ TABLE "informix".cmched row size = 148 number of columns = 14 index size = 22 }

create table "informix".cmched 
  (
    edu_no serial not null ,
    chart integer not null ,
    edu_dat date not null ,
    edu_tis smallint not null ,
    edu_tie smallint not null ,
    can_typ smallint not null ,
    edu_fam char(2) not null ,
    fam_oth char(20) not null ,
    edu_itm char(1) not null ,
    edu_oth char(50) not null ,
    ref_sev char(1) not null ,
    ref_oth char(50) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (edu_no) 
  );

revoke all on "informix".cmched from "public" as "informix";

{ TABLE "informix".cmtmppd row size = 16 number of columns = 5 index size = 20 }

create table "informix".cmtmppd 
  (
    mpp_no serial not null ,
    mee_no integer not null ,
    mee_dct smallint not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (mpp_no) 
  );

revoke all on "informix".cmtmppd from "public" as "informix";

{ TABLE "informix".cmtpcd row size = 14 number of columns = 5 index size = 18 }

create table "informix".cmtpcd 
  (
    tem_no serial not null ,
    can_typ smallint not null ,
    tem_dct smallint not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (tem_no) 
  );

revoke all on "informix".cmtpcd from "public" as "informix";

{ TABLE "informix".rodipr row size = 18 number of columns = 7 index size = 20 }

create table "informix".rodipr 
  (
    dia_no serial not null ,
    chart integer not null ,
    can_typ smallint not null ,
    ecg_sts char(1) not null ,
    kps_sts char(1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (dia_no) 
  );

revoke all on "informix".rodipr from "public" as "informix";

{ TABLE "informix".rocpsr row size = 17 number of columns = 6 index size = 21 }

create table "informix".rocpsr 
  (
    cps_no serial not null ,
    dia_no integer not null ,
    dia_sta char(1) not null ,
    dia_lev smallint not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (cps_no) 
  );

revoke all on "informix".rocpsr from "public" as "informix";

{ TABLE "informix".rotgr row size = 86 number of columns = 14 index size = 24 }

create table "informix".rotgr 
  (
    tre_no serial not null ,
    chart integer not null ,
    tre_eff date not null ,
    tre_stp date not null ,
    can_typ smallint not null ,
    tre_tgt char(1) not null ,
    rad_tre char(1) not null ,
    sur_seq char(1) not null ,
    com_che char(1) not null ,
    com_rgm text not null ,
    rad_tgt char(1) not null ,
    tre_hsp char(1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (tre_no) 
  );

revoke all on "informix".rotgr from "public" as "informix";

{ TABLE "informix".rostr row size = 134 number of columns = 10 index size = 23 }

create table "informix".rostr 
  (
    xra_no serial not null ,
    xra_dat date not null ,
    tre_no integer not null ,
    oth_rad char(1) not null ,
    rad_rsm text not null ,
    eng_sid text not null ,
    rad_res char(1) not null ,
    rad_emp smallint not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (xra_no) 
  );

revoke all on "informix".rostr from "public" as "informix";

{ TABLE "informix".rosldtr row size = 26 number of columns = 10 index size = 30 }

create table "informix".rosldtr 
  (
    sum_no serial not null ,
    sum_dat date not null ,
    tre_no integer not null ,
    tre_pos char(2) not null ,
    sum_dos char(1) not null ,
    sum_tcd char(1) not null ,
    tum_tot smallint not null ,
    tum_cnt smallint not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (sum_no) 
  );

revoke all on "informix".rosldtr from "public" as "informix";

{ TABLE "informix".rosdtter row size = 119 number of columns = 8 index size = 20 }

create table "informix".rosdtter 
  (
    det_no serial not null ,
    sum_no integer not null ,
    tre_seq smallint not null ,
    tre_dos smallint not null ,
    tre_unt char(1) not null ,
    tre_cmt char(100) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (det_no) 
  );

revoke all on "informix".rosdtter from "public" as "informix";

{ TABLE "informix".rodtsr row size = 53 number of columns = 6 index size = 56 }

create table "informix".rodtsr 
  (
    pos_no serial not null ,
    tre_pos char(2) not null ,
    pos_nam char(40) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (pos_no) 
  );

revoke all on "informix".rodtsr from "public" as "informix";

{ TABLE "informix".eoged row size = 82 number of columns = 5 index size = 31 }

create table "informix".eoged 
  (
    itm_no serial not null ,
    atriageid char(13) not null ,
    eva_no integer not null ,
    tsc char(1) not null ,
    oth_dsc char(60) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".eoged from "public" as "informix";

{ TABLE "informix".momsg row size = 56 number of columns = 15 index size = 53 }

create table "informix".momsg 
  (
    msg_no serial not null ,
    chart integer not null ,
    map_no smallint not null ,
    lvl char(1) not null ,
    tsc char(1) not null ,
    fun_no char(4) not null ,
    lnk_no integer not null ,
    lnk_cod char(7) 
        default '' not null ,
    sed_man smallint not null ,
    sed_tim datetime year to minute not null ,
    rec_man smallint not null ,
    rec_tim datetime year to minute 
        default  datetime (1899-12-31 00:00) year to minute not null ,
    rec_loc smallint not null ,
    rtp smallint not null ,
    rtd datetime year to minute not null ,
    primary key (msg_no) 
  );

revoke all on "informix".momsg from "public" as "informix";

{ TABLE "informix".momsg2 row size = 404 number of columns = 7 index size = 9 }

create table "informix".momsg2 
  (
    msg_no integer not null ,
    msg_txt char(255) not null ,
    exe_tim datetime year to minute not null ,
    exe_rsn char(1) 
        default '' not null ,
    cmt char(128) not null ,
    rtp smallint not null ,
    rtd datetime year to minute not null ,
    primary key (msg_no) 
  );

revoke all on "informix".momsg2 from "public" as "informix";

{ TABLE "informix".mosmi row size = 32 number of columns = 9 index size = 35 }

create table "informix".mosmi 
  (
    mst_no serial not null ,
    lnk_no integer not null ,
    fun_typ char(2) not null ,
    sht_typ char(2) not null ,
    tsc char(1) not null ,
    rec_tim datetime year to minute not null ,
    rec_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (mst_no) 
  );

revoke all on "informix".mosmi from "public" as "informix";

{ TABLE "informix".mosdi row size = 13 number of columns = 4 index size = 18 }

create table "informix".mosdi 
  (
    dtl_no serial not null ,
    mst_no integer not null ,
    itm_no integer not null ,
    itm_sts char(1) not null ,
    primary key (dtl_no) 
  );

revoke all on "informix".mosdi from "public" as "informix";

{ TABLE "informix".roptar row size = 80 number of columns = 10 index size = 25 }

create table "informix".roptar 
  (
    pta_no serial not null ,
    chart integer not null ,
    can_typ smallint not null ,
    pta_dat date not null ,
    pta_typ char(1) not null ,
    pta_txt text not null ,
    pta_doc smallint not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (pta_no) 
  );

revoke all on "informix".roptar from "public" as "informix";

{ TABLE "informix".mrpsrdd row size = 44 number of columns = 6 index size = 20 }

create table "informix".mrpsrdd 
  (
    dtl_no serial not null ,
    chart integer not null ,
    spc_mrk smallint not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    spc_dsc char(20) not null ,
    primary key (dtl_no) 
  );

revoke all on "informix".mrpsrdd from "public" as "informix";

{ TABLE "informix".moccirp row size = 38 number of columns = 7 index size = 25 }

create table "informix".moccirp 
  (
    ref_no serial not null ,
    itm_no integer not null ,
    ptc_cod char(7) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (ref_no) 
  );

revoke all on "informix".moccirp from "public" as "informix";

{ TABLE "informix".movuot row size = 30 number of columns = 5 index size = 9 }

create table "informix".movuot 
  (
    vsn integer not null ,
    ord_rtt datetime year to second 
        default  datetime (1899-12-31 00:00:00) year to second not null ,
    nod_rtt datetime year to second 
        default  datetime (1899-12-31 00:00:00) year to second not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (vsn) 
  );

revoke all on "informix".movuot from "public" as "informix";

{ TABLE "informix".mocfl row size = 19 number of columns = 5 index size = 19 }

create table "informix".mocfl 
  (
    cfm_no serial not null ,
    cfm_typ char(1) not null ,
    lnk_no integer not null ,
    cfm_man smallint not null ,
    cfm_tim datetime year to second 
        default current year to second not null ,
    primary key (cfm_no) 
  );

revoke all on "informix".mocfl from "public" as "informix";

{ TABLE "informix".npieb2 row size = 26 number of columns = 6 index size = 18 }

create table "informix".npieb2 
  (
    rec_no serial not null ,
    eva_no integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".npieb2 from "public" as "informix";

{ TABLE "informix".moicpm row size = 51 number of columns = 8 index size = 52 }

create table "informix".moicpm 
  (
    icp_no serial not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    chg_cod char(7) not null ,
    cmb_pst char(16) not null ,
    icp_cod char(10) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (icp_no) 
  );

revoke all on "informix".moicpm from "public" as "informix";

{ TABLE "informix".udsdr row size = 43 number of columns = 10 index size = 49 }

create table "informix".udsdr 
  (
    sdr_no serial not null ,
    chart integer not null ,
    exp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    typ char(1) not null ,
    room char(4) not null ,
    bed char(2) not null ,
    prt_nam char(10) 
        default '' not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (sdr_no) 
  );

revoke all on "informix".udsdr from "public" as "informix";

{ TABLE "informix".udsdd row size = 44 number of columns = 12 index size = 27 }

create table "informix".udsdd 
  (
    det_no serial not null ,
    sdr_no integer not null ,
    itm_no integer not null ,
    dug_typ char(1) not null ,
    udr_qty1 decimal(8,2) not null ,
    udr_qty2 decimal(8,2) not null ,
    sdr_man smallint not null ,
    sdr_tim datetime year to minute not null ,
    snd_way smallint not null ,
    cfm_sts char(1) 
        default '' not null ,
    cfm_man smallint not null ,
    cfm_tim datetime year to minute not null ,
    primary key (det_no) 
  );

revoke all on "informix".udsdd from "public" as "informix";

{ TABLE "informix".udsddlog row size = 29 number of columns = 8 index size = 18 }

create table "informix".udsddlog 
  (
    log_no serial not null ,
    det_no integer not null ,
    sdr_man smallint not null ,
    sdr_tim datetime year to minute not null ,
    snd_way smallint not null ,
    cfm_sts char(1) 
        default '' not null ,
    cfm_man smallint not null ,
    cfm_tim datetime year to minute not null ,
    primary key (log_no) 
  );

revoke all on "informix".udsddlog from "public" as "informix";

{ TABLE "informix".udsdbd row size = 41 number of columns = 6 index size = 25 }

create table "informix".udsdbd 
  (
    sbd_no serial not null ,
    sbd_typ char(1) not null ,
    ref_cod char(10) not null ,
    ref_nam char(20) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (sbd_no) 
  );

revoke all on "informix".udsdbd from "public" as "informix";

{ TABLE "informix".nherst row size = 24 number of columns = 6 index size = 24 }

create table "informix".nherst 
  (
    ser_no serial not null ,
    itm_cod char(6) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".nherst from "public" as "informix";

{ TABLE "informix".nhudficd row size = 31 number of columns = 8 index size = 25 }

create table "informix".nhudficd 
  (
    ser_no serial not null ,
    typ char(1) not null ,
    icd_f char(6) not null ,
    icd_t char(6) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".nhudficd from "public" as "informix";

{ TABLE "informix".mrvrd row size = 38 number of columns = 5 index size = 18 }

create table "informix".mrvrd 
  (
    vrd_no serial not null ,
    vsn integer not null ,
    rec_typ char(2) not null ,
    rec_txt char(20) not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (vrd_no) 
  );

revoke all on "informix".mrvrd from "public" as "informix";

{ TABLE "informix".nhietnms row size = 42 number of columns = 7 index size = 30 }

create table "informix".nhietnms 
  (
    ser_no serial not null ,
    itm_f char(12) not null ,
    itm_t char(12) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".nhietnms from "public" as "informix";

{ TABLE "informix".ifdmr row size = 24 number of columns = 9 index size = 27 }

create table "informix".ifdmr 
  (
    ifd_no serial not null ,
    chart integer not null ,
    div_no smallint not null ,
    drg_dct smallint not null ,
    pmg_dat date not null ,
    typ char(1) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ifd_no) 
  );

revoke all on "informix".ifdmr from "public" as "informix";

{ TABLE "informix".mracbd row size = 92 number of columns = 13 index size = 24 }

create table "informix".mracbd 
  (
    acb_no serial not null ,
    tc char(1) not null ,
    id_no char(10) not null ,
    nam char(20) not null ,
    born_yy smallint not null ,
    born_mmdd smallint not null ,
    sex char(1) not null ,
    c_r_cod integer not null ,
    c_r_adrs char(34) not null ,
    tel_1 integer not null ,
    tel_2 integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (acb_no) 
  );

revoke all on "informix".mracbd from "public" as "informix";

{ TABLE "informix".mocacdi row size = 21 number of columns = 7 index size = 20 }

create table "informix".mocacdi 
  (
    cac_no serial not null ,
    dtl_typ char(2) not null ,
    lnk_no integer not null ,
    itm_no integer not null ,
    itm_sts char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (cac_no) 
  );

revoke all on "informix".mocacdi from "public" as "informix";

{ TABLE "ap21".ocmcpgmd2 row size = 127 number of columns = 9 index size = 31 }

create table "ap21".ocmcpgmd2 
  (
    evt_no serial not null ,
    cas_no integer not null ,
    chart integer not null ,
    use_typ char(1) not null ,
    use_dat date not null ,
    use_qty decimal(6,2) not null ,
    cmt char(100) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (evt_no) 
  );

revoke all on "ap21".ocmcpgmd2 from "public" as "ap21";

{ TABLE "informix".ocmcpgmd row size = 135 number of columns = 11 index size = 31 }

create table "informix".ocmcpgmd 
  (
    evt_no serial not null ,
    cas_no integer not null ,
    chart integer not null ,
    use_typ char(1) not null ,
    use_dat date not null ,
    use_qty decimal(6,2) not null ,
    visit_no decimal(11,0) 
        default 0 not null ,
    pas_sts char(1) 
        default '' not null ,
    cmt char(100) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (evt_no) 
  );

revoke all on "informix".ocmcpgmd from "public" as "informix";

{ TABLE "informix".cmcg row size = 22 number of columns = 6 index size = 22 }

create table "informix".cmcg 
  (
    cmg_id serial not null ,
    grp_id integer not null ,
    cus_id integer not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rthm datetime year to minute not null ,
    primary key (cmg_id) 
  );

revoke all on "informix".cmcg from "public" as "informix";

{ TABLE "informix".mrrmdm row size = 55 number of columns = 10 index size = 54 }

create table "informix".mrrmdm 
  (
    dcm_no serial not null ,
    chart integer not null ,
    frm char(1) 
        default '' not null ,
    typ char(1) not null ,
    did_no char(30) 
        default '' not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    rtd date not null ,
    rtp smallint not null ,
    primary key (dcm_no) 
  );

revoke all on "informix".mrrmdm from "public" as "informix";

{ TABLE "informix".moiolog row size = 25 number of columns = 7 index size = 18 }

create table "informix".moiolog 
  (
    log_num serial not null ,
    fun_no char(4) not null ,
    lnk_num integer not null ,
    emp_no smallint not null ,
    loc_no smallint not null ,
    log_sts char(1) not null ,
    log_tim datetime year to second 
        default current year to second not null ,
    primary key (log_num) 
  );

revoke all on "informix".moiolog from "public" as "informix";

{ TABLE "informix".moqr row size = 22 number of columns = 6 index size = 34 }

create table "informix".moqr 
  (
    log_tim datetime year to second 
        default current year to second not null ,
    emp_no smallint not null ,
    fun_no char(4) not null ,
    loc_no smallint not null ,
    chart integer not null ,
    map_no smallint 
        default 0 not null ,
    primary key (log_tim,emp_no,map_no) 
  );

revoke all on "informix".moqr from "public" as "informix";

{ TABLE "informix".sdcallog row size = 1064 number of columns = 14 index size = 18 }

create table "informix".sdcallog 
  (
    log_num serial not null ,
    evt_num integer not null ,
    tsc char(1) not null ,
    sub char(20) not null ,
    lnk_typ char(1) not null ,
    lnk_num integer not null ,
    mis_num integer not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    emp_no smallint not null ,
    pmt char(1) not null ,
    coment char(1000) 
        default '' not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (log_num) 
  );

revoke all on "informix".sdcallog from "public" as "informix";

{ TABLE "informix".tddrgab row size = 34 number of columns = 10 index size = 18 }

create table "informix".tddrgab 
  (
    ser_no serial not null ,
    fym smallint not null ,
    tym smallint not null ,
    spr integer not null ,
    sla integer not null ,
    rat_b decimal(4,3) not null ,
    rat_c decimal(4,3) not null ,
    rat_m decimal(4,3) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".tddrgab from "public" as "informix";

{ TABLE "informix".mopnmp row size = 26 number of columns = 7 index size = 31 }

create table "informix".mopnmp 
  (
    prc_no serial not null ,
    vsn integer not null ,
    typ integer not null ,
    seq_no smallint not null ,
    ver_no smallint 
        default 0 not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (prc_no) 
  );

revoke all on "informix".mopnmp from "public" as "informix";

{ TABLE "informix".doolev row size = 110 number of columns = 17 index size = 22 }

create table "informix".doolev 
  (
    lev_no serial not null ,
    dct_no integer not null ,
    apl_dat date not null ,
    eff_dat date not null ,
    fhm smallint not null ,
    stp_dat date not null ,
    thm smallint not null ,
    lev_typ char(5) not null ,
    go_abd char(1) not null ,
    opd char(1) not null ,
    cmt char(60) not null ,
    sts char(1) not null ,
    sgn_seq char(2) not null ,
    lnk_lev integer not null ,
    amc_tot integer not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (lev_no) 
  );

revoke all on "informix".doolev from "public" as "informix";

{ TABLE "informix".dolevoa row size = 41 number of columns = 14 index size = 18 }

create table "informix".dolevoa 
  (
    agt_no serial not null ,
    lev_no integer not null ,
    vst_dat date not null ,
    sft char(1) not null ,
    rom smallint not null ,
    agt_typ char(1) not null ,
    agt_rom smallint not null ,
    agt_dct integer not null ,
    sgn_seq char(2) not null ,
    sts char(1) not null ,
    lnk_agt integer not null ,
    amc_amt integer not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (agt_no) 
  );

revoke all on "informix".dolevoa from "public" as "informix";

{ TABLE "informix".dolevwa row size = 29 number of columns = 8 index size = 22 }

create table "informix".dolevwa 
  (
    wgt_no serial not null ,
    lev_no integer not null ,
    dct integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (wgt_no) 
  );

revoke all on "informix".dolevwa from "public" as "informix";

{ TABLE "informix".doolsp row size = 120 number of columns = 8 index size = 18 }

create table "informix".doolsp 
  (
    sgn_no serial not null ,
    typ char(1) not null ,
    lnk_no integer not null ,
    sgn_seq char(2) not null ,
    sgn_sts char(1) not null ,
    sgn_cmt char(100) not null ,
    sgn_emp integer not null ,
    rtd date not null ,
    primary key (sgn_no) 
  );

revoke all on "informix".doolsp from "public" as "informix";

{ TABLE "informix".cgrcod row size = 35 number of columns = 7 index size = 30 }

create table "informix".cgrcod 
  (
    chg_cod char(7) not null ,
    typ char(2) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    cod char(12) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chg_cod,typ,eff_dat,cod) 
  );

revoke all on "informix".cgrcod from "public" as "informix";

{ TABLE "informix".mocdus row size = 10 number of columns = 5 index size = 9 }

create table "informix".mocdus 
  (
    itm_no integer not null ,
    src char(1) not null ,
    typ char(1) not null ,
    def_seq smallint not null ,
    rel_seq smallint not null ,
    primary key (itm_no) 
  );

revoke all on "informix".mocdus from "public" as "informix";

{ TABLE "informix".lbplval row size = 94 number of columns = 10 index size = 18 }

create table "informix".lbplval 
  (
    rvl_no serial not null ,
    chart integer not null ,
    chg_cod char(7) not null ,
    lab_nam char(10) not null ,
    val char(20) not null ,
    lv char(10) not null ,
    hv char(20) not null ,
    rpt_tim datetime year to minute not null ,
    lab_no integer not null ,
    rtt datetime year to second not null ,
    primary key (rvl_no) 
  );

revoke all on "informix".lbplval from "public" as "informix";

{ TABLE "informix".nhdnicc row size = 30 number of columns = 4 index size = 17 }

create table "informix".nhdnicc 
  (
    nhi_cod char(12) not null ,
    ctl_cod char(12) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (nhi_cod) 
  );

revoke all on "informix".nhdnicc from "public" as "informix";

{ TABLE "informix".nhtpgd row size = 14 number of columns = 5 index size = 18 }

create table "informix".nhtpgd 
  (
    ser_no serial not null ,
    grp char(2) not null ,
    pos char(2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".nhtpgd from "public" as "informix";

{ TABLE "informix".mtval row size = 25 number of columns = 6 index size = 23 }

create table "informix".mtval 
  (
    val_no serial not null ,
    mt_cod char(7) not null ,
    typ char(2) not null ,
    val integer not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (val_no) 
  );

revoke all on "informix".mtval from "public" as "informix";

{ TABLE "informix".moeci row size = 125 number of columns = 8 index size = 21 }

create table "informix".moeci 
  (
    chk_no serial not null ,
    chg_cod char(7) not null ,
    div_no smallint not null ,
    seq_no smallint not null ,
    chk_nam char(100) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (chk_no) 
  );

revoke all on "informix".moeci from "public" as "informix";

{ TABLE "informix".bmbed row size = 75 number of columns = 30 index size = 55 }

create table "informix".bmbed 
  (
    room char(4) 
        default '' not null ,
    bed char(2) not null ,
    class char(1) not null ,
    rank char(1) not null ,
    division_rm smallint not null ,
    doctor_rm smallint not null ,
    ward char(3) 
        default '' not null ,
    dpt_no smallint 
        default 0 not null ,
    team char(1) not null ,
    ud char(1) not null ,
    toilet char(1) not null ,
    disbu char(1) not null ,
    sex_ctl char(1) not null ,
    sts char(1) not null ,
    chart integer not null ,
    acc_no integer not null ,
    isolat char(1) not null ,
    nam char(12) not null ,
    sex char(1) not null ,
    born_yy smallint not null ,
    zip smallint not null ,
    fil1 char(1) not null ,
    pre_dat date not null ,
    pre_chart integer not null ,
    cur_loc char(3) not null ,
    udd_dat date 
        default today not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null ,
    rtl smallint not null 
  );

revoke all on "informix".bmbed from "public" as "informix";

{ TABLE "informix".moitm row size = 326 number of columns = 21 index size = 58 }

create table "informix".moitm 
  (
    itm_no serial not null ,
    ord_no integer not null ,
    seq_no smallint 
        default 1 not null ,
    chg_cod char(7) not null ,
    dos_qty char(5) 
        default '' not null ,
    itm1 char(4) 
        default '' not null ,
    itm2 char(4) 
        default '' not null ,
    itm3 char(4) 
        default '' not null ,
    itm4 char(4) 
        default '' not null ,
    exe_qty char(5) 
        default '0' not null ,
    nhi_qty decimal(5,1) 
        default 0.0 not null ,
    slf_qty decimal(5,1) 
        default 0.0 not null ,
    mrk char(1) 
        default '' not null ,
    adv varchar(255),
    lnk_typ char(1) 
        default '' not null ,
    lnk_no integer 
        default 0 not null ,
    nrs_man smallint 
        default 0 not null ,
    nrs_dat date 
        default  '2025/12/31' not null ,
    nrs_hm smallint 
        default 0 not null ,
    nrs_sts char(1) 
        default '' not null ,
    chg_no integer 
        default 0 not null ,
    primary key (itm_no) 
  );

revoke all on "informix".moitm from "public" as "informix";

{ TABLE "informix".mtbillgn row size = 31 number of columns = 6 index size = 33 }

create table "informix".mtbillgn 
  (
    grp_no serial not null ,
    grp_cod char(7) not null ,
    nhi_cod char(12) not null ,
    qty smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (grp_no) 
  );

revoke all on "informix".mtbillgn from "public" as "informix";

{ TABLE "informix".npcmr row size = 33 number of columns = 8 index size = 23 }

create table "informix".npcmr 
  (
    cvr_no serial not null ,
    emp_no smallint not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    cvr_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (cvr_no) 
  );

revoke all on "informix".npcmr from "public" as "informix";

{ TABLE "informix".npstcm row size = 36 number of columns = 9 index size = 33 }

create table "informix".npstcm 
  (
    sft_no serial not null ,
    dpt_no smallint not null ,
    grp char(3) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    stc_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (sft_no) 
  );

revoke all on "informix".npstcm from "public" as "informix";

{ TABLE "informix".npgrb row size = 44 number of columns = 11 index size = 39 }

create table "informix".npgrb 
  (
    grp_no serial not null ,
    dpt_no smallint not null ,
    grp char(3) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    stp_rsn char(1) not null ,
    room char(4) not null ,
    bed char(2) not null ,
    acc_no integer not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (grp_no) 
  );

revoke all on "informix".npgrb from "public" as "informix";

{ TABLE "informix".npoxls row size = 609 number of columns = 4 index size = 19 }

create table "informix".npoxls 
  (
    xls_no serial not null ,
    cls_typ char(1) not null ,
    itm_no integer not null ,
    oth_dsc char(600) not null ,
    primary key (xls_no) 
  );

revoke all on "informix".npoxls from "public" as "informix";

{ TABLE "informix".cmtmpd row size = 642 number of columns = 16 index size = 33 }

create table "informix".cmtmpd 
  (
    mpd_no serial not null ,
    mee_no integer not null ,
    can_typ smallint 
        default 0 not null ,
    chart integer not null ,
    icd_cod text not null ,
    oth_cmt char(60) not null ,
    met_obj char(20) not null ,
    met_oth char(60) not null ,
    met_con text not null ,
    met_res text not null ,
    met_rep smallint not null ,
    tre_gui char(1) not null ,
    gui_cmt char(255) not null ,
    cmt text not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (mpd_no) 
  );

revoke all on "informix".cmtmpd from "public" as "informix";

{ TABLE "informix".cmctmr row size = 200 number of columns = 18 index size = 20 }

create table "informix".cmctmr 
  (
    mee_no serial not null ,
    mee_dat date not null ,
    mee_typ smallint not null ,
    mee_obj char(40) not null ,
    mee_yy smallint not null ,
    mee_seq smallint not null ,
    mee_hos smallint not null ,
    mee_rec smallint not null ,
    mee_loc char(30) not null ,
    acc_div smallint not null ,
    act_div smallint not null ,
    new_cas smallint not null ,
    act_dis smallint not null ,
    pri_dis smallint not null ,
    dis_chd char(40) not null ,
    cmt text not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (mee_no) 
  );

revoke all on "informix".cmctmr from "public" as "informix";

{ TABLE "informix".cmpipd row size = 72 number of columns = 6 index size = 20 }

create table "informix".cmpipd 
  (
    pip_no serial not null ,
    mpd_no integer not null ,
    ind_dct smallint not null ,
    cmt text not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (pip_no) 
  );

revoke all on "informix".cmpipd from "public" as "informix";

{ TABLE "ap15".mrchgadr row size = 72 number of columns = 3 index size = 9 }

create table "ap15".mrchgadr 
  (
    chg_no serial not null ,
    old_adr char(34) not null ,
    new_adr char(34) not null ,
    primary key (chg_no) 
  );

revoke all on "ap15".mrchgadr from "public" as "ap15";

{ TABLE "informix".moir row size = 24 number of columns = 7 index size = 28 }

create table "informix".moir 
  (
    rlt_no serial not null ,
    typ char(1) not null ,
    frm_no integer not null ,
    lnk_no integer not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rlt_no) 
  );

revoke all on "informix".moir from "public" as "informix";

{ TABLE "informix".dglmpr row size = 55 number of columns = 14 index size = 44 }

create table "informix".dglmpr 
  (
    rec_no serial not null ,
    rec_typ char(1) not null ,
    lnk_no integer not null ,
    cmp_tim datetime year to second not null ,
    hpt_loc char(1) 
        default '1' not null ,
    lmp_loc smallint not null ,
    lmp_typ char(1) not null ,
    lmp_no smallint not null ,
    tsc char(1) not null ,
    prn_tim datetime year to minute not null ,
    chg_tim datetime year to minute 
        default  datetime (1899-12-31 00:00) year to minute not null ,
    out_tim datetime year to minute not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".dglmpr from "public" as "informix";

{ TABLE "informix".npnsr row size = 30 number of columns = 9 index size = 19 }

create table "informix".npnsr 
  (
    nsr_no serial not null ,
    cls_typ char(1) not null ,
    itm_no integer not null ,
    act_typ char(1) not null ,
    tsc char(1) not null ,
    act_man smallint not null ,
    act_tim datetime year to minute not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (nsr_no) 
  );

revoke all on "informix".npnsr from "public" as "informix";

{ TABLE "informix".ntpdadt2 row size = 20 number of columns = 6 index size = 14 }

create table "informix".ntpdadt2 
  (
    acc_no integer not null ,
    f_dat date not null ,
    f_meal char(1) not null ,
    add_typ char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second,
    primary key (acc_no,f_dat,f_meal) 
  );

revoke all on "informix".ntpdadt2 from "public" as "informix";

{ TABLE "informix".pdpcr row size = 51 number of columns = 12 index size = 20 }

create table "informix".pdpcr 
  (
    ser_no serial not null ,
    chart integer not null ,
    typ char(2) not null ,
    sgn_dtt datetime year to second not null ,
    stp_dtt datetime year to second 
        default  datetime (2025-12-31 23:59:59) year to second not null ,
    tsc char(1) not null ,
    lnk_no integer not null ,
    cst char(1) not null ,
    opt char(5) 
        default '' not null ,
    frm char(4) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".pdpcr from "public" as "informix";

{ TABLE "informix".cgppi row size = 161 number of columns = 10 index size = 21 }

create table "informix".cgppi 
  (
    pkg_no serial not null ,
    pkg_cod char(7) not null ,
    nam char(50) not null ,
    eff_dat date 
        default today not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    typ char(2) not null ,
    pkg_amt integer not null ,
    cmt char(80) 
        default '' not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (pkg_no) 
  );

revoke all on "informix".cgppi from "public" as "informix";

{ TABLE "informix".dci10cn row size = 575 number of columns = 23 index size = 40 }

create table "informix".dci10cn 
  (
    icd_cod char(8) not null ,
    typ char(2) not null ,
    nhi_cod char(9) not null ,
    drg_cod char(5) not null ,
    qip_drg char(6) not null ,
    nam_e char(255) not null ,
    nam_c char(255) not null ,
    icd_typ char(4) not null ,
    sru_mrk smallint not null ,
    ifq_mrk char(1) not null ,
    crn_mrk char(1) not null ,
    crn_typ char(6) not null ,
    con_mrk char(1) not null ,
    con_typ smallint not null ,
    sex_lmt char(1) not null ,
    dag_lmt char(1) not null ,
    spc_typ char(2) not null ,
    min_age smallint not null ,
    max_age smallint not null ,
    std_days smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null ,
    primary key (icd_cod) 
  );

revoke all on "informix".dci10cn from "public" as "informix";

{ TABLE "informix".dcicdm row size = 31 number of columns = 7 index size = 33 }

create table "informix".dcicdm 
  (
    imp_no serial not null ,
    i09_cod char(6) not null ,
    i10_cod char(8) not null ,
    map_typ char(5) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null ,
    primary key (imp_no) 
  );

revoke all on "informix".dcicdm from "public" as "informix";

{ TABLE "informix".ooptmeet row size = 37 number of columns = 9 index size = 25 }

create table "informix".ooptmeet 
  (
    evt_no serial not null ,
    chart integer not null ,
    visit_no decimal(11,0) not null ,
    exm_typ char(1) not null ,
    evt_typ char(1) not null ,
    cnt smallint not null ,
    tim datetime year to second not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (evt_no) 
  );

revoke all on "informix".ooptmeet from "public" as "informix";

{ TABLE "informix".ooptmret row size = 27 number of columns = 6 index size = 25 }

create table "informix".ooptmret 
  (
    evt_no serial not null ,
    chart integer not null ,
    visit_no decimal(11,0) not null ,
    evt_typ char(2) not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (evt_no) 
  );

revoke all on "informix".ooptmret from "public" as "informix";

{ TABLE "informix".mrpbd99 row size = 127 number of columns = 31 index size = 62 }

create table "informix".mrpbd99 
  (
    chart integer not null ,
    nam char(12) not null ,
    born_yy smallint not null ,
    born_mmdd smallint not null ,
    sex char(1) not null ,
    l_mark char(1) not null ,
    c_r_cod integer not null ,
    c_r_adrs char(34) not null ,
    domicile char(8) not null ,
    marr char(1) not null ,
    educ char(1) not null ,
    profes char(3) not null ,
    fil1 char(1) not null ,
    id_no char(10) not null ,
    tel_h integer not null ,
    tel_o integer not null ,
    gl_typ char(2) not null ,
    bl_typ char(2) not null ,
    pt_typ char(2) not null ,
    sp_typ char(2) not null ,
    sw_typ char(2) not null ,
    insured integer not null ,
    cer_no integer not null ,
    loc_o char(1) not null ,
    hpt_loc char(1) not null ,
    nv_times smallint not null ,
    bad_amt integer not null ,
    no_good char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null 
  );

revoke all on "informix".mrpbd99 from "public" as "informix";

{ TABLE "informix".emrunset row size = 471 number of columns = 9 index size = 69 }

create table "informix".emrunset 
  (
    run_no varchar(32) not null ,
    typ1 varchar(12) 
        default '' not null ,
    typ2 varchar(12) 
        default '' not null ,
    typ_nam varchar(100) 
        default '' not null ,
    run_ap varchar(100) 
        default '' not null ,
    run_url varchar(100) 
        default '' not null ,
    ap_dsc varchar(100) 
        default '' not null ,
    rtp integer not null ,
    rtd date 
        default today not null ,
    primary key (run_no) 
  );

revoke all on "informix".emrunset from "public" as "informix";

{ TABLE "informix".mtdesc2 row size = 214 number of columns = 9 index size = 12 }

create table "informix".mtdesc2 
  (
    mt_cod char(7) not null ,
    qlt_typ char(2) not null ,
    qlt_cmt char(80),
    dvc char(80) 
        default '' not null ,
    saf_mm smallint,
    mt_cod12 char(12) 
        default '',
    spc char(20) 
        default '',
    rtp integer not null ,
    rtt datetime year to minute not null ,
    primary key (mt_cod) 
  );

revoke all on "informix".mtdesc2 from "public" as "informix";

{ TABLE "informix".mooir row size = 45 number of columns = 8 index size = 22 }

create table "informix".mooir 
  (
    oir_no serial not null ,
    chg_cod char(7) not null ,
    typ char(1) not null ,
    tsc char(1) not null ,
    frm char(1) not null ,
    val varchar(20) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (oir_no) 
  );

revoke all on "informix".mooir from "public" as "informix";

{ TABLE "informix".pcvilned row size = 52 number of columns = 9 index size = 30 }

create table "informix".pcvilned 
  (
    eff_no serial not null ,
    frm char(1) not null ,
    acd_no integer not null ,
    itm_cod char(7) not null ,
    lot_no char(20),
    eff_dat date not null ,
    qty integer not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (eff_no) 
  );

revoke all on "informix".pcvilned from "public" as "informix";

{ TABLE "informix".dgldap row size = 28 number of columns = 10 index size = 27 }

create table "informix".dgldap 
  (
    ldp_no serial not null ,
    ord_no integer not null ,
    apt_man smallint not null ,
    rcd_dat date not null ,
    apt_dat date not null ,
    hpt_loc char(1) 
        default '1' not null ,
    seq_no smallint not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ldp_no) 
  );

revoke all on "informix".dgldap from "public" as "informix";

{ TABLE "informix".npned row size = 16 number of columns = 6 index size = 18 }

create table "informix".npned 
  (
    itm_no serial not null ,
    ast_no integer not null ,
    itm_cls smallint not null ,
    tsc char(1) not null ,
    sel_dat date not null ,
    sel_itm char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".npned from "public" as "informix";

{ TABLE "informix".mofulog row size = 33 number of columns = 8 index size = 33 }

create table "informix".mofulog 
  (
    log_num serial not null ,
    fun_no char(4) not null ,
    fun_typ char(2) not null ,
    lnk_num integer not null ,
    rec_val char(7) not null ,
    emp_no smallint not null ,
    loc_no smallint not null ,
    log_tim datetime year to second 
        default current year to second not null ,
    primary key (log_num) 
  );

revoke all on "informix".mofulog from "public" as "informix";

{ TABLE "informix".nhocmr row size = 27 number of columns = 7 index size = 33 }

create table "informix".nhocmr 
  (
    rcd_no serial not null ,
    vsn integer not null ,
    id_no char(10) not null ,
    tsc char(1) not null ,
    mrk char(2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (rcd_no) 
  );

revoke all on "informix".nhocmr from "public" as "informix";

{ TABLE "informix".cgupbdm row size = 76 number of columns = 11 index size = 35 }

create table "informix".cgupbdm 
  (
    rul_no serial not null ,
    cod_typ char(2) not null ,
    cod char(10) not null ,
    pay_typ char(1) not null ,
    vit_typ char(1) not null ,
    grp_id smallint not null ,
    rul_typ char(2) not null ,
    rul_val char(40) not null ,
    lnk_num integer not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rul_no) 
  );

revoke all on "informix".cgupbdm from "public" as "informix";

{ TABLE "informix".cgupbdr row size = 51 number of columns = 11 index size = 18 }

create table "informix".cgupbdr 
  (
    det_no serial not null ,
    rul_no integer not null ,
    use_pnt char(2) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rng_typ char(1) not null ,
    sat_val char(10) not null ,
    end_val char(10) not null ,
    ret_val smallint 
        default 1 not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (det_no) 
  );

revoke all on "informix".cgupbdr from "public" as "informix";

{ TABLE "informix".cmcpd row size = 136 number of columns = 10 index size = 22 }

create table "informix".cmcpd 
  (
    psy_no serial not null ,
    chart integer not null ,
    psy_dat date not null ,
    num_min smallint not null ,
    ref_sou smallint not null ,
    sco_sht smallint not null ,
    sev_cmt text not null ,
    pla_cmt text not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (psy_no) 
  );

revoke all on "informix".cmcpd from "public" as "informix";

{ TABLE "informix".cmupl row size = 107 number of columns = 9 index size = 28 }

create table "informix".cmupl 
  (
    upl_no serial not null ,
    vsn integer not null ,
    chart integer not null ,
    icd_cod char(6) not null ,
    doctor smallint not null ,
    desc char(80) not null ,
    sts char(1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (upl_no) 
  );

revoke all on "informix".cmupl from "public" as "informix";

{ TABLE "informix".nppvlm row size = 59 number of columns = 6 index size = 18 }

create table "informix".nppvlm 
  (
    vlm_no serial not null ,
    vsn integer not null ,
    typ1 char(2) not null ,
    typ2 char(1) not null ,
    dsc char(40) not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (vlm_no) 
  );

revoke all on "informix".nppvlm from "public" as "informix";

{ TABLE "informix".dgprn row size = 19 number of columns = 6 index size = 21 }

create table "informix".dgprn 
  (
    prn_no serial not null ,
    drg_cod char(5) not null ,
    seq_no smallint 
        default 0,
    prn_typ char(2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (prn_no) 
  );

revoke all on "informix".dgprn from "public" as "informix";

{ TABLE "informix".dgdbd4 row size = 101 number of columns = 8 index size = 25 }

create table "informix".dgdbd4 
  (
    drg_no serial not null ,
    drg_cod char(5) not null ,
    typ char(2) not null ,
    use_way char(2) not null ,
    seq_no smallint not null ,
    dsc char(80) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (drg_no) 
  );

revoke all on "informix".dgdbd4 from "public" as "informix";

{ TABLE "informix".nhailsoe row size = 136 number of columns = 7 index size = 28 }

create table "informix".nhailsoe 
  (
    ser_no serial not null ,
    nhi_f char(12) not null ,
    nhi_t char(12) not null ,
    emp_no smallint not null ,
    dsc char(100) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".nhailsoe from "public" as "informix";

{ TABLE "informix".mrcnmqva row size = 28 number of columns = 10 index size = 44 }

create table "informix".mrcnmqva 
  (
    apl_no serial not null ,
    chart integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    opn_man smallint not null ,
    qry_rsn char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    rtl smallint not null ,
    primary key (apl_no) 
  );

revoke all on "informix".mrcnmqva from "public" as "informix";

{ TABLE "informix".dgddd row size = 25 number of columns = 7 index size = 10 }

create table "informix".dgddd 
  (
    drg_cod char(5) not null ,
    val decimal(10,2) not null ,
    dos_unt char(4) not null ,
    dos_sal_r1 smallint not null ,
    dos_sal_r2 smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (drg_cod) 
  );

revoke all on "informix".dgddd from "public" as "informix";

{ TABLE "informix".dgdibd row size = 178 number of columns = 8 index size = 28 }

create table "informix".dgdibd 
  (
    itm_no serial not null ,
    cod char(7) not null ,
    itm char(3) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    nam char(150) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (itm_no) 
  );

revoke all on "informix".dgdibd from "public" as "informix";

{ TABLE "informix".mofht row size = 84 number of columns = 6 index size = 18 }

create table "informix".mofht 
  (
    hnt_no serial not null ,
    fun_no char(4) not null ,
    lnk_no integer not null ,
    dsc text,
    see_tim datetime year to second not null ,
    rtt datetime year to second not null ,
    primary key (hnt_no) 
  );

revoke all on "informix".mofht from "public" as "informix";

{ TABLE "informix".mrpsdsc row size = 60 number of columns = 4 index size = 20 }

create table "informix".mrpsdsc 
  (
    dsc_no serial not null ,
    chart integer not null ,
    spc_mrk smallint not null ,
    dsc char(50) not null ,
    primary key (dsc_no) 
  );

revoke all on "informix".mrpsdsc from "public" as "informix";

{ TABLE "informix".dcordmd row size = 21 number of columns = 6 index size = 23 }

create table "informix".dcordmd 
  (
    odm_no serial not null ,
    chg_cod char(7) not null ,
    typ char(2) not null ,
    val char(2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (odm_no) 
  );

revoke all on "informix".dcordmd from "public" as "informix";

{ TABLE "informix".nhpnpic row size = 38 number of columns = 7 index size = 21 }

create table "informix".nhpnpic 
  (
    chart integer not null ,
    nhi_cod char(12) not null ,
    qty_l decimal(9,2) not null ,
    qty_a decimal(9,2) not null ,
    rpd date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (chart,nhi_cod) 
  );

revoke all on "informix".nhpnpic from "public" as "informix";

{ TABLE "informix".nhpnpit row size = 37 number of columns = 8 index size = 34 }

create table "informix".nhpnpit 
  (
    trn_no serial not null ,
    chart integer not null ,
    frm_cls char(1) not null ,
    frm_no integer not null ,
    nhi_cod char(12) not null ,
    qty decimal(9,2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (trn_no) 
  );

revoke all on "informix".nhpnpit from "public" as "informix";

{ TABLE "informix".dcdccr row size = 13 number of columns = 4 index size = 22 }

create table "informix".dcdccr 
  (
    rec_no serial not null ,
    dcc_no integer not null ,
    itm_no integer not null ,
    itm_sts char(1) not null ,
    primary key (rec_no) 
  );

revoke all on "informix".dcdccr from "public" as "informix";

{ TABLE "informix".bmhrpc row size = 25 number of columns = 7 index size = 18 }

create table "informix".bmhrpc 
  (
    itm_no serial not null ,
    vsn integer not null ,
    typ char(2) not null ,
    eff_dat date 
        default  '1899/12/31' not null ,
    tsc char(1) not null ,
    itp smallint not null ,
    itt datetime year to second not null ,
    primary key (itm_no) 
  );

revoke all on "informix".bmhrpc from "public" as "informix";

{ TABLE "informix".dcdcc row size = 157 number of columns = 14 index size = 39 }

create table "informix".dcdcc 
  (
    dcc_no serial not null ,
    vsn integer not null ,
    frm_no integer not null ,
    dcc_typ char(1) not null ,
    dcc_man smallint not null ,
    dcc_txt text,
    dcc_tim datetime year to second not null ,
    dcc_tsc char(1) not null ,
    rpy_man smallint not null ,
    rpy_txt text,
    rpy_tim datetime year to second 
        default  datetime (1899-12-31 00:00:00) year to second not null ,
    rpy_tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (dcc_no) 
  );

revoke all on "informix".dcdcc from "public" as "informix";

{ TABLE "informix".dgadmcr row size = 77 number of columns = 11 index size = 27 }

create table "informix".dgadmcr 
  (
    dmc_no serial not null ,
    chart integer not null ,
    tsc char(1) not null ,
    typ char(2) not null ,
    mng_sts char(1) not null ,
    val char(1) not null ,
    dsc char(50),
    res_dat date not null ,
    par_no integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (dmc_no) 
  );

revoke all on "informix".dgadmcr from "public" as "informix";

{ TABLE "informix".dgpadr row size = 27 number of columns = 6 index size = 18 }

create table "informix".dgpadr 
  (
    adr_no serial not null ,
    dmc_no integer not null ,
    tsc char(1) not null ,
    cod char(12) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (adr_no) 
  );

revoke all on "informix".dgpadr from "public" as "informix";

{ TABLE "informix".emumrt row size = 14 number of columns = 4 index size = 20 }

create table "informix".emumrt 
  (
    itm_no serial not null ,
    evt_no integer not null ,
    typ char(2) not null ,
    don_dat date not null ,
    primary key (itm_no) 
  );

revoke all on "informix".emumrt from "public" as "informix";

{ TABLE "informix".dcdcd row size = 23 number of columns = 7 index size = 18 }

create table "informix".dcdcd 
  (
    dcd_no serial not null ,
    div_no smallint not null ,
    tsc char(1) not null ,
    typ char(2) not null ,
    val char(8) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (dcd_no) 
  );

revoke all on "informix".dcdcd from "public" as "informix";

{ TABLE "informix".mocrir row size = 43 number of columns = 8 index size = 20 }

create table "informix".mocrir 
  (
    cri_no serial not null ,
    lnk_no integer not null ,
    typ1 char(2) not null ,
    typ2 char(2) not null ,
    tsc char(1) not null ,
    val char(20) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (cri_no) 
  );

revoke all on "informix".mocrir from "public" as "informix";

{ TABLE "informix".cgqtsr row size = 23 number of columns = 4 index size = 25 }

create table "informix".cgqtsr 
  (
    qts_no serial not null ,
    qts_typ char(1) not null ,
    itm_no char(10) not null ,
    qts_tim datetime year to second not null ,
    primary key (qts_no) 
  );

revoke all on "informix".cgqtsr from "public" as "informix";

{ TABLE "informix".hdpgd row size = 115 number of columns = 12 index size = 17 }

create table "informix".hdpgd 
  (
    pgd_no serial not null ,
    yyymm smallint not null ,
    chart integer not null ,
    grp char(1) not null ,
    shift char(1) not null ,
    room smallint not null ,
    tsc char(1) not null ,
    pgd_man smallint not null ,
    prn_tim datetime year to second not null ,
    comment char(80) not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (pgd_no) 
  );

revoke all on "informix".hdpgd from "public" as "informix";

{ TABLE "informix".cgdcdr row size = 29 number of columns = 5 index size = 35 }

create table "informix".cgdcdr 
  (
    dcd_no serial not null ,
    ivc_no char(12) not null ,
    vsn integer not null ,
    tsc char(1) not null ,
    rtt datetime year to second not null ,
    primary key (dcd_no) 
  );

revoke all on "informix".cgdcdr from "public" as "informix";

{ TABLE "informix".npcrm row size = 34 number of columns = 9 index size = 33 }

create table "informix".npcrm 
  (
    rec_no serial not null ,
    vsn integer not null ,
    typ char(2) 
        default '' not null ,
    tsc char(1) not null ,
    lnk_no integer not null ,
    rec_tim datetime year to minute not null ,
    rec_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".npcrm from "public" as "informix";

{ TABLE "informix".npcrd row size = 13 number of columns = 4 index size = 22 }

create table "informix".npcrd 
  (
    itm_no serial not null ,
    rec_no integer not null ,
    eva_no integer not null ,
    eva_sts char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".npcrd from "public" as "informix";

{ TABLE "informix".mrpcr row size = 36 number of columns = 10 index size = 19 }

create table "informix".mrpcr 
  (
    pcr_no serial not null ,
    vsn integer not null ,
    cst_typ char(1) not null ,
    sgn_dtt datetime year to second not null ,
    tsc char(1) not null ,
    lnk_no integer 
        default 0 not null ,
    cst_way char(1) not null ,
    cst_wrd char(3) 
        default '' not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (pcr_no) 
  );

revoke all on "informix".mrpcr from "public" as "informix";

{ TABLE "informix".morsnm row size = 28 number of columns = 8 index size = 26 }

create table "informix".morsnm 
  (
    rec_no serial not null ,
    vsn integer not null ,
    src char(1) not null ,
    itm_no integer not null ,
    typ_no integer not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".morsnm from "public" as "informix";

{ TABLE "informix".morsndt row size = 13 number of columns = 4 index size = 18 }

create table "informix".morsndt 
  (
    det_no serial not null ,
    rec_no integer not null ,
    rsn_no integer not null ,
    tsc char(1) not null ,
    primary key (det_no) 
  );

revoke all on "informix".morsndt from "public" as "informix";

{ TABLE "informix".qmatsarm row size = 33 number of columns = 9 index size = 31 }

create table "informix".qmatsarm 
  (
    rec_no serial not null ,
    vsn integer not null ,
    lnk_no integer not null ,
    tsc char(1) not null ,
    rec_typ char(1) not null ,
    rec_tim datetime year to minute not null ,
    rec_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".qmatsarm from "public" as "informix";

{ TABLE "informix".qmatsari row size = 17 number of columns = 5 index size = 26 }

create table "informix".qmatsari 
  (
    itm_no serial not null ,
    rec_no integer not null ,
    eva_no integer not null ,
    ext_no integer not null ,
    eva_sts char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".qmatsari from "public" as "informix";

{ TABLE "informix".dcdicdm row size = 287 number of columns = 9 index size = 37 }

create table "informix".dcdicdm 
  (
    imp_no serial not null ,
    div_no smallint not null ,
    i09_cod char(6) not null ,
    i10_cod char(8) not null ,
    map_typ char(5) not null ,
    tsc char(1) not null ,
    cmt char(255) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (imp_no) 
  );

revoke all on "informix".dcdicdm from "public" as "informix";

{ TABLE "informix".cgpra row size = 35 number of columns = 8 index size = 31 }

create table "informix".cgpra 
  (
    pre_no serial not null ,
    vsn integer not null ,
    tsc char(1) not null ,
    pre_amt integer not null ,
    collect_no integer 
        default 0 not null ,
    chg_tim datetime year to second 
        default  datetime (1899-12-31 00:00:00) year to second not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (pre_no) 
  );

revoke all on "informix".cgpra from "public" as "informix";

{ TABLE "informix".mrirbm row size = 36 number of columns = 8 index size = 18 }

create table "informix".mrirbm 
  (
    mng_no serial not null ,
    id char(10) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rsh_no integer not null ,
    fct_no integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (mng_no) 
  );

revoke all on "informix".mrirbm from "public" as "informix";

{ TABLE "informix".mrirbrp row size = 18 number of columns = 5 index size = 9 }

create table "informix".mrirbrp 
  (
    pts_no serial not null ,
    rsh_no integer not null ,
    chart integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (pts_no) 
  );

revoke all on "informix".mrirbrp from "public" as "informix";

{ TABLE "informix".mrirbr row size = 57 number of columns = 8 index size = 21 }

create table "informix".mrirbr 
  (
    rsh_no serial not null ,
    irb_cod char(7) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    apl_man smallint not null ,
    rsh_nam char(30) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (rsh_no) 
  );

revoke all on "informix".mrirbr from "public" as "informix";

{ TABLE "informix".mrirbf row size = 40 number of columns = 4 index size = 9 }

create table "informix".mrirbf 
  (
    fct_no serial not null ,
    nam char(30) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (fct_no) 
  );

revoke all on "informix".mrirbf from "public" as "informix";

{ TABLE "informix".ntpes row size = 2111 number of columns = 9 index size = 10 }

create table "informix".ntpes 
  (
    pes_cod char(5) not null ,
    nam char(40) not null ,
    nam_e char(60) not null ,
    def char(500) not null ,
    bio char(500) not null ,
    ant char(500) not null ,
    rec char(500) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (pes_cod) 
  );

revoke all on "informix".ntpes from "public" as "informix";

{ TABLE "informix".qmacarm row size = 24 number of columns = 7 index size = 19 }

create table "informix".qmacarm 
  (
    ast_no serial not null ,
    vsn integer not null ,
    ord_no integer not null ,
    tsc char(1) not null ,
    ast_typ char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (ast_no) 
  );

revoke all on "informix".qmacarm from "public" as "informix";

{ TABLE "informix".qmacai row size = 13 number of columns = 4 index size = 22 }

create table "informix".qmacai 
  (
    rec_no serial not null ,
    ast_no integer not null ,
    itm_no integer not null ,
    itm_sts char(1) not null ,
    primary key (rec_no) 
  );

revoke all on "informix".qmacai from "public" as "informix";

{ TABLE "informix".qmaipr row size = 16 number of columns = 4 index size = 17 }

create table "informix".qmaipr 
  (
    ast_no integer not null ,
    ast_typ char(2) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (ast_no,rtt) 
  );

revoke all on "informix".qmaipr from "public" as "informix";

{ TABLE "informix".moltxt row size = 65 number of columns = 4 index size = 19 }

create table "informix".moltxt 
  (
    txt_no serial not null ,
    cls_typ char(1) not null ,
    lnk_no integer not null ,
    txt text not null ,
    primary key (txt_no) 
  );

revoke all on "informix".moltxt from "public" as "informix";

{ TABLE "informix".rgfstdat row size = 20 number of columns = 6 index size = 22 }

create table "informix".rgfstdat 
  (
    fvt_no serial not null ,
    chart integer not null ,
    frv_dat date not null ,
    div_no smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (fvt_no) 
  );

revoke all on "informix".rgfstdat from "public" as "informix";

{ TABLE "informix".cmrcud row size = 536 number of columns = 41 index size = 50 }

create table "informix".cmrcud 
  (
    rcu_no serial not null ,
    chart integer not null ,
    can_typ char(2) not null ,
    rep_hsp char(1) not null ,
    rep_no char(10) not null ,
    rep_nam char(100) 
        default '' not null ,
    id_no char(10) not null ,
    sex char(10) not null ,
    name char(10) not null ,
    birth char(10) not null ,
    adr_cod char(4) not null ,
    rep_dat1 char(8) not null ,
    rep_dat2 char(8) not null ,
    ord_dat char(8) not null ,
    can_pos char(2) not null ,
    cli_sta char(1) not null ,
    kno_sts char(1) 
        default '' not null ,
    kno_oth char(30) 
        default '' not null ,
    fam_sts char(1) 
        default '' not null ,
    fam_oth char(30) 
        default '' not null ,
    tra_rec char(1) not null ,
    tra_num char(1) not null ,
    hsp_typ char(1) not null ,
    hsp_no char(10) not null ,
    pro_mod char(1) not null ,
    die_sts char(1) not null ,
    not_cur char(20) not null ,
    cau_cmt char(30) not null ,
    fir_dat char(8) not null ,
    fir_typ char(1) not null ,
    fir_cmt char(30) not null ,
    pat_sta char(1) not null ,
    tre_dee char(1) not null ,
    tre_cmt char(30) not null ,
    tra_dat char(8) not null ,
    tra_typ char(1) not null ,
    tra_cmt char(30) not null ,
    cmt char(100) not null ,
    sts char(1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (rcu_no) 
  );

revoke all on "informix".cmrcud from "public" as "informix";

{ TABLE "informix".cmncud row size = 537 number of columns = 42 index size = 37 }

create table "informix".cmncud 
  (
    ncu_no serial not null ,
    chart integer not null ,
    can_typ char(2) not null ,
    dia_hsp char(1) not null ,
    dia_no char(10) not null ,
    dia_nam char(100) 
        default '' not null ,
    id_no char(10) not null ,
    sex char(10) not null ,
    name char(10) not null ,
    birth char(10) not null ,
    adr_cod char(4) not null ,
    ord_dat char(8) not null ,
    dia_dat char(8) not null ,
    oth_dat char(8) not null ,
    can_pos char(2) not null ,
    eff_typ char(1) not null ,
    cli_sta char(1) not null ,
    kno_sts char(1) 
        default '' not null ,
    kno_oth char(30) 
        default '' not null ,
    fam_sts char(1) 
        default '' not null ,
    fam_oth char(30) 
        default '' not null ,
    tra_rec char(1) not null ,
    tra_num char(1) not null ,
    hsp_typ char(1) not null ,
    hsp_no char(10) not null ,
    pro_mod char(1) not null ,
    die_sts char(1) not null ,
    not_cur char(20) not null ,
    cau_cmt char(30) not null ,
    fir_dat char(8) not null ,
    fir_typ char(1) not null ,
    fir_cmt char(30) not null ,
    pat_sta char(1) not null ,
    tre_dee char(1) not null ,
    tre_cmt char(30) not null ,
    tra_dat char(8) not null ,
    tra_typ char(1) not null ,
    tra_cmt char(30) not null ,
    cmt char(100) not null ,
    sts char(1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (ncu_no) 
  );

revoke all on "informix".cmncud from "public" as "informix";

{ TABLE "informix".cmcirtr row size = 68 number of columns = 9 index size = 20 }

create table "informix".cmcirtr 
  (
    irt_no serial not null ,
    chart integer not null ,
    can_typ smallint not null ,
    irt_itm char(1) not null ,
    irt_oth char(40) not null ,
    irt_dat char(10) not null ,
    irt_typ char(1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (irt_no) 
  );

revoke all on "informix".cmcirtr from "public" as "informix";

{ TABLE "informix".cmcdd row size = 420 number of columns = 47 index size = 20 }

create table "informix".cmcdd 
  (
    dia_no serial not null ,
    chart integer not null ,
    dia_dat char(10) not null ,
    dia_hsp char(20) not null ,
    hsp_no char(10) 
        default '' not null ,
    dia_age smallint not null ,
    cas_typ smallint not null ,
    cas_oth char(10) not null ,
    enr_way char(1) not null ,
    enr_oth char(20) not null ,
    sta_dia char(1) not null ,
    sta_oth char(20) not null ,
    tra_sta char(1) not null ,
    tra_oth char(20) not null ,
    fit_eco char(1) not null ,
    fit_kps smallint not null ,
    can_typ smallint not null ,
    can_oth char(40) not null ,
    can_pos char(2) 
        default '' not null ,
    cli_lev char(1) not null ,
    cli_t char(15) not null ,
    cli_n char(15) not null ,
    cli_m char(15) not null ,
    cli_sta char(15) not null ,
    cli_stb char(15) not null ,
    pat_lev char(1) not null ,
    pat_t char(15) not null ,
    pat_n char(15) not null ,
    pat_m char(15) not null ,
    pat_sta char(15) not null ,
    pat_stb char(15) not null ,
    dis_rec char(1) not null ,
    dis_hsp char(1) 
        default '' not null ,
    dis_no char(10) 
        default '' not null ,
    fir_dat date 
        default  '1899/12/31' not null ,
    dis_dat date not null ,
    dis_pos char(1) not null ,
    tre_way char(1) not null ,
    tre_oth char(40) not null ,
    die_dat char(10) not null ,
    tra_dat char(10) not null ,
    a_dr1 smallint 
        default 0 not null ,
    a_dr2 smallint 
        default 0 not null ,
    a_dr3 smallint 
        default 0 not null ,
    a_dr4 smallint 
        default 0 not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (dia_no) 
  );

revoke all on "informix".cmcdd from "public" as "informix";

{ TABLE "informix".cmctcrr row size = 94 number of columns = 10 index size = 43 }

create table "informix".cmctcrr 
  (
    res_no serial not null ,
    sou_no integer 
        default 0 not null ,
    sou_typ smallint 
        default 0 not null ,
    chart integer not null ,
    can_typ smallint not null ,
    cau_dat char(10) not null ,
    cau_no smallint not null ,
    cau_cmt char(60) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (res_no) 
  );

revoke all on "informix".cmctcrr from "public" as "informix";

{ TABLE "informix".cmcird row size = 583 number of columns = 13 index size = 32 }

create table "informix".cmcird 
  (
    ins_no serial not null ,
    chart integer not null ,
    can_typ smallint not null ,
    ins_dat char(10) not null ,
    ins_typ smallint not null ,
    ins_sta char(1) not null ,
    ins_pos char(20) not null ,
    ins_pro char(20) not null ,
    exe_dat date not null ,
    cmt_pos char(255) not null ,
    cmt_pro char(255) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (ins_no) 
  );

revoke all on "informix".cmcird from "public" as "informix";

{ TABLE "informix".mofltstr row size = 273 number of columns = 7 index size = 279 }

create table "informix".mofltstr 
  (
    rec_no serial not null ,
    rec_typ char(2) not null ,
    idx_str_1 char(128) not null ,
    idx_str_2 char(128) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".mofltstr from "public" as "informix";

{ TABLE "informix".dcordmi row size = 24 number of columns = 5 index size = 18 }

create table "informix".dcordmi 
  (
    itm_no serial not null ,
    odm_no integer not null ,
    rlt char(3) 
        default '' not null ,
    tsc char(1) not null ,
    val char(12) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".dcordmi from "public" as "informix";

{ TABLE "informix".ntdns row size = 10661 number of columns = 14 index size = 15 }

create table "informix".ntdns 
  (
    dns_cod char(10) not null ,
    dns_typ char(2) 
        default '' not null ,
    nam char(40) not null ,
    nam_e char(100) not null ,
    def char(1500) not null ,
    res char(1500) not null ,
    bio char(1500) not null ,
    ant char(1500) not null ,
    nhy char(1500) not null ,
    rec char(1500) not null ,
    phy char(1500) not null ,
    sts char(1) 
        default '' not null ,
    rtp integer,
    rtd date not null ,
    primary key (dns_cod) 
  );

revoke all on "informix".ntdns from "public" as "informix";

{ TABLE "informix".emogm row size = 16 number of columns = 5 index size = 9 }

create table "informix".emogm 
  (
    grp_no serial not null ,
    typ char(1) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (grp_no) 
  );

revoke all on "informix".emogm from "public" as "informix";

{ TABLE "informix".emogi row size = 12 number of columns = 3 index size = 27 }

create table "informix".emogi 
  (
    itm_no serial not null ,
    grp_no integer not null ,
    ord_no integer not null ,
    primary key (itm_no) 
  );

revoke all on "informix".emogi from "public" as "informix";

{ TABLE "informix".osdesclog row size = 25 number of columns = 7 index size = 27 }

create table "informix".osdesclog 
  (
    rec_no serial not null ,
    order_no integer not null ,
    dlr_no integer not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    rtl smallint not null ,
    primary key (rec_no) 
  );

revoke all on "informix".osdesclog from "public" as "informix";

{ TABLE "informix".ositemlog row size = 72 number of columns = 16 index size = 18 }

create table "informix".ositemlog 
  (
    det_no serial not null ,
    rec_no integer not null ,
    seq_no smallint not null ,
    item_cod char(7) not null ,
    loc smallint not null ,
    usag char(20) not null ,
    tot_qty char(5) not null ,
    self_qty char(5) not null ,
    emg char(1) not null ,
    self char(1) not null ,
    chg char(1) not null ,
    prm_no integer not null ,
    ppf_no integer 
        default 0 not null ,
    map_no smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (det_no) 
  );

revoke all on "informix".ositemlog from "public" as "informix";

{ TABLE "informix".moimgm row size = 40 number of columns = 9 index size = 34 }

create table "informix".moimgm 
  (
    rec_no serial not null ,
    src char(1) not null ,
    typ char(3) not null ,
    lnk_num integer not null ,
    lnk_num2 integer 
        default 0 not null ,
    fm_rec integer 
        default 0 not null ,
    upd_tim datetime year to second 
        default  datetime (2025-12-31 00:00:00) year to second not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".moimgm from "public" as "informix";

{ TABLE "informix".moimgd row size = 151 number of columns = 8 index size = 31 }

create table "informix".moimgd 
  (
    det_no serial not null ,
    rec_no integer not null ,
    seq_no smallint not null ,
    pth char(128) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    rtl smallint not null ,
    primary key (det_no) 
  );

revoke all on "informix".moimgd from "public" as "informix";

{ TABLE "informix".rpmmrd row size = 107 number of columns = 12 index size = 27 }

create table "informix".rpmmrd 
  (
    mmr_no serial not null ,
    sou_no integer 
        default 0 not null ,
    ord_no integer not null ,
    sed_man integer not null ,
    sed_tim datetime year to second not null ,
    sed_typ char(2) not null ,
    msg text not null ,
    rec_man integer not null ,
    rec_tim datetime year to second not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (mmr_no) 
  );

revoke all on "informix".rpmmrd from "public" as "informix";

{ TABLE "informix".cgval row size = 33 number of columns = 8 index size = 27 }

create table "informix".cgval 
  (
    val_no serial not null ,
    chg_cod char(7) not null ,
    typ char(2) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    val decimal(10,2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (val_no) 
  );

revoke all on "informix".cgval from "public" as "informix";

{ TABLE "informix".mrrdr row size = 44 number of columns = 8 index size = 44 }

create table "informix".mrrdr 
  (
    rdr_no serial not null ,
    idn char(10) not null ,
    icd_cod char(8) not null ,
    i10_cod char(8) 
        default '' not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (rdr_no) 
  );

revoke all on "informix".mrrdr from "public" as "informix";

{ TABLE "informix".uddir row size = 39 number of columns = 11 index size = 49 }

create table "informix".uddir 
  (
    dir_no serial not null ,
    itm_no integer not null ,
    acc_no integer not null ,
    typ char(1) not null ,
    rec_dat date not null ,
    val decimal(8,2) not null ,
    mrk char(1) 
        default '' not null ,
    room char(4) not null ,
    bed char(2) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (dir_no) 
  );

revoke all on "informix".uddir from "public" as "informix";

{ TABLE "informix".hccdh row size = 109 number of columns = 14 index size = 37 }

create table "informix".hccdh 
  (
    cdh_no serial not null ,
    id_no char(10) not null ,
    typ char(10) not null ,
    icd_cod char(8) not null ,
    atc_cod char(7) not null ,
    ing_cod char(12) not null ,
    nhi_cod char(12) not null ,
    dos_qty char(6) not null ,
    dos_unt char(6) not null ,
    use_usg char(20) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    crt_man smallint not null ,
    crt_dat date not null ,
    primary key (cdh_no) 
  );

revoke all on "informix".hccdh from "public" as "informix";

{ TABLE "informix".nhnicatc row size = 158 number of columns = 9 index size = 46 }

create table "informix".nhnicatc 
  (
    imp_no serial not null ,
    nhi_cod char(12) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    nhi_nam char(120) not null ,
    atc_cod char(7) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (imp_no) 
  );

revoke all on "informix".nhnicatc from "public" as "informix";

{ TABLE "informix".rgscdv row size = 26 number of columns = 9 index size = 25 }

create table "informix".rgscdv 
  (
    scd_no serial not null ,
    visit_dat date not null ,
    sft char(1) not null ,
    room smallint not null ,
    dct_no smallint not null ,
    div_no smallint not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second,
    primary key (scd_no) 
  );

revoke all on "informix".rgscdv from "public" as "informix";

{ TABLE "informix".rgwscdv row size = 25 number of columns = 9 index size = 24 }

create table "informix".rgwscdv 
  (
    wsd_no serial not null ,
    wek_day char(1) not null ,
    sft char(1) not null ,
    room smallint not null ,
    stp_dat date not null ,
    div_no smallint not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second,
    primary key (wsd_no) 
  );

revoke all on "informix".rgwscdv from "public" as "informix";

{ TABLE "informix".moepdsc row size = 79 number of columns = 22 index size = 45 }

create table "informix".moepdsc 
  (
    epd_no serial not null ,
    vsn integer not null ,
    typ char(2) not null ,
    map_no smallint not null ,
    div_no smallint not null ,
    ord_man smallint not null ,
    ord_dat date 
        default today not null ,
    ord_hm smallint 
        default 0 not null ,
    ord_loc smallint 
        default 0 not null ,
    tsc char(1) 
        default '1' not null ,
    lnk_no integer 
        default 0 not null ,
    usg varchar(18),
    sts char(1) 
        default 'N' not null ,
    exp_dat date 
        default  '1899/12/31' not null ,
    pre_dat date 
        default today not null ,
    pre_hm smallint 
        default 0 not null ,
    exe_man smallint 
        default 0 not null ,
    exe_dat date 
        default  '2025/12/31' not null ,
    exe_hm smallint 
        default 0 not null ,
    exe_wrd smallint 
        default 0 not null ,
    exe_loc smallint 
        default 0 not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (epd_no) 
  );

revoke all on "informix".moepdsc from "public" as "informix";

{ TABLE "informix".moepitm row size = 320 number of columns = 18 index size = 45 }

create table "informix".moepitm 
  (
    epi_no serial not null ,
    epd_no integer not null ,
    seq_no smallint 
        default 1 not null ,
    chg_cod char(7) not null ,
    dos_qty char(5) 
        default '' not null ,
    itm1 char(4) 
        default '' not null ,
    itm2 char(4) 
        default '' not null ,
    itm3 char(4) 
        default '' not null ,
    itm4 char(4) 
        default '' not null ,
    exe_qty char(5) 
        default '0' not null ,
    nhi_qty decimal(5,1) 
        default 0.0 not null ,
    slf_qty decimal(5,1) 
        default 0.0 not null ,
    adv varchar(255),
    exe_man smallint 
        default 0 not null ,
    exe_dat date 
        default  '2025/12/31' not null ,
    exe_hm smallint 
        default 0 not null ,
    exe_sts char(1) 
        default '' not null ,
    lnk_no integer 
        default 0 not null ,
    primary key (epi_no) 
  );

revoke all on "informix".moepitm from "public" as "informix";

{ TABLE "informix".eosoerpatientddesc2 row size = 139 number of columns = 12 index size = 50 }

create table "informix".eosoerpatientddesc2 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    aadescription text,
    aflag char(1),
    astatus char(1),
    ahisgetdate datetime year to second,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes) 
  );

revoke all on "informix".eosoerpatientddesc2 from "public" as "informix";

{ TABLE "informix".eosoerpatientdiag2 row size = 107 number of columns = 17 index size = 55 }

create table "informix".eosoerpatientdiag2 
  (
    ahospitalid char(10) not null ,
    avisitno char(13) not null ,
    aordertimes char(4) not null ,
    asequenceno char(5) not null ,
    aitemno integer,
    aicd9id char(12) not null ,
    achieficd9id char(1),
    agreatill char(1),
    aflag char(1),
    astatus char(1),
    awordstyle char(1),
    ahisgetdate datetime year to second,
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ahospitalid,avisitno,aordertimes,asequenceno) 
  );

revoke all on "informix".eosoerpatientdiag2 from "public" as "informix";

{ TABLE "informix".eosoerpatientdiagl2 row size = 95 number of columns = 13 index size = 27 }

create table "informix".eosoerpatientdiagl2 
  (
    ano serial not null ,
    ahospitalid char(10),
    avisitno char(13),
    aordertimes char(4),
    asequenceno char(5),
    aitemno integer,
    aicd9id char(8),
    astatus char(1),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ano) 
  );

revoke all on "informix".eosoerpatientdiagl2 from "public" as "informix";

{ TABLE "informix".dci10kw row size = 32 number of columns = 2 index size = 37 }

create table "informix".dci10kw 
  (
    key_word char(20) not null ,
    icd_cod char(12),
    primary key (key_word,icd_cod) 
  );

revoke all on "informix".dci10kw from "public" as "informix";

{ TABLE "informix".mear row size = 146 number of columns = 6 index size = 9 }

create table "informix".mear 
  (
    mea_no serial not null ,
    met_no integer not null ,
    mea_nam char(128) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (mea_no) 
  );

revoke all on "informix".mear from "public" as "informix";

{ TABLE "informix".mecr row size = 118 number of columns = 11 index size = 21 }

create table "informix".mecr 
  (
    met_no serial not null ,
    typ char(3) not null ,
    lnk_no integer not null ,
    cvn_man smallint not null ,
    met_loc char(30) not null ,
    met_tim datetime year to minute not null ,
    met_txt text,
    rec_man smallint not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (lnk_no) 
  );

revoke all on "informix".mecr from "public" as "informix";

{ TABLE "informix".mepr row size = 22 number of columns = 7 index size = 18 }

create table "informix".mepr 
  (
    mep_no serial not null ,
    met_no integer not null ,
    pre_man smallint not null ,
    exe_man smallint not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to minute not null ,
    primary key (mep_no) 
  );

revoke all on "informix".mepr from "public" as "informix";

{ TABLE "informix".moipcl row size = 33 number of columns = 12 index size = 37 }

create table "informix".moipcl 
  (
    est_no serial not null ,
    vsn integer 
        default 0 not null ,
    chart integer not null ,
    sys char(1) 
        default '' not null ,
    typ char(1) not null ,
    itm char(3) not null ,
    ass_dat date not null ,
    ass_hm smallint not null ,
    dct_no smallint not null ,
    grd smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (est_no) 
  );

revoke all on "informix".moipcl from "public" as "informix";

{ TABLE "informix".peerm row size = 33 number of columns = 9 index size = 19 }

create table "informix".peerm 
  (
    rec_no serial not null ,
    chart integer not null ,
    frq char(1) not null ,
    tsc char(1) not null ,
    lnk_no integer not null ,
    rec_tim datetime year to minute not null ,
    rec_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".peerm from "public" as "informix";

{ TABLE "informix".peged row size = 13 number of columns = 4 index size = 22 }

create table "informix".peged 
  (
    itm_no serial not null ,
    rec_no integer not null ,
    eva_no integer not null ,
    eva_sts char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".peged from "public" as "informix";

{ TABLE "informix".peerl row size = 19 number of columns = 5 index size = 19 }

create table "informix".peerl 
  (
    log_no serial not null ,
    rec_typ char(1) not null ,
    itm_no integer not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (log_no) 
  );

revoke all on "informix".peerl from "public" as "informix";

{ TABLE "informix".fmmrimgd row size = 61 number of columns = 5 index size = 73 }

create table "informix".fmmrimgd 
  (
    det_no serial not null ,
    rec_no integer not null ,
    seq_no smallint not null ,
    uno char(50) not null ,
    tsc char(1) not null ,
    primary key (det_no) 
  );

revoke all on "informix".fmmrimgd from "public" as "informix";

{ TABLE "informix".fmmrimgm row size = 105 number of columns = 18 index size = 93 }

create table "informix".fmmrimgm 
  (
    rec_no serial not null ,
    src char(1) not null ,
    typ1 char(5) not null ,
    typ2 char(7) not null ,
    lnk_typ char(1) not null ,
    sed_tim datetime year to second not null ,
    chart integer not null ,
    vsn integer not null ,
    lnk_num integer not null ,
    oth_lnk char(32) 
        default '' not null ,
    tsc char(1) not null ,
    sav_loc char(1) 
        default '1' not null ,
    sav_num smallint 
        default 0 not null ,
    sav_ets char(10) 
        default '' not null ,
    p_sts char(1) 
        default 'N' not null ,
    p_tim datetime year to second 
        default  datetime (1899-12-31 00:00:00) year to second not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".fmmrimgm from "public" as "informix";

{ TABLE "root".mtoitg row size = 23 number of columns = 7 index size = 29 }

create table "root".mtoitg 
  (
    grp_no serial not null ,
    typ char(2) not null ,
    itm char(3) 
        default '' not null ,
    mt_cod char(7) not null ,
    sts char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (grp_no) 
  );

revoke all on "root".mtoitg from "public" as "root";

{ TABLE "informix".nhuapi row size = 88 number of columns = 9 index size = 54 }

create table "informix".nhuapi 
  (
    rec_num serial not null ,
    chg_cod char(7) not null ,
    nhi_cod char(12) not null ,
    dat_f date not null ,
    dat_t date not null ,
    nam char(45) not null ,
    nhi_up decimal(9,2) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (rec_num) 
  );

revoke all on "informix".nhuapi from "public" as "informix";

{ TABLE "informix".mtoibcr row size = 140 number of columns = 8 index size = 45 }

create table "informix".mtoibcr 
  (
    rec_no serial not null ,
    itm_no integer not null ,
    seq_no smallint 
        default 1 not null ,
    bar_cod char(100) not null ,
    lot_no char(20) not null ,
    vaildity date 
        default  '',
    rtp smallint not null ,
    rtd date not null ,
    primary key (rec_no) 
  );

revoke all on "informix".mtoibcr from "public" as "informix";

{ TABLE "informix".fmmridsc row size = 90 number of columns = 6 index size = 9 }

create table "informix".fmmridsc 
  (
    det_no integer not null ,
    det_typ char(7) not null ,
    det_loc char(7) not null ,
    det_dsc char(60) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (det_no) 
  );

revoke all on "informix".fmmridsc from "public" as "informix";

{ TABLE "informix".fmmrimgl row size = 71 number of columns = 6 index size = 74 }

create table "informix".fmmrimgl 
  (
    imy_no serial not null ,
    det_no integer not null ,
    imy_typ char(1) not null ,
    uno char(50) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (imy_no) 
  );

revoke all on "informix".fmmrimgl from "public" as "informix";

{ TABLE "informix".nhdin row size = 349 number of columns = 8 index size = 28 }

create table "informix".nhdin 
  (
    din_no serial not null ,
    ing_cod char(10) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    ing_nam char(320) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (din_no) 
  );

revoke all on "informix".nhdin from "public" as "informix";

{ TABLE "informix".mocfr row size = 25 number of columns = 6 index size = 35 }

create table "informix".mocfr 
  (
    rec_no serial not null ,
    fun_no char(4) not null ,
    lnk_no integer not null ,
    val char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".mocfr from "public" as "informix";

{ TABLE "informix".dgparm row size = 27 number of columns = 7 index size = 31 }

create table "informix".dgparm 
  (
    par_no serial not null ,
    chart integer not null ,
    vsn integer not null ,
    tsc char(1) not null ,
    par_dat date not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (par_no) 
  );

revoke all on "informix".dgparm from "public" as "informix";

{ TABLE "informix".dgpari row size = 13 number of columns = 4 index size = 22 }

create table "informix".dgpari 
  (
    rec_no serial not null ,
    par_no integer not null ,
    itm_no integer not null ,
    itm_sts char(1) not null ,
    primary key (rec_no) 
  );

revoke all on "informix".dgpari from "public" as "informix";

{ TABLE "informix".cgcodctr row size = 37 number of columns = 8 index size = 23 }

create table "informix".cgcodctr 
  (
    ctr_no serial not null ,
    chg_cod char(7) not null ,
    typ char(2) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    val char(10) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ctr_no) 
  );

revoke all on "informix".cgcodctr from "public" as "informix";

{ TABLE "informix".mocmi2 row size = 13 number of columns = 4 index size = 22 }

create table "informix".mocmi2 
  (
    evt_no serial not null ,
    sub_no integer not null ,
    itm_no integer not null ,
    itm_sts char(1) not null ,
    primary key (evt_no) 
  );

revoke all on "informix".mocmi2 from "public" as "informix";

{ TABLE "informix".mocmm2 row size = 40 number of columns = 11 index size = 18 }

create table "informix".mocmm2 
  (
    sub_no serial not null ,
    vsn integer not null ,
    ord_no integer not null ,
    cnr_no integer not null ,
    sys_typ char(2) not null ,
    itm_typ char(2) not null ,
    tsc char(1) not null ,
    cnr_tim datetime year to minute not null ,
    cnr_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (sub_no) 
  );

revoke all on "informix".mocmm2 from "public" as "informix";

{ TABLE "informix".mootxt2 row size = 65 number of columns = 4 index size = 19 }

create table "informix".mootxt2 
  (
    txt_no serial not null ,
    cls_typ char(1) not null ,
    itm_no integer not null ,
    oth_dsc text not null ,
    primary key (txt_no) 
  );

revoke all on "informix".mootxt2 from "public" as "informix";

{ TABLE "informix".mooss2 row size = 29 number of columns = 4 index size = 19 }

create table "informix".mooss2 
  (
    oss_no serial not null ,
    cls_typ char(1) not null ,
    itm_no integer not null ,
    oth_dsc char(20) not null ,
    primary key (oss_no) 
  );

revoke all on "informix".mooss2 from "public" as "informix";

{ TABLE "informix".mools2 row size = 129 number of columns = 4 index size = 19 }

create table "informix".mools2 
  (
    ols_no serial not null ,
    cls_typ char(1) not null ,
    itm_no integer not null ,
    oth_dsc char(120) not null ,
    primary key (ols_no) 
  );

revoke all on "informix".mools2 from "public" as "informix";

{ TABLE "informix".modds2 row size = 13 number of columns = 4 index size = 19 }

create table "informix".modds2 
  (
    dds_no serial not null ,
    cls_typ char(1) not null ,
    itm_no integer not null ,
    dat date not null ,
    primary key (dds_no) 
  );

revoke all on "informix".modds2 from "public" as "informix";

{ TABLE "informix".moolls2 row size = 309 number of columns = 4 index size = 19 }

create table "informix".moolls2 
  (
    lls_no serial not null ,
    cls_typ char(1) not null ,
    itm_no integer not null ,
    oth_dsc char(300) not null ,
    primary key (lls_no) 
  );

revoke all on "informix".moolls2 from "public" as "informix";

{ TABLE "informix".ifdpmsi row size = 13 number of columns = 4 index size = 22 }

create table "informix".ifdpmsi 
  (
    det_no serial not null ,
    sts_no integer not null ,
    itm_no integer not null ,
    itm_sts char(1) not null ,
    primary key (det_no) 
  );

revoke all on "informix".ifdpmsi from "public" as "informix";

{ TABLE "informix".morur row size = 34 number of columns = 9 index size = 37 }

create table "informix".morur 
  (
    rur_no serial not null ,
    ord_no integer not null ,
    map_no integer not null ,
    vis_typ char(1) not null ,
    adm_dr integer not null ,
    tsc char(1),
    asg_dat date 
        default  '1899/12/31',
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rur_no) 
  );

revoke all on "informix".morur from "public" as "informix";

{ TABLE "informix".pdctbd row size = 104 number of columns = 9 index size = 20 }

create table "informix".pdctbd 
  (
    ser_no serial not null ,
    typ char(2) not null ,
    nam char(60) not null ,
    nam_a char(20) 
        default '' not null ,
    dat_f date 
        default  '1899/12/31' not null ,
    dat_t date 
        default  '2025/12/31' not null ,
    eff_day smallint 
        default 0 not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".pdctbd from "public" as "informix";

{ TABLE "informix".empoia row size = 30 number of columns = 9 index size = 26 }

create table "informix".empoia 
  (
    oia_no serial not null ,
    map_typ char(1) not null ,
    map_no smallint 
        default 0 not null ,
    itm_cod char(7) 
        default '' not null ,
    sht_typ char(3) 
        default '' not null ,
    oia_dat date not null ,
    tsc char(1) 
        default 'A' not null ,
    rtp integer not null ,
    rtd date 
        default today not null ,
    primary key (oia_no) 
  );

revoke all on "informix".empoia from "public" as "informix";

{ TABLE "informix".emshtsch row size = 905 number of columns = 57 index size = 8 }

create table "informix".emshtsch 
  (
    sht_typ_no char(3) not null ,
    sht_nam char(60) not null ,
    sht_nam_e char(60) 
        default '' not null ,
    word_path char(100) 
        default '' not null ,
    xml_path char(100) 
        default '' not null ,
    prt_path char(100) 
        default '' not null ,
    hbe_mrk char(1) 
        default 'N' not null ,
    het_mrk char(1) 
        default 'N' not null ,
    rpt_mrk char(1) 
        default 'N' not null ,
    he_mrk char(1) 
        default 'N' not null ,
    pt_mrk char(1) 
        default 'N' not null ,
    rf_mrk char(1) 
        default 'N' not null ,
    ef_mrk char(1) 
        default 'N' not null ,
    ins_mrk char(1) 
        default 'N' not null ,
    con_mrk char(1) 
        default 'N' not null ,
    cf_mrk char(1) 
        default 'N' not null ,
    pap_mrk char(1) 
        default 'N' not null ,
    hc_mrk char(1) 
        default 'N' not null ,
    pic_mrk char(1) 
        default 'N' not null ,
    grp_mrk char(1) 
        default 'N' not null ,
    cs_mrk char(1) 
        default 'N' not null ,
    iaw text,
    mes text,
    ncc_dat date 
        default  '1899/12/31' not null ,
    ec_dat date 
        default  '1899/12/31' not null ,
    ieo_man integer 
        default 0 not null ,
    emr_dat date 
        default  '1899/12/31' not null ,
    emr_man integer 
        default 0 not null ,
    uu_dpt smallint 
        default 0 not null ,
    uu_man integer 
        default 0 not null ,
    iu_mrk char(1) 
        default 'N' not null ,
    sau_mrk char(1) 
        default 'N' not null ,
    use_tim text,
    pid_mrk char(10) 
        default '' not null ,
    pg text,
    cmt text,
    tsc char(1) 
        default 'A' not null ,
    sht_typ char(3) not null ,
    law_chk char(1) 
        default 'N' not null ,
    e_sig char(1) 
        default 'N' not null ,
    dcl_mrk char(1) 
        default 'N' not null ,
    visit_typ char(3) 
        default 'NNN' not null ,
    dcl_dat date 
        default  '1899/12/31' not null ,
    his_pre_dat date 
        default  '1899/12/31' not null ,
    emr_pre_dat date 
        default  '1899/12/31' not null ,
    on_line_prt char(1) 
        default 'N' not null ,
    rp31_prt char(1) 
        default 'N' not null ,
    paper_path char(100) 
        default '' not null ,
    xml_dat date 
        default  '1899/12/31' not null ,
    xml_man integer 
        default 0 not null ,
    dsr_mrk char(1) 
        default 'N' not null ,
    lr_mrk char(1) 
        default 'N' not null ,
    ps_mrk char(1) 
        default 'N' not null ,
    barcode char(1) 
        default 'N' not null ,
    bar_cod char(5) 
        default '' not null ,
    rtp integer not null ,
    rtd date 
        default today not null ,
    primary key (sht_typ_no) 
  );

revoke all on "informix".emshtsch from "public" as "informix";

{ TABLE "informix".nptjr row size = 104 number of columns = 22 index size = 29 }

create table "informix".nptjr 
  (
    rec_no serial not null ,
    ord_no integer not null ,
    bpd_n decimal(10,0) not null ,
    arr_tim datetime year to second not null ,
    sgn_man integer 
        default 0 not null ,
    lec_fir char(1) 
        default 'N' not null ,
    chk_tim datetime year to second not null ,
    chk_man integer 
        default 0 not null ,
    rck_man integer 
        default 0 not null ,
    tsf_tim datetime year to second not null ,
    tsf_man integer 
        default 0 not null ,
    tsf_dtr integer 
        default 0 not null ,
    rtf_man integer 
        default 0 not null ,
    rec_sts char(1) 
        default '' not null ,
    rtn_lnk integer 
        default 0 not null ,
    rtn_hei integer 
        default 0 not null ,
    rtn_vis integer 
        default 0 not null ,
    stp_tim datetime year to second 
        default  datetime (1899-12-31 00:00:00) year to second not null ,
    stp_man integer 
        default 0 not null ,
    stp_dtr integer 
        default 0 not null ,
    rtp integer 
        default 0 not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".nptjr from "public" as "informix";

{ TABLE "informix".moctrl row size = 40 number of columns = 7 index size = 33 }

create table "informix".moctrl 
  (
    log_no serial not null ,
    log_tim datetime year to second 
        default current year to second not null ,
    log_typ char(2) not null ,
    lnk_no integer not null ,
    val_old char(10) not null ,
    val_new char(10) not null ,
    rtp smallint not null ,
    primary key (log_no) 
  );

revoke all on "informix".moctrl from "public" as "informix";

{ TABLE "informix".dci10fa row size = 38 number of columns = 11 index size = 37 }

create table "informix".dci10fa 
  (
    itm_no serial not null ,
    yyyymm integer not null ,
    typ1 char(2) not null ,
    typ2 char(1) not null ,
    div_no smallint not null ,
    emp_no smallint not null ,
    i10_cod char(12) not null ,
    tsc char(1) not null ,
    cnt integer not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (itm_no) 
  );

revoke all on "informix".dci10fa from "public" as "informix";

{ TABLE "informix".dccdspcs row size = 1812 number of columns = 13 index size = 26 }

create table "informix".dccdspcs 
  (
    itm_no serial not null ,
    icd_cod char(12) not null ,
    eff_dat date not null ,
    tsc char(1) not null ,
    sct char(255) not null ,
    bdy_sys char(255) not null ,
    opr char(255) not null ,
    bdy_prt char(255) not null ,
    apc char(255) not null ,
    dvc char(255) not null ,
    qlf char(255) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (itm_no) 
  );

revoke all on "informix".dccdspcs from "public" as "informix";

{ TABLE "informix".cndcnr row size = 94 number of columns = 11 index size = 27 }

create table "informix".cndcnr 
  (
    cnr_no serial not null ,
    dag_no integer not null ,
    apt_dat date not null ,
    cnr_typ char(1) not null ,
    nam char(12) not null ,
    tel integer not null ,
    cnr_cut smallint not null ,
    sts char(1) not null ,
    val char(50) 
        default '' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (cnr_no) 
  );

revoke all on "informix".cndcnr from "public" as "informix";

{ TABLE "informix".mrvci row size = 21 number of columns = 7 index size = 20 }

create table "informix".mrvci 
  (
    rec_no serial not null ,
    vsn integer not null ,
    typ char(2) not null ,
    itm_no integer not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (rec_no) 
  );

revoke all on "informix".mrvci from "public" as "informix";

{ TABLE "informix".rfhbrd row size = 85 number of columns = 9 index size = 21 }

create table "informix".rfhbrd 
  (
    brd_no serial not null ,
    hsp_no decimal(10,0) not null ,
    seq char(1) not null ,
    nam_a char(8) not null ,
    nam_f char(50) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (brd_no) 
  );

revoke all on "informix".rfhbrd from "public" as "informix";

{ TABLE "informix".npotxt row size = 65 number of columns = 4 index size = 19 }

create table "informix".npotxt 
  (
    txt_no serial not null ,
    cls_typ char(1) not null ,
    itm_no integer not null ,
    oth_dsc text not null ,
    primary key (txt_no) 
  );

revoke all on "informix".npotxt from "public" as "informix";

{ TABLE "informix".smdmola row size = 30 number of columns = 10 index size = 29 }

create table "informix".smdmola 
  (
    dmo_no serial not null ,
    sub_no smallint not null ,
    yymm smallint not null ,
    div_no smallint not null ,
    dct smallint not null ,
    typ char(2) not null ,
    amt_l_o integer not null ,
    amt_l integer not null ,
    cnt_a integer not null ,
    amt_a integer not null ,
    primary key (dmo_no) 
  );

revoke all on "informix".smdmola from "public" as "informix";

{ TABLE "informix".monot row size = 80 number of columns = 7 index size = 24 }

create table "informix".monot 
  (
    not_no serial not null ,
    vsn integer not null ,
    typ integer not null ,
    seq_no smallint 
        default 0 not null ,
    txt text,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (not_no) 
  );

revoke all on "informix".monot from "public" as "informix";

{ TABLE "informix".mrvts row size = 241 number of columns = 11 index size = 18 }

create table "informix".mrvts 
  (
    rec_no serial not null ,
    typ char(2) not null ,
    lnk_no integer not null ,
    str_man smallint not null ,
    str_tim datetime year to second,
    ntc_man smallint not null ,
    ntc_tim datetime year to second,
    txt char(200) not null ,
    sts char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second,
    primary key (rec_no) 
  );

revoke all on "informix".mrvts from "public" as "informix";

{ TABLE "informix".ifdpmsr row size = 133 number of columns = 6 index size = 18 }

create table "informix".ifdpmsr 
  (
    pm_no serial not null ,
    sts_no integer not null ,
    pm_sts char(1) not null ,
    fil_nam char(60) not null ,
    ret_dsc text not null ,
    rtt datetime year to second not null ,
    primary key (pm_no) 
  );

revoke all on "informix".ifdpmsr from "public" as "informix";

{ TABLE "informix".scerm row size = 35 number of columns = 9 index size = 25 }

create table "informix".scerm 
  (
    erm_no serial not null ,
    scp_no integer not null ,
    typ char(3) not null ,
    lnk_no integer not null ,
    erm_man smallint not null ,
    erm_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (erm_no) 
  );

revoke all on "informix".scerm from "public" as "informix";

{ TABLE "informix".scedf row size = 13 number of columns = 4 index size = 22 }

create table "informix".scedf 
  (
    itm_no serial not null ,
    erm_no integer not null ,
    eva_no integer not null ,
    eva_sts char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".scedf from "public" as "informix";

{ TABLE "informix".cgpap row size = 90 number of columns = 9 index size = 18 }

create table "informix".cgpap 
  (
    pap_no serial not null ,
    chart integer not null ,
    typ char(1) not null ,
    use_typ char(2) not null ,
    collect_no integer not null ,
    amt integer not null ,
    mrk char(60) 
        default '' not null ,
    rtp integer not null ,
    rtt datetime year to minute not null ,
    primary key (pap_no) 
  );

revoke all on "informix".cgpap from "public" as "informix";

{ TABLE "informix".tdcctipc row size = 38 number of columns = 8 index size = 25 }

create table "informix".tdcctipc 
  (
    itm_no serial not null ,
    chg_cod char(7) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    icd_cod char(12) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (itm_no) 
  );

revoke all on "informix".tdcctipc from "public" as "informix";

{ TABLE "informix".mofnd row size = 13 number of columns = 4 index size = 18 }

create table "informix".mofnd 
  (
    dtl_no serial not null ,
    mst_no integer not null ,
    itm_no integer not null ,
    itm_sts char(1) not null ,
    primary key (dtl_no) 
  );

revoke all on "informix".mofnd from "public" as "informix";

{ TABLE "informix".nssmtc row size = 45 number of columns = 6 index size = 17 }

create table "informix".nssmtc 
  (
    smt_no serial not null ,
    wrd smallint not null ,
    typ char(1) not null ,
    nam char(30) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (smt_no) 
  );

revoke all on "informix".nssmtc from "public" as "informix";

{ TABLE "informix".mofnm row size = 32 number of columns = 8 index size = 37 }

create table "informix".mofnm 
  (
    mst_no serial not null ,
    lnk_no integer not null ,
    itm char(3) not null ,
    rec_man smallint not null ,
    rec_tim datetime year to second not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (mst_no) 
  );

revoke all on "informix".mofnm from "public" as "informix";

{ TABLE "informix".cmrols row size = 515 number of columns = 6 index size = 18 }

create table "informix".cmrols 
  (
    itm_no serial not null ,
    res_no integer not null ,
    cau_cmt char(500) not null ,
    sts char(1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (itm_no) 
  );

revoke all on "informix".cmrols from "public" as "informix";

{ TABLE "informix".cmirm row size = 35 number of columns = 11 index size = 33 }

create table "informix".cmirm 
  (
    cmm_no serial not null ,
    vsn integer not null ,
    ord_no integer not null ,
    chart integer not null ,
    can_typ smallint not null ,
    ord_dat date not null ,
    rpt_dat date not null ,
    frm_typ char(2) not null ,
    sts char(1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (cmm_no) 
  );

revoke all on "informix".cmirm from "public" as "informix";

{ TABLE "informix".cmird row size = 19 number of columns = 6 index size = 24 }

create table "informix".cmird 
  (
    ird_no serial not null ,
    con_no integer not null ,
    itm_no integer not null ,
    seq_no smallint not null ,
    ext_no integer not null ,
    itm_sts char(1) not null ,
    primary key (ird_no) 
  );

revoke all on "informix".cmird from "public" as "informix";

{ TABLE "informix".fofib row size = 291 number of columns = 9 index size = 40 }

create table "informix".fofib 
  (
    itm_no serial not null ,
    sys_no char(4) not null ,
    msr_no char(10) not null ,
    det_no char(8) not null ,
    lnk_no integer not null ,
    tbl_rel char(1) not null ,
    itm_nam char(250) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (itm_no) 
  );

revoke all on "informix".fofib from "public" as "informix";

{ TABLE "informix".fooss row size = 30 number of columns = 4 index size = 18 }

create table "informix".fooss 
  (
    oss_no serial not null ,
    cls_typ char(2) not null ,
    ird_no integer not null ,
    oth_dsc char(20) not null ,
    primary key (oss_no) 
  );

revoke all on "informix".fooss from "public" as "informix";

{ TABLE "informix".fools row size = 130 number of columns = 4 index size = 18 }

create table "informix".fools 
  (
    ols_no serial not null ,
    cls_typ char(2) not null ,
    ird_no integer not null ,
    oth_dsc char(120) not null ,
    primary key (ols_no) 
  );

revoke all on "informix".fools from "public" as "informix";

{ TABLE "informix".foolls row size = 310 number of columns = 4 index size = 18 }

create table "informix".foolls 
  (
    lls_no serial not null ,
    cls_typ char(2) not null ,
    ird_no integer not null ,
    oth_dsc char(300) not null ,
    primary key (lls_no) 
  );

revoke all on "informix".foolls from "public" as "informix";

{ TABLE "informix".footxt row size = 66 number of columns = 4 index size = 18 }

create table "informix".footxt 
  (
    txt_no serial not null ,
    cls_typ char(2) not null ,
    ird_no integer not null ,
    oth_dsc text not null ,
    primary key (txt_no) 
  );

revoke all on "informix".footxt from "public" as "informix";

{ TABLE "informix".tdccrdag row size = 32 number of columns = 7 index size = 32 }

create table "informix".tdccrdag 
  (
    ccg_no serial not null ,
    icd_grp smallint not null ,
    icd_cod char(12) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (ccg_no) 
  );

revoke all on "informix".tdccrdag from "public" as "informix";

{ TABLE "informix".tdccrda row size = 32 number of columns = 7 index size = 32 }

create table "informix".tdccrda 
  (
    cca_no serial not null ,
    npd_cod char(12) not null ,
    icd_grp smallint not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (cca_no) 
  );

revoke all on "informix".tdccrda from "public" as "informix";

{ TABLE "informix".fodds row size = 14 number of columns = 4 index size = 18 }

create table "informix".fodds 
  (
    dds_no serial not null ,
    cls_typ char(2) not null ,
    ird_no integer not null ,
    dat date not null ,
    primary key (dds_no) 
  );

revoke all on "informix".fodds from "public" as "informix";

{ TABLE "informix".ucapes row size = 208 number of columns = 8 index size = 47 }

create table "informix".ucapes 
  (
    user_key serial not null ,
    trigger_dttm varchar(14) not null ,
    user_id varchar(32) not null ,
    user_name varchar(64) not null ,
    password varchar(64) not null ,
    user_status char(1) not null ,
    user_level varchar(16) not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (user_key) 
  );

revoke all on "informix".ucapes from "public" as "informix";

{ TABLE "informix".cmspr row size = 81 number of columns = 17 index size = 22 }

create table "informix".cmspr 
  (
    spr_no serial not null ,
    lnk_no integer not null ,
    frm char(1) not null ,
    cir_no integer not null ,
    spr_typ char(1) not null ,
    eva_no integer not null ,
    eff_man smallint not null ,
    eff_tim datetime year to minute not null ,
    spr_sts char(2) not null ,
    spr_man smallint,
    spr_tim datetime year to minute,
    pre_cnt smallint not null ,
    pre_nam char(12) not null ,
    pre_tim datetime year to minute not null ,
    pre_dtr char(12) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (spr_no) 
  );

revoke all on "informix".cmspr from "public" as "informix";

{ TABLE "informix".cmcrm row size = 36 number of columns = 11 index size = 22 }

create table "informix".cmcrm 
  (
    rec_no serial not null ,
    lnk_typ char(1) not null ,
    lnk_no integer not null ,
    frm char(1) not null ,
    cir_no integer not null ,
    rec_typ char(2) not null ,
    tsc char(1) not null ,
    rec_tim datetime year to minute not null ,
    rec_man smallint not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".cmcrm from "public" as "informix";

{ TABLE "informix".cmcrd row size = 21 number of columns = 6 index size = 22 }

create table "informix".cmcrd 
  (
    itm_no serial not null ,
    rec_no integer not null ,
    eva_no integer not null ,
    grp_no integer not null ,
    ext_no integer not null ,
    eva_sts char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".cmcrd from "public" as "informix";

{ TABLE "informix".cmpcr row size = 49 number of columns = 14 index size = 45 }

create table "informix".cmpcr 
  (
    cir_no serial not null ,
    typ char(3) not null ,
    chart integer not null ,
    vsn integer not null ,
    dis_typ char(2) not null ,
    lnk_no integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    stp_rsn char(1) not null ,
    dct1 integer not null ,
    dct2 integer not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (cir_no) 
  );

revoke all on "informix".cmpcr from "public" as "informix";

{ TABLE "informix".cgmie row size = 102 number of columns = 8 index size = 23 }

create table "informix".cgmie 
  (
    itm_no serial not null ,
    chg_cod char(7) not null ,
    typ char(2) not null ,
    seq_no smallint not null ,
    tsc char(1) not null ,
    dsc char(80) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (itm_no) 
  );

revoke all on "informix".cgmie from "public" as "informix";

{ TABLE "informix".eobatriagejudge2 row size = 462 number of columns = 10 index size = 9 }

create table "informix".eobatriagejudge2 
  (
    aid char(4) not null ,
    achinesename lvarchar(200),
    aenglishname lvarchar(200),
    arank5 char(1),
    amark char(5),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (aid) 
  );

revoke all on "informix".eobatriagejudge2 from "public" as "informix";

{ TABLE "informix".eobatriagecc2 row size = 256 number of columns = 9 index size = 10 }

create table "informix".eobatriagecc2 
  (
    aid char(5) not null ,
    asid char(3),
    achinesename varchar(100),
    aenglishname varchar(100),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (aid) 
  );

revoke all on "informix".eobatriagecc2 from "public" as "informix";

{ TABLE "informix".eobatrdetaillist2 row size = 73 number of columns = 10 index size = 19 }

create table "informix".eobatrdetaillist2 
  (
    ano integer not null ,
    ahospitalid char(10) not null ,
    acid char(5),
    atid char(4),
    attasjudgeid char(4),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    primary key (ano,ahospitalid) 
  );

revoke all on "informix".eobatrdetaillist2 from "public" as "informix";

{ TABLE "informix".tddrgspm row size = 42 number of columns = 9 index size = 24 }

create table "informix".tddrgspm 
  (
    mst_no serial not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    drg_cod_f char(5) not null ,
    drg_cod_t char(5) not null ,
    typ char(1) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (mst_no) 
  );

revoke all on "informix".tddrgspm from "public" as "informix";

{ TABLE "informix".tddrgspd row size = 17 number of columns = 4 index size = 31 }

create table "informix".tddrgspd 
  (
    rec_no serial not null ,
    mst_no integer not null ,
    icd_cod char(8) not null ,
    tsc char(1) not null ,
    primary key (rec_no) 
  );

revoke all on "informix".tddrgspd from "public" as "informix";

{ TABLE "informix".mrpbie row size = 219 number of columns = 7 index size = 18 }

create table "informix".mrpbie 
  (
    pbe_no serial not null ,
    chart integer not null ,
    clm_typ char(2) not null ,
    val char(200) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (pbe_no) 
  );

revoke all on "informix".mrpbie from "public" as "informix";

{ TABLE "informix".xrpdip row size = 37 number of columns = 5 index size = 38 }

create table "informix".xrpdip 
  (
    pdi_no serial not null ,
    chart integer not null ,
    acs_no char(20) not null ,
    tsc char(1) not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (pdi_no) 
  );

revoke all on "informix".xrpdip from "public" as "informix";

{ TABLE "informix".hcpicc row size = 24 number of columns = 6 index size = 32 }

create table "informix".hcpicc 
  (
    rec_no serial not null ,
    icd_cod char(8) not null ,
    cod char(5) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtd date not null ,
    primary key (rec_no) 
  );

revoke all on "informix".hcpicc from "public" as "informix";

{ TABLE "informix".pbges row size = 324 number of columns = 19 index size = 9 }

create table "informix".pbges 
  (
    evt_qno serial not null ,
    evt_sou char(10) not null ,
    evt_tag char(32) not null ,
    evt_sys char(4) not null ,
    evt_fun char(15) 
        default '' not null ,
    evt_lvl char(1) 
        default '1' not null ,
    evt_lnk char(32) 
        default '' not null ,
    evt_val text not null ,
    par_enc char(1) 
        default '1' not null ,
    pre_sts char(1) 
        default '0' not null ,
    pre_tag char(32) 
        default '' not null ,
    pre_val text,
    pre_tim datetime year to second 
        default  datetime (1899-12-31 00:00:00) year to second,
    frm_id char(10) 
        default '' not null ,
    tar_id char(10) 
        default '' not null ,
    exe_tim datetime year to second 
        default  datetime (1899-12-31 00:00:00) year to second,
    flag char(32) 
        default '' not null ,
    evt_rtp integer not null ,
    evt_rtt datetime year to second 
        default current year to second not null ,
    primary key (evt_qno) 
  );

revoke all on "informix".pbges from "public" as "informix";

{ TABLE "informix".eaeiicm row size = 35 number of columns = 11 index size = 18 }

create table "informix".eaeiicm 
  (
    rec_no serial not null ,
    chart integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    eff_man smallint not null ,
    stp_man smallint not null ,
    stp_rsn char(1) not null ,
    ast_typ char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".eaeiicm from "public" as "informix";

{ TABLE "informix".eaeiici row size = 13 number of columns = 4 index size = 22 }

create table "informix".eaeiici 
  (
    itm_no serial not null ,
    rec_no integer not null ,
    eva_no integer not null ,
    tsc char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".eaeiici from "public" as "informix";

{ TABLE "informix".eaeiicr row size = 18 number of columns = 4 index size = 18 }

create table "informix".eaeiicr 
  (
    ser_no serial not null ,
    rec_no integer not null ,
    rec_man smallint not null ,
    rec_tim datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".eaeiicr from "public" as "informix";

{ TABLE "informix".nhtdaacd row size = 38 number of columns = 11 index size = 39 }

create table "informix".nhtdaacd 
  (
    ser_no serial not null ,
    chart integer not null ,
    adm_dat date not null ,
    dcg_dat date not null ,
    dct_no integer not null ,
    amt_r integer not null ,
    amt_n integer not null ,
    cmb char(1) 
        default 'N' not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".nhtdaacd from "public" as "informix";

{ TABLE "informix".cgqec row size = 38 number of columns = 8 index size = 25 }

create table "informix".cgqec 
  (
    qec_no serial not null ,
    chart integer not null ,
    typ char(3) not null ,
    chg_cod char(7) not null ,
    chg_qty integer not null ,
    exe_qty integer not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (qec_no) 
  );

revoke all on "informix".cgqec from "public" as "informix";

{ TABLE "informix".cgqecd row size = 29 number of columns = 10 index size = 22 }

create table "informix".cgqecd 
  (
    trn_no serial not null ,
    qec_no integer not null ,
    fun_typ char(2) not null ,
    exe_dat date not null ,
    exe_qty smallint not null ,
    exe_man integer not null ,
    mrk char(1) 
        default 'N' not null ,
    had_exe_qty smallint 
        default 0 not null ,
    lnk_no integer 
        default 0 not null ,
    lnk_seq_no smallint 
        default 0,
    primary key (trn_no) 
  );

revoke all on "informix".cgqecd from "public" as "informix";

{ TABLE "informix".cgdud row size = 29 number of columns = 6 index size = 27 }

create table "informix".cgdud 
  (
    ser_no serial not null ,
    chart integer not null ,
    chg_cod char(7) not null ,
    rec_typ char(2) not null ,
    stp_dat date not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".cgdud from "public" as "informix";

{ TABLE "informix".dccdrc row size = 274 number of columns = 8 index size = 22 }

create table "informix".dccdrc 
  (
    drc_no serial not null ,
    frm_typ char(4) 
        default '' not null ,
    cnc_no integer not null ,
    itm char(3) not null ,
    val char(250) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (drc_no) 
  );

revoke all on "informix".dccdrc from "public" as "informix";

{ TABLE "informix".eoptbr row size = 33 number of columns = 7 index size = 31 }

create table "informix".eoptbr 
  (
    trg_no serial not null ,
    trg_tim datetime year to second not null ,
    bar_no integer not null ,
    tsc char(1) not null ,
    vsn integer not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (trg_no) 
  );

revoke all on "informix".eoptbr from "public" as "informix";

{ TABLE "informix".osppbr row size = 45 number of columns = 6 index size = 18 }

create table "informix".osppbr 
  (
    rec_no serial not null ,
    vsn integer not null ,
    bed_typ char(1) not null ,
    cmt char(30),
    rtp smallint not null ,
    rtd date not null ,
    primary key (rec_no) 
  );

revoke all on "informix".osppbr from "public" as "informix";

{ TABLE "informix".ospptr row size = 12 number of columns = 5 index size = 18 }

create table "informix".ospptr 
  (
    tim_no serial not null ,
    rec_no integer not null ,
    rec_typ char(1) not null ,
    tim_typ char(1) not null ,
    rec_tim smallint not null ,
    primary key (tim_no) 
  );

revoke all on "informix".ospptr from "public" as "informix";

{ TABLE "informix".ospprr row size = 38 number of columns = 3 index size = 18 }

create table "informix".ospprr 
  (
    rsn_no serial not null ,
    rec_no integer not null ,
    rsn_dsc char(30) not null ,
    primary key (rsn_no) 
  );

revoke all on "informix".ospprr from "public" as "informix";

{ TABLE "informix".ntird row size = 21 number of columns = 6 index size = 26 }

create table "informix".ntird 
  (
    ird_no serial not null ,
    ass_no integer not null ,
    itm_no integer not null ,
    seq_no integer not null ,
    ext_no integer not null ,
    itm_sts char(1) not null ,
    primary key (ird_no) 
  );

revoke all on "informix".ntird from "public" as "informix";

{ TABLE "informix".ntrcr row size = 36 number of columns = 10 index size = 26 }

create table "informix".ntrcr 
  (
    rcr_no serial not null ,
    chart integer not null ,
    acc_no integer not null ,
    adm_dat date not null ,
    rc_typ char(3) not null ,
    rc_dat date not null ,
    ec_dat date not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date 
        default today not null ,
    primary key (rcr_no) 
  );

revoke all on "informix".ntrcr from "public" as "informix";

{ TABLE "informix".nteid row size = 101 number of columns = 11 index size = 18 }

create table "informix".nteid 
  (
    exi_no serial not null ,
    ass_no integer not null ,
    ord_no integer not null ,
    rpt_tim datetime year to second not null ,
    itm_typ char(2) not null ,
    itm_cod char(7) not null ,
    itm_nam char(45) not null ,
    val char(20) not null ,
    sts char(1) not null ,
    rtp smallint not null ,
    rtd date 
        default today not null ,
    primary key (exi_no) 
  );

revoke all on "informix".nteid from "public" as "informix";

{ TABLE "informix".ntdwd row size = 22 number of columns = 7 index size = 18 }

create table "informix".ntdwd 
  (
    dwd_no serial not null ,
    emp_no integer not null ,
    ward char(3) not null ,
    dpt_no smallint not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date 
        default today not null ,
    primary key (dwd_no) 
  );

revoke all on "informix".ntdwd from "public" as "informix";

{ TABLE "informix".nttfnud row size = 351 number of columns = 53 index size = 21 }

create table "informix".nttfnud 
  (
    tub_no serial not null ,
    tub_cod char(7) not null ,
    tub_nam char(40) not null ,
    tub_abb char(20) not null ,
    tub_cap char(6) not null ,
    tub_unt char(6) not null ,
    tub_typ char(1) not null ,
    nut_eng char(6) not null ,
    nut_pro char(6) not null ,
    nut_fat char(6) not null ,
    nut_cho char(6) not null ,
    nut_va char(6) not null ,
    nut_bta char(6) not null ,
    nut_vd char(6) not null ,
    nut_ve char(6) not null ,
    nut_vk char(6) not null ,
    nut_vb1 char(6) not null ,
    nut_vb2 char(6) not null ,
    nut_vb6 char(6) not null ,
    nut_vb12 char(6) not null ,
    nut_vc char(6) not null ,
    nut_nia char(6) not null ,
    nut_foc char(6) not null ,
    nut_pa char(6) not null ,
    nut_bio char(6) not null ,
    nut_col char(6) not null ,
    nut_ino char(6) not null ,
    nut_ca char(6) not null ,
    nut_p char(6) not null ,
    nut_fe char(6) not null ,
    nut_na char(6) not null ,
    nut_k char(6) not null ,
    nut_cl char(6) not null ,
    nut_mg char(6) not null ,
    nut_zn char(6) not null ,
    nut_cu char(6) not null ,
    nut_i char(6) not null ,
    nut_mn char(6) not null ,
    nut_se char(6) not null ,
    nut_cr char(6) not null ,
    nut_mo char(6) not null ,
    nut_tau char(6) not null ,
    nut_crn char(6) not null ,
    nut_arg char(6) not null ,
    nut_glu char(6) not null ,
    nut_fib char(6) not null ,
    nut_so char(6) not null ,
    nut_ace char(6) not null ,
    nut_gcn char(6) not null ,
    nut_dp char(6) not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (tub_no) 
  );

revoke all on "informix".nttfnud from "public" as "informix";

{ TABLE "informix".mrwpr row size = 38 number of columns = 8 index size = 18 }

create table "informix".mrwpr 
  (
    rec_no serial not null ,
    lnk_no integer not null ,
    func_no char(4) not null ,
    typ char(3) not null ,
    tsc char(1) not null ,
    prt_nam char(10) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".mrwpr from "public" as "informix";

{ TABLE "informix".cgnhdud row size = 44 number of columns = 7 index size = 32 }

create table "informix".cgnhdud 
  (
    ser_no serial not null ,
    chart integer not null ,
    nhi_cod char(12) not null ,
    rec_typ char(2) not null ,
    stp_dat date not null ,
    rct_frm char(10) not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".cgnhdud from "public" as "informix";

{ TABLE "informix".cmrf row size = 96 number of columns = 10 index size = 35 }

create table "informix".cmrf 
  (
    rec_no serial not null ,
    vsn integer not null ,
    typ char(3) not null ,
    lnk_no integer not null ,
    rec_man integer not null ,
    rec_tim datetime year to second not null ,
    rec_sts char(1) not null ,
    rec_txt text not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".cmrf from "public" as "informix";

{ TABLE "informix".hccexmh row size = 104 number of columns = 14 index size = 37 }

create table "informix".hccexmh 
  (
    cdh_no serial not null ,
    id_no char(10) not null ,
    typ char(10) not null ,
    yyymm char(6) not null ,
    div_cod char(2) not null ,
    icd_cod char(12) not null ,
    exm_typ char(6) not null ,
    nhi_cod char(12) not null ,
    pos_nam char(20) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    opr_cnt char(6) not null ,
    crt_man integer not null ,
    crt_dat date not null ,
    primary key (cdh_no) 
  );

revoke all on "informix".hccexmh from "public" as "informix";

{ TABLE "informix".hccoprh row size = 98 number of columns = 13 index size = 37 }

create table "informix".hccoprh 
  (
    cdh_no serial not null ,
    id_no char(10) not null ,
    typ char(10) not null ,
    yyymm char(6) not null ,
    div_cod char(2) not null ,
    icd_cod char(12) not null ,
    nhi_cod char(12) not null ,
    pos_nam char(20) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    opr_cnt char(6) not null ,
    crt_man integer not null ,
    crt_dat date not null ,
    primary key (cdh_no) 
  );

revoke all on "informix".hccoprh from "public" as "informix";

{ TABLE "informix".hccdenh row size = 96 number of columns = 12 index size = 37 }

create table "informix".hccdenh 
  (
    cdh_no serial not null ,
    id_no char(10) not null ,
    typ char(10) not null ,
    yyymm char(6) not null ,
    icd_cod char(12) not null ,
    nhi_cod char(12) not null ,
    pos_nam char(20) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    opr_cnt char(6) not null ,
    crt_man integer not null ,
    crt_dat date not null ,
    primary key (cdh_no) 
  );

revoke all on "informix".hccdenh from "public" as "informix";

{ TABLE "informix".hccalgh row size = 848 number of columns = 10 index size = 37 }

create table "informix".hccalgh 
  (
    cdh_no serial not null ,
    id_no char(10) not null ,
    typ char(10) not null ,
    upl_dat date not null ,
    upl_hm smallint not null ,
    upl_idno char(10) not null ,
    upl_sgn char(600) not null ,
    alg_nam char(200) not null ,
    crt_man integer not null ,
    crt_dat date not null ,
    primary key (cdh_no) 
  );

revoke all on "informix".hccalgh from "public" as "informix";

{ TABLE "informix".nhcodecn row size = 186 number of columns = 10 index size = 28 }

create table "informix".nhcodecn 
  (
    imp_no serial not null ,
    typ char(2) not null ,
    cod char(12) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    lng_typ char(1) not null ,
    cod_nam char(150) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (imp_no) 
  );

revoke all on "informix".nhcodecn from "public" as "informix";

{ TABLE "informix".dgdfi row size = 39 number of columns = 8 index size = 28 }

create table "informix".dgdfi 
  (
    dfi_no serial not null ,
    chg_cod char(7) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rls_sts char(1) 
        default '' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (dfi_no) 
  );

revoke all on "informix".dgdfi from "public" as "informix";

{ TABLE "informix".rgdie row size = 49 number of columns = 7 index size = 18 }

create table "informix".rgdie 
  (
    rde_no serial not null ,
    vsn integer not null ,
    clm_typ char(2) not null ,
    val char(30) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rde_no) 
  );

revoke all on "informix".rgdie from "public" as "informix";

{ TABLE "informix".rrsyspar row size = 416 number of columns = 16 index size = 25 }

create table "informix".rrsyspar 
  (
    par_id char(20) not null ,
    par_nam char(40) not null ,
    par_val char(20) not null ,
    par_v01 char(20) not null ,
    par_v02 char(20) not null ,
    par_v03 char(20) not null ,
    par_v04 char(20) not null ,
    par_v05 char(20) not null ,
    par_v06 char(20) not null ,
    par_v07 char(20) not null ,
    par_v08 char(20) not null ,
    par_v09 char(20) not null ,
    par_v10 char(20) not null ,
    par_dsc char(128) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (par_id) 
  );

revoke all on "informix".rrsyspar from "public" as "informix";

{ TABLE "informix".pfdpdsb row size = 31 number of columns = 10 index size = 26 }

create table "informix".pfdpdsb 
  (
    ser_no serial not null ,
    ord_no integer not null ,
    itm_no integer 
        default 0,
    emp_no integer not null ,
    tc char(1) not null ,
    typ char(2) not null ,
    typ_d char(1) 
        default '1' not null ,
    rat decimal(3,2) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".pfdpdsb from "public" as "informix";

{ TABLE "informix".ntcar row size = 40 number of columns = 10 index size = 31 }

create table "informix".ntcar 
  (
    ass_no serial not null ,
    ass_dat datetime year to second not null ,
    ass_typ char(1) 
        default '' not null ,
    chart integer not null ,
    acc_no integer not null ,
    visit_no decimal(11,0) not null ,
    frm_typ char(3) not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date 
        default today not null ,
    primary key (ass_no) 
  );

revoke all on "informix".ntcar from "public" as "informix";

{ TABLE "informix".dgdbmr row size = 47 number of columns = 11 index size = 30 }

create table "informix".dgdbmr 
  (
    bmr_no serial not null ,
    vsn integer not null ,
    frm_no integer not null ,
    frm char(1) not null ,
    gen_tim datetime year to minute not null ,
    tsc char(1) not null ,
    lmp_typ char(1) not null ,
    lmp_no smallint not null ,
    adj_info char(11) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (bmr_no) 
  );

revoke all on "informix".dgdbmr from "public" as "informix";

{ TABLE "informix".dgdbir row size = 109 number of columns = 18 index size = 43 }

create table "informix".dgdbir 
  (
    bir_no serial not null ,
    bmr_no integer not null ,
    chg_cod char(7) not null ,
    loc smallint not null ,
    dos_qty char(5) 
        default '' not null ,
    usg char(18) not null ,
    itm1 char(4) 
        default '' not null ,
    itm2 char(4) 
        default '' not null ,
    itm3 char(4) 
        default '' not null ,
    itm4 char(4) 
        default '' not null ,
    mrk char(1) 
        default '' not null ,
    qty_tot char(5) not null ,
    qty_prc integer not null ,
    self char(1) 
        default '' not null ,
    prt_nam char(10) 
        default '' not null ,
    bar_cod char(20) 
        default '' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (bir_no) 
  );

revoke all on "informix".dgdbir from "public" as "informix";

{ TABLE "informix".cmmtr row size = 344 number of columns = 15 index size = 36 }

create table "informix".cmmtr 
  (
    mtr_no serial not null ,
    lnk_typ char(1) not null ,
    lnk_no integer not null ,
    chart integer not null ,
    room char(7),
    ord_dat date not null ,
    typ char(2) not null ,
    can_typ smallint not null ,
    div_no smallint not null ,
    doctor integer not null ,
    receive char(1) not null ,
    cmt char(300) not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date 
        default today not null ,
    primary key (mtr_no) 
  );

revoke all on "informix".cmmtr from "public" as "informix";

{ TABLE "informix".mrisrant row size = 94 number of columns = 12 index size = 42 }

create table "informix".mrisrant 
  (
    ant_num serial not null ,
    evt_no integer not null ,
    id_no char(10) not null ,
    tsc char(1) not null ,
    reg_dat date not null ,
    cmp_dat date not null ,
    snd_man integer not null ,
    snd_dat date not null ,
    cmt char(50) not null ,
    att char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (ant_num) 
  );

revoke all on "informix".mrisrant from "public" as "informix";

{ TABLE "informix".catkbd row size = 134 number of columns = 12 index size = 18 }

create table "informix".catkbd 
  (
    ser_no serial not null ,
    typ char(2) not null ,
    lnk_no integer not null ,
    inr smallint 
        default 0 not null ,
    sub_dsc char(40) not null ,
    dsc text not null ,
    emp_no integer not null ,
    eff_tim datetime year to second not null ,
    sts char(1) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".catkbd from "public" as "informix";

{ TABLE "informix".dcdnf10 row size = 29 number of columns = 7 index size = 29 }

create table "informix".dcdnf10 
  (
    dnf_no serial not null ,
    icd_cod char(12) not null ,
    typ char(3) not null ,
    tsc char(1) not null ,
    flg char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (dnf_no) 
  );

revoke all on "informix".dcdnf10 from "public" as "informix";

{ TABLE "informix".psdmses row size = 34 number of columns = 10 index size = 27 }

create table "informix".psdmses 
  (
    ser_no serial not null ,
    emp_no integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    typ char(1) not null ,
    seq_no integer not null ,
    dut_man integer not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".psdmses from "public" as "informix";

{ TABLE "informix".psdmsesl row size = 38 number of columns = 11 index size = 9 }

create table "informix".psdmsesl 
  (
    log_no serial not null ,
    ser_no integer not null ,
    emp_no integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    typ char(1) not null ,
    seq_no integer not null ,
    dut_man integer not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (log_no) 
  );

revoke all on "informix".psdmsesl from "public" as "informix";

{ TABLE "root".mmreq3 row size = 116 number of columns = 11 index size = 34 }

create table "root".mmreq3 
  (
    seq_no serial not null ,
    sed_no integer not null ,
    evt_typ char(3) not null ,
    tsc char(1) not null ,
    evt_man integer not null ,
    evt_tim datetime year to second not null ,
    evt_flg char(20) not null ,
    cmt text not null ,
    rtp integer not null ,
    rtl integer not null ,
    rtt datetime year to second not null ,
    primary key (seq_no) 
  );

revoke all on "root".mmreq3 from "public" as "root";

{ TABLE "informix".bmathinf row size = 51 number of columns = 10 index size = 55 }

create table "informix".bmathinf 
  (
    ath_no serial not null ,
    acc_no integer not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    typ char(10) not null ,
    emp_no integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    rtl smallint not null ,
    primary key (ath_no) 
  );

revoke all on "informix".bmathinf from "public" as "informix";

{ TABLE "informix".pbgesn row size = 80 number of columns = 6 index size = 48 }

create table "informix".pbgesn 
  (
    evt_no serial not null ,
    evt_typ char(4) not null ,
    evt_sou char(30) not null ,
    evt_val char(30) not null ,
    evt_rtp integer not null ,
    evt_rtt datetime year to second 
        default current year to second not null ,
    primary key (evt_no) 
  );

revoke all on "informix".pbgesn from "public" as "informix";

{ TABLE "informix".dgdsp row size = 76 number of columns = 16 index size = 48 }

create table "informix".dgdsp 
  (
    rec_no serial not null ,
    bar_cod char(12) not null ,
    bar_typ char(1) not null ,
    chart integer not null ,
    lmp_typ char(1),
    lmp_no smallint,
    tsc char(1) not null ,
    cmp_tim datetime year to second,
    prn_tim datetime year to minute,
    chg_tim datetime year to minute,
    out_tim datetime year to second,
    emp_man integer,
    dct_no integer not null ,
    loc_no smallint not null ,
    rtp integer not null ,
    rtt datetime year to minute not null ,
    primary key (rec_no) 
  );

revoke all on "informix".dgdsp from "public" as "informix";

{ TABLE "informix".pseepdat row size = 36 number of columns = 7 index size = 9 }

create table "informix".pseepdat 
  (
    eep_no integer not null ,
    eep_nam char(10) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    cmp_no char(3) not null ,
    rtp integer not null ,
    rtt datetime year to minute not null 
  );

revoke all on "informix".pseepdat from "public" as "informix";

{ TABLE "informix".momclog row size = 95 number of columns = 10 index size = 41 }

create table "informix".momclog 
  (
    log_num serial not null ,
    fun_typ char(4) not null ,
    typ char(2) not null ,
    lnk_num integer not null ,
    ctl_cod char(10) not null ,
    log_sts char(1) not null ,
    log_txt text not null ,
    emp_no integer not null ,
    loc_no smallint not null ,
    log_tim datetime year to second 
        default current year to second not null ,
    primary key (log_num) 
  );

revoke all on "informix".momclog from "public" as "informix";

{ TABLE "informix".zzgacn row size = 150 number of columns = 9 index size = 30 }

create table "informix".zzgacn 
  (
    gac_no serial not null ,
    lnk_no integer not null ,
    cod char(7) not null ,
    typ char(2) not null ,
    nam char(40) not null ,
    nam_e char(80) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (gac_no) 
  );

revoke all on "informix".zzgacn from "public" as "informix";

{ TABLE "informix".ifdcd row size = 37 number of columns = 9 index size = 30 }

create table "informix".ifdcd 
  (
    ccp_no serial not null ,
    gac_no integer not null ,
    level char(1) not null ,
    diag_cod char(7) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ccp_no) 
  );

revoke all on "informix".ifdcd from "public" as "informix";

{ TABLE "informix".ifdbd row size = 114 number of columns = 9 index size = 21 }

create table "informix".ifdbd 
  (
    ifd_no serial not null ,
    typ char(2) not null ,
    cod char(7) not null ,
    nam char(80) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ifd_no) 
  );

revoke all on "informix".ifdbd from "public" as "informix";

{ TABLE "informix".mowpr row size = 41 number of columns = 10 index size = 39 }

create table "informix".mowpr 
  (
    wpr_no serial not null ,
    vsn integer not null ,
    lnk_no integer not null ,
    fun_typ char(4) not null ,
    typ char(2) not null ,
    tsc char(1) not null ,
    wpr_man integer not null ,
    wpr_tim datetime year to minute not null ,
    rtp integer not null ,
    rtt datetime year to minute not null ,
    primary key (wpr_no) 
  );

revoke all on "informix".mowpr from "public" as "informix";

{ TABLE "informix".ossub row size = 72 number of columns = 4 index size = 9 }

create table "informix".ossub 
  (
    order_no integer not null ,
    txt text not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (order_no) 
  );

revoke all on "informix".ossub from "public" as "informix";

{ TABLE "informix".osobj row size = 72 number of columns = 4 index size = 9 }

create table "informix".osobj 
  (
    order_no integer not null ,
    txt text not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (order_no) 
  );

revoke all on "informix".osobj from "public" as "informix";

{ TABLE "informix".oscmt row size = 72 number of columns = 4 index size = 9 }

create table "informix".oscmt 
  (
    order_no integer not null ,
    txt text not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (order_no) 
  );

revoke all on "informix".oscmt from "public" as "informix";

{ TABLE "informix".ossublog row size = 76 number of columns = 5 index size = 18 }

create table "informix".ossublog 
  (
    log_no serial not null ,
    order_no integer not null ,
    txt text not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (log_no) 
  );

revoke all on "informix".ossublog from "public" as "informix";

{ TABLE "informix".osobjlog row size = 76 number of columns = 5 index size = 18 }

create table "informix".osobjlog 
  (
    log_no serial not null ,
    order_no integer not null ,
    txt text not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (log_no) 
  );

revoke all on "informix".osobjlog from "public" as "informix";

{ TABLE "informix".oscmtlog row size = 76 number of columns = 5 index size = 18 }

create table "informix".oscmtlog 
  (
    log_no serial not null ,
    order_no integer not null ,
    txt text not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (log_no) 
  );

revoke all on "informix".oscmtlog from "public" as "informix";

{ TABLE "informix".oransitl row size = 51 number of columns = 15 index size = 27 }

create table "informix".oransitl 
  (
    evt_no serial not null ,
    ord_no integer not null ,
    ans_ord integer not null ,
    dat_s date not null ,
    thm_s smallint not null ,
    dat_e date not null ,
    thm_e smallint not null ,
    ans_dr1 integer 
        default 0 not null ,
    ans_dr2 integer 
        default 0 not null ,
    ans_dr3 integer 
        default 0 not null ,
    opr_typ char(1) not null ,
    o_i char(1) not null ,
    ane_typ char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (evt_no) 
  );

revoke all on "informix".oransitl from "public" as "informix";

{ TABLE "informix".catmf row size = 19 number of columns = 6 index size = 18 }

create table "informix".catmf 
  (
    tmf_no serial not null ,
    cnr_no integer not null ,
    tre_typ char(2) not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (tmf_no) 
  );

revoke all on "informix".catmf from "public" as "informix";

{ TABLE "informix".cartf row size = 147 number of columns = 9 index size = 20 }

create table "informix".cartf 
  (
    rtf_no serial not null ,
    tmf_no integer not null ,
    cur_typ char(2) not null ,
    gy integer not null ,
    fr integer not null ,
    loc char(120) not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rtf_no) 
  );

revoke all on "informix".cartf from "public" as "informix";

{ TABLE "informix".catdf row size = 77 number of columns = 7 index size = 18 }

create table "informix".catdf 
  (
    tdf_no serial not null ,
    cnr_no integer not null ,
    tmf_no integer not null ,
    txt text not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (tdf_no) 
  );

revoke all on "informix".catdf from "public" as "informix";

{ TABLE "informix".caast row size = 128 number of columns = 17 index size = 18 }

create table "informix".caast 
  (
    ast_no serial not null ,
    chart integer not null ,
    cas_typ char(1) not null ,
    ord_no integer not null ,
    sta_man integer not null ,
    sta_dat date not null ,
    can_typ char(2) not null ,
    sys_typ char(4) not null ,
    tnm_typ char(2) not null ,
    tumor char(10) not null ,
    node char(10) not null ,
    met char(20) not null ,
    stage char(10) not null ,
    summary char(40),
    sts char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (ast_no) 
  );

revoke all on "informix".caast from "public" as "informix";

{ TABLE "informix".caasim row size = 27 number of columns = 9 index size = 9 }

create table "informix".caasim 
  (
    sim_no serial not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    can_typ char(2) not null ,
    ver_no smallint not null ,
    tnm_typ char(2) not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (sim_no) 
  );

revoke all on "informix".caasim from "public" as "informix";

{ TABLE "informix".caasid row size = 40 number of columns = 8 index size = 18 }

create table "informix".caasid 
  (
    sid_no serial not null ,
    sim_no integer not null ,
    typ char(1) not null ,
    seq_no smallint not null ,
    as_itm char(20) not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (sid_no) 
  );

revoke all on "informix".caasid from "public" as "informix";

{ TABLE "informix".cacmf row size = 295 number of columns = 12 index size = 32 }

create table "informix".cacmf 
  (
    cmf_no serial not null ,
    tmf_no integer not null ,
    ptc_cod char(7) not null ,
    itm_cod char(7) 
        default '' not null ,
    cur_typ char(2) not null ,
    cyc_num integer not null ,
    cyc_unt integer not null ,
    num integer not null ,
    dsc char(250) not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (cmf_no) 
  );

revoke all on "informix".cacmf from "public" as "informix";

{ TABLE "informix".mevtd row size = 84 number of columns = 9 index size = 20 }

create table "informix".mevtd 
  (
    vtd_no serial not null ,
    typ char(2) not null ,
    lnk_no integer not null ,
    var_typ char(2) not null ,
    dsc text not null ,
    rec_man integer 
        default 0 not null ,
    tsc char(1) 
        default '' not null ,
    rtp integer not null ,
    rtt datetime year to minute not null ,
    primary key (vtd_no) 
  );

revoke all on "informix".mevtd from "public" as "informix";

{ TABLE "informix".mopfr row size = 40 number of columns = 11 index size = 31 }

create table "informix".mopfr 
  (
    evt_no serial not null ,
    act_sys char(2) not null ,
    act_typ char(2) not null ,
    lnk_typ char(1) not null ,
    lnk_no integer not null ,
    tsc char(1) not null ,
    act_man integer not null ,
    act_tim datetime year to second not null ,
    act_loc smallint not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (evt_no) 
  );

revoke all on "informix".mopfr from "public" as "informix";

{ TABLE "informix".mopfrpkg row size = 15 number of columns = 5 index size = 27 }

create table "informix".mopfrpkg 
  (
    itm_no serial not null ,
    pkg_no integer not null ,
    evt_no integer not null ,
    exe_loc smallint not null ,
    tsc char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".mopfrpkg from "public" as "informix";

{ TABLE "informix".hccexrh row size = 799 number of columns = 22 index size = 37 }

create table "informix".hccexrh 
  (
    cdh_no serial not null ,
    id_no char(10) not null ,
    rep_typ char(1) not null ,
    typ char(10) not null ,
    yyymm char(6) not null ,
    div_cod char(2) not null ,
    icd_cod char(12) not null ,
    pos_nam char(20) not null ,
    exm_typ char(6) not null ,
    nhi_cod char(12) not null ,
    lab_nam char(100) not null ,
    lab_typ char(150) not null ,
    lab_val char(60) not null ,
    lab_unt char(30) not null ,
    lab_ref char(100) not null ,
    rpt_txt text not null ,
    rpt_typ char(200) not null ,
    opr_dat date not null ,
    exm_dat date not null ,
    rep_dat date not null ,
    crt_man integer not null ,
    crt_dat date not null ,
    primary key (cdh_no) 
  );

revoke all on "informix".hccexrh from "public" as "informix";

{ TABLE "informix".hccdcsh row size = 106 number of columns = 9 index size = 33 }

create table "informix".hccdcsh 
  (
    cdh_no serial not null ,
    id_no char(10) not null ,
    typ char(10) not null ,
    hpt_cod char(10) not null ,
    adm_dat date not null ,
    dis_dat date not null ,
    fil_txt text not null ,
    crt_man integer not null ,
    crt_dat date not null ,
    primary key (cdh_no) 
  );

revoke all on "informix".hccdcsh from "public" as "informix";

{ TABLE "informix".hccphmh row size = 112 number of columns = 14 index size = 37 }

create table "informix".hccphmh 
  (
    cdh_no serial not null ,
    id_no char(10) not null ,
    typ char(10) not null ,
    icd_cod char(12) not null ,
    tre_typ char(10) not null ,
    try_lvl char(30) not null ,
    yyymm char(6) not null ,
    opr_cnt char(6) not null ,
    admit_dat date not null ,
    tre_dat date not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    crt_man integer not null ,
    crt_dat date not null ,
    primary key (cdh_no) 
  );

revoke all on "informix".hccphmh from "public" as "informix";

{ TABLE "informix".hccetmh row size = 151 number of columns = 13 index size = 37 }

create table "informix".hccetmh 
  (
    cdh_no serial not null ,
    id_no char(10) not null ,
    typ char(10) not null ,
    icd_cod char(12) not null ,
    chr_dis char(1) not null ,
    etm_cod char(12) not null ,
    use_usg char(20) not null ,
    med_day integer not null ,
    med_dsc char(60) not null ,
    med_cnt char(6) not null ,
    opr_dat date not null ,
    crt_man integer not null ,
    crt_dat date not null ,
    primary key (cdh_no) 
  );

revoke all on "informix".hccetmh from "public" as "informix";

{ TABLE "informix".mosysprm row size = 336 number of columns = 9 index size = 21 }

create table "informix".mosysprm 
  (
    rec_no serial not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    func_no char(4) not null ,
    typ char(2) not null ,
    tsc char(1) not null ,
    msg_txt char(300) not null ,
    rtp integer not null ,
    rtt datetime year to minute not null ,
    primary key (rec_no) 
  );

revoke all on "informix".mosysprm from "public" as "informix";

{ TABLE "informix".tddrgps4 row size = 22 number of columns = 6 index size = 13 }

create table "informix".tddrgps4 
  (
    mdc_cod char(2) not null ,
    seq_no smallint not null ,
    drg char(5) not null ,
    wgt decimal(8,4) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    primary key (mdc_cod,seq_no,eff_dat) 
  );

revoke all on "informix".tddrgps4 from "public" as "informix";

{ TABLE "informix".dci10cn4 row size = 573 number of columns = 23 index size = 40 }

create table "informix".dci10cn4 
  (
    icd_cod char(8) not null ,
    typ char(2) not null ,
    nhi_cod char(9) not null ,
    drg_cod char(5) not null ,
    qip_drg char(4) not null ,
    nam_e char(255) not null ,
    nam_c char(255) not null ,
    icd_typ char(4) not null ,
    sru_mrk smallint not null ,
    ifq_mrk char(1) not null ,
    crn_mrk char(1) not null ,
    crn_typ char(6) not null ,
    con_mrk char(1) not null ,
    con_typ smallint not null ,
    sex_lmt char(1) not null ,
    dag_lmt char(1) not null ,
    spc_typ char(2) not null ,
    min_age smallint not null ,
    max_age smallint not null ,
    std_days smallint not null ,
    rtp smallint not null ,
    rtd date not null ,
    rthm smallint not null ,
    primary key (icd_cod) 
  );

revoke all on "informix".dci10cn4 from "public" as "informix";

{ TABLE "informix".dci10kw4 row size = 28 number of columns = 2 index size = 33 }

create table "informix".dci10kw4 
  (
    key_word char(20) not null ,
    icd_cod char(8) not null ,
    primary key (key_word,icd_cod) 
  );

revoke all on "informix".dci10kw4 from "public" as "informix";

{ TABLE "informix".mocorif row size = 1355 number of columns = 12 index size = 30 }

create table "informix".mocorif 
  (
    cri_no serial not null ,
    ptc_cod char(7) not null ,
    tc char(1) not null ,
    eff_tim datetime year to second not null ,
    stp_tim datetime year to second not null ,
    itm_nam char(50) not null ,
    tmt_cyc char(1000) not null ,
    idc_lst char(255) not null ,
    vfy_man integer 
        default 0 not null ,
    vfy_tim datetime year to second 
        default  datetime (2025-12-31 00:00:00) year to second not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (cri_no) 
  );

revoke all on "informix".mocorif from "public" as "informix";

{ TABLE "informix".mochgtyp row size = 27 number of columns = 7 index size = 25 }

create table "informix".mochgtyp 
  (
    chg_no serial not null ,
    chg_cod char(7) not null ,
    typ char(2) not null ,
    voc_no integer not null ,
    seq_no smallint 
        default 0 not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (chg_no) 
  );

revoke all on "informix".mochgtyp from "public" as "informix";

{ TABLE "informix".moitmvoc row size = 41 number of columns = 7 index size = 18 }

create table "informix".moitmvoc 
  (
    voc_no serial not null ,
    typ char(2) not null ,
    itm_no char(4) not null ,
    nam char(20) not null ,
    grp_typ char(3) 
        default '' not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (voc_no) 
  );

revoke all on "informix".moitmvoc from "public" as "informix";

{ TABLE "informix".movctrdf row size = 35 number of columns = 9 index size = 27 }

create table "informix".movctrdf 
  (
    vcc_no serial not null ,
    chart integer not null ,
    lnk_num integer not null ,
    rom_seq integer not null ,
    chg_cod char(7) not null ,
    vcc_rsn char(1) not null ,
    tsc char(1) not null ,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (vcc_no) 
  );

revoke all on "informix".movctrdf from "public" as "informix";

{ TABLE "informix".tddrgcn4 row size = 259 number of columns = 8 index size = 10 }

create table "informix".tddrgcn4 
  (
    drg_cod char(5) not null ,
    nam_e char(120) not null ,
    nam_c char(120) not null ,
    div_typ char(1) not null ,
    mrk char(1) not null ,
    eff_dat date not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (drg_cod) 
  );

revoke all on "informix".tddrgcn4 from "public" as "informix";

{ TABLE "informix".tddrgnfc4 row size = 31 number of columns = 9 index size = 21 }

create table "informix".tddrgnfc4 
  (
    drg_num serial not null ,
    drg_cod char(5) not null ,
    eff_ym smallint not null ,
    stp_ym smallint not null ,
    day_avg smallint not null ,
    amt_low integer not null ,
    amt_hgh integer not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (drg_num) 
  );

revoke all on "informix".tddrgnfc4 from "public" as "informix";

{ TABLE "informix".tdmdcbd4 row size = 132 number of columns = 6 index size = 7 }

create table "informix".tdmdcbd4 
  (
    mdc char(2) not null ,
    nam_e char(80) not null ,
    nam_c char(40) not null ,
    yy smallint not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (mdc) 
  );

revoke all on "informix".tdmdcbd4 from "public" as "informix";

{ TABLE "informix".tdncbd4 row size = 36 number of columns = 12 index size = 18 }

create table "informix".tdncbd4 
  (
    mdc_num serial not null ,
    mdc char(2) not null ,
    eff_ym smallint not null ,
    stp_ym smallint not null ,
    rat_m_1 decimal(3,2) not null ,
    rat_m_2 decimal(3,2) not null ,
    rat_m_3 decimal(3,2) not null ,
    rat_p_1 decimal(3,2) not null ,
    rat_p_2 decimal(3,2) not null ,
    rat_p_3 decimal(3,2) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (mdc_num) 
  );

revoke all on "informix".tdncbd4 from "public" as "informix";

{ TABLE "informix".rfiambd row size = 638 number of columns = 15 index size = 72 }

create table "informix".rfiambd 
  (
    rfi_no serial not null ,
    rfi_id char(50) not null ,
    nam char(50) not null ,
    pwd char(30) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    hpt char(25) not null ,
    area char(12) not null ,
    mail char(100) not null ,
    tel char(100) not null ,
    addr char(200) not null ,
    com_typ char(1) not null ,
    com_id char(50) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rfi_no) 
  );

revoke all on "informix".rfiambd from "public" as "informix";

{ TABLE "informix".eherm row size = 255 number of columns = 14 index size = 30 }

create table "informix".eherm 
  (
    erm_no serial not null ,
    vsn integer not null ,
    typ char(1) not null ,
    erm_man integer not null ,
    erm_tim datetime year to minute not null ,
    exe_typ char(1) not null ,
    sed_man integer not null ,
    sed_tim datetime year to minute not null ,
    sed_dsc char(100) not null ,
    exe_man integer not null ,
    exe_tim datetime year to minute not null ,
    exe_dsc char(100) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (erm_no) 
  );

revoke all on "informix".eherm from "public" as "informix";

{ TABLE "informix".eherd row size = 17 number of columns = 5 index size = 28 }

create table "informix".eherd 
  (
    erd_no serial not null ,
    erm_no integer not null ,
    itm_typ char(1) not null ,
    lnk_no integer not null ,
    itm_val integer not null ,
    primary key (erd_no) 
  );

revoke all on "informix".eherd from "public" as "informix";

{ TABLE "informix".dgcdqm row size = 542 number of columns = 11 index size = 38 }

create table "informix".dgcdqm 
  (
    ctl_no serial not null ,
    chg_cod char(7) not null ,
    chart integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    ctl_typ char(1) not null ,
    tsc char(1) not null ,
    qty decimal(7,1) 
        default 0.0 not null ,
    cmt char(500) 
        default '' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ctl_no) 
  );

revoke all on "informix".dgcdqm from "public" as "informix";

{ TABLE "informix".dgcdqr row size = 31 number of columns = 8 index size = 27 }

create table "informix".dgcdqr 
  (
    rec_no serial not null ,
    ctl_no integer not null ,
    lnk_no integer not null ,
    dos_qty decimal(7,1) not null ,
    tsc char(1) not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".dgcdqr from "public" as "informix";

{ TABLE "informix".tddrgab4 row size = 40 number of columns = 10 index size = 22 }

create table "informix".tddrgab4 
  (
    ser_no serial not null ,
    fym integer not null ,
    tym integer not null ,
    spr integer not null ,
    sla integer not null ,
    rat_b decimal(4,3) not null ,
    rat_c decimal(4,3) not null ,
    rat_m decimal(4,3) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".tddrgab4 from "public" as "informix";

{ TABLE "informix".xrcalist row size = 33 number of columns = 10 index size = 18 }

create table "informix".xrcalist 
  (
    evt_no serial not null ,
    ord_no integer not null ,
    year smallint not null ,
    tsc char(1) not null ,
    rsn_typ char(1) 
        default '' not null ,
    can_typ char(2) not null ,
    exe_dat date not null ,
    rpt_dat date not null ,
    rpt_man integer not null ,
    rtt datetime year to minute 
        default current year to minute not null ,
    primary key (evt_no) 
  );

revoke all on "informix".xrcalist from "public" as "informix";

{ TABLE "informix".osrfodp row size = 77 number of columns = 6 index size = 18 }

create table "informix".osrfodp 
  (
    rpy_no serial not null ,
    rfo_no integer not null ,
    rpy_txt text not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rpy_no) 
  );

revoke all on "informix".osrfodp from "public" as "informix";

{ TABLE "informix".osrfodr row size = 105 number of columns = 11 index size = 61 }

create table "informix".osrfodr 
  (
    rfo_no serial not null ,
    rfo_vsn integer not null ,
    rfo_dct integer not null ,
    rfo_tim datetime year to second not null ,
    rfo_rsn text not null ,
    frm_vsn integer not null ,
    frm_dct integer not null ,
    rpy_tim datetime year to second not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rfo_no) 
  );

revoke all on "informix".osrfodr from "public" as "informix";

{ TABLE "informix".tdh10ccd row size = 36 number of columns = 5 index size = 38 }

create table "informix".tdh10ccd 
  (
    ccd_no serial not null ,
    icd_cod_m char(12) not null ,
    icd_cod_c char(12) not null ,
    cnt integer not null ,
    rtd date not null ,
    primary key (ccd_no) 
  );

revoke all on "informix".tdh10ccd from "public" as "informix";

{ TABLE "informix".modcui10 row size = 28 number of columns = 7 index size = 26 }

create table "informix".modcui10 
  (
    dcu_no serial not null ,
    typ char(2) not null ,
    div_no smallint not null ,
    icd_cod char(8) not null ,
    cnt integer not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (dcu_no) 
  );

revoke all on "informix".modcui10 from "public" as "informix";

{ TABLE "informix".mrrmp row size = 82 number of columns = 7 index size = 31 }

create table "informix".mrrmp 
  (
    mrc_no serial not null ,
    fun_no char(4) not null ,
    lnk_no integer not null ,
    ver_no smallint 
        default 0 not null ,
    txt text,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (mrc_no) 
  );

revoke all on "informix".mrrmp from "public" as "informix";

{ TABLE "informix".rgrup row size = 31 number of columns = 13 index size = 25 }

create table "informix".rgrup 
  (
    rsn_no serial not null ,
    opd_er char(1) not null ,
    charg_typ char(1) not null ,
    f_r char(1) not null ,
    pt_typ char(2) not null ,
    sft char(1) not null ,
    week char(1) not null ,
    amt smallint not null ,
    eff_dat date 
        default  '1899/12/31' not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    rtp integer not null ,
    rtd date not null ,
    rthm smallint not null ,
    primary key (rsn_no) 
  );

revoke all on "informix".rgrup from "public" as "informix";

{ TABLE "informix".mrqar1 row size = 43 number of columns = 9 index size = 24 }

create table "informix".mrqar1 
  (
    mr_no serial not null ,
    chart integer not null ,
    dat date not null ,
    typ char(2) not null ,
    val char(10) not null ,
    fun_no char(4) 
        default '' not null ,
    lnk_num integer 
        default 0 not null ,
    rtp integer 
        default 0 not null ,
    rtt datetime year to minute not null ,
    primary key (mr_no) 
  );

revoke all on "informix".mrqar1 from "public" as "informix";

{ TABLE "informix".emtmpq row size = 126 number of columns = 10 index size = 56 }

create table "informix".emtmpq 
  (
    emq_no varchar(32) not null ,
    emq_typ1 varchar(12) not null ,
    emq_typ2 varchar(12) not null ,
    lnk_no varchar(32) not null ,
    cmp_man integer not null ,
    cmp_tim datetime year to second not null ,
    tsc varchar(1) not null ,
    tsf_tim datetime year to second not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (emq_no) 
  );

revoke all on "informix".emtmpq from "public" as "informix";

{ TABLE "informix".emtmpql row size = 126 number of columns = 10 index size = 149 }

create table "informix".emtmpql 
  (
    emq_no varchar(32) not null ,
    emq_typ1 varchar(12) not null ,
    emq_typ2 varchar(12) not null ,
    lnk_no varchar(32) not null ,
    cmp_man integer not null ,
    cmp_tim datetime year to second not null ,
    tsc varchar(1) not null ,
    tsf_tim datetime year to second not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (emq_no) 
  );

revoke all on "informix".emtmpql from "public" as "informix";

{ TABLE "informix".mostts row size = 29 number of columns = 6 index size = 9 }

create table "informix".mostts 
  (
    stts_no serial not null ,
    lnk_num integer not null ,
    typ char(3) not null ,
    val decimal(11,2) not null ,
    rtp integer not null ,
    rtt datetime year to minute not null 
  );

revoke all on "informix".mostts from "public" as "informix";

{ TABLE "informix".qmolls row size = 64 number of columns = 3 index size = 9 }

create table "informix".qmolls 
  (
    lls_no serial not null ,
    itm_no integer not null ,
    oth_dsc text,
    primary key (lls_no) 
  );

revoke all on "informix".qmolls from "public" as "informix";

{ TABLE "informix".rgdiel row size = 419 number of columns = 7 index size = 18 }

create table "informix".rgdiel 
  (
    rde_no serial not null ,
    vsn integer not null ,
    clm_typ char(2) not null ,
    val char(400) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rde_no) 
  );

revoke all on "informix".rgdiel from "public" as "informix";

{ TABLE "informix".rgdrdie row size = 79 number of columns = 9 index size = 18 }

create table "informix".rgdrdie 
  (
    rde_no serial not null ,
    dct_no integer not null ,
    clm_typ char(2) not null ,
    v01 char(20) not null ,
    v02 char(20) not null ,
    v03 char(20) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rde_no) 
  );

revoke all on "informix".rgdrdie from "public" as "informix";

{ TABLE "informix".rfebdi row size = 411 number of columns = 30 index size = 54 }

create table "informix".rfebdi 
  (
    rf_no serial not null ,
    rf_tr_no char(16) 
        default '' not null ,
    id_no char(10) not null ,
    ctt_tel char(16) 
        default '',
    ctt_nam char(16) 
        default '',
    eff_dat date not null ,
    dat_up_tim datetime year to second not null ,
    rf_hpt_cod char(10) not null ,
    rf_hpt char(15) not null ,
    rf_prp_cod char(1) not null ,
    rf_prp char(20) not null ,
    rf_div_cod char(2) not null ,
    rf_div char(20) not null ,
    arr_dat date,
    arr_div_cod char(2) 
        default '',
    arr_div char(20) 
        default '',
    rlt_dct char(10) not null ,
    rlt_dct_nam char(20) 
        default '' not null ,
    rlt_div_cod char(2) 
        default '' not null ,
    rlt_div char(20) not null ,
    sts char(30) not null ,
    stp_dat date not null ,
    ath_flg char(2) not null ,
    cnt_prc_mrk char(100) not null ,
    hpt_slf_no char(23),
    ori_tr_no char(16) 
        default '',
    acc_dat date 
        default  '1899/12/31' not null ,
    rep_dat date 
        default  '1899/12/31' not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rf_no) 
  );

revoke all on "informix".rfebdi from "public" as "informix";

{ TABLE "informix".rfebdo row size = 511 number of columns = 31 index size = 54 }

create table "informix".rfebdo 
  (
    rf_no serial not null ,
    rf_tr_no char(16) 
        default '' not null ,
    id_no char(10) not null ,
    ctt_tel char(16) 
        default '',
    ctt_nam char(16) 
        default '',
    eff_dat date not null ,
    dat_up_tim datetime year to second not null ,
    sou_dct_id char(10) 
        default '' not null ,
    sou_dct char(20) not null ,
    sou_div_cod char(2) 
        default '' not null ,
    sou_div char(20) not null ,
    rf_prp_cod char(1) 
        default '' not null ,
    rf_prp char(20) not null ,
    rf_hpt_cod char(10) 
        default '' not null ,
    rf_hpt char(15) 
        default '' not null ,
    rf_div_cod char(2) 
        default '' not null ,
    rf_div char(20) 
        default '' not null ,
    arr_dat date,
    arr_div_cod char(2) 
        default '',
    arr_div char(20) 
        default '',
    sts char(30) 
        default '' not null ,
    stp_dat date not null ,
    ath_flg char(2) not null ,
    mdc_smr char(100) not null ,
    hpt_slf_no char(23),
    ori_tr_no char(16) 
        default '',
    acc_dat date 
        default  '1899/12/31' not null ,
    rep_dat date 
        default  '1899/12/31' not null ,
    cnt_prc_mrk char(100) 
        default '' not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rf_no) 
  );

revoke all on "informix".rfebdo from "public" as "informix";

{ TABLE "informix".lbdema row size = 151 number of columns = 32 index size = 64 }

create table "informix".lbdema 
  (
    lbd_no serial not null ,
    chart integer not null ,
    vsn integer not null ,
    ord_no integer not null ,
    lab_no integer not null ,
    lnk_no char(20) not null ,
    typ char(2) not null ,
    source char(1) not null ,
    chg_cod char(7) not null ,
    tsc char(1) not null ,
    loc integer 
        default 0 not null ,
    chg_no integer 
        default 0 not null ,
    exe_man integer 
        default 0 not null ,
    exe_dat date 
        default  '2025/12/31' not null ,
    exe_hm integer 
        default 0 not null ,
    dly_man integer 
        default 0 not null ,
    dly_dat date 
        default  '2025/12/31' not null ,
    dly_hm integer 
        default 0 not null ,
    rcv_man integer 
        default 0 not null ,
    rcv_dat date 
        default  '2025/12/31' not null ,
    rcv_hm integer 
        default 0 not null ,
    rev_man integer 
        default 0 not null ,
    rev_dat date 
        default  '2025/12/31' not null ,
    rev_hm integer 
        default 0 not null ,
    pre_man integer 
        default 0 not null ,
    pre_rtt datetime year to second 
        default  datetime (2025-12-31 00:00:00) year to second not null ,
    pre_dat date 
        default  '2025/12/31' not null ,
    pay_man integer 
        default 0 not null ,
    pay_rtt datetime year to second 
        default  datetime (2025-12-31 00:00:00) year to second not null ,
    pay_dat date 
        default  '2025/12/31' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (lbd_no) 
  );

revoke all on "informix".lbdema from "public" as "informix";

{ TABLE "informix".cgromdcr row size = 39 number of columns = 10 index size = 28 }

create table "informix".cgromdcr 
  (
    rdc_no serial not null ,
    room char(4) not null ,
    bed char(2) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tc char(1) not null ,
    rdc_fee integer not null ,
    rsn_no integer not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rdc_no) 
  );

revoke all on "informix".cgromdcr from "public" as "informix";

{ TABLE "informix".cgtsrrf row size = 289 number of columns = 8 index size = 28 }

create table "informix".cgtsrrf 
  (
    rsn_no serial not null ,
    typ_cod char(8) not null ,
    itm_no smallint not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rsn char(255) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rsn_no) 
  );

revoke all on "informix".cgtsrrf from "public" as "informix";

{ TABLE "informix".lbiisf row size = 54 number of columns = 10 index size = 34 }

create table "informix".lbiisf 
  (
    ser_no serial not null ,
    chg_cod char(7) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    src char(2) not null ,
    typ char(4) not null ,
    val char(10) 
        default '0' not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".lbiisf from "public" as "informix";

{ TABLE "informix".ehpvcrf row size = 188 number of columns = 10 index size = 24 }

create table "informix".ehpvcrf 
  (
    set_no serial not null ,
    cod char(7) not null ,
    typ char(3) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    nam char(150) not null ,
    crt_man integer not null ,
    ctt_dat date not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (set_no) 
  );

revoke all on "informix".ehpvcrf from "public" as "informix";

{ TABLE "informix".udocr row size = 65 number of columns = 10 index size = 18 }

create table "informix".udocr 
  (
    ser_no serial not null ,
    typ char(1) not null ,
    det_no integer not null ,
    tsc char(1) not null ,
    rev_sts char(2) not null ,
    rev_man integer not null ,
    rev_tim datetime year to minute not null ,
    coment char(30) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".udocr from "public" as "informix";

{ TABLE "informix".cgvda row size = 91 number of columns = 13 index size = 44 }

create table "informix".cgvda 
  (
    vda_no serial not null ,
    vsn integer not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    clm_typ char(2) not null ,
    val char(30) not null ,
    tsc char(1) not null ,
    crt_man integer not null ,
    crt_tim datetime year to second not null ,
    apv_man integer not null ,
    apv_tim datetime year to second not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (vda_no) 
  );

revoke all on "informix".cgvda from "public" as "informix";

{ TABLE "informix".dcidie row size = 143 number of columns = 8 index size = 145 }

create table "informix".dcidie 
  (
    dci_no serial not null ,
    icd_cod char(12) not null ,
    cor_typ char(2) not null ,
    cor_cod char(12) not null ,
    val char(100) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (dci_no) 
  );

revoke all on "informix".dcidie from "public" as "informix";

{ TABLE "informix".dgcdqml row size = 77 number of columns = 6 index size = 31 }

create table "informix".dgcdqml 
  (
    log_num serial not null ,
    lnk_no integer not null ,
    typ char(1) not null ,
    txt text,
    log_man integer not null ,
    log_tim datetime year to second 
        default current year to second not null ,
    primary key (log_num) 
  );

revoke all on "informix".dgcdqml from "public" as "informix";

{ TABLE "informix".moocr row size = 43 number of columns = 10 index size = 25 }

create table "informix".moocr 
  (
    rec_no serial not null ,
    vsn integer not null ,
    chg_cod char(7) not null ,
    typ char(3) not null ,
    tsc char(1) not null ,
    lnk_num integer not null ,
    ord_dat date not null ,
    ord_man integer not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".moocr from "public" as "informix";

{ TABLE "informix".padsc row size = 284 number of columns = 16 index size = 18 }

create table "informix".padsc 
  (
    pal_no serial not null ,
    ord_no integer not null ,
    tse_sit1 char(3) 
        default '' not null ,
    tse_sit2 char(3) 
        default '' not null ,
    tse_drt1 char(3) 
        default '' not null ,
    tse_drt2 char(3) 
        default '' not null ,
    tse_end char(3) 
        default '' not null ,
    tse_sit3 char(3) 
        default '' not null ,
    tsc char(1),
    oth_tis varchar(50),
    oth_drt varchar(50),
    oth_end varchar(50),
    oth_tis3 varchar(50),
    cmt varchar(40) 
        default ' ',
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (pal_no) 
  );

revoke all on "informix".padsc from "public" as "informix";

{ TABLE "informix".dgdiad row size = 43 number of columns = 12 index size = 39 }

create table "informix".dgdiad 
  (
    itr_no serial not null ,
    srv_cod char(10) not null ,
    srv_typ char(1) not null ,
    clt_cod char(10) not null ,
    clt_typ char(1) not null ,
    tsc char(1) not null ,
    src char(1) not null ,
    sev_rat char(1) not null ,
    ost char(1) not null ,
    doc_gde char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (itr_no) 
  );

revoke all on "informix".dgdiad from "public" as "informix";

{ TABLE "informix".dgdbde row size = 33 number of columns = 7 index size = 33 }

create table "informix".dgdbde 
  (
    bde_no serial not null ,
    cls_typ char(2) not null ,
    lnk_num integer not null ,
    val char(10) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (bde_no) 
  );

revoke all on "informix".dgdbde from "public" as "informix";

{ TABLE "informix".dgotxt row size = 66 number of columns = 4 index size = 20 }

create table "informix".dgotxt 
  (
    dsc_no serial not null ,
    cls_typ char(2) not null ,
    lnk_num integer not null ,
    dsc text not null ,
    primary key (dsc_no) 
  );

revoke all on "informix".dgotxt from "public" as "informix";

{ TABLE "informix".xrpodip row size = 25 number of columns = 5 index size = 31 }

create table "informix".xrpodip 
  (
    pdi_no serial not null ,
    chart integer not null ,
    tsc char(1) not null ,
    upl_tim datetime year to second not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (pdi_no) 
  );

revoke all on "informix".xrpodip from "public" as "informix";

{ TABLE "informix".bmptba row size = 30 number of columns = 8 index size = 36 }

create table "informix".bmptba 
  (
    rlt_no serial not null ,
    chart integer not null ,
    typ char(1) not null ,
    frm_no integer not null ,
    acc_no integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rlt_no) 
  );

revoke all on "informix".bmptba from "public" as "informix";

{ TABLE "informix".rgdmd row size = 96 number of columns = 10 index size = 18 }

create table "informix".rgdmd 
  (
    md_no serial not null ,
    sd_no integer not null ,
    sd_frm_no integer not null ,
    typ char(1) not null ,
    dsc text not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (md_no) 
  );

revoke all on "informix".rgdmd from "public" as "informix";

{ TABLE "informix".rgdsm row size = 142 number of columns = 12 index size = 9 }

create table "informix".rgdsm 
  (
    sd_no serial not null ,
    sd_frm_no integer not null ,
    nam char(50) not null ,
    typ char(1) not null ,
    lv_no smallint 
        default 0 not null ,
    dsc char(50) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (sd_no) 
  );

revoke all on "informix".rgdsm from "public" as "informix";

{ TABLE "informix".rgdrd row size = 346 number of columns = 11 index size = 18 }

create table "informix".rgdrd 
  (
    rd_no serial not null ,
    sd_no integer not null ,
    rd_frm_no integer not null ,
    typ char(1) not null ,
    rule text not null ,
    dsc char(250) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rd_no) 
  );

revoke all on "informix".rgdrd from "public" as "informix";

{ TABLE "informix".lbcodcmd row size = 95 number of columns = 10 index size = 60 }

create table "informix".lbcodcmd 
  (
    ser_no serial not null ,
    typ char(2) not null ,
    cod char(12) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    nam_s char(20) not null ,
    nam_f char(30) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".lbcodcmd from "public" as "informix";

{ TABLE "informix".cgpcmd row size = 136 number of columns = 13 index size = 31 }

create table "informix".cgpcmd 
  (
    pcm_no serial not null ,
    chart integer not null ,
    trn_tim datetime year to second not null ,
    tsc char(1) not null ,
    crd_typ char(1) not null ,
    crd_no char(20) not null ,
    inv_no char(50) 
        default '' not null ,
    epr_dat char(10) not null ,
    apv_no char(10) not null ,
    trn_amt decimal(10,2) not null ,
    term_id char(10) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (pcm_no) 
  );

revoke all on "informix".cgpcmd from "public" as "informix";

{ TABLE "informix".cgpcvr row size = 20 number of columns = 6 index size = 18 }

create table "informix".cgpcvr 
  (
    pcv_no serial not null ,
    pcm_no integer not null ,
    typ char(1) 
        default 'I' not null ,
    vsn integer not null ,
    tsc char(1) not null ,
    amt decimal(10,2) not null ,
    primary key (pcv_no) 
  );

revoke all on "informix".cgpcvr from "public" as "informix";

{ TABLE "informix".mrlldat row size = 38 number of columns = 8 index size = 33 }

create table "informix".mrlldat 
  (
    ser_no serial not null ,
    id_no char(10) not null ,
    typ char(3) not null ,
    lnk_no integer not null ,
    dat date not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".mrlldat from "public" as "informix";

{ TABLE "informix".smlabrpt row size = 52 number of columns = 8 index size = 34 }

create table "informix".smlabrpt 
  (
    ser_no serial not null ,
    sed_no integer not null ,
    chart integer not null ,
    chg_cod char(7) not null ,
    val char(20) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".smlabrpt from "public" as "informix";

{ TABLE "informix".bmrup row size = 82 number of columns = 9 index size = 73 }

create table "informix".bmrup 
  (
    brp_no serial not null ,
    charg_typ char(1) not null ,
    lnk_no char(8) not null ,
    val char(50) not null ,
    sts char(1) not null ,
    acc_no integer not null ,
    rtl smallint not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (brp_no) 
  );

revoke all on "informix".bmrup from "public" as "informix";

{ TABLE "informix".bmmakie row size = 116 number of columns = 13 index size = 82 }

create table "informix".bmmakie 
  (
    bme_no serial not null ,
    acc_no integer not null ,
    eff_tim datetime year to second not null ,
    stp_tim datetime year to second not null ,
    tsc char(1) not null ,
    typ char(1) not null ,
    val char(50) not null ,
    pre_days smallint not null ,
    cnt_man char(20) not null ,
    cnt_tel integer not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    rtl smallint not null ,
    primary key (bme_no) 
  );

revoke all on "informix".bmmakie from "public" as "informix";

{ TABLE "informix".icatfee row size = 29 number of columns = 7 index size = 18 }

create table "informix".icatfee 
  (
    at_no serial not null ,
    acc_no integer not null ,
    each_dat date not null ,
    typ char(1) not null ,
    amt decimal(6,2) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (at_no) 
  );

revoke all on "informix".icatfee from "public" as "informix";

{ TABLE "informix".bmwrdcnt row size = 28 number of columns = 7 index size = 21 }

create table "informix".bmwrdcnt 
  (
    ser_no serial not null ,
    dat date not null ,
    ward char(3) not null ,
    inp_cnt integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".bmwrdcnt from "public" as "informix";

{ TABLE "informix".motbd row size = 200 number of columns = 10 index size = 28 }

create table "informix".motbd 
  (
    ser_no serial not null ,
    typ char(10) not null ,
    frm_no integer not null ,
    nam char(60) not null ,
    cmt char(100) not null ,
    eff_dat date 
        default  '1899/12/31' not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    eff_day smallint 
        default 0 not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".motbd from "public" as "informix";

{ TABLE "informix".motrd row size = 74 number of columns = 13 index size = 33 }

create table "informix".motrd 
  (
    rec_no serial not null ,
    id_no char(10) not null ,
    ser_no integer not null ,
    src char(1) not null ,
    lnk_no integer not null ,
    val char(10) not null ,
    tsc char(1) not null ,
    rec_tim datetime year to second not null ,
    rec_man integer not null ,
    eff_tim datetime year to second not null ,
    stp_tim datetime year to second not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".motrd from "public" as "informix";

{ TABLE "informix".hccish row size = 338 number of columns = 9 index size = 24 }

create table "informix".hccish 
  (
    cdh_no serial not null ,
    id_no char(10) not null ,
    typ char(3) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    cdh_msg char(300) not null ,
    tsc char(1) 
        default 'A' not null ,
    crt_man integer not null ,
    crt_tim datetime year to second not null ,
    primary key (cdh_no) 
  );

revoke all on "informix".hccish from "public" as "informix";

{ TABLE "informix".padscd row size = 67 number of columns = 7 index size = 18 }

create table "informix".padscd 
  (
    ser_no serial not null ,
    pal_no integer not null ,
    seq_no smallint not null ,
    typ char(2) 
        default '' not null ,
    tse char(3) 
        default '' not null ,
    other varchar(50),
    tsc char(1),
    primary key (ser_no) 
  );

revoke all on "informix".padscd from "public" as "informix";

{ TABLE "informix".exregrul row size = 32 number of columns = 7 index size = 30 }

create table "informix".exregrul 
  (
    seq_no serial not null ,
    item_cod char(10) not null ,
    typ char(2) not null ,
    eff_tim date not null ,
    stp_tim date not null ,
    rtp integer not null ,
    rtt date not null ,
    primary key (seq_no) 
  );

revoke all on "informix".exregrul from "public" as "informix";

{ TABLE "informix".oomtlrl row size = 32 number of columns = 8 index size = 30 }

create table "informix".oomtlrl 
  (
    ser_no serial not null ,
    vsn integer not null ,
    itm char(3) not null ,
    res_dat date not null ,
    res_man integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".oomtlrl from "public" as "informix";

{ TABLE "informix".rrchgpar row size = 47 number of columns = 8 index size = 36 }

create table "informix".rrchgpar 
  (
    par_no serial not null ,
    chg_typ integer not null ,
    par_typ1 char(6) not null ,
    par_typ2 char(6) not null ,
    par_typ3 char(6) not null ,
    amt decimal(15,4) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (par_no) 
  );

revoke all on "informix".rrchgpar from "public" as "informix";

{ TABLE "informix".hecm row size = 330 number of columns = 32 index size = 70 }

create table "informix".hecm 
  (
    cm_no serial not null ,
    bar_cod char(12) not null ,
    prj_no char(12) not null ,
    hec_no integer not null ,
    wrk_area char(1) not null ,
    vsn integer not null ,
    ocp_no char(20) not null ,
    dis_sts char(1) not null ,
    dis_cmt char(30) not null ,
    ana_sis integer not null ,
    idc integer not null ,
    author integer not null ,
    intl char(4) not null ,
    dis_amt integer not null ,
    o_amt integer not null ,
    g_amt integer not null ,
    c_amt integer not null ,
    p_amt integer not null ,
    pr_amt integer not null ,
    phy_amt integer not null ,
    oth_amt integer not null ,
    charg_no integer not null ,
    wte_sts char(1) not null ,
    rec_num char(32) not null ,
    acc_num char(32) not null ,
    off_num char(32) not null ,
    lnk_prj char(32) not null ,
    cmt char(20) not null ,
    lnk_no char(32) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (cm_no) 
  );

revoke all on "informix".hecm from "public" as "informix";

{ TABLE "informix".hecsi row size = 268 number of columns = 23 index size = 18 }

create table "informix".hecsi 
  (
    csi_no serial not null ,
    cm_no integer not null ,
    sch_auo integer not null ,
    acd char(1) not null ,
    sch_typ char(1) not null ,
    sch_nam char(64) not null ,
    charg_typ char(1) not null ,
    prs_amt integer not null ,
    dvg_amt integer not null ,
    rec_amt integer not null ,
    act_amt integer not null ,
    sym char(7) not null ,
    qty integer not null ,
    loc integer not null ,
    wte_sts char(1) not null ,
    rec_num char(32) not null ,
    acc_num char(32) not null ,
    off_num char(32) not null ,
    cmt char(20) not null ,
    lnk_no char(32) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (csi_no) 
  );

revoke all on "informix".hecsi from "public" as "informix";

{ TABLE "informix".hecsd row size = 108 number of columns = 14 index size = 18 }

create table "informix".hecsd 
  (
    csd_no serial not null ,
    csi_no integer not null ,
    exm_chg char(12) not null ,
    charg_no integer not null ,
    seq_no integer not null ,
    item_cod char(7) not null ,
    loc integer not null ,
    qty integer not null ,
    amt integer not null ,
    cmt char(20) not null ,
    lnk_no char(32) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (csd_no) 
  );

revoke all on "informix".hecsd from "public" as "informix";

{ TABLE "informix".erdisaster row size = 260 number of columns = 15 index size = 31 }

create table "informix".erdisaster 
  (
    rep_no serial not null ,
    vsn integer not null ,
    disaster_no char(12) not null ,
    report_tim datetime year to second not null ,
    report_typ char(2) not null ,
    trend char(2) not null ,
    trend_other char(200) not null ,
    eqt_use char(3) not null ,
    chk_level char(4) 
        default '' not null ,
    chk_level_0 char(1) 
        default '0' not null ,
    send_typ char(1) 
        default '0' not null ,
    leave_tim datetime year to second not null ,
    del_flag char(3) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rep_no) 
  );

revoke all on "informix".erdisaster from "public" as "informix";

{ TABLE "informix".erunotim row size = 38 number of columns = 9 index size = 9 }

create table "informix".erunotim 
  (
    rep_no serial not null ,
    report_tim datetime year to second not null ,
    report_119 char(2) not null ,
    wait_visit integer not null ,
    wait_pushbed integer not null ,
    wait_hospital integer not null ,
    wait_icu integer not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rep_no) 
  );

revoke all on "informix".erunotim from "public" as "informix";

{ TABLE "informix".cghicc row size = 49 number of columns = 10 index size = 9 }

create table "informix".cghicc 
  (
    rec_no serial not null ,
    typ char(2) not null ,
    pt_typ char(1) not null ,
    chg_cod char(12) not null ,
    amt char(9) not null ,
    eff_dat char(7) not null ,
    tsc char(1) not null ,
    sts char(1),
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".cghicc from "public" as "informix";

{ TABLE "informix".moval2 row size = 76 number of columns = 8 index size = 22 }

create table "informix".moval2 
  (
    ser_no serial not null ,
    lnk_num integer not null ,
    seq_no smallint not null ,
    typ char(2) not null ,
    val varchar(50) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".moval2 from "public" as "informix";

{ TABLE "informix".progbd row size = 447 number of columns = 22 index size = 83 }

create table "informix".progbd 
  (
    ser_no serial not null ,
    org_no integer not null ,
    org_nam char(40) not null ,
    zip integer 
        default 0 not null ,
    adr varchar(30) not null ,
    tel_no integer 
        default 0 not null ,
    fax_no integer 
        default 0 not null ,
    eml_no varchar(30),
    hed_nam char(12) 
        default '' not null ,
    brn_dat date 
        default  '1899/12/31' not null ,
    tit_nam varchar(20) not null ,
    emp_cnt smallint 
        default 0 not null ,
    car_cnt smallint 
        default 0 not null ,
    ogt_no smallint 
        default 0 not null ,
    rsp_seq integer not null ,
    cnt_dm smallint 
        default 0 not null ,
    frm_no integer 
        default 0 not null ,
    eff_dat date 
        default  '1899/12/31' not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    cmt varchar(255),
    rtp integer 
        default 0 not null ,
    rtd date not null ,
    primary key (ser_no) 
  );

revoke all on "informix".progbd from "public" as "informix";

{ TABLE "informix".cgepkgi row size = 118 number of columns = 10 index size = 21 }

create table "informix".cgepkgi 
  (
    pkg_no serial not null ,
    pkg_cod char(7) not null ,
    eff_dat date 
        default today not null ,
    stp_dat date 
        default  '2025/12/31' not null ,
    typ char(2) not null ,
    tsc char(1) 
        default '' not null ,
    pkg_amt integer not null ,
    cmt char(80) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (pkg_no) 
  );

revoke all on "informix".cgepkgi from "public" as "informix";

{ TABLE "informix".ifdpbc row size = 37 number of columns = 9 index size = 18 }

create table "informix".ifdpbc 
  (
    bar_no serial not null ,
    seq_no integer not null ,
    rec_no integer not null ,
    typ char(1) not null ,
    tsc char(1) not null ,
    pro_man integer not null ,
    pro_tim datetime year to minute not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (bar_no) 
  );

revoke all on "informix".ifdpbc from "public" as "informix";

{ TABLE "informix".bmdast row size = 48 number of columns = 12 index size = 41 }

create table "informix".bmdast 
  (
    evt_no serial not null ,
    acc_no integer not null ,
    typ char(3) 
        default '' not null ,
    frm_no integer 
        default 0 not null ,
    eff_tim datetime year to minute not null ,
    seq_no smallint not null ,
    div_no integer not null ,
    old_dct integer not null ,
    new_dct integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to minute not null ,
    primary key (evt_no) 
  );

revoke all on "informix".bmdast from "public" as "informix";

{ TABLE "informix".pssqibd row size = 1249 number of columns = 17 index size = 22 }

create table "informix".pssqibd 
  (
    sqi_no serial not null ,
    itm_typ char(1) not null ,
    itm_num char(3) not null ,
    sfc_frm char(1) not null ,
    nhi_cod char(12) not null ,
    chg_cod char(7) not null ,
    chk_tsc char(1) not null ,
    pay_sfc char(600) not null ,
    sfc_anl char(600) not null ,
    chk_lic char(1) not null ,
    chk_ctf char(1) not null ,
    chk_prf char(1) not null ,
    chk_exe char(1) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (sqi_no) 
  );

revoke all on "informix".pssqibd from "public" as "informix";

{ TABLE "informix".pssqrps row size = 33 number of columns = 10 index size = 22 }

create table "informix".pssqrps 
  (
    rps_no serial not null ,
    emp_no integer not null ,
    itm_typ char(1) not null ,
    itm_num char(3) not null ,
    uld_sts char(1) not null ,
    rp_sts char(1) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    rtp integer not null ,
    rtt datetime year to minute not null ,
    primary key (rps_no) 
  );

revoke all on "informix".pssqrps from "public" as "informix";

{ TABLE "informix".mmecprrf row size = 98 number of columns = 12 index size = 23 }

create table "informix".mmecprrf 
  (
    ser_no serial not null ,
    map_no smallint not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    ecp_cod char(7) not null ,
    rec_typ char(2) not null ,
    rec_dpt integer not null ,
    rec_no char(50) not null ,
    rec_knd char(2) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".mmecprrf from "public" as "informix";

{ TABLE "informix".rgafdr row size = 77 number of columns = 6 index size = 44 }

create table "informix".rgafdr 
  (
    fdr_no serial not null ,
    fil_cod char(30) not null ,
    dsc char(30) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (fdr_no) 
  );

revoke all on "informix".rgafdr from "public" as "informix";

{ TABLE "informix".rgard row size = 280 number of columns = 7 index size = 18 }

create table "informix".rgard 
  (
    ard_no serial not null ,
    arm_no integer not null ,
    fdr_no integer not null ,
    val char(255) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ard_no) 
  );

revoke all on "informix".rgard from "public" as "informix";

{ TABLE "informix".rgarm row size = 35 number of columns = 7 index size = 37 }

create table "informix".rgarm 
  (
    arm_no serial not null ,
    eff_dat date not null ,
    typ char(10) not null ,
    lnk_vsn integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (arm_no) 
  );

revoke all on "informix".rgarm from "public" as "informix";

{ TABLE "informix".sigdma row size = 363 number of columns = 10 index size = 37 }

create table "informix".sigdma 
  (
    sirm_no serial not null ,
    ma_cod char(20) not null ,
    ma_nam char(60) not null ,
    spc_typ char(3) not null ,
    tsc char(1) not null ,
    eff_tim date not null ,
    stp_tim date 
        default  '2025/12/31' not null ,
    cmt char(255) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (sirm_no) 
  );

revoke all on "informix".sigdma from "public" as "informix";

{ TABLE "informix".sigddef row size = 277 number of columns = 8 index size = 74 }

create table "informix".sigddef 
  (
    gd_no serial not null ,
    ctl_tab char(20) not null ,
    ctl_fld_nam char(20) not null ,
    def_cod char(20) not null ,
    def_nam char(200) not null ,
    tsc char(1) 
        default 'A' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (gd_no) 
  );

revoke all on "informix".sigddef from "public" as "informix";

{ TABLE "informix".sigdde row size = 377 number of columns = 10 index size = 54 }

create table "informix".sigdde 
  (
    sird_no serial not null ,
    ma_cod char(20) not null ,
    det_cod char(20) not null ,
    det_nam char(60) not null ,
    rea_days char(4) not null ,
    ded_flg char(1) not null ,
    sts char(1) not null ,
    cmt char(255) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (sird_no) 
  );

revoke all on "informix".sigdde from "public" as "informix";

{ TABLE "informix".dgpcm row size = 280 number of columns = 9 index size = 31 }

create table "informix".dgpcm 
  (
    mst_no serial not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    typ char(1) not null ,
    typ_sub char(2) not null ,
    tit char(250) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt date 
        default today not null ,
    primary key (mst_no) 
  );

revoke all on "informix".dgpcm from "public" as "informix";

{ TABLE "informix".dgpcd row size = 88 number of columns = 9 index size = 32 }

create table "informix".dgpcd 
  (
    det_no serial not null ,
    mst_no integer not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    typ char(1) not null ,
    msg text not null ,
    rtp integer not null ,
    rtt date 
        default today not null ,
    primary key (det_no) 
  );

revoke all on "informix".dgpcd from "public" as "informix";

{ TABLE "informix".molog row size = 79 number of columns = 9 index size = 23 }

create table "informix".molog 
  (
    log_no serial not null ,
    lnk_num integer not null ,
    seq_no smallint not null ,
    typ char(3) not null ,
    val varchar(50) not null ,
    tsc char(1) not null ,
    emp_no integer not null ,
    loc_no smallint not null ,
    loc_tim datetime year to second not null ,
    primary key (log_no) 
  );

revoke all on "informix".molog from "public" as "informix";

{ TABLE "informix".moupbd row size = 355 number of columns = 18 index size = 57 }

create table "informix".moupbd 
  (
    ser_no serial not null ,
    cod_typ char(1) not null ,
    cod char(7) not null ,
    pay_typ char(1) not null ,
    vit_typ char(1) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    grp_id smallint 
        default 0 not null ,
    use_pnt char(2) 
        default '' not null ,
    sat_val char(12) not null ,
    end_val char(12) not null ,
    ret_val smallint 
        default 1 not null ,
    lnk_num integer not null ,
    rsn varchar(255) 
        default '' not null ,
    cnt_psn integer 
        default 0 not null ,
    tel varchar(20) 
        default '' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (cod_typ,cod,pay_typ,vit_typ,eff_tim) 
  );

revoke all on "informix".moupbd from "public" as "informix";

{ TABLE "informix".lbsperod row size = 34 number of columns = 8 index size = 20 }

create table "informix".lbsperod 
  (
    rec_no serial not null ,
    lab_no integer not null ,
    typ char(2) not null ,
    rec_tim datetime year to minute not null ,
    rec_man integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".lbsperod from "public" as "informix";

{ TABLE "informix".bmnapl row size = 31 number of columns = 5 index size = 18 }

create table "informix".bmnapl 
  (
    ntf_no serial not null ,
    acc_no integer not null ,
    chart integer not null ,
    exe_man varchar(10) 
        default '' not null ,
    exe_tim datetime year to second 
        default  datetime (1899-12-31 00:00:00) year to second not null ,
    primary key (ntf_no) 
  );

revoke all on "informix".bmnapl from "public" as "informix";

{ TABLE "informix".moruq row size = 37 number of columns = 9 index size = 46 }

create table "informix".moruq 
  (
    ser_no serial not null ,
    rur_no integer not null ,
    ord_no integer not null ,
    depart integer 
        default 0 not null ,
    adm_dr integer not null ,
    asg_dat date 
        default  '1899/12/31' not null ,
    typ char(1),
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".moruq from "public" as "informix";

{ TABLE "informix".bmvstrod row size = 120 number of columns = 17 index size = 55 }

create table "informix".bmvstrod 
  (
    ser_no serial not null ,
    acc_no integer not null ,
    typ char(2) not null ,
    room char(4) not null ,
    bed char(2) not null ,
    shift char(1) not null ,
    lnk_typ char(1) 
        default '' not null ,
    id_no char(20) not null ,
    nam char(50) not null ,
    tel_no integer not null ,
    born_dat date 
        default  '1899/12/31' not null ,
    sex smallint 
        default 0 not null ,
    relation smallint 
        default 0 not null ,
    ent_tim datetime year to minute not null ,
    tsc char(1) 
        default '' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".bmvstrod from "public" as "informix";

{ TABLE "informix".mobar row size = 30 number of columns = 7 index size = 24 }

create table "informix".mobar 
  (
    bar_no serial not null ,
    bar_typ char(3) not null ,
    lnk_no decimal(12,0) not null ,
    act_typ char(2) 
        default '' not null ,
    act_loc smallint not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (bar_no) 
  );

revoke all on "informix".mobar from "public" as "informix";

{ TABLE "informix".mopmt row size = 30 number of columns = 7 index size = 26 }

create table "informix".mopmt 
  (
    pmt_no serial not null ,
    pmt_dat date 
        default today not null ,
    pmt_cod char(8) not null ,
    typ char(1) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (pmt_no) 
  );

revoke all on "informix".mopmt from "public" as "informix";

{ TABLE "informix".mopmtpkg row size = 13 number of columns = 4 index size = 27 }

create table "informix".mopmtpkg 
  (
    itm_no serial not null ,
    pmt_no integer not null ,
    evt_no integer not null ,
    tsc char(1) not null ,
    primary key (itm_no) 
  );

revoke all on "informix".mopmtpkg from "public" as "informix";

{ TABLE "informix".pdpcitm row size = 110 number of columns = 10 index size = 19 }

create table "informix".pdpcitm 
  (
    itm_no serial not null ,
    lnk_no char(5) not null ,
    typ char(1) not null ,
    seq_no integer not null ,
    nam char(60) not null ,
    val char(20) not null ,
    dat_f date 
        default  '1899/12/31' not null ,
    dat_t date 
        default  '2025/12/31' not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (itm_no) 
  );

revoke all on "informix".pdpcitm from "public" as "informix";

{ TABLE "informix".pdpcrd row size = 46 number of columns = 8 index size = 18 }

create table "informix".pdpcrd 
  (
    dtl_no serial not null ,
    lnk_no integer not null ,
    tsc char(1) not null ,
    itm_no integer not null ,
    typ char(1) not null ,
    val char(20) 
        default '' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (dtl_no) 
  );

revoke all on "informix".pdpcrd from "public" as "informix";

{ TABLE "informix".moogm row size = 20 number of columns = 5 index size = 9 }

create table "informix".moogm 
  (
    grp_no serial not null ,
    typ char(3) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (grp_no) 
  );

revoke all on "informix".moogm from "public" as "informix";

{ TABLE "informix".moogi row size = 13 number of columns = 4 index size = 28 }

create table "informix".moogi 
  (
    itm_no serial not null ,
    grp_no integer not null ,
    typ char(1) not null ,
    lnk_no integer not null ,
    primary key (itm_no) 
  );

revoke all on "informix".moogi from "public" as "informix";

{ TABLE "informix".ntdie row size = 55 number of columns = 10 index size = 24 }

create table "informix".ntdie 
  (
    rde_no serial not null ,
    acc_no integer not null ,
    dt_own char(1) not null ,
    f_dat date not null ,
    f_meal char(1) not null ,
    clm_typ char(2) not null ,
    val char(30) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rde_no) 
  );

revoke all on "informix".ntdie from "public" as "informix";

{ TABLE "informix".btsdm row size = 215 number of columns = 17 index size = 31 }

create table "informix".btsdm 
  (
    bts_no serial not null ,
    dpt_no integer not null ,
    frm_no integer not null ,
    mak_tim datetime year to second not null ,
    eff_tim datetime year to second not null ,
    src char(1) 
        default 'A' not null ,
    cate char(1) 
        default 'B' not null ,
    typ char(2) 
        default '00' not null ,
    capacity integer 
        default 0 not null ,
    tsc char(1) not null ,
    res char(1) 
        default '0' not null ,
    res_dsc char(120) 
        default '' not null ,
    crt_man integer not null ,
    crt_tim datetime year to second not null ,
    cmt varchar(32),
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (bts_no) 
  );

revoke all on "informix".btsdm from "public" as "informix";

{ TABLE "informix".btiod row size = 42 number of columns = 10 index size = 31 }

create table "informix".btiod 
  (
    bio_no serial not null ,
    bts_no integer not null ,
    ref_no integer not null ,
    bas_no integer not null ,
    typ char(1) not null ,
    res char(1) 
        default '' not null ,
    do_man integer,
    do_tim datetime year to second,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (bio_no) 
  );

revoke all on "informix".btiod from "public" as "informix";

{ TABLE "informix".btedf row size = 49 number of columns = 10 index size = 40 }

create table "informix".btedf 
  (
    edf_no serial not null ,
    bts_no integer not null ,
    ord_no integer not null ,
    pnt_usr integer,
    pnt_tim datetime year to second,
    exe_man integer,
    exe_tim datetime year to second,
    exe_tsc char(1),
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (edf_no) 
  );

revoke all on "informix".btedf from "public" as "informix";

{ TABLE "informix".bteqd row size = 43 number of columns = 7 index size = 20 }

create table "informix".bteqd 
  (
    ser_no serial not null ,
    eqd_no integer not null ,
    etyp char(2) not null ,
    eqd_nam char(20) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".bteqd from "public" as "informix";

{ TABLE "informix".btird row size = 83 number of columns = 11 index size = 18 }

create table "informix".btird 
  (
    ser_no serial not null ,
    frm_no integer not null ,
    col_num integer not null ,
    frz_num integer not null ,
    tsc char(1) not null ,
    crt_man integer not null ,
    crt_tim datetime year to second not null ,
    crt_typ char(2) not null ,
    cmt char(40) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".btird from "public" as "informix";

{ TABLE "informix".rgvsnrel row size = 27 number of columns = 7 index size = 27 }

create table "informix".rgvsnrel 
  (
    rel_no serial not null ,
    sou_vsn integer not null ,
    rel_vsn integer not null ,
    typ smallint not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rel_no) 
  );

revoke all on "informix".rgvsnrel from "public" as "informix";

{ TABLE "informix".rgovdie row size = 88 number of columns = 10 index size = 22 }

create table "informix".rgovdie 
  (
    scd_no serial not null ,
    wek_day char(1) not null ,
    sft char(1) not null ,
    room smallint not null ,
    stp_dat date not null ,
    clm_typ char(3) not null ,
    val char(60) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second,
    primary key (scd_no) 
  );

revoke all on "informix".rgovdie from "public" as "informix";

{ TABLE "informix".rgrldie row size = 87 number of columns = 9 index size = 21 }

create table "informix".rgrldie 
  (
    scd_no serial not null ,
    visit_dat date not null ,
    sft char(1) not null ,
    room smallint not null ,
    clm_typ char(3) not null ,
    val char(60) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second,
    primary key (scd_no) 
  );

revoke all on "informix".rgrldie from "public" as "informix";

{ TABLE "informix".rgrdiel row size = 119 number of columns = 7 index size = 18 }

create table "informix".rgrdiel 
  (
    rrl_no serial not null ,
    room integer not null ,
    clm_typ char(2) not null ,
    val char(100) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rrl_no) 
  );

revoke all on "informix".rgrdiel from "public" as "informix";

{ TABLE "informix".rgcsdie row size = 50 number of columns = 7 index size = 18 }

create table "informix".rgcsdie 
  (
    rcs_no serial not null ,
    mis_num integer not null ,
    clm_typ char(3) not null ,
    val char(30) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rcs_no) 
  );

revoke all on "informix".rgcsdie from "public" as "informix";

{ TABLE "informix".udocrd row size = 13 number of columns = 4 index size = 18 }

create table "informix".udocrd 
  (
    ocd_no serial not null ,
    ser_no integer not null ,
    eva_no integer not null ,
    eva_sts char(1) not null ,
    primary key (ocd_no) 
  );

revoke all on "informix".udocrd from "public" as "informix";

{ TABLE "informix".ossoalog row size = 277 number of columns = 6 index size = 18 }

create table "informix".ossoalog 
  (
    det_no serial not null ,
    rec_no integer not null ,
    seq_no smallint not null ,
    desc char(255) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (det_no) 
  );

revoke all on "informix".ossoalog from "public" as "informix";

{ TABLE "informix".hcwcl row size = 54 number of columns = 7 index size = 21 }

create table "informix".hcwcl 
  (
    ser_no serial not null ,
    ccd_no integer not null ,
    typ char(3) not null ,
    val char(30) not null ,
    tsc char(1) 
        default 'A' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".hcwcl from "public" as "informix";

{ TABLE "informix".cghtid row size = 55 number of columns = 10 index size = 42 }

create table "informix".cghtid 
  (
    tid_no serial not null ,
    hsp_no char(10) not null ,
    chg_cod char(7) not null ,
    typ char(4) not null ,
    dis_rat decimal(3,2) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (tid_no) 
  );

revoke all on "informix".cghtid from "public" as "informix";

{ TABLE "informix".eotrtriage row size = 8610 number of columns = 51 index size = 84 }

create table "informix".eotrtriage 
  (
    ahospitalid char(10) not null ,
    atriageid char(13) not null ,
    atriagetimes char(4) not null ,
    auserkeyinid char(15),
    avisitno varchar(13) not null ,
    aarriveid char(2),
    aphotopath varchar(100),
    atemperature decimal(3,1),
    abreath decimal(3,0),
    apulse decimal(3,0),
    asbp decimal(3,0),
    adbp decimal(3,0),
    aweight decimal(5,2),
    aheight decimal(5,2),
    asao2 decimal(3,0),
    agcse char(2),
    agcsv char(2),
    agcsm char(2),
    adepartmentid char(10),
    asystemid char(3),
    acomplaintid char(5),
    ajudgeid char(4),
    acomputelevel char(1),
    afactitiouslevel char(1),
    achangelevelnote lvarchar(4000),
    anursenote lvarchar(4000),
    afinallevel char(1),
    apainlevel decimal(2,0),
    aspecialcase "informix".boolean,
    adangerturn "informix".boolean,
    aepidemic "informix".boolean,
    aisreferral "informix".boolean,
    aisacute "informix".boolean,
    apicturedata text,
    apatientname varchar(30),
    apatientsex char(1),
    apatientage char(10),
    arpupilreaction decimal(3,1),
    arpupillreflection char(2),
    alpupilreaction decimal(3,1),
    alpupillreflection char(2),
    aregdeptid char(10),
    aprotectionname varchar(30),
    aroomno char(10),
    abedno char(10),
    acreatedate datetime year to second,
    acreateuserid char(10),
    amodifydate datetime year to second,
    amodifyuserid char(10),
    acreatehospitalid char(10),
    atakedrug varchar(160),
    primary key (ahospitalid,atriageid,atriagetimes) 
  );

revoke all on "informix".eotrtriage from "public" as "informix";

{ TABLE "informix".uddmr row size = 21 number of columns = 5 index size = 18 }

create table "informix".uddmr 
  (
    dpm_no serial not null ,
    vsn integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (dpm_no) 
  );

revoke all on "informix".uddmr from "public" as "informix";

{ TABLE "informix".uddid row size = 49 number of columns = 11 index size = 39 }

create table "informix".uddid 
  (
    det_no serial not null ,
    dpm_no integer not null ,
    lnk_no integer not null ,
    seq_no smallint not null ,
    tsc char(1) not null ,
    dpm_man integer not null ,
    dpm_tim datetime year to minute not null ,
    cfm_man integer not null ,
    cfm_tim datetime year to minute not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (det_no) 
  );

revoke all on "informix".uddid from "public" as "informix";

{ TABLE "informix".moowvr row size = 49 number of columns = 8 index size = 36 }

create table "informix".moowvr 
  (
    ser_no serial not null ,
    ord_no integer not null ,
    itm_no integer not null ,
    acc_no integer not null ,
    tsc char(1) not null ,
    mrk char(20) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".moowvr from "public" as "informix";

{ TABLE "informix".moowvrl row size = 61 number of columns = 10 index size = 31 }

create table "informix".moowvrl 
  (
    log_no serial not null ,
    log_tim datetime year to second 
        default current year to second not null ,
    ser_no integer not null ,
    ord_no integer not null ,
    itm_no integer not null ,
    acc_no integer not null ,
    tsc char(1) not null ,
    mrk char(20) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".moowvrl from "public" as "informix";

{ TABLE "informix".osdcdb row size = 45 number of columns = 8 index size = 38 }

create table "informix".osdcdb 
  (
    dcd_no serial not null ,
    doctor integer not null ,
    nhi_cod char(12) not null ,
    icd_cod char(8) not null ,
    qut_cnt integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (dcd_no) 
  );

revoke all on "informix".osdcdb from "public" as "informix";

{ TABLE "informix".exexec2 row size = 34 number of columns = 8 index size = 19 }

create table "informix".exexec2 
  (
    rec_no serial not null ,
    evt_num integer not null ,
    typ char(1) not null ,
    eff_tim datetime year to second 
        default current year to second not null ,
    emp_no integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".exexec2 from "public" as "informix";

{ TABLE "informix".exexec row size = 103 number of columns = 8 index size = 18 }

create table "informix".exexec 
  (
    ser_no serial not null ,
    evt_num integer not null ,
    ord_no integer 
        default 0 not null ,
    tc1 char(1) 
        default '0' not null ,
    tc2 char(1) 
        default '' not null ,
    ane_typ char(1) not null ,
    cmt char(80) 
        default '' not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".exexec from "public" as "informix";

{ TABLE "informix".dgpobs row size = 263 number of columns = 18 index size = 22 }

create table "informix".dgpobs 
  (
    set_no serial not null ,
    typ char(2) not null ,
    eff_tim datetime year to second not null ,
    stp_tim datetime year to second not null ,
    hsp_no char(1) not null ,
    set_flg1 char(10) not null ,
    set_flg2 char(10) not null ,
    set_flg3 char(10) not null ,
    set_flg4 char(10) not null ,
    set_flg5 char(10) not null ,
    set_flg6 char(10) not null ,
    set_flg7 char(10) not null ,
    set_flg8 char(10) not null ,
    set_flg9 char(10) not null ,
    set_flg10 char(10) not null ,
    dsc char(128) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (set_no) 
  );

revoke all on "informix".dgpobs from "public" as "informix";

{ TABLE "informix".cgcar row size = 105 number of columns = 13 index size = 88 }

create table "informix".cgcar 
  (
    car_no serial not null ,
    frm_typ char(3) not null ,
    lnk_num char(20) not null ,
    chg_typ smallint not null ,
    org_no char(10) not null ,
    org_nam char(40) not null ,
    sou_amt integer not null ,
    eff_dat date not null ,
    upy_amt integer not null ,
    close_acc char(1) not null ,
    comp_acc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (car_no) 
  );

revoke all on "informix".cgcar from "public" as "informix";

{ TABLE "informix".moctb row size = 122 number of columns = 7 index size = 18 }

create table "informix".moctb 
  (
    bmk_no serial not null ,
    emp_no integer not null ,
    seq_no smallint not null ,
    nam char(100) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to minute not null ,
    primary key (bmk_no) 
  );

revoke all on "informix".moctb from "public" as "informix";

{ TABLE "informix".mocti row size = 140 number of columns = 9 index size = 18 }

create table "informix".mocti 
  (
    itm_no serial not null ,
    bmk_no integer not null ,
    seq_no smallint not null ,
    tbl_nam char(8) not null ,
    itm char(10) not null ,
    nam char(100) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to minute not null ,
    primary key (itm_no) 
  );

revoke all on "informix".mocti from "public" as "informix";

{ TABLE "informix".rgdrcdie row size = 47 number of columns = 9 index size = 33 }

create table "informix".rgdrcdie 
  (
    rd_no serial not null ,
    typ char(2) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    dsp_nam char(10) not null ,
    tsc char(1) not null ,
    typ_lnk integer not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rd_no) 
  );

revoke all on "informix".rgdrcdie from "public" as "informix";

{ TABLE "informix".moiolog2 row size = 25 number of columns = 7 index size = 18 }

create table "informix".moiolog2 
  (
    log_num serial not null ,
    fun_no char(4) not null ,
    lnk_num integer not null ,
    emp_no smallint not null ,
    loc_no smallint not null ,
    log_sts char(1) not null ,
    log_tim datetime year to second 
        default current year to second not null ,
    primary key (log_num) 
  );

revoke all on "informix".moiolog2 from "public" as "informix";

{ TABLE "informix".moiolog3 row size = 25 number of columns = 7 index size = 18 }

create table "informix".moiolog3 
  (
    log_num serial not null ,
    fun_no char(4) not null ,
    lnk_num integer not null ,
    emp_no smallint not null ,
    loc_no smallint not null ,
    log_sts char(1) not null ,
    log_tim datetime year to second 
        default current year to second not null ,
    primary key (log_num) 
  );

revoke all on "informix".moiolog3 from "public" as "informix";

{ TABLE "informix".moiolog4 row size = 25 number of columns = 7 index size = 18 }

create table "informix".moiolog4 
  (
    log_num serial not null ,
    fun_no char(4) not null ,
    lnk_num integer not null ,
    emp_no smallint not null ,
    loc_no smallint not null ,
    log_sts char(1) not null ,
    log_tim datetime year to second 
        default current year to second not null ,
    primary key (log_num) 
  );

revoke all on "informix".moiolog4 from "public" as "informix";

{ TABLE "informix".moiolog5 row size = 25 number of columns = 7 index size = 35 }

create table "informix".moiolog5 
  (
    log_num serial not null ,
    fun_no char(4) not null ,
    lnk_num integer not null ,
    emp_no smallint not null ,
    loc_no smallint not null ,
    log_sts char(1) not null ,
    log_tim datetime year to second 
        default current year to second not null ,
    primary key (log_num) 
  );

revoke all on "informix".moiolog5 from "public" as "informix";

{ TABLE "informix".padscg row size = 37 number of columns = 7 index size = 35 }

create table "informix".padscg 
  (
    scg_no serial not null ,
    crt_dat date not null ,
    grp_no char(12) not null ,
    ord_no integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (scg_no) 
  );

revoke all on "informix".padscg from "public" as "informix";

{ TABLE "informix".mrpnie row size = 24 number of columns = 7 index size = 27 }

create table "informix".mrpnie 
  (
    pbe_no serial not null ,
    chart integer not null ,
    clm_typ char(3) not null ,
    val integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (pbe_no) 
  );

revoke all on "informix".mrpnie from "public" as "informix";

{ TABLE "informix".uddtg row size = 18 number of columns = 5 index size = 9 }

create table "informix".uddtg 
  (
    grp_no serial not null ,
    typ char(1) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (grp_no) 
  );

revoke all on "informix".uddtg from "public" as "informix";

{ TABLE "informix".udded row size = 38 number of columns = 9 index size = 39 }

create table "informix".udded 
  (
    det_no serial not null ,
    grp_no integer not null ,
    lnk_no integer not null ,
    seq_no smallint not null ,
    tsc char(1) not null ,
    exe_man integer not null ,
    exe_tim datetime year to minute not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (det_no) 
  );

revoke all on "informix".udded from "public" as "informix";

{ TABLE "informix".moaar row size = 84 number of columns = 8 index size = 34 }

create table "informix".moaar 
  (
    aar_no serial not null ,
    ord_no integer not null ,
    itm_typ char(3) not null ,
    tsc char(1) not null ,
    rpt text,
    rpt_dat date 
        default today not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (aar_no) 
  );

revoke all on "informix".moaar from "public" as "informix";

{ TABLE "informix".mopspf row size = 68 number of columns = 11 index size = 39 }

create table "informix".mopspf 
  (
    pf_no serial not null ,
    emp_no integer not null ,
    fun_no char(4) not null ,
    atr_no integer not null ,
    atr_val varchar(20) not null ,
    eff_tim datetime year to second not null ,
    stp_tim datetime year to second not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    rtl smallint not null ,
    primary key (pf_no) 
  );

revoke all on "informix".mopspf from "public" as "informix";

{ TABLE "informix".moarf row size = 332 number of columns = 9 index size = 30 }

create table "informix".moarf 
  (
    atr_no serial not null ,
    atr_nam varchar(40) not null ,
    msg varchar(255) not null ,
    eff_tim datetime year to second not null ,
    stp_tim datetime year to second not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    rtl smallint not null ,
    primary key (atr_no) 
  );

revoke all on "informix".moarf from "public" as "informix";

{ TABLE "informix".mosrpt row size = 84 number of columns = 8 index size = 43 }

create table "informix".mosrpt 
  (
    srp_no serial not null ,
    ord_no integer not null ,
    itm_typ char(3) not null ,
    tsc char(1) not null ,
    rpt text,
    rpt_dat date 
        default today not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (srp_no) 
  );

revoke all on "informix".mosrpt from "public" as "informix";

{ TABLE "informix".dgmrkl row size = 1330 number of columns = 18 index size = 48 }

create table "informix".dgmrkl 
  (
    rec_no serial not null ,
    lnk_num integer not null ,
    seq_no smallint not null ,
    typ char(2) not null ,
    tsc char(1) not null ,
    sts char(1) not null ,
    rsn char(1) 
        default '' not null ,
    rsn_dsc char(200) 
        default '' not null ,
    sym char(80) 
        default '' not null ,
    sym_dsc char(500) 
        default '' not null ,
    lev_sev char(1) 
        default '' not null ,
    dat_so char(2) 
        default '' not null ,
    so_dsc char(500) 
        default '' not null ,
    mrk_man integer 
        default 0 not null ,
    mrk_tim datetime year to second 
        default current year to second not null ,
    up_tim datetime year to second 
        default current year to second not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".dgmrkl from "public" as "informix";

{ TABLE "informix".cgnhded row size = 46 number of columns = 12 index size = 23 }

create table "informix".cgnhded 
  (
    ded_no serial not null ,
    typ char(1) not null ,
    amt_min integer not null ,
    amt_max integer not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    rf_amt integer not null ,
    nrf_amt integer not null ,
    snf_amt integer 
        default 0 not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ded_no) 
  );

revoke all on "informix".cgnhded from "public" as "informix";

{ TABLE "informix".motxt2 row size = 1109 number of columns = 13 index size = 45 }

create table "informix".motxt2 
  (
    ser_no serial not null ,
    ord_no integer not null ,
    chart integer not null ,
    sub varchar(255),
    obj varchar(255),
    ass varchar(255),
    cmt varchar(255),
    rpt_man integer 
        default 0 not null ,
    rpt_dat date 
        default  '1899/12/31' not null ,
    rpt_hm smallint 
        default 0 not null ,
    rpt_typ char(4) 
        default '' not null ,
    txt_typ char(3) 
        default '' not null ,
    rpt text,
    primary key (ser_no) 
  );

revoke all on "informix".motxt2 from "public" as "informix";

{ TABLE "informix".ordie row size = 54 number of columns = 7 index size = 18 }

create table "informix".ordie 
  (
    ode_no serial not null ,
    ord_no integer not null ,
    typ char(3) not null ,
    val char(30) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ode_no) 
  );

revoke all on "informix".ordie from "public" as "informix";

{ TABLE "informix".padscm row size = 172 number of columns = 10 index size = 18 }

create table "informix".padscm 
  (
    pal_no serial not null ,
    ord_no integer not null ,
    frm_no integer 
        default 0 not null ,
    seq_no smallint not null ,
    tse_sit char(3) 
        default '' not null ,
    tsc char(1),
    oth_tis varchar(100),
    cmt varchar(40),
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (pal_no) 
  );

revoke all on "informix".padscm from "public" as "informix";

{ TABLE "informix".dtptvet row size = 26 number of columns = 6 index size = 16 }

create table "informix".dtptvet 
  (
    evt_no serial not null ,
    chart integer not null ,
    visit_no decimal(11,0),
    typ char(2) 
        default 'A1' not null ,
    tsc char(1) 
        default 'W' not null ,
    rtt datetime year to second not null 
  );

revoke all on "informix".dtptvet from "public" as "informix";

{ TABLE "informix".capmcr row size = 157 number of columns = 11 index size = 18 }

create table "informix".capmcr 
  (
    pmc_no serial not null ,
    cnr_no integer not null ,
    rec_dat datetime year to second not null ,
    seq_no smallint not null ,
    rea_typ char(2) not null ,
    rea_oth char(120) not null ,
    dr_no integer not null ,
    emp_no integer not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (pmc_no) 
  );

revoke all on "informix".capmcr from "public" as "informix";

{ TABLE "informix".cgroompd row size = 49 number of columns = 10 index size = 35 }

create table "informix".cgroompd 
  (
    ser_no serial not null ,
    class char(1) not null ,
    rank char(1) not null ,
    eff_dat date not null ,
    fee_cod char(15) not null ,
    amt integer not null ,
    cod char(7) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".cgroompd from "public" as "informix";

{ TABLE "informix".cgroompm row size = 90 number of columns = 8 index size = 33 }

create table "informix".cgroompm 
  (
    ser_no serial not null ,
    fee_cod char(15) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    fee_nam char(50) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".cgroompm from "public" as "informix";

{ TABLE "informix".dgpcf row size = 60 number of columns = 8 index size = 31 }

create table "informix".dgpcf 
  (
    pcf_no serial not null ,
    drug_cod char(7) not null ,
    m_typ char(3) not null ,
    s_typ char(7) not null ,
    val char(30) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (pcf_no) 
  );

revoke all on "informix".dgpcf from "public" as "informix";

{ TABLE "informix".mosbldd row size = 34 number of columns = 9 index size = 45 }

create table "informix".mosbldd 
  (
    ser_no serial not null ,
    chart integer not null ,
    pre_chart integer not null ,
    pre_vsn integer not null ,
    lnk_no integer not null ,
    tsc char(1) not null ,
    lab_rpt char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".mosbldd from "public" as "informix";

{ TABLE "informix".moblddbb row size = 25 number of columns = 6 index size = 27 }

create table "informix".moblddbb 
  (
    ser_no serial not null ,
    lnk_no integer not null ,
    bpd_n integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".moblddbb from "public" as "informix";

{ TABLE "informix".estmmf row size = 89 number of columns = 11 index size = 22 }

create table "informix".estmmf 
  (
    ser_no serial not null ,
    itm_no char(3) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    typ char(1) not null ,
    pp_typ char(2) not null ,
    pp_no char(7) not null ,
    tsc char(1) not null ,
    remark varchar(50),
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".estmmf from "public" as "informix";

{ TABLE "informix".morrd row size = 34 number of columns = 9 index size = 43 }

create table "informix".morrd 
  (
    rec_no serial not null ,
    std_no integer not null ,
    tch_no integer not null ,
    typ char(1) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".morrd from "public" as "informix";

{ TABLE "informix".dgdped row size = 612 number of columns = 13 index size = 257 }

create table "informix".dgdped 
  (
    ser_no serial not null ,
    license_no char(10) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    pre_lab char(100) not null ,
    ing_nam char(200) not null ,
    ing_cod char(11) not null ,
    con_desc char(200) not null ,
    content char(10) not null ,
    con_unit char(50) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".dgdped from "public" as "informix";

{ TABLE "informix".dgfsob row size = 553 number of columns = 11 index size = 446 }

create table "informix".dgfsob 
  (
    ser_no serial not null ,
    license_no char(10) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    ch_nam char(200) not null ,
    en_nam char(200) not null ,
    fs_lnk text not null ,
    ob_lnk text not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".dgfsob from "public" as "informix";

{ TABLE "informix".dglnd row size = 2863 number of columns = 34 index size = 246 }

create table "informix".dglnd 
  (
    ser_no serial not null ,
    license_no char(10) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    lt_sts char(6) not null ,
    lt_dat date not null ,
    lt_rsn char(500) not null ,
    eff_dat date not null ,
    isd_dat date not null ,
    typ char(8) not null ,
    old_ls char(10) not null ,
    cus_num char(14) not null ,
    ch_nam char(200) not null ,
    en_nam char(200) not null ,
    indicat text not null ,
    dos_typ char(30) not null ,
    package char(500) not null ,
    drug_typ char(80) not null ,
    ctl_lv char(20) not null ,
    prin_com text not null ,
    app_nam char(60) not null ,
    app_ads char(100) not null ,
    app_num char(10) not null ,
    manu_nam char(100) not null ,
    manu_site char(100) not null ,
    manu_ads char(100) not null ,
    manu_cty char(20) not null ,
    process char(80) not null ,
    chg_dat date not null ,
    usg_dos text not null ,
    pack_bar char(500) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".dglnd from "public" as "informix";

{ TABLE "informix".dglned row size = 847 number of columns = 18 index size = 36 }

create table "informix".dglned 
  (
    ser_no serial not null ,
    license_no char(10) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    ch_nam char(200) not null ,
    en_nam char(200) not null ,
    shape char(10) not null ,
    sp_dos char(10) not null ,
    color char(20) not null ,
    sp_sme char(20) not null ,
    notches char(6) not null ,
    phy_dim char(80) not null ,
    lab1 char(30) not null ,
    lab2 char(30) not null ,
    phy_lnk char(200) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".dglned from "public" as "informix";

{ TABLE "informix".dgpcatc row size = 1053 number of columns = 11 index size = 51 }

create table "informix".dgpcatc 
  (
    ser_no serial not null ,
    license_no char(10) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    itm char(2) not null ,
    cod char(10) not null ,
    en_nam char(500) not null ,
    ch_nam char(500) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".dgpcatc from "public" as "informix";

{ TABLE "informix".rgdrl row size = 94 number of columns = 10 index size = 31 }

create table "informix".rgdrl 
  (
    rl_no serial not null ,
    typ char(1) not null ,
    lnk_no integer not null ,
    dsc text not null ,
    lang char(2) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rl_no) 
  );

revoke all on "informix".rgdrl from "public" as "informix";

{ TABLE "informix".rgdrc row size = 536 number of columns = 10 index size = 31 }

create table "informix".rgdrc 
  (
    rc_no serial not null ,
    typ char(1) not null ,
    lnk_no integer not null ,
    bet char(250) not null ,
    aft char(250) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rc_no) 
  );

revoke all on "informix".rgdrc from "public" as "informix";

{ TABLE "informix".mrrst row size = 31 number of columns = 9 index size = 32 }

create table "informix".mrrst 
  (
    sub_no serial not null ,
    vsn integer not null ,
    sub_yymm char(5) not null ,
    dct_no integer not null ,
    sub_sts char(1) not null ,
    frm char(1) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to minute not null ,
    primary key (sub_no) 
  );

revoke all on "informix".mrrst from "public" as "informix";

{ TABLE "informix".bmdie row size = 49 number of columns = 7 index size = 18 }

create table "informix".bmdie 
  (
    bde_no serial not null ,
    acc_no integer not null ,
    clm_typ char(2) not null ,
    val char(30) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (bde_no) 
  );

revoke all on "informix".bmdie from "public" as "informix";

{ TABLE "informix".hcwcupl row size = 29 number of columns = 6 index size = 31 }

create table "informix".hcwcupl 
  (
    ser_no serial not null ,
    ccd_no integer not null ,
    wrt_tim datetime year to second not null ,
    tsc char(1) 
        default 'N' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no) 
  );

revoke all on "informix".hcwcupl from "public" as "informix";

{ TABLE "informix".cgqecdl row size = 284 number of columns = 8 index size = 27 }

create table "informix".cgqecdl 
  (
    cdl_no serial not null ,
    trn_no integer not null ,
    sou_typ char(3) not null ,
    lnk_no integer not null ,
    tsc char(1) 
        default 'A' not null ,
    coment varchar(255),
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (cdl_no) 
  );

revoke all on "informix".cgqecdl from "public" as "informix";

{ TABLE "informix".mocmd row size = 65 number of columns = 10 index size = 35 }

create table "informix".mocmd 
  (
    cmd_no serial not null ,
    lnk_no integer not null ,
    frm char(1) not null ,
    func_no char(4) not null ,
    clm_typ char(3) not null ,
    val char(30) not null ,
    tsc char(1) not null ,
    stp_tim datetime year to minute not null ,
    rtp integer not null ,
    rtt datetime year to minute not null ,
    primary key (cmd_no)  constraint "informix".i1_mocmd
  );

revoke all on "informix".mocmd from "public" as "informix";

{ TABLE "informix".bmpvt row size = 35 number of columns = 8 index size = 18 }

create table "informix".bmpvt 
  (
    pvt_no serial not null ,
    acc_no integer not null ,
    room char(4) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (pvt_no)  constraint "informix".i1_bmpvt
  );

revoke all on "informix".bmpvt from "public" as "informix";

{ TABLE "informix".rgdrcd row size = 114 number of columns = 12 index size = 51 }

create table "informix".rgdrcd 
  (
    rc_no serial not null ,
    typ char(1) not null ,
    apr_typ char(1) not null ,
    lnk_no integer not null ,
    sft char(1) not null ,
    rul_cod char(20) not null ,
    dsc text not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rc_no)  constraint "informix".i1_rgdrcd
  );

revoke all on "informix".rgdrcd from "public" as "informix";

{ TABLE "informix".cgoscm row size = 36 number of columns = 9 index size = 37 }

create table "informix".cgoscm 
  (
    osc_no serial not null ,
    lnk_no char(10) not null ,
    lnk_typ char(2) not null ,
    charg_amt integer not null ,
    cash integer not null ,
    rtp integer not null ,
    rtd date not null ,
    rthm smallint not null ,
    rtl smallint not null ,
    primary key (osc_no)  constraint "informix".i1_cgoscm
  );

revoke all on "informix".cgoscm from "public" as "informix";

{ TABLE "informix".cgoscd row size = 52 number of columns = 9 index size = 18 }

create table "informix".cgoscd 
  (
    det_no serial not null ,
    osc_no integer not null ,
    typ smallint not null ,
    amt integer not null ,
    bill_c char(2) not null ,
    bill_n char(20) not null ,
    sheet_c char(2) not null ,
    sheet_n char(10) not null ,
    due_dat date,
    primary key (det_no)  constraint "informix".i1_cgoscd
  );

revoke all on "informix".cgoscd from "public" as "informix";

{ TABLE "informix".tcmsnc row size = 31 number of columns = 6 index size = 33 }

create table "informix".tcmsnc 
  (
    his_vsn serial not null ,
    his_id char(10) not null ,
    tsc char(1) not null ,
    his_dat date not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (his_vsn)  constraint "informix".i1_tcmsnc
  );

revoke all on "informix".tcmsnc from "public" as "informix";

{ TABLE "informix".rfpar row size = 56 number of columns = 9 index size = 34 }

create table "informix".rfpar 
  (
    evt_no serial not null ,
    vsn integer not null ,
    act_typ char(3) not null ,
    val char(20) not null ,
    act_man integer not null ,
    tsc char(1) not null ,
    act_tim datetime year to second not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (evt_no)  constraint "informix".i1_rfpar
  );

revoke all on "informix".rfpar from "public" as "informix";

{ TABLE "informix".osdugdff row size = 331 number of columns = 18 index size = 27 }

create table "informix".osdugdff 
  (
    det_no serial not null ,
    lnk_no integer not null ,
    typ char(2) not null ,
    item_cod char(7) not null ,
    tsc char(1) not null ,
    loc smallint not null ,
    usag char(20) not null ,
    tot_qty char(5) not null ,
    self_qty char(5) not null ,
    emg char(1) not null ,
    self char(1) not null ,
    chg char(1) not null ,
    prm_no integer not null ,
    map_no smallint not null ,
    adv varchar(255) not null ,
    icr_no integer not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (det_no)  constraint "informix".i1_osdugdff
  );

revoke all on "informix".osdugdff from "public" as "informix";

{ TABLE "informix".dgdbicr row size = 321 number of columns = 16 index size = 31 }

create table "informix".dgdbicr 
  (
    icr_no serial not null ,
    bmr_no integer not null ,
    chg_cod char(7) not null ,
    tsc char(1) not null ,
    loc smallint not null ,
    usag char(20) not null ,
    qty_tot char(5) not null ,
    qty_prc integer not null ,
    self char(1) 
        default '' not null ,
    adv varchar(255) 
        default ' ' not null ,
    lng_mrk char(1) 
        default '' not null ,
    lmp_typ char(1) not null ,
    lmp_no smallint not null ,
    bag_prn char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (icr_no)  constraint "informix".i1_dgdbicr
  );

revoke all on "informix".dgdbicr from "public" as "informix";

{ TABLE "informix".pbatl row size = 39 number of columns = 8 index size = 15 }

create table "informix".pbatl 
  (
    dat date not null ,
    hpt_loc char(1) 
        default '1' not null ,
    typ1 char(2) not null ,
    itm char(3) not null ,
    val char(20) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (dat,hpt_loc,typ1,itm)  constraint "informix".i1_pbatl
  );

revoke all on "informix".pbatl from "public" as "informix";

{ TABLE "informix".momblog row size = 85 number of columns = 9 index size = 33 }

create table "informix".momblog 
  (
    log_num serial not null ,
    fun_typ char(4) not null ,
    typ char(2) not null ,
    lnk_num integer not null ,
    log_sts char(1) not null ,
    log_txt text not null ,
    emp_no integer not null ,
    loc_no smallint not null ,
    log_tim datetime year to second 
        default current year to second not null ,
    primary key (log_num)  constraint "informix".i1_momblog
  );

revoke all on "informix".momblog from "public" as "informix";

{ TABLE "informix".osdugitm row size = 338 number of columns = 20 index size = 27 }

create table "informix".osdugitm 
  (
    itm_no serial not null ,
    lnk_no integer not null ,
    typ char(2) not null ,
    item_cod char(7) not null ,
    loc smallint not null ,
    usag char(20) not null ,
    tot_qty char(5) not null ,
    self_qty char(5) not null ,
    emg char(1) not null ,
    self char(1) not null ,
    chg char(1) not null ,
    prm_no integer not null ,
    map_no smallint not null ,
    adv varchar(255) not null ,
    bag_prn char(1) not null ,
    del_rec_no integer not null ,
    lamp_no char(6) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (itm_no)  constraint "informix".i1_osdugitm
  );

revoke all on "informix".osdugitm from "public" as "informix";

{ TABLE "informix".rgldie row size = 119 number of columns = 7 index size = 18 }

create table "informix".rgldie 
  (
    rde_no serial not null ,
    clm_typ char(2) not null ,
    rd_no integer not null ,
    val char(100) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rde_no)  constraint "informix".i1_rgldie
  );

revoke all on "informix".rgldie from "public" as "informix";

{ TABLE "informix".cgipar row size = 43 number of columns = 9 index size = 34 }

create table "informix".cgipar 
  (
    evt_no serial not null ,
    evt_num integer not null ,
    item_cod char(7) not null ,
    eff_dat date not null ,
    dpt_typ char(2) not null ,
    rec_man integer not null ,
    rec_tim datetime year to minute not null ,
    rev_man integer not null ,
    rev_tim datetime year to minute not null ,
    primary key (evt_no)  constraint "informix".i1_cgipar
  );

revoke all on "informix".cgipar from "public" as "informix";

{ TABLE "informix".dgoutitm row size = 661 number of columns = 23 index size = 38 }

create table "informix".dgoutitm 
  (
    ser_no serial not null ,
    mst_no integer not null ,
    chg_cod char(7) not null ,
    dos_qty char(5) 
        default '' not null ,
    dos_unt char(5) 
        default '' not null ,
    usg char(30) not null ,
    acpc char(4) 
        default '' not null ,
    route char(4) 
        default '' not null ,
    tot_qty char(6) not null ,
    self_qty char(6) not null ,
    days char(3) not null ,
    unit char(4) not null ,
    tot char(8) not null ,
    self_tot char(8) not null ,
    mrk char(1) 
        default '' not null ,
    adv varchar(255) 
        default ' ' not null ,
    desc varchar(255) 
        default ' ' not null ,
    lngd char(2) 
        default '' not null ,
    dg_tsc char(2) not null ,
    lot_num char(30),
    loc integer,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no)  constraint "informix".i1_dgoutitm
  );

revoke all on "informix".dgoutitm from "public" as "informix";

{ TABLE "informix".dgoutmst row size = 75 number of columns = 17 index size = 85 }

create table "informix".dgoutmst 
  (
    mst_no serial not null ,
    vsn integer not null ,
    dug_dat date not null ,
    fil1 char(1) not null ,
    lmp_typ char(1) not null ,
    lmp_no integer not null ,
    bmr_no integer not null ,
    ord_typ integer not null ,
    ord_lnk_no integer not null ,
    tsc char(1) not null ,
    ord_tim datetime year to second,
    chg_tim datetime year to second,
    out_tim datetime year to second,
    emp_man integer,
    loc_no integer not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (mst_no)  constraint "informix".i1_dgoutmst
  );

revoke all on "informix".dgoutmst from "public" as "informix";

{ TABLE "informix".paabr row size = 184 number of columns = 9 index size = 32 }

create table "informix".paabr 
  (
    ser_no serial not null ,
    pal_no integer not null ,
    typ char(1) not null ,
    val char(150) not null ,
    tsc char(1) not null ,
    rec_tim datetime year to second not null ,
    rec_man integer not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no)  constraint "informix".i1_paabr
  );

revoke all on "informix".paabr from "public" as "informix";

{ TABLE "informix".mosoahfd row size = 126 number of columns = 9 index size = 20 }

create table "informix".mosoahfd 
  (
    itm_no serial not null ,
    own_no char(5) not null ,
    typ char(1) not null ,
    frm_no integer not null ,
    nam varchar(100),
    seq_no smallint not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date 
        default today not null ,
    primary key (itm_no)  constraint "informix".i1_mosoahfd
  );

revoke all on "informix".mosoahfd from "public" as "informix";

{ TABLE "informix".mormr row size = 2041 number of columns = 10 index size = 53 }

create table "informix".mormr 
  (
    rec_no serial not null ,
    lnk_no integer not null ,
    ret_man integer not null ,
    rcv_man integer not null ,
    typ char(3) not null ,
    rsn lvarchar(2000) not null ,
    tsc char(1) not null ,
    ret_tim datetime year to minute not null ,
    rtp integer not null ,
    rtt datetime year to minute not null ,
    primary key (rec_no) 
  );

revoke all on "informix".mormr from "public" as "informix";

{ TABLE "informix".cgbdar row size = 57 number of columns = 14 index size = 35 }

create table "informix".cgbdar 
  (
    apv_no serial not null ,
    lnk_typ char(2) not null ,
    lnk_no integer not null ,
    apl_man integer not null ,
    apl_tim datetime year to second 
        default current year to second not null ,
    apl_typ char(1) not null ,
    tsc char(1) not null ,
    pre_eff_dat date not null ,
    pre_stp_dat date not null ,
    apv_man integer not null ,
    apv_tim datetime year to second 
        default  datetime (2025-12-31 23:59:59) year to second not null ,
    apv_rlt char(1) 
        default '' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (apv_no)  constraint "informix".i1_cgbdar
  );

revoke all on "informix".cgbdar from "public" as "informix";

{ TABLE "informix".smrf row size = 253 number of columns = 13 index size = 62 }

create table "informix".smrf 
  (
    sed_no serial not null ,
    apl_man integer not null ,
    tel_no integer not null ,
    msg char(200) not null ,
    sed_tim datetime year to second not null ,
    chart integer not null ,
    lnk_no integer not null ,
    lnk_typ char(1) not null ,
    apl_tim datetime year to minute not null ,
    apl_loc integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (sed_no)  constraint "informix".i1_smrf
  );

revoke all on "informix".smrf from "public" as "informix";

{ TABLE "informix".dgdipr row size = 50 number of columns = 11 index size = 42 }

create table "informix".dgdipr 
  (
    rec_no serial not null ,
    det_no integer not null ,
    sdr_man smallint not null ,
    sdr_tim datetime year to minute not null ,
    sbd_no integer not null ,
    bar_tim datetime year to minute not null ,
    cfm_sts char(1) 
        default '' not null ,
    cfm_man smallint not null ,
    cfm_tim datetime year to minute not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (rec_no)  constraint "informix".i1_dgdipr
  );

revoke all on "informix".dgdipr from "public" as "informix";

{ TABLE "informix".moomm row size = 47 number of columns = 10 index size = 20 }

create table "informix".moomm 
  (
    mst_no serial not null ,
    lnk_no integer not null ,
    seq_no smallint not null ,
    fun_typ char(3) not null ,
    typ char(10) not null ,
    tsc char(1) not null ,
    rec_tim datetime year to minute not null ,
    rec_man integer not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (mst_no)  constraint "informix".i1_moomm
  );

revoke all on "informix".moomm from "public" as "informix";

{ TABLE "informix".moomd row size = 13 number of columns = 4 index size = 18 }

create table "informix".moomd 
  (
    dtl_no serial not null ,
    mst_no integer not null ,
    itm_no integer not null ,
    itm_sts char(1) not null ,
    primary key (dtl_no)  constraint "informix".i1_moomd
  );

revoke all on "informix".moomd from "public" as "informix";

{ TABLE "informix".moomdd row size = 12 number of columns = 3 index size = 18 }

create table "informix".moomdd 
  (
    dds_no serial not null ,
    itm_no integer not null ,
    dat date not null ,
    primary key (dds_no)  constraint "informix".i1_moomdd
  );

revoke all on "informix".moomdd from "public" as "informix";

{ TABLE "informix".moomlls row size = 308 number of columns = 3 index size = 18 }

create table "informix".moomlls 
  (
    lls_no serial not null ,
    itm_no integer not null ,
    oth_dsc char(300) not null ,
    primary key (lls_no)  constraint "informix".i1_moomlls
  );

revoke all on "informix".moomlls from "public" as "informix";

{ TABLE "informix".moomls row size = 128 number of columns = 3 index size = 18 }

create table "informix".moomls 
  (
    ols_no serial not null ,
    itm_no integer not null ,
    oth_dsc char(120) not null ,
    primary key (ols_no)  constraint "informix".i1_moomls
  );

revoke all on "informix".moomls from "public" as "informix";

{ TABLE "informix".moomss row size = 28 number of columns = 3 index size = 18 }

create table "informix".moomss 
  (
    oss_no serial not null ,
    itm_no integer not null ,
    oth_dsc char(20) not null ,
    primary key (oss_no)  constraint "informix".i1_moomss
  );

revoke all on "informix".moomss from "public" as "informix";

{ TABLE "informix".moomtr row size = 625 number of columns = 6 index size = 20 }

create table "informix".moomtr 
  (
    ser_no serial not null ,
    lnk_num integer not null ,
    seq_no smallint not null ,
    val lvarchar(600) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no)  constraint "informix".i1_moomtr
  );

revoke all on "informix".moomtr from "public" as "informix";

{ TABLE "informix".dgoutlot row size = 55 number of columns = 7 index size = 53 }

create table "informix".dgoutlot 
  (
    ser_no serial not null ,
    itm_no integer not null ,
    lot_num char(30) not null ,
    lot_qty integer not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ser_no)  constraint "informix".i1_dgoutlot
  );

revoke all on "informix".dgoutlot from "public" as "informix";

{ TABLE "informix".dgoutpar row size = 39 number of columns = 10 index size = 32 }

create table "informix".dgoutpar 
  (
    ser_no serial not null ,
    mst_no integer not null ,
    act_typ char(1) not null ,
    sts char(1) not null ,
    tsc char(1) 
        default 'A' not null ,
    act_man integer not null ,
    act_tim datetime year to second 
        default current year to second not null ,
    act_loc integer not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ser_no)  constraint "informix".i1_dgoutpar
  );

revoke all on "informix".dgoutpar from "public" as "informix";

{ TABLE "informix".pscontra row size = 47 number of columns = 8 index size = 22 }

create table "informix".pscontra 
  (
    ctt_no serial not null ,
    emp_no integer not null ,
    contra_no char(3) 
        default '' not null ,
    f_dat date not null ,
    t_dat date not null ,
    coment char(20) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (ctt_no)  constraint "informix".i1_pscontra
  );

revoke all on "informix".pscontra from "public" as "informix";

{ TABLE "informix".mopkgdif row size = 53 number of columns = 7 index size = 18 }

create table "informix".mopkgdif 
  (
    ser_no serial not null ,
    pkg_no integer not null ,
    clm_typ char(2) not null ,
    val char(30) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no)  constraint "informix".i1_mopkgdif
  );

revoke all on "informix".mopkgdif from "public" as "informix";

{ TABLE "informix".rgdsmn row size = 142 number of columns = 12 index size = 9 }

create table "informix".rgdsmn 
  (
    sd_no serial not null ,
    sd_frm_no integer not null ,
    nam char(50) not null ,
    typ char(1) not null ,
    lv_no smallint not null ,
    dsc char(50) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (sd_no)  constraint "informix".i1_rgdsmn
  );

revoke all on "informix".rgdsmn from "public" as "informix";

{ TABLE "informix".rgdrdn row size = 346 number of columns = 11 index size = 18 }

create table "informix".rgdrdn 
  (
    rd_no serial not null ,
    sd_no integer not null ,
    rd_frm_no integer not null ,
    typ char(1) not null ,
    rule text not null ,
    dsc char(250) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rd_no)  constraint "informix".i1_rgdrdn
  );

revoke all on "informix".rgdrdn from "public" as "informix";

{ TABLE "informix".rgdrcdn row size = 114 number of columns = 12 index size = 51 }

create table "informix".rgdrcdn 
  (
    rc_no serial not null ,
    typ char(1) not null ,
    apr_typ char(1) not null ,
    lnk_no integer not null ,
    sft char(1) not null ,
    rul_cod char(20) not null ,
    dsc text not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rc_no)  constraint "informix".i1_rgdrcdn
  );

revoke all on "informix".rgdrcdn from "public" as "informix";

{ TABLE "informix".pasamf row size = 173 number of columns = 15 index size = 24 }

create table "informix".pasamf 
  (
    psa_no serial not null ,
    pa_no char(10) not null ,
    src_loc char(1) not null ,
    oc_nam varchar(40),
    src_typ char(1) not null ,
    src_typ_ot varchar(40),
    afp_no integer not null ,
    afp_date date not null ,
    ischarg char(1) not null ,
    reason varchar(40),
    mt_no integer,
    pd_tim datetime year to second,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (psa_no)  constraint "informix".i1_pasamf
  );

revoke all on "informix".pasamf from "public" as "informix";

{ TABLE "informix".pasadf row size = 178 number of columns = 18 index size = 18 }

create table "informix".pasadf 
  (
    ser_no serial not null ,
    psa_no integer not null ,
    part char(3) not null ,
    ihc_no char(5) not null ,
    seq_no char(3) not null ,
    ihc_nam varchar(30) not null ,
    sr_i char(1) 
        default '',
    sr_p integer 
        default 0,
    sq_bc char(1) 
        default '',
    sq_oi char(1) 
        default '',
    ctrl_i char(1) 
        default '',
    ctrl_p integer 
        default 0,
    restain char(1) 
        default 'N',
    display char(1) 
        default 'Y',
    remark varchar(100),
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no)  constraint "informix".i1_pasadf
  );

revoke all on "informix".pasadf from "public" as "informix";

{ TABLE "informix".hcwcld row size = 56 number of columns = 8 index size = 23 }

create table "informix".hcwcld 
  (
    ser_no serial not null ,
    ccd_no integer not null ,
    seq_no smallint not null ,
    typ char(3) not null ,
    val char(30) not null ,
    tsc char(1) 
        default 'A' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no)  constraint "informix".i1_hcwcld
  );

revoke all on "informix".hcwcld from "public" as "informix";

{ TABLE "root".momdymrk row size = 228 number of columns = 8 index size = 21 }

create table "root".momdymrk 
  (
    mdy_no serial not null ,
    chart integer not null ,
    typ char(3) not null ,
    fun_typ char(4) not null ,
    val char(200) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (mdy_no)  constraint "root".i1_momdymrk
  );

revoke all on "root".momdymrk from "public" as "root";

{ TABLE "informix".moprnrsn row size = 35 number of columns = 7 index size = 34 }

create table "informix".moprnrsn 
  (
    rec_no serial not null ,
    vsn integer not null ,
    typ char(3) not null ,
    rsn char(10) not null ,
    emp_no integer not null ,
    loc_no smallint not null ,
    log_tim datetime year to second 
        default current year to second not null ,
    primary key (rec_no)  constraint "informix".i1_moprnrsn
  );

revoke all on "informix".moprnrsn from "public" as "informix";

{ TABLE "informix".moprnoth row size = 108 number of columns = 3 index size = 18 }

create table "informix".moprnoth 
  (
    oth_no serial not null ,
    rec_no integer not null ,
    dsc char(100) not null ,
    primary key (oth_no)  constraint "informix".i1_moprnoth
  );

revoke all on "informix".moprnoth from "public" as "informix";

{ TABLE "informix".moefrd row size = 14 number of columns = 5 index size = 28 }

create table "informix".moefrd 
  (
    det_no serial not null ,
    mst_no integer not null ,
    lnk_typ char(1) not null ,
    lnk_no integer not null ,
    sts char(1) 
        default '' not null ,
    primary key (det_no)  constraint "informix".i1_moefrd
  );

revoke all on "informix".moefrd from "public" as "informix";

{ TABLE "informix".moefrm row size = 49 number of columns = 7 index size = 34 }

create table "informix".moefrm 
  (
    mst_no serial not null ,
    frm_no char(20) not null ,
    sts char(1) 
        default '' not null ,
    rec_man integer not null ,
    rec_tim datetime year to second not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (mst_no)  constraint "informix".i1_moefrm
  );

revoke all on "informix".moefrm from "public" as "informix";

{ TABLE "informix".ntpsac row size = 71 number of columns = 12 index size = 18 }

create table "informix".ntpsac 
  (
    nt_no serial not null ,
    typ char(2) not null ,
    amt smallint not null ,
    bkt_amt smallint not null ,
    lnh_amt smallint not null ,
    dnr_amt smallint not null ,
    rules char(30) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (nt_no)  constraint "informix".i1_ntpsac
  );

revoke all on "informix".ntpsac from "public" as "informix";

{ TABLE "informix".hcextwcr row size = 316 number of columns = 13 index size = 61 }

create table "informix".hcextwcr 
  (
    ser_no serial not null ,
    typ char(1) not null ,
    his_id char(20) not null ,
    vsn integer not null ,
    chart integer not null ,
    his_dat date not null ,
    icc_ext char(10) not null ,
    icc_memo text not null ,
    icc_norm char(100),
    icc_abnorm char(100),
    tsc char(1) 
        default 'A' not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no)  constraint "informix".i1_hcextwcr
  );

revoke all on "informix".hcextwcr from "public" as "informix";

{ TABLE "informix".doolfm row size = 53 number of columns = 10 index size = 43 }

create table "informix".doolfm 
  (
    ser_no serial not null ,
    lev_no integer not null ,
    rel_no char(20) not null ,
    eff_dat date not null ,
    fhm smallint not null ,
    stp_dat date not null ,
    thm smallint not null ,
    sts char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no)  constraint "informix".i1_doolfm
  );

revoke all on "informix".doolfm from "public" as "informix";

{ TABLE "informix".monotm row size = 60 number of columns = 2 index size = 9 }

create table "informix".monotm 
  (
    not_no integer not null ,
    txt text
  );

revoke all on "informix".monotm from "public" as "informix";

{ TABLE "informix".cggtrd row size = 400 number of columns = 24 index size = 52 }

create table "informix".cggtrd 
  (
    grp_no serial not null ,
    grp_cod char(7) not null ,
    grp_typ char(1) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    detai_cod char(7) not null ,
    tsc char(1) not null ,
    det_typ char(2) not null ,
    seq_no integer not null ,
    slf_qty integer not null ,
    nhi_qty integer not null ,
    inc_itm char(1) not null ,
    sco_app char(1) not null ,
    nrs_mrk char(1) not null ,
    pre_sts char(1) not null ,
    rsn_dsc char(300) 
        default '' not null ,
    est_man integer not null ,
    est_tim datetime year to second not null ,
    rev_man integer not null ,
    rev_tim datetime year to second not null ,
    cfm_man integer not null ,
    cfm_tim datetime year to second not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (grp_no)  constraint "informix".i1_cggtrd
  );

revoke all on "informix".cggtrd from "public" as "informix";

{ TABLE "informix".cggtrdl row size = 412 number of columns = 26 index size = 29 }

create table "informix".cggtrdl 
  (
    log_no serial not null ,
    log_tim datetime year to second 
        default current year to second not null ,
    grp_no integer not null ,
    grp_cod char(7) not null ,
    grp_typ char(1) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    detai_cod char(7) not null ,
    tsc char(1) not null ,
    det_typ char(2) not null ,
    seq_no integer not null ,
    slf_qty integer not null ,
    nhi_qty integer not null ,
    inc_itm char(1) not null ,
    sco_app char(1) not null ,
    nrs_mrk char(1) not null ,
    pre_sts char(1) not null ,
    rsn_dsc char(300) 
        default '' not null ,
    est_man integer not null ,
    est_tim datetime year to second not null ,
    rev_man integer not null ,
    rev_tim datetime year to second not null ,
    cfm_man integer not null ,
    cfm_tim datetime year to second not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (log_no)  constraint "informix".i1_cggtrdl
  );

revoke all on "informix".cggtrdl from "public" as "informix";

{ TABLE "informix".dgdedf row size = 33 number of columns = 7 index size = 33 }

create table "informix".dgdedf 
  (
    ser_no serial not null ,
    cls_typ char(2) not null ,
    lnk_num integer not null ,
    val char(10) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no)  constraint "informix".i1_dgdedf
  );

revoke all on "informix".dgdedf from "public" as "informix";

{ TABLE "informix".dgtpdf row size = 944 number of columns = 16 index size = 24 }

create table "informix".dgtpdf 
  (
    itr_no serial not null ,
    srv_cod char(10) not null ,
    srv_typ char(1) not null ,
    tsc char(1) not null ,
    std_mrk char(300) not null ,
    adv char(300) not null ,
    oth_mrk char(300) not null ,
    com_tim integer not null ,
    irr_tim integer not null ,
    pur char(1) not null ,
    def_prm char(1) not null ,
    mon_frq integer not null ,
    mon_typ char(1) not null ,
    mon_prm char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (itr_no)  constraint "informix".i1_dgtpdf
  );

revoke all on "informix".dgtpdf from "public" as "informix";

{ TABLE "informix".moplr row size = 74 number of columns = 10 index size = 49 }

create table "informix".moplr 
  (
    rec_no serial not null ,
    id_no char(10) not null ,
    typ char(3) not null ,
    lnk_no integer not null ,
    rec_sts varchar(20) not null ,
    rec_man integer not null ,
    eff_tim datetime year to second not null ,
    stp_tim datetime year to second not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (rec_no) 
  );

revoke all on "informix".moplr from "public" as "informix";

{ TABLE "informix".dci10cnf row size = 1137 number of columns = 31 index size = 57 }

create table "informix".dci10cnf 
  (
    icd_cod char(12) not null ,
    typ char(2) not null ,
    nhi_cod char(9) not null ,
    eff_dat date not null ,
    stp_dat date not null ,
    tsc char(1) not null ,
    drg_cod char(5) not null ,
    qip_drg char(6) not null ,
    icd_ver char(10) not null ,
    nam_e char(255) not null ,
    nam_c char(255) not null ,
    icd_typ char(4) not null ,
    sru_mrk smallint not null ,
    ifq_mrk char(1) not null ,
    crn_mrk char(1) not null ,
    crn_typ char(6) not null ,
    con_mrk char(1) not null ,
    con_typ smallint not null ,
    sex_lmt char(1) not null ,
    dag_lmt char(1) not null ,
    spc_typ char(2) not null ,
    min_age smallint not null ,
    max_age smallint not null ,
    std_days smallint not null ,
    sru_lmt char(1) not null ,
    cmt char(255),
    mrk_1 char(12),
    mrk_2 char(12),
    mrk_3 char(255),
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (icd_cod,eff_dat)  constraint "informix".i1_dci10cnf
  );

revoke all on "informix".dci10cnf from "public" as "informix";

{ TABLE "informix".dcicdmf row size = 343 number of columns = 12 index size = 58 }

create table "informix".dcicdmf 
  (
    dci_no serial not null ,
    src_ver char(10) not null ,
    src_cod char(12) not null ,
    tgt_ver char(10) not null ,
    tgt_cod char(12) not null ,
    dfn_tag smallint not null ,
    mi_iht smallint not null ,
    cmt char(255),
    mrk_1 char(12),
    mrk_2 char(12),
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (dci_no)  constraint "informix".i1_dcicdmf
  );

revoke all on "informix".dcicdmf from "public" as "informix";

{ TABLE "informix".bmnurnum row size = 43 number of columns = 9 index size = 26 }

create table "informix".bmnurnum 
  (
    ser_no serial not null ,
    ward char(3) not null ,
    eff_tim datetime year to minute not null ,
    stp_tim datetime year to minute not null ,
    typ char(2) not null ,
    cnt integer not null ,
    apl_man integer not null ,
    rtp integer not null ,
    rtt datetime year to second not null ,
    primary key (ser_no)  constraint "informix".i1_bmnurnum
  );

revoke all on "informix".bmnurnum from "public" as "informix";

{ TABLE "informix".mormp row size = 80 number of columns = 7 index size = 31 }

create table "informix".mormp 
  (
    rrc_no serial not null ,
    fun_no char(4) not null ,
    lnk_no integer not null ,
    ver_no smallint 
        default 0 not null ,
    txt text,
    rtp smallint not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (rrc_no)  constraint "informix".i1_mormp
  );

revoke all on "informix".mormp from "public" as "informix";

{ TABLE "informix".oostsrcd row size = 57 number of columns = 9 index size = 24 }

create table "informix".oostsrcd 
  (
    ser_no serial not null ,
    visit_dat date not null ,
    sft char(1) not null ,
    room smallint not null ,
    sts_cod char(3) not null ,
    val char(30) not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtt datetime year to second 
        default current year to second not null ,
    primary key (ser_no)  constraint "informix".i1_oostsrcd
  );

revoke all on "informix".oostsrcd from "public" as "informix";

{ TABLE "informix".eodiel row size = 76 number of columns = 7 index size = 18 }

create table "informix".eodiel 
  (
    rde_no serial not null ,
    vsn integer not null ,
    clm_typ char(3) not null ,
    txt text not null ,
    tsc char(1) not null ,
    rtp integer not null ,
    rtd date not null ,
    primary key (rde_no)  constraint "informix".i1_eodiel
  );

revoke all on "informix".eodiel from "public" as "informix";

{ TABLE "dfe".test_chinese_no_key row size = 204 number of columns = 3 index size = 0 }

create table "dfe".test_chinese_no_key 
  (
    id integer,
    c char(100),
    remark char(100)
  );

revoke all on "dfe".test_chinese_no_key from "public" as "dfe";

{ TABLE "informix".cmspr_2 row size = 81 number of columns = 17 index size = 9 }

create table "informix".cmspr_2 
  (
    spr_no serial not null ,
    lnk_no integer not null ,
    frm char(1) not null ,
    cir_no integer not null ,
    spr_typ char(1) not null ,
    eva_no integer not null ,
    eff_man smallint not null ,
    eff_tim datetime year to minute not null ,
    spr_sts char(2) not null ,
    spr_man smallint,
    spr_tim datetime year to minute,
    pre_cnt smallint not null ,
    pre_nam char(12) not null ,
    pre_tim datetime year to minute not null ,
    pre_dtr char(12) not null ,
    rtp smallint not null ,
    rtt datetime year to second not null ,
    primary key (spr_no) 
  );

revoke all on "informix".cmspr_2 from "public" as "informix";

{ TABLE "informix".motxt_test row size = 1100 number of columns = 11 index size = 9 }

create table "informix".motxt_test 
  (
    ord_no integer not null ,
    chart integer not null ,
    sub varchar(255),
    obj varchar(255),
    ass varchar(255),
    cmt varchar(255),
    rpt_man smallint 
        default 0 not null ,
    rpt_dat date 
        default  '1899/12/31' not null ,
    rpt_hm smallint 
        default 0 not null ,
    rpt_typ char(4) 
        default '' not null ,
    rpt text,
    primary key (ord_no) 
  );

revoke all on "informix".motxt_test from "public" as "informix";

{ TABLE "hispcd".test_chinese row size = 212 number of columns = 4 index size = 9 }

create table "hispcd".test_chinese 
  (
    id integer,
    c char(100),
    remark char(100),
    dt datetime year to second,
    primary key (id) 
  );

revoke all on "hispcd".test_chinese from "public" as "hispcd";


create unique index "informix".i1_mrpbd1 on "informix".mrpbd1 
    (chart) using btree ;
create index "informix".i2_mrpbd1 on "informix".mrpbd1 (nam) using 
    btree ;
create unique index "informix".i3_mrpbd1 on "informix".mrpbd1 
    (id_no,typ) using btree ;
create unique index "informix".i4_mrpbd1 on "informix".mrpbd1 
    (tel_h,nam,typ) using btree ;
create unique index "informix".i1_ocoditem on "informix".ocoditem 
    (charg_no,seq_no,item_cod) using btree ;
create index "informix".i2_ocoditem on "informix".ocoditem (item_cod,
    rtd,charg_no) using btree ;
create unique index "informix".i1_ocdesc on "informix".ocdesc 
    (charg_no) using btree ;
create index "informix".i2_ocdesc on "informix".ocdesc (chart,
    visit_no) using btree ;
create index "informix".i3_ocdesc on "informix".ocdesc (rtd,rthm) 
    using btree ;
create unique index "informix".i1_cgastitm on "informix".cgastitm 
    (ast_cod) using btree ;
create unique index "informix".i1_cgbillgc on "informix".cgbillgc 
    (group_cod,o_i,detai_cod) using btree ;
create unique index "informix".i1_cgcnc on "informix".cgcnc (typ) 
    using btree ;
create unique index "informix".i1_cgcncc on "informix".cgcncc 
    (collect_no,typ) using btree ;
create unique index "informix".i1_cgcoment on "informix".cgcoment 
    (item_cod) using btree ;
create unique index "informix".i1_cgndmnam on "informix".cgndmnam 
    (item_cod) using btree ;
create unique index "informix".i1_cgpar on "informix".cgpar (chart,
    visit_no,typ) using btree ;
create unique index "informix".i1_cgpfdcnt on "informix".cgpfdcnt 
    (pt_typ,fee_typ) using btree ;
create unique index "informix".i1_cgptbd on "informix".cgptbd 
    (pt_typ) using btree ;
create unique index "informix".i1_dgfomula on "informix".dgfomula 
    (drug_cod,typ,seq_no) using btree ;
create unique index "informix".i1_dgjobdsp on "informix".dgjobdsp 
    (dispense_typ,start_hhii) using btree ;
create unique index "informix".i1_dgnam on "informix".dgnam (drug_cod,
    seq_no) using btree ;
create index "informix".i2_dgnam on "informix".dgnam (nam) using 
    btree ;
create unique index "informix".i1_glnprcn on "informix".glnprcn 
    (cod) using btree ;
create unique index "informix".i1_mrocgprg on "informix".mrocgprg 
    (chart) using btree ;
create index "informix".i2_mrocgprg on "informix".mrocgprg (rg_dat) 
    using btree ;
create unique index "informix".i3_mrocgprg on "informix".mrocgprg 
    (diag) using btree ;
create unique index "informix".i1_mromcn on "informix".mromcn 
    (om_cod,seq_no) using btree ;
create unique index "informix".i1_mrpbd2 on "informix".mrpbd2 
    (chart) using btree ;
create unique index "informix".i1_mtnam on "informix".mtnam (mt_cod,
    seq_no) using btree ;
create unique index "informix".i1_psemprel on "informix".psemprel 
    (emp_no,relat) using btree ;
create unique index "informix".i2_psemprel on "informix".psemprel 
    (id_no) using btree ;
create unique index "informix".i1_psshcn on "informix".psshcn 
    (cod) using btree ;
create unique index "informix".i1_rgrup on "informix".rgrup2 (opd_er,
    charg_typ,f_r,pt_typ) using btree ;
create unique index "informix".i1_ucogfunc on "informix".ucogfuncold 
    (group_func_no,func_no) using btree ;
create unique index "informix".i1_cgdfrat on "informix".cgdfrat 
    (item_cod) using btree ;
create unique index "informix".i1_cgroompf on "informix".cgroompf 
    (class,rank,eff_dat) using btree ;
create unique index "informix".i1_cgroompp on "informix".cgroompp 
    (class,rank) using btree ;
create unique index "informix".i1_icoditem on "informix".icoditem 
    (charg_no,seq_no,item_cod) using btree ;
create index "informix".i2_icoditem on "informix".icoditem (item_cod,
    rtd,charg_no) using btree ;
create unique index "informix".i1_bmrmlvl on "informix".bmrmlvl 
    (room,bed,eff_dat) using btree ;
create unique index "informix".i2_bmrmlvl on "informix".bmrmlvl 
    (eff_dat,room,bed) using btree ;
create unique index "informix".i1_icglscon on "informix".icglscon 
    (acc_no,item_cod) using btree ;
create index "informix".i1_icrolog on "informix".icrolog (acc_no) 
    using btree ;
create index "informix".i2_icrolog on "informix".icrolog (td) 
    using btree ;
create unique index "informix".i1_rfdata on "informix".rfdata 
    (chart,visit_no) using btree ;
create unique index "informix".i1_icitmqty on "informix".icitmqty 
    (acc_no,item_cod,fee_cod) using btree ;
create unique index "informix".i1_psdpatbd on "informix".psdpatbd 
    (sub_h_no,unit_no) using btree ;
create index "informix".i1_icptclog on "informix".icptclog (acc_no) 
    using btree ;
create unique index "informix".i1_cgpcs on "informix".cgpcs (chart,
    visit_no,typ) using btree ;
create unique index "informix".i1_mricddsc on "informix".mricddsc 
    (icd_cod,seq_no) using btree ;
create unique index "informix".i1_ntpdrscn on "informix".ntpdrscn 
    (cod) using btree ;
create unique index "informix".i1_ntpdrest on "informix".ntpdrest 
    (acc_no,f_dat,f_meal) using btree ;
create unique index "informix".i1_ntpddesc on "informix".ntpddesc 
    (acc_no,dt_own,f_dat,f_meal) using btree ;
create unique index "informix".i1_mrptdiag on "informix".mrptdiag 
    (chart,visit_no,diag) using btree ;
create index "informix".i2_mrptdiag on "informix".mrptdiag (diag,
    visit_no) using btree ;
create unique index "informix".i1_pslicens on "informix".pslicens 
    (emp_no,typ,typ_1,seq) using btree ;
create unique index "informix".i1_pssclcn on "informix".pssclcn 
    (scl_no) using btree ;
create unique index "informix".i1_psdptbd on "informix".psdptbd 
    (depart) using btree ;
create unique index "informix".i1_psdptitl on "informix".psdptitl 
    (depart,titl) using btree ;
create unique index "informix".i1_cgcolect on "informix".cgcolect 
    (collect_no) using btree ;
create unique index "informix".i2_cgcolect on "informix".cgcolect 
    (chart,visit_no,collect_no) using btree ;
create unique index "informix".i3_cgcolect on "informix".cgcolect 
    (rtd,collect_no) using btree ;
create unique index "informix".i1_pscmback on "informix".pscmback 
    (emp_no,f_dat) using btree ;
create unique index "informix".i1_pstrain on "informix".pstrain 
    (emp_no,f_dat) using btree ;
create unique index "informix".i1_psempscl on "informix".psempscl 
    (emp_no,scl_no) using btree ;
create unique index "informix".i1_psephbcn on "informix".psephbcn 
    (exp_hby,typ) using btree ;
create index "informix".i1_psexphby on "informix".psexphby (emp_no,
    exp_hby,typ) using btree ;
create unique index "informix".i1_pspripun on "informix".pspripun 
    (emp_no,pp_dat) using btree ;
create unique index "informix".i1_psprodod on "informix".psprodod 
    (emp_no,pre_od_dat) using btree ;
create unique index "informix".i1_psufbd on "informix".psufbd 
    (typ) using btree ;
create unique index "informix".i1_psunifom on "informix".psunifom 
    (emp_no,dat) using btree ;
create unique index "informix".i1_psscldpt on "informix".psscldpt 
    (dpt_no) using btree ;
create unique index "informix".i1_pstitlt on "informix".pstitlt 
    (emp_no,td) using btree ;
create unique index "informix".i1_ocmaoimt on "informix".ocmaoimt 
    (item_cod,lp_seq) using btree ;
create unique index "informix".i1_psepbd2 on "informix".psepbd2 
    (emp_no) using btree ;
create unique index "informix".i1_zzrptbd on "informix".zzrptbd 
    (typ,lp_seq) using btree ;
create unique index "informix".i2_zzrptbd on "informix".zzrptbd 
    (progrm) using btree ;
create unique index "informix".i1_pscareer on "informix".pscareer 
    (emp_no,f_dat) using btree ;
create unique index "informix".i1_ofvacat on "informix".ofvacat 
    (emp_no,f_dat,f_hm) using btree ;
create unique index "informix".i1_psyrexam on "informix".psyrexam 
    (yymm,emp_no) using btree ;
create unique index "informix".i1_psyrtot on "informix".psyrtot 
    (emp_no) using btree ;
create unique index "informix".i1_pssalary on "informix".pssalary 
    (emp_no) using btree ;
create index "informix".i1_icffamt on "informix".icffamt (acc_no,
    each_dat) using btree ;
create index "informix".i2_icffamt on "informix".icffamt (rtd,
    rthm) using btree ;
create unique index "informix".i1_erptbd on "informix".erptbd 
    (chart,er_dat,er_thm) using btree ;
create index "informix".i2_erptbd on "informix".erptbd (er_dat) 
    using btree ;
create unique index "informix".i1_uddisodf on "informix".uddisodf 
    (acc_no,seq_no) using btree ;
create index "informix".i2_uddisodf on "informix".uddisodf (acc_no,
    item_cod) using btree ;
create index "informix".i1_uddologf on "informix".uddologf (acc_no,
    seq_no) using btree ;
create unique index "informix".i1_udductrf on "informix".udductrf 
    (usagcod,div360,dap) using btree ;
create index "informix".i1_lbbookbr on "informix".lbbookbr (loc,
    borrower) using btree ;
create index "informix".i2_lbbookbr on "informix".lbbookbr (loc,
    acc_no) using btree ;
create index "informix".i3_lbbookbr on "informix".lbbookbr (loc,
    pre_dat) using btree ;
create index "informix".i1_gllauiff on "informix".gllauiff (gl_typ,
    appl_depart,seq_no) using btree ;
create index "informix".i2_gllauiff on "informix".gllauiff (chart) 
    using btree ;
create index "informix".ix_1 on "informix".iofeem (typ,pt_typ,
    chart) using btree ;
create unique index "informix".i1_dgdesc1 on "informix".dgdesc1 
    (drug_cod) using btree ;
create unique index "informix".i1_osdesc on "informix".osdesc 
    (order_no) using btree ;
create unique index "informix".i2_osdesc on "informix".osdesc 
    (chart,visit_no desc) using btree ;
create unique index "informix".i1_ossoa on "informix".ossoa (order_no,
    seq_no) using btree ;
create index "informix".i1_ossoal on "informix".ossoal (order_no) 
    using btree ;
create unique index "informix".i1_osditto on "informix".osditto 
    (md_dr,ditto_no,seq_no) using btree ;
create unique index "informix".i1_lbbookbd on "informix".lbbookbd 
    (loc,acc_no) using btree ;
create index "informix".i2_lbbookbd on "informix".lbbookbd (class_no,
    title) using btree ;
create index "informix".i3_lbbookbd on "informix".lbbookbd (vol_no,
    seq_no,title) using btree ;
create index "informix".i4_lbbookbd on "informix".lbbookbd (pubshr_no) 
    using btree ;
create index "informix".i5_lbbookbd on "informix".lbbookbd (sou_loc) 
    using btree ;
create unique index "informix".i_iaasmst1 on "informix".iaasmst 
    (assets_no,assets_ser) using btree ;
create index "informix".i_iaasmst2 on "informix".iaasmst (supplier_no) 
    using btree ;
create index "informix".i_iaasmst3 on "informix".iaasmst (user_no) 
    using btree ;
create unique index "informix".i_iaassub1 on "informix".iaassub 
    (assets_no,assets_ser,change_ser) using btree ;
create index "informix".i_iaassub2 on "informix".iaassub (assets_no,
    assets_ser) using btree ;
create index "informix".i_iaassub3 on "informix".iaassub (change_type) 
    using btree ;
create unique index "informix".i_iaassup1 on "informix".iaassup 
    (supplier_no) using btree ;
create unique index "informix".i_iaasuse1 on "informix".iaasuse 
    (user_no) using btree ;
create unique index "informix".i1_lbjvbd on "informix".lbjvbd 
    (loc,com_no) using btree ;
create unique index "informix".i2_lbjvbd on "informix".lbjvbd 
    (f_vol_no,f_seq_no,title) using btree ;
create index "informix".i3_lbjvbd on "informix".lbjvbd (loc,f_vol_no,
    f_seq_no) using btree ;
create unique index "informix".i1_bmelidat on "informix".bmelidat 
    (acc_no,seq_no) using btree ;
create unique index "informix".i1_mtdesc on "informix".mtdesc 
    (mt_cod) using btree ;
create unique index "informix".meniidx on "informix".sysmenuitems 
    (imenuname,itemnum) using btree ;
create unique index "informix".i1_cgpf on "informix".cgsiupf (item_cod,
    eff_dat) using btree ;
create index "informix".i2_cgpf on "informix".cgsiupf (eff_dat) 
    using btree ;
create unique index "informix".i1_cgsiupp on "informix".cgsiupp 
    (item_cod) using btree ;
create unique index "informix".icddata_1 on "informix".icddata 
    (admit_dat,admit_hm,chart) using btree ;
create unique index "informix".icddata_2 on "informix".icddata 
    (chart,discha_dat,discha_hm) using btree ;
create unique index "informix".i1_iclaudat on "informix".iclaudat 
    (chart,in_dat,in_hm) using btree ;
create unique index "informix".i1_mrptccs on "informix".mrptccs 
    (chart,diag,eff_dat desc) using btree ;
create unique index "informix".i1_dccontcb on "informix".dccontcb 
    (dc_cod_m,dc_cod_a) using btree ;
create unique index "informix".i1_zzcodnam on "informix".zzcodnam 
    (cod) using btree ;
create unique index "informix".i1_mrpobd on "informix".mrpobd 
    (organ_no) using btree ;
create unique index "informix".i2_mrpobd on "informix".mrpobd 
    (organ_nam) using btree ;
create unique index "informix".i1_rfdbd on "informix".rfdbd (hospital_no,
    doctor_no) using btree ;
create unique index "informix".i1_rgdata on "informix".rgdata 
    (visit_no,seq_no) using btree ;
create unique index "informix".i2_rgdata on "informix".rgdata 
    (chart,visit_no) using btree ;
create unique index "informix".i1_bmdrbac on "informix".bmdrbac 
    (doctor) using btree ;
create unique index "informix".i1_mrcco on "informix".mrcco (chronic_no) 
    using btree ;
create unique index "informix".i2_mrcco on "informix".mrcco (chart,
    doctor,stp_dat desc) using btree ;
create unique index "informix".i1_mrglcdcn on "informix".mrglcdcn 
    (gl_cod) using btree ;
create unique index "informix".i1_mricdcn on "informix".mricdcn 
    (icd_cod) using btree ;
create index "informix".i2_mricdcn on "informix".mricdcn (gl_cod,
    icd_cod) using btree ;
create unique index "informix".i1_cgndmdsc on "informix".cgndmdsc 
    (item_cod) using btree ;
create index "informix".i1_rgrtl on "informix".rgrtl (chart,visit_dat) 
    using btree ;
create unique index "informix".i1_cgrmod on "informix".cgrmod 
    (rmo_no) using btree ;
create unique index "informix".i1_udmcwkds on "informix".udmcwkds 
    (ward,dat) using btree ;
create unique index "informix".i1_glrccd on "informix".glrccd 
    (id_no,refer_dat) using btree ;
create unique index "informix".i1_rfhbd on "informix".rfhbd (hospital_no) 
    using btree ;
create unique index "informix".i2_rfhbd on "informix".rfhbd (nam_a) 
    using btree ;
create unique index "informix".i1_mmivtcst on "informix".mmivtcst 
    (giv_loc,req_loc,yy,item_cod,tc) using btree ;
create index "informix".i2_mmivtcst on "informix".mmivtcst (req_loc,
    item_cod,yy) using btree ;
create index "informix".ix290_1 on "informix".pspoffd (emp_no) 
    using btree ;
create index "informix".ix290_2 on "informix".pspoffd (pre_dat) 
    using btree ;
create unique index "informix".i1_oscnam on "informix".oscnam 
    (map_no,typ,cod) using btree ;
create unique index "informix".i1_orroombd on "informix".orroombd 
    (room) using btree ;
create unique index "informix".i1_oropday on "informix".oropday 
    (room,week,shift,pri) using btree ;
create unique index "informix".i2_oropday on "informix".oropday 
    (dr,week,shift,room) using btree ;
create unique index "informix".i1_orasrmcd on "informix".orasrmcd 
    (room,chg_cod) using btree ;
create unique index "informix".i1_orexec on "informix".orexec 
    (ord_no) using btree ;
create index "informix".i2_orexec on "informix".orexec (opr_dat,
    opr_shift,tc1,pri_typ,ord_no) using btree ;
create index "informix".i3_orexec on "informix".orexec (opr_dat,
    opr_shift,opr_room,pri_typ,opr_seq) using btree ;
create unique index "informix".i1_uclogin on "informix".uclogin 
    (loc_id) using btree ;
create unique index "informix".i1_cgctrl on "informix".cgctrl 
    (chg_cod,seq_no) using btree ;
create index "informix".i1_moexeloc on "informix".moexeloc (map_no) 
    using btree ;
create unique index "informix".tableext1 on "informix".systableext 
    (owner,tabname) using btree ;
create unique index "informix".columnext1 on "informix".syscolumnext 
    (owner,tabname,colname) using btree ;
create unique index "informix".colformats1 on "informix".syscolformats 
    (owner,tabname,colname,priority) using btree ;
create index "informix".colformats2 on "informix".syscolformats 
    (owner,tabname,colname) using btree ;
create unique index "informix".colinput1 on "informix".syscolinput 
    (owner,tabname,colname,attrname) using btree ;
create index "informix".colinput2 on "informix".syscolinput (owner,
    tabname,colname) using btree ;
create unique index "informix".colinclude1 on "informix".syscolinclude 
    (owner,tabname,colname,priority) using btree ;
create index "informix".colinclude2 on "informix".syscolinclude 
    (owner,tabname,colname) using btree ;
create unique index "informix".superview1 on "informix".syssuperviews 
    (svwid) using btree ;
create unique index "informix".superview2 on "informix".syssuperviews 
    (svwname) using btree ;
create unique index "informix".svwtables1 on "informix".syssvwtables 
    (svwid,tabalias) using btree ;
create unique index "informix".svwtables2 on "informix".syssvwtables 
    (svwid,tableseq) using btree ;
create unique index "informix".svwjoins1 on "informix".syssvwjoins 
    (svwid,tabalias,jcolseq) using btree ;
create unique index "informix".svwaliases1 on "informix".syssvwaliases 
    (svwid,tabalias,colname) using btree ;
create unique index "informix".svwaliases2 on "informix".syssvwaliases 
    (svwid,colalias) using btree ;
create index "informix".svwaliases3 on "informix".syssvwaliases 
    (svwid,colseq) using btree ;
create unique index "informix".svworder1 on "informix".syssvworder 
    (svwid,seqno) using btree ;
create unique index "informix".svwauth1 on "informix".syssvwauth 
    (svwid,username) using btree ;
create unique index "informix".svwformats1 on "informix".syssvwformats 
    (svwid,colalias,priority) using btree ;
create index "informix".svwformats2 on "informix".syssvwformats 
    (svwid,colalias) using btree ;
create unique index "informix".svwinput1 on "informix".syssvwinput 
    (svwid,colalias,attrname) using btree ;
create index "informix".svwinput2 on "informix".syssvwinput (svwid,
    colalias) using btree ;
create unique index "informix".svwinclude1 on "informix".syssvwinclude 
    (svwid,colalias,priority) using btree ;
create index "informix".svwinclude2 on "informix".syssvwinclude 
    (svwid,colalias) using btree ;
create index "informix".i1_icdtfee on "informix".icdtfee (acc_no,
    each_dat) using btree ;
create index "informix".i2_icdtfee on "informix".icdtfee (rtd,
    rthm) using btree ;
create unique index "informix".ulist1 on "informix".sysulist (username) 
    using btree ;
create unique index "informix".i1_rhexedsc on "informix".rhexedsc 
    (job_no) using btree ;
create unique index "informix".i2_rhexedsc on "informix".rhexedsc 
    (chart,visit_no,trp_dat,cki_hm) using btree ;
create index "informix".i3_rhexedsc on "informix".rhexedsc (charg_no) 
    using btree ;
create unique index "informix".i1_xrbordat on "informix".xrbordat 
    (apl_no) using btree ;
create unique index "informix".i2_xrbordat on "informix".xrbordat 
    (chart,ret_dat desc,ret_hm) using btree ;
create index "informix".i3_xrbordat on "informix".xrbordat (bor_apl,
    bor_dat,bor_hm) using btree ;
create unique index "informix".i1_xrfilmst on "informix".xrfilmst 
    (chart) using btree ;
create unique index "informix".i1_nhhicicn on "informix".nhhicicn 
    (nh_cod,c_e) using btree ;
create unique index "informix".i1_rhexeitm on "informix".rhexeitm 
    (job_no,chg_cod,pos) using btree ;
create index "informix".i2_rhexeitm on "informix".rhexeitm (trp_man) 
    using btree ;
create unique index "informix".i1_stcgst on "informix".stcgst 
    (charg_cod,stock_cod) using btree ;
create unique index "informix".i1_xritem on "informix".xritem 
    (ord_no,chg_cod,dup_no,stock_cod) using btree ;
create unique index "informix".i1_astbd on "informix".astbd (ast_no) 
    using btree ;
create index "informix".i2_astbd on "informix".astbd (hdl_man,
    nam_a) using btree ;
create unique index "informix".i1_asacsitm on "informix".asacsitm 
    (ast_no,acs_seq) using btree ;
create index "informix".i2_asacsitm on "informix".asacsitm (loc_no) 
    using btree ;
create unique index "informix".i1_asscdnam on "informix".asscdnam 
    (ast_no,seq_no) using btree ;
create unique index "informix".i1_mooprcon on "informix".mooprcon 
    (icd_cod) using btree ;
create unique index "informix".i2_mooprcon on "informix".mooprcon 
    (division,seq_no,icd_cod) using btree ;
create unique index "informix".i1_mdvoc on "informix".mdvoc (own_no,
    map_no,voc_typ,seq_no) using btree ;
create unique index "informix".i1_rgovrl on "informix".rgovrl 
    (room) using btree ;
create unique index "informix".i1_modoc on "informix".modoc (ord_no,
    frm_sys) using btree ;
create unique index "informix".i1_mdvoc1 on "informix".mdvoc1 
    (own_no,map_no,voc_typ,seq_no) using btree ;
create unique index "informix".i1_ucterml on "informix".ucterml 
    (loc_id) using btree ;
create unique index "informix".i2_ucterml on "informix".ucterml 
    (device_id) using btree ;
create unique index "informix".i1_ucolfunc on "informix".ucolfuncold 
    (func_no) using btree ;
create unique index "informix".i1_paucdata on "informix".paucdata 
    (pa_no,pa_typ) using btree ;
create unique index "informix".i2_paucdata on "informix".paucdata 
    (rep_dat,id_no) using btree ;
create unique index "informix".i1_sttrms on "informix".sttrms 
    (loc,stk_cod) using btree ;
create unique index "informix".i1_ositem on "informix".ositem 
    (order_no,seq_no) using btree ;
create index "informix".i2_ositem on "informix".ositem (prm_no,
    map_no) using btree ;
create index "informix".i3_ositem on "informix".ositem (rtt,map_no) 
    using btree ;
create unique index "informix".i1_nsipcl on "informix".nsipcl 
    (chart,typ,ass_dat,ass_hm) using btree ;
create unique index "informix".i1_nsphw on "informix".nsphw (chart,
    msr_dat,msr_hm) using btree ;
create unique index "informix".i1_nspnvs on "informix".nspnvs 
    (chart,msr_dat,msr_hm) using btree ;
create unique index "informix".i1_mrpar on "informix".mrpar (chart,
    rtt) using btree ;
create unique index "informix".i1_sepbd on "informix".sepbd (sep_no) 
    using btree ;
create unique index "informix".i2_mrmrdir on "informix".mrmrdir 
    (chart,dcg_dat,dcg_hm) using btree ;
create unique index "informix".i1_ofjbd on "informix".ofjbd (dpt_no,
    job_no) using btree ;
create unique index "informix".i1_ofjobdsp on "informix".ofjobdsp 
    (dpt_no,job_no,dat,sft) using btree ;
create index "informix".i2_ofjobdsp on "informix".ofjobdsp (emp_no) 
    using btree ;
create unique index "informix".i1_tgavou on "informix".tgavou 
    (vou_dat,sub_h_no,typ,seq_no,item_no) using btree ;
create unique index "informix".ix713_1 on "informix".seril (num) 
    using btree ;
create unique index "informix".i1_moapdn on "informix".moapdn 
    (chart,visit_no,typ) using btree ;
create unique index "informix".i1_mrppsc on "informix".mrppsc 
    (chart,sck_dat) using btree ;
create index "informix".i1_dgfmindx on "informix".dgfmindx (pc_12,
    pc_3,pc_sub1,pc_sub2,typ,nam) using btree ;
create unique index "informix".i1_dgfmproc on "informix".dgfmproc 
    (pc_12,pc_3,pc_sub1,pc_sub2,nam_s) using btree ;
create unique index "informix".i1_pmmember on "informix".pmmember 
    (id_no) using btree ;
create unique index "informix".i2_pmmember on "informix".pmmember 
    (tel_h,nam) using btree ;
create index "informix".i3_pmmember on "informix".pmmember (emp_no) 
    using btree ;
create unique index "informix".i1_nhtncic on "informix".nhtncic 
    (itm_cod,dat_f) using btree ;
create index "informix".i2_nhtncic on "informix".nhtncic (nhi_cod) 
    using btree ;
create index "informix".i3_nhtncic on "informix".nhtncic (dat_t) 
    using btree ;
create unique index "informix".i1_dcicdcn on "informix".dcicdcn1 
    (icd_cod) using btree ;
create unique index "informix".i2_dcicdcn on "informix".dcicdcn1 
    (icd_typ,icd_cod) using btree ;
create index "informix".i3_dcicdcn on "informix".dcicdcn1 (drg_cod) 
    using btree ;
create unique index "informix".i1_dcicddsc on "informix".dcicddsc 
    (icd_cod,seq_no) using btree ;
create unique index "informix".i1_zzrrcn on "informix".zzrrcn 
    (region_no) using btree ;
create unique index "informix".i1_nsiprd on "informix".nsiprd 
    (acc_no) using btree ;
create unique index "informix".i1_rgovt on "informix".rgovt (wek_day,
    sft,room,stp_dat desc) using btree ;
create index "informix".i2_rgovt on "informix".rgovt (dct_no,wek_day,
    sft) using btree ;
create index "informix".i3_rgovt1 on "informix".rgovt (div_no,
    wek_day,sft) using btree ;
create unique index "informix".i1_rgctrl1 on "informix".rgctrl 
    (visit_dat,sft,room) using btree ;
create unique index "informix".i2_rgctrl1 on "informix".rgctrl 
    (visit_dat,sft,dct_no,stp) using btree ;
create index "informix".i3_rgctrl1 on "informix".rgctrl (visit_dat,
    sft,div_no,cur_cnt) using btree ;
create unique index "informix".i1_cpndsp on "informix".cpndsp 
    (drg_cod,eff_dat,itm_cod) using btree ;
create index "informix".i1_rgnofee on "informix".rgnofee (visit_dat) 
    using btree ;
create unique index "informix".i1_osinst on "informix".osinst 
    (mapno,seq_no) using btree ;
create index "informix".i1_mrcharbr on "informix".mrcharbr (chart) 
    using btree ;
create index "informix".i2_mrcharbr on "informix".mrcharbr (bor_dat,
    ret_mark) using btree ;
create index "informix".i3_mrcharbr on "informix".mrcharbr (borrower) 
    using btree ;
create index "informix".i1_gactoa on "informix".gactoa (acc_cod) 
    using btree ;
create unique index "informix".i2_gactoa on "informix".gactoa 
    (chg_cod,pd_typ,nh_typ) using btree ;
create unique index "informix".i1_mrpbd3 on "informix".mrpbd3 
    (chart) using btree ;
create index "informix".i2_mrpbd3 on "informix".mrpbd3 (nam) using 
    btree ;
create unique index "informix".i3_mrpbd3 on "informix".mrpbd3 
    (id_no) using btree ;
create unique index "informix".i4_mrpbd3 on "informix".mrpbd3 
    (tel_h,nam) using btree ;
create unique index "informix".i1_mrpbd4 on "informix".mrpbd4 
    (chart) using btree ;
create unique index "informix".i1_rhtibd on "informix".rhtibd 
    (trp_itm) using btree ;
create unique index "informix".i1_rgmdcn on "informix".rgmdcn 
    (division) using btree ;
create unique index "informix".i2_ucclicfg on "informix".ucclicfg 
    (loc_no) using btree ;
create index "informix".i3_ucclicfg on "informix".ucclicfg (dep_no) 
    using btree ;
create unique index "informix".i4_ucclicfg on "informix".ucclicfg 
    (tcp_adr) using btree ;
create unique index "root".i5_ucclicfg on "informix".ucclicfg 
    (cmp_nam) using btree ;
create unique index "root".i6_ucclicfg on "informix".ucclicfg 
    (mac_adr) using btree ;
create unique index "informix".i1_bmfftran on "informix".bmfftran 
    (acc_no,f_dat,f_hm) using btree ;
create index "informix".i2_bmfftran on "informix".bmfftran (f_dat,
    f_hm) using btree ;
create index "informix".i3_bmfftran on "informix".bmfftran (t_dat,
    room,bed) using btree ;
create index "informix".i1_bmfflog on "informix".bmfflog (acc_no,
    f_dat,f_hm) using btree ;
create unique index "informix".i2_mrvcsn on "informix".mrvcsn 
    (chart,visit_no) using btree ;
create index "root".i3_mrvcsn on "informix".mrvcsn (chart,card_yy,
    vsn_nh) using btree ;
create index "informix".i4_mrvcsn on "informix".mrvcsn (cg_rtp,
    cg_rtd,cg_rthm) using btree ;
create index "informix".i2_modsc on "informix".modsc (vsn,map_no,
    frm_no desc,tsc) using btree ;
create index "informix".i3_modsc on "informix".modsc (vsn,pre_dat,
    pre_hm,frm_no) using btree ;
create index "root".i4_modsc on "informix".modsc (map_no,tsc,pre_dat 
    desc,pre_hm desc) using btree ;
create index "informix".i5_modsc on "informix".modsc (exe_dat 
    desc,map_no,exe_hm desc) using btree ;
create index "informix".i2_motxt on "informix".motxt (chart,rpt_dat 
    desc,rpt_hm) using btree ;
create index "informix".i3_motxt on "informix".motxt (rpt_typ) 
    using btree ;
create index "informix".i4_motxt on "informix".motxt (rpt_dat) 
    using btree ;
create index "informix".i2_mopdd on "informix".mopdd (icd_cod,
    seq_no) using btree ;
create index "informix".i1_mower on "informix".mower (ord_no) 
    using btree ;
create index "informix".i2_mower on "informix".mower (map_no,tsc) 
    using btree ;
create index "informix".i2_mopar on "informix".mopar (act_dat,
    act_typ) using btree ;
create unique index "informix".i1_monot on "informix".monot3 (vsn,
    typ,seq_no) using btree ;
create index "informix".i2_moeps on "informix".moeps (map_no,eff_tim) 
    using btree ;
create index "informix".i2_nsntwd on "informix".nsntwd (dat,wad) 
    using btree ;
create unique index "informix".i1_pstitlcn on "informix".pstitlcn 
    (titl) using btree ;
create unique index "informix".i1_bmptbd on "informix".bmptbd 
    (acc_no) using btree ;
create index "informix".i2_bmptbd on "informix".bmptbd (admit_dat,
    admit_hm) using btree ;
create index "informix".i3_bmptbd on "informix".bmptbd (link_acc) 
    using btree ;
create unique index "informix".i4_bmptbd on "informix".bmptbd 
    (chart,tp_dat,tp_hm) using btree ;
create index "informix".i5_bmptbd on "informix".bmptbd (comp_acc) 
    using btree ;
create index "informix".i6_bmptbd on "informix".bmptbd (a_dr1) 
    using btree ;
create index "informix".i7_bmptbd on "informix".bmptbd (tp_dat,
    tp_hm) using btree ;
create index "informix".i8_bmptbd on "informix".bmptbd (rtd) using 
    btree ;
create unique index "informix".i1_bmpobd on "informix".bmpobd 
    (chart,admit_dat) using btree ;
create index "informix".i2_bmpobd on "informix".bmpobd (pre_dat) 
    using btree ;
create index "informix".i3_bmpobd on "informix".bmpobd (dct1_no) 
    using btree ;
create index "informix".i2_morprv on "informix".morprv (rpt_tim,
    rpt_man) using btree ;
create unique index "informix".i2_mosoah on "informix".mosoah 
    (own_no,typ,nam) using btree ;
create index "informix".i2_nsidpr on "informix".nsidpr (pmg_dat,
    pmg_dr) using btree ;
create index "informix".i2_moexe on "informix".moexe (chart,chg_cod,
    exe_dat) using btree ;
create index "informix".i2_npdsc on "informix".npdsc (vsn,eff_dat 
    desc) using btree ;
create index "informix".i3_npdsc on "informix".npdsc (nrs_dag,
    stp_dat) using btree ;
create index "informix".i2_npitm on "informix".npitm (nrs_cod,
    exe_sts,exe_dat) using btree ;
create unique index "informix".i1_dgdesc on "informix".dgdesc 
    (drug_cod) using btree ;
create index "informix".i2_dgdesc on "informix".dgdesc (nam) using 
    btree ;
create index "informix".i2_mrchtbor on "informix".mrchtbor (chart,
    dcg_dat) using btree ;
create index "informix".i3_mrchtbor on "informix".mrchtbor (ret_dat,
    bor_man) using btree ;
create unique index "informix".i1_mrumrdr on "informix".mrumrdr 
    (evt_no,eff_dat) using btree ;
create index "informix".i2_prrbd on "informix".prrbd (nam,brn_dat) 
    using btree ;
create unique index "informix".i3_prrbd on "informix".prrbd (tel_h,
    nam) using btree ;
create unique index "informix".i2_bcbemp on "informix".bcbemp 
    (emp_no) using btree ;
create unique index "informix".i2_bcgcn on "informix".bcgcn (grp_nam) 
    using btree ;
create unique index "informix".i2_bcmtn on "informix".bcmtn (dpt_no,
    msg_typ) using btree ;
create unique index "informix".i2_ucmsg on "informix".ucmsg (tbl_id,
    evt_no,msg_no) using btree ;
create index "informix".i3_ucmsg on "informix".ucmsg (sed_man,
    sed_tim) using btree ;
create index "informix".i4_ucmsg on "informix".ucmsg (rec_man,
    rec_tim) using btree ;
create index "informix".i5_ucmsg on "informix".ucmsg (exe_tim,
    rec_tim) using btree ;
create unique index "root".sysmenidx on "root".sysmenus (menuname) 
    using btree ;
create unique index "informix".i1_dgdnc on "informix".dgdnc (hpt_loc,
    typ) using btree ;
create index "informix".i2_nsmss on "informix".nsmss (wrd,mtl_cod) 
    using btree ;
create index "informix".i2_dcptbd on "informix".dcptbd (chart,
    dis_dat desc) using btree ;
create index "informix".i3_dcptbd on "informix".dcptbd (dis_dat 
    desc) using btree ;
create index "informix".i4_dcptbd on "informix".dcptbd (div_no) 
    using btree ;
create index "informix".i5_dcptbd on "informix".dcptbd (reg_no) 
    using btree ;
create index "informix".i2_modct on "informix".modct (dct_no,seq_no,
    stp_dat desc,stp_hm) using btree ;
create index "informix".i3_modct on "informix".modct (div_no,seq_no,
    stp_dat desc,stp_hm) using btree ;
create index "root".i2_tecttr on "root".tecttr (vsn) using btree 
    ;
create index "root".i3_tecttr on "root".tecttr (sub_tel,vsn) using 
    btree ;
create index "root".i2_tetbd on "root".tetbd (loc_no) using btree 
    ;
create index "informix".i3_tetbd on "root".tetbd (nam) using btree 
    ;
create index "informix".i4_tetbd on "root".tetbd (sub_tel) using 
    btree ;
create index "informix".i2_motdn on "informix".motdn (trn_tim) 
    using btree ;
create unique index "informix".i1_nhdcn on "informix".nhdcn (drg_cod,
    eff_dat) using btree ;
create index "informix".i2_nhdcn on "informix".nhdcn (div_no,drg_cod) 
    using btree ;
create index "informix".i2_hcbtm on "informix".hcbtm (idn) using 
    btree ;
create index "informix".i2_hcvcd on "informix".hcvcd (vsn) using 
    btree ;
create index "informix".i3_hcvcd on "informix".hcvcd (wrt_tim) 
    using btree ;
create index "informix".i2_rosars on "informix".rosars (nam) using 
    btree ;
create index "informix".i3_rosars on "informix".rosars (tel_no) 
    using btree ;
create index "informix".i2_smreq on "informix".smreq (sed_tim) 
    using btree ;
create unique index "root".i2_nsntm on "root".nsntm (mat_cod,chg_cod) 
    using btree ;
create unique index "informix".i2_nentm on "informix".nentm (mat_cod,
    chg_cod) using btree ;
create unique index "informix".i1_garcbd1 on "informix".garcbd 
    (rc) using btree ;
create unique index "informix".i2_garcbd1 on "informix".garcbd 
    (level_no) using btree ;
create index "informix".i2_hcccd on "informix".hcccd (vsn) using 
    btree ;
create index "informix".i3_hcccd on "informix".hcccd (wrt_tim) 
    using btree ;
create unique index "informix".i1_dcdsc92 on "informix".dcdsc92 
    (icd_cod,seq_no) using btree ;
create unique index "informix".i1_dcicd92 on "informix".dcicd92 
    (icd_cod) using btree ;
create unique index "informix".i2_dcicd92 on "informix".dcicd92 
    (icd_typ,icd_cod) using btree ;
create index "informix".i3_dcicd92 on "informix".dcicd92 (drg_cod) 
    using btree ;
create unique index "informix".i2_scpbd on "informix".scpbd (chart,
    scn_typ,stp_dat) using btree ;
create index "informix".i3_scpbd on "informix".scpbd (scn_typ,
    eff_dat desc) using btree ;
create index "informix".i2_sccer on "informix".sccer (pkg_cod,
    cfm_dat desc) using btree ;
create unique index "informix".i1_dcicdcn2 on "informix".dcicdcn 
    (icd_cod) using btree ;
create unique index "informix".i2_dcicdcn2 on "informix".dcicdcn 
    (icd_typ,icd_cod) using btree ;
create index "informix".i3_dcicdcn2 on "informix".dcicdcn (drg_cod) 
    using btree ;
create index "informix".i2_cndcn on "informix".cndcn (dag_dat,
    dag_typ,tsc) using btree ;
create index "informix".i3_cndcn on "informix".cndcn (vsn) using 
    btree ;
create index "informix".i2_cnssp on "informix".cnssp (cod) using 
    btree ;
create index "informix".i1_ositeml on "informix".ositeml (order_no,
    rtt) using btree ;
create unique index "informix".i2_hcvch on "informix".hcvch (idn,
    wrt_tim) using btree ;
create index "informix".i3_hcvch on "informix".hcvch (idn,rec_tim) 
    using btree ;
create index "informix".i2_hcpst on "informix".hcpst (ccd_no,typ) 
    using btree ;
create index "informix".i2_pipvr on "informix".pipvr (inj_dat) 
    using btree ;
create index "informix".i2_pibvr on "informix".pibvr (bat_no) 
    using btree ;
create index "informix".i3_pibvr on "informix".pibvr (eff_dat) 
    using btree ;
create unique index "informix".i1_psepbdat on "informix".psepbdat 
    (emp_no) using btree ;
create unique index "informix".i2_psepbdat on "informix".psepbdat 
    (emp_nam,birthday) using btree ;
create index "informix".i3_psepbdat on "informix".psepbdat (depart) 
    using btree ;
create index "informix".i4_psepbdat on "informix".psepbdat (quit_dat) 
    using btree ;
create unique index "informix".i2_mrumrt on "informix".mrumrt 
    (reg_dat,evt_no) using btree ;
create unique index "informix".i3_mrumrt on "informix".mrumrt 
    (chart,dcg_dat,dcg_hm) using btree ;
create unique index "informix".i4_mrumrt on "informix".mrumrt 
    (snd_dat,evt_no) using btree ;
create unique index "root".i1_icdesc on "root".icdesc (charg_no) 
    using btree ;
create index "root".i2_icdesc on "root".icdesc (acc_no,charg_no) 
    using btree ;
create index "root".i3_icdesc on "root".icdesc (rtd,rthm) using 
    btree ;
create index "informix".i2_tdheccd on "informix".tdheccd (icd_cod_m,
    cnt) using btree ;
create index "informix".i2_mrumrh on "informix".mrumrh (dct,pre_dat) 
    using btree ;
create index "informix".i2_eheer on "informix".eheer (chart,frm,
    eer_tim) using btree ;
create index "informix".i2_teeamt on "informix".teeamt (tel_o) 
    using btree ;
create index "informix".i3_teeamt on "informix".teeamt (tel_i) 
    using btree ;
create index "informix".i2_mompc on "informix".mompc (src,typ,
    dct_no) using btree ;
create unique index "informix".i1_psctcont on "informix".psctcont 
    (contra_no) using btree ;
create index "informix".i2_morcr on "informix".morcr (chart,eff_dat) 
    using btree ;
create index "informix".i2_cgbqt2 on "informix".cgbqt2 (chart) 
    using btree ;
create index "informix".i3_cgbqt2 on "informix".cgbqt2 (bqt_gov,
    eff_dat) using btree ;
create index "informix".i2_cgbqt on "informix".cgbqt (chart) using 
    btree ;
create index "informix".i3_cgbqt on "informix".cgbqt (bqt_gov,
    eff_dat) using btree ;
create index "informix".i2_ospmh on "informix".ospmh (chart,typ) 
    using btree ;
create index "informix".i2_mocrs on "informix".mocrs (vsn) using 
    btree ;
create index "informix".i2_mrdnrosr on "informix".mrdnrosr (id_no,
    eff_dat) using btree ;
create unique index "informix".i2_dcdcr3 on "informix".dgdcr (vsn) 
    using btree ;
create index "informix".i2_mrbatbor on "informix".mrbatbor (bat_num) 
    using btree ;
create index "informix".i2_psdsdiv on "informix".psdsdiv (div_no) 
    using btree ;
create index "informix".i2_eaeir1 on "informix".eaeir1 (chart) 
    using btree ;
create index "informix".i2_eaeir2 on "informix".eaeir2 (rec_no,
    eva_no) using btree ;
create index "informix".i2_npfr on "informix".npfr (vsn,cls_typ,
    rec_tim desc,rec_sts) using btree ;
create index "informix".i2_nppahr on "informix".nppahr (chart,
    adm_dat) using btree ;
create index "informix".i2_nppecm on "informix".nppecm (chart,
    ect_seq) using btree ;
create index "informix".i2_nppohr on "informix".nppohr (chart,
    opr_dat) using btree ;
create index "informix".i2_mecmc on "informix".mecmc (acc_no) 
    using btree ;
create index "informix".i3_mecmc on "informix".mecmc (met_tim) 
    using btree ;
create index "informix".i2_mecmm on "informix".mecmm (cve_no) 
    using btree ;
create index "informix".i2_meccr on "informix".meccr (acc_no,eff_tim) 
    using btree ;
create index "informix".i3_meccr on "informix".meccr (cve_no) 
    using btree ;
create index "informix".i2_mecms on "informix".mecms (sch_dat) 
    using btree ;
create index "informix".i2_moccdi on "informix".moccdi (typ,itm_no,
    seq_no) using btree ;
create unique index "informix".i1_mocclog on "informix".mocclog 
    (log_tim,typ,vsn) using btree ;
create index "informix".i2_mocclog on "informix".mocclog (vsn,
    typ) using btree ;
create index "informix".i2_cgctr on "informix".cgctr (chart) using 
    btree ;
create index "informix".i3_cgctr on "informix".cgctr (tst_typ) 
    using btree ;
create index "informix".i2_npdphra on "informix".npdphra (chart,
    ast_dat,ast_frm) using btree ;
create index "informix".i2_npfdhra on "informix".npfdhra (chart,
    ast_dat) using btree ;
create index "informix".i2_nppshra on "informix".nppshra (chart,
    ast_dat) using btree ;
create index "informix".i2_modcuicd on "informix".modcuicd (typ,
    div_no,icd_cod) using btree ;
create index "informix".i2_mmreq2 on "informix".mmreq2 (lnk_no1) 
    using btree ;
create index "informix".i3_mmreq2 on "informix".mmreq2 (exe_tim 
    desc,rcv_man) using btree ;
create index "informix".i2_npieb on "informix".npieb (div_no) 
    using btree ;
create index "informix".i3_npieb on "informix".npieb (msr_no,det_no) 
    using btree ;
create index "informix".i2_qmerm on "informix".qmerm (vsn) using 
    btree ;
create index "informix".i3_qmerm on "informix".qmerm (frm_no) 
    using btree ;
create index "informix".i2_qmged on "informix".qmged (rec_no,eva_no) 
    using btree ;
create index "informix".i2_qmhss on "informix".qmhss (frm_no) 
    using btree ;
create index "informix".i2_qmqrl on "informix".qmqrl (itm_no) 
    using btree ;
create unique index "informix".i2_qmserd on "informix".qmserd 
    (vsn) using btree ;
create index "informix".i2_qmsicr on "informix".qmsicr (vsn) using 
    btree ;
create index "informix".i3_qmsicr on "informix".qmsicr (eff_dat) 
    using btree ;
create index "informix".i2_moilar on "informix".moilar (acc_no,
    in_dat,in_hm) using btree ;
create index "informix".i2_moilari on "informix".moilari (icu_no) 
    using btree ;
create index "informix".i2_mmcam on "informix".mmcam (typ,typ_no) 
    using btree ;
create index "informix".i2_dgpar on "informix".dgpar (vsn) using 
    btree ;
create index "informix".i3_dgpar on "informix".dgpar (chart,par_dat) 
    using btree ;
create index "informix".i2_cgcid on "informix".cgcid (charg_no,
    seq_no) using btree ;
create index "informix".i2_meacr on "informix".meacr (lnk_no) 
    using btree ;
create index "informix".i3_meacr on "informix".meacr (rcv_no) 
    using btree ;
create index "informix".i2_mecmr on "informix".mecmr (lnk_no) 
    using btree ;
create index "informix".i3_mecmr on "informix".mecmr (met_tim) 
    using btree ;
create index "informix".i2_mecmp on "informix".mecmp (rcv_no) 
    using btree ;
create index "informix".i2_megmc on "informix".megmc (rcv_no) 
    using btree ;
create index "informix".i2_mesrr on "informix".mesrr (rcv_no) 
    using btree ;
create index "informix".i2_emtemr on "informix".emtemr (emr_typ,
    lnk_no) using btree ;
create index "informix".i3_emtemr on "informix".emtemr (cmp_tim,
    tsc) using btree ;
create index "informix".i2_qmcpr on "informix".qmcpr (acc_no,typ) 
    using btree ;
create index "informix".i3_moipar on "informix".moipar (act_dat,
    act_typ) using btree ;
create index "informix".i4_moipar on "informix".moipar (itm_no) 
    using btree ;
create index "informix".i2_mocodi on "informix".mocodi (ptc_cod,
    seq_no) using btree ;
create index "informix".i3_mocodi on "informix".mocodi (itm_cod,
    ptc_cod) using btree ;
create index "informix".i4_mocodi on "informix".mocodi (ptc_cod,
    eff_tim) using btree ;
create index "informix".i2_moieb on "informix".moieb (rec_no,cls_typ) 
    using btree ;
create index "informix".i2_mored on "informix".mored (vsn,cls_typ) 
    using btree ;
create index "informix".i2_nperm on "informix".nperm (vsn,frq) 
    using btree ;
create index "informix".i3_nperm on "informix".nperm (rec_tim,
    frq) using btree ;
create index "informix".i2_npiebom on "informix".npiebom (own_no,
    seq_no) using btree ;
create index "informix".i2_nprf on "informix".nprf (vsn,rec_tim) 
    using btree ;
create index "informix".i2_npged on "informix".npged (rec_no,eva_no) 
    using btree ;
create index "informix".i2_npnrl on "informix".npnrl (rec_typ,
    itm_no) using btree ;
create index "informix".i2_npqbd on "informix".npqbd (vsn,eff_tim) 
    using btree ;
create index "informix".i2_oritmlog on "informix".oritmlog (opr_ord) 
    using btree ;
create index "informix".i2_orexec2 on "informix".orexec2 (ord_no) 
    using btree ;
create index "informix".i2_npsvr on "informix".npsvr (vsn,rec_tim) 
    using btree ;
create index "informix".i2_sdmis on "informix".sdmis (rsc_num) 
    using btree ;
create index "informix".i2_sdrule on "informix".sdrule (lnk_num) 
    using btree ;
create index "informix".i3_sdrule on "informix".sdrule (eff_tim,
    stp_tim) using btree ;
create index "informix".i4_sdrule on "informix".sdrule (sat_val) 
    using btree ;
create index "informix".i5_sdrule on "informix".sdrule (end_val) 
    using btree ;
create index "informix".i2_sdcal on "informix".sdcal (mis_num,
    eff_tim) using btree ;
create index "informix".i3_sdcal on "informix".sdcal (lnk_num) 
    using btree ;
create index "informix".i4_sdcal on "informix".sdcal (eff_tim,
    sub) using btree ;
create index "informix".i5_sdcal on "informix".sdcal (eff_tim,
    stp_tim,emp_no) using btree ;
create index "informix".i2_emerda on "informix".emerda (act_dat,
    emr_typ,map_no) using btree ;
create index "informix".i2_nppfdhra on "informix".nppfdhra (chart,
    ast_dat) using btree ;
create index "informix".i2_dglleqr on "informix".dglleqr (chart,
    chg_cod) using btree ;
create index "informix".i2_moicda on "informix".moicda (dpt_no) 
    using btree ;
create index "informix".i2_molleqr on "informix".molleqr (vsn,
    chg_cod) using btree ;
create index "informix".i2_scptv on "informix".scptv (scp_no,ptv_dat) 
    using btree ;
create index "informix".i2_mocodif on "informix".mocodif (cri_no,
    ptc_cod) using btree ;
create index "informix".i3_mocodif on "informix".mocodif (ptc_cod,
    seq_no) using btree ;
create index "informix".i4_mocodif on "informix".mocodif (itm_cod,
    ptc_cod) using btree ;
create index "informix".i5_mocodif on "informix".mocodif (ptc_cod,
    eff_tim) using btree ;
create index "informix".i2_qmcadrm on "informix".qmcadrm (vsn,
    rec_typ) using btree ;
create index "informix".i2_qmcadrd on "informix".qmcadrd (rec_no,
    eva_no) using btree ;
create index "informix".i2_uccwc on "informix".uccwc (ccp_no,crd_loc,
    crd_tim) using btree ;
create index "informix".i2_ucccp on "informix".ucccp (typ,cod) 
    using btree ;
create index "informix".i3_ucccp on "informix".ucccp (typ,num) 
    using btree ;
create index "informix".i2_ocoditm2 on "informix".ocoditm2 (charg_no,
    seq_no) using btree ;
create index "informix".i2_ucusb on "informix".ucusb (emp_no,fun_cod) 
    using btree ;
create unique index "informix".i2_ofdedd on "informix".ofdedd 
    (dat,dct) using btree ;
create index "informix".i2_psemrnsr on "informix".psemrnsr (emp_no) 
    using btree ;
create index "informix".i2_mopcot on "informix".mopcot (vsn) using 
    btree ;
create index "informix".i3_mopcot on "informix".mopcot (ord_dat,
    ptc_no) using btree ;
create index "informix".i2_npqtr on "informix".npqtr (nqu_no,eva_no) 
    using btree ;
create index "informix".i2_npqtri on "informix".npqtri (qtr_no) 
    using btree ;
create index "informix".i3_npqtri on "informix".npqtri (frm_no) 
    using btree ;
create index "informix".i2_npqtrp on "informix".npqtrp (qtr_no) 
    using btree ;
create index "informix".i3_npqtrp on "informix".npqtrp (frm_no) 
    using btree ;
create index "informix".i2_npolls on "informix".npolls (cls_typ,
    itm_no) using btree ;
create index "informix".i1_mrsstmr on "informix".mrsstmr (vsn) 
    using btree ;
create unique index "informix".i2_mrsensar on "informix".mrsensar 
    (sst_no,eff_tim,aut_man) using btree ;
create index "informix".i2_emsndly on "informix".emsndly (dly_man) 
    using btree ;
create index "informix".i2_bmwtbd on "informix".bmwtbd (dat) using 
    btree ;
create index "informix".i2_moocn on "informix".moocn (chart,typ1,
    rec_tim desc) using btree ;
create index "informix".i3_moocn on "informix".moocn (rec_tim,
    vsn) using btree ;
create index "informix".i2_qmeierm on "informix".qmeierm (vsn) 
    using btree ;
create index "informix".i3_qmeierm on "informix".qmeierm (sys_typ,
    itm_typ,est_tim) using btree ;
create index "informix".i2_qmeierd on "informix".qmeierd (est_no,
    eva_no) using btree ;
create index "informix".i1_eobeerptstatus on "informix".eobeerptstatus 
    (avisitno) using btree ;
create index "informix".i1_eodierdischargent on "informix".eodierdischargent 
    (avisitno) using btree ;
create index "informix".i1_eodierfinaldiag on "informix".eodierfinaldiag 
    (avisitno) using btree ;
create index "informix".i1_ernursetpr on "informix".eosoernursetpr 
    (avisitno) using btree ;
create index "informix".i1_eosoerpatientddesc on "informix".eosoerpatientddesc 
    (avisitno) using btree ;
create index "informix".i1_eosoerpatientdiag on "informix".eosoerpatientdiag 
    (avisitno) using btree ;
create index "informix".i1_eosoerpatientpdesc on "informix".eosoerpatientpdesc 
    (avisitno) using btree ;
create index "informix".i1_eosoerpatientph on "informix".eosoerpatientph 
    (avisitno) using btree ;
create index "informix".i1_eosoerpatientphl on "informix".eosoerpatientphl 
    (avisitno) using btree ;
create index "informix".i1_eosoerpatientpot on "informix".eosoerpatientpot 
    (avisitno) using btree ;
create index "informix".i2_eosoerpatientpot on "informix".eosoerpatientpot 
    (achartno) using btree ;
create index "informix".i1_eosoerptobject on "informix".eosoerptobject 
    (avisitno) using btree ;
create index "informix".i1_eosoerptobjectl on "informix".eosoerptobjectl 
    (avisitno) using btree ;
create index "informix".i1_eosoerptocappic on "informix".eosoerptocappic 
    (avisitno) using btree ;
create index "informix".i1_eosoerptodrawpic on "informix".eosoerptodrawpic 
    (avisitno) using btree ;
create index "informix".i1_eosoerptprotocol on "informix".eosoerptprotocol 
    (avisitno) using btree ;
create index "informix".i1_erptprotoco on "informix".eosoerptprotocol 
    (ahospitalid,avisitno,aordertimes) using btree ;
create index "informix".i1_eosoerptsubject on "informix".eosoerptsubject 
    (avisitno) using btree ;
create index "informix".i1_eosonursingwarning on "informix".eosonursingwarning 
    (avisitno) using btree ;
create index "informix".i1_eosopainscore on "informix".eosopainscore 
    (avisitno) using btree ;
create index "informix".i1_eososoapdataforhis on "informix".eososoapdataforhis 
    (avisitno) using btree ;
create index "informix".i1_eososoapmaster on "informix".eososoapmaster 
    (avisitno) using btree ;
create index "informix".i2_eososoapmaster on "informix".eososoapmaster 
    (achartno) using btree ;
create index "informix".i1_eososoapuserlog on "informix".eososoapuserlog 
    (avisitno) using btree ;
create index "informix".i1_eosoerptsubjectl on "informix".eosoerptsubjectl 
    (avisitno) using btree ;
create index "informix".i1_eosoerpatientdiagl on "informix".eosoerpatientdiagl 
    (avisitno) using btree ;
create index "informix".i1_eosoerrpatientdrug on "informix".eosoerrpatientdrug 
    (avisitno) using btree ;
create index "informix".i1_eosoerrptdrugat on "informix".eosoerrptdrugat 
    (avisitno) using btree ;
create index "informix".i1_eosoerrpatientlab on "informix".eosoerrpatientlab 
    (avisitno) using btree ;
create unique index "informix".i2_ntgad on "informix".ntgad (ass_no,
    ass_typ,ass_seq) using btree ;
create index "informix".i2_ntgar on "informix".ntgar (ass_dat,
    chart) using btree ;
create index "informix".i2_mocmm on "informix".mocmm (vsn) using 
    btree ;
create index "informix".i3_mocmm on "informix".mocmm (ord_no) 
    using btree ;
create index "informix".i2_mocmi on "informix".mocmi (cnr_no,itm_no) 
    using btree ;
create index "informix".i2_mofib on "informix".mofib (msr_no,det_no) 
    using btree ;
create index "informix".i2_mooss on "informix".mooss (cls_typ,
    itm_no) using btree ;
create index "informix".i2_moolls on "informix".moolls (cls_typ,
    itm_no) using btree ;
create index "informix".i2_modds on "informix".modds (cls_typ,
    itm_no) using btree ;
create index "informix".i2_mootxt on "informix".mootxt (cls_typ,
    itm_no) using btree ;
create unique index "informix".i1_mools on "informix".mools (ols_no) 
    using btree ;
create index "informix".i2_mools on "informix".mools (cls_typ,
    itm_no) using btree ;
create index "informix".i2_ifdpm on "informix".ifdpm (pmg_dat) 
    using btree ;
create index "informix".i3_ifdpm on "informix".ifdpm (chart) using 
    btree ;
create index "informix".i2_ifdpmi on "informix".ifdpmi (ifd_no,
    itm_no) using btree ;
create index "informix".i2_ifdpms on "informix".ifdpms (snd_dat) 
    using btree ;
create unique index "informix".i1_cmcsd on "informix".cmcsd (chart,
    sub_seq) using btree ;
create unique index "informix".i1_cmcpird on "informix".cmcpird 
    (chart,can_typ,pat_dat) using btree ;
create unique index "informix".i1_cmcesd on "informix".cmcesd 
    (chart,can_typ,enr_dat,enr_typ) using btree ;
create unique index "informix".i1_cmcctd on "informix".cmcctd 
    (chart,can_typ,tre_sta,tre_typ) using btree ;
create index "informix".i1_cmccad on "informix".cmccad (chart,
    adv_dat) using btree ;
create index "informix".i1_cmctfur on "informix".cmctfur (chart,
    can_typ) using btree ;
create index "informix".i1_cmched on "informix".cmched (chart,
    edu_dat) using btree ;
create unique index "informix".i2_cmtmppd on "informix".cmtmppd 
    (mee_no,mee_dct) using btree ;
create unique index "informix".i2_cmtpcd on "informix".cmtpcd 
    (tem_dct,can_typ) using btree ;
create unique index "informix".i2_rodipr on "informix".rodipr 
    (chart,can_typ) using btree ;
create unique index "informix".i1_rocpsr on "informix".rocpsr 
    (dia_no,dia_sta,dia_lev) using btree ;
create index "informix".i2_rotgr on "informix".rotgr (chart,tre_eff,
    can_typ) using btree ;
create index "informix".i2_rgstr on "informix".rostr (tre_no,xra_dat,
    oth_rad) using btree ;
create index "informix".i2_rosldtr on "informix".rosldtr (tre_no,
    tre_pos) using btree ;
create index "informix".i3_rosldtr on "informix".rosldtr (sum_dat,
    sum_dos) using btree ;
create index "informix".i2_rosdtter on "informix".rosdtter (sum_no,
    tre_seq) using btree ;
create index "informix".i2_rodtsr on "informix".rodtsr (tre_pos,
    pos_nam) using btree ;
create index "informix".i2_eoged on "informix".eoged (atriageid,
    eva_no) using btree ;
create index "informix".i2_momsg on "informix".momsg (sed_tim,
    rec_man) using btree ;
create index "informix".i3_momsg on "informix".momsg (chart,sed_tim 
    desc) using btree ;
create index "informix".i4_momsg on "informix".momsg (rec_tim,
    rec_man) using btree ;
create index "informix".i2_mosmi on "informix".mosmi (lnk_no) 
    using btree ;
create index "informix".i3_mosmi on "informix".mosmi (rec_tim,
    fun_typ,sht_typ,tsc) using btree ;
create index "informix".i2_mosdi on "informix".mosdi (mst_no) 
    using btree ;
create unique index "informix".i2_roptar on "informix".roptar 
    (chart,can_typ,pta_dat,pta_typ) using btree ;
create index "informix".i2_mrpsrdd on "informix".mrpsrdd (chart,
    spc_mrk) using btree ;
create index "informix".i2_moccirp on "informix".moccirp (itm_no,
    ptc_cod) using btree ;
create index "informix".i2_mocfl on "informix".mocfl (lnk_no,cfm_typ) 
    using btree ;
create index "informix".i2_npieb2 on "informix".npieb2 (eva_no) 
    using btree ;
create unique index "informix".i2_moicpm on "informix".moicpm 
    (chg_cod,cmb_pst) using btree ;
create unique index "informix".i3_moicpm on "informix".moicpm 
    (icp_cod) using btree ;
create index "informix".i2_udsdr on "informix".udsdr (chart) using 
    btree ;
create index "informix".i3_udsdr on "informix".udsdr (exp_tim,
    tsc) using btree ;
create index "informix".i4_udsdr on "informix".udsdr (exp_tim,
    room,bed) using btree ;
create index "informix".i2_udsdd on "informix".udsdd (sdr_no) 
    using btree ;
create index "informix".i3_udsdd on "informix".udsdd (itm_no) 
    using btree ;
create index "informix".i2_udsddlog on "informix".udsddlog (det_no) 
    using btree ;
create index "informix".i2_udsdbd on "informix".udsdbd (sbd_typ,
    ref_cod) using btree ;
create unique index "informix".i2_nherst on "informix".nherst 
    (itm_cod,eff_dat) using btree ;
create unique index "informix".i2_nhudficd on "informix".nhudficd 
    (typ,icd_f,eff_dat) using btree ;
create index "informix".i2_mrvrd on "informix".mrvrd (vsn) using 
    btree ;
create unique index "informix".i2_nhietnms on "informix".nhietnms 
    (itm_f,eff_dat) using btree ;
create index "informix".i2_ifdmr on "informix".ifdmr (pmg_dat) 
    using btree ;
create index "informix".i3_ifdmr on "informix".ifdmr (chart) using 
    btree ;
create unique index "informix".i2_mracbd on "informix".mracbd 
    (id_no) using btree ;
create index "informix".i2_mocacdi on "informix".mocacdi (dtl_typ,
    lnk_no) using btree ;
create index "ap21".i2_ocmcpgmd2 on "ap21".ocmcpgmd2 (chart,use_dat) 
    using btree ;
create index "ap21".i3_ocmcpgmd2 on "ap21".ocmcpgmd2 (rtd) using 
    btree ;
create index "informix".i2_ocmcpgmd on "informix".ocmcpgmd (chart,
    use_dat) using btree ;
create index "informix".i3_ocmcpgmd on "informix".ocmcpgmd (rtd) 
    using btree ;
create unique index "informix".i2_cmcg on "informix".cmcg (grp_id,
    cus_id) using btree ;
create index "informix".i2_mrrmdm on "informix".mrrmdm (chart) 
    using btree ;
create index "informix".i3_mrrmdm on "informix".mrrmdm (did_no,
    typ) using btree ;
create index "informix".i2_moiolog2 on "informix".moiolog (lnk_num) 
    using btree ;
create index "informix".i2_moqr2 on "informix".moqr (chart,log_tim 
    desc) using btree ;
create index "informix".i2_sdcallog on "informix".sdcallog (evt_num) 
    using btree ;
create unique index "informix".i2_tddrgab on "informix".tddrgab 
    (fym,tym) using btree ;
create index "informix".i2_mopnmp on "informix".mopnmp (vsn) using 
    btree ;
create index "informix".i3_mopnmp on "informix".mopnmp (rtt) using 
    btree ;
create index "informix".i2_doolev on "informix".doolev (eff_dat,
    dct_no) using btree ;
create index "informix".i2_dolevoa on "informix".dolevoa (lev_no) 
    using btree ;
create unique index "informix".i2_dolevwa on "informix".dolevwa 
    (lev_no,eff_dat) using btree ;
create index "informix".i2_doolsp on "informix".doolsp (lnk_no) 
    using btree ;
create index "informix".i2_lbplval on "informix".lbplval (chart) 
    using btree ;
create unique index "informix".i2_nhtpgd on "informix".nhtpgd 
    (grp,pos) using btree ;
create unique index "informix".i2_mtval on "informix".mtval (mt_cod,
    typ) using btree ;
create index "informix".i2_moeci on "informix".moeci (chg_cod) 
    using btree ;
create unique index "informix".i1_bmbed on "informix".bmbed (room,
    bed) using btree ;
create unique index "informix".i4_bmbed on "informix".bmbed (acc_no) 
    using btree ;
create unique index "informix".i5_bmbed on "informix".bmbed (chart,
    toilet) using btree ;
create unique index "informix".i6_bmbed on "informix".bmbed (pre_chart,
    toilet) using btree ;
create index "informix".i7_bmbed on "informix".bmbed (ward) using 
    btree ;
create index "informix".i8_bmbed on "informix".bmbed (dpt_no) 
    using btree ;
create index "informix".i2_moitm on "informix".moitm (ord_no,seq_no) 
    using btree ;
create index "informix".i3_moitm on "informix".moitm (chg_cod,
    itm_no) using btree ;
create index "root".i4_moitm on "informix".moitm (chg_no,itm_no) 
    using btree ;
create unique index "informix".i2_mtbillgn on "informix".mtbillgn 
    (grp_cod,nhi_cod) using btree ;
create index "informix".i2_npcmr on "informix".npcmr (emp_no,eff_tim) 
    using btree ;
create index "informix".i2_npstcm on "informix".npstcm (stp_tim,
    dpt_no) using btree ;
create index "informix".i3_npstcm on "informix".npstcm (dpt_no,
    grp) using btree ;
create index "informix".i3_npgrb on "informix".npgrb (acc_no) 
    using btree ;
create index "informix".i4_npgrb on "informix".npgrb (eff_tim,
    stp_tim,dpt_no) using btree ;
create index "informix".i2_npoxls on "informix".npoxls (cls_typ,
    itm_no) using btree ;
create index "informix".i2_cmtmpd on "informix".cmtmpd (mee_no,
    can_typ,chart) using btree ;
create index "informix".i3_cmtmpd on "informix".cmtmpd (chart) 
    using btree ;
create unique index "informix".i2_cmctmr on "informix".cmctmr 
    (mee_dat,mee_typ) using btree ;
create unique index "informix".i1_cmpipd on "informix".cmpipd 
    (mpd_no,ind_dct) using btree ;
create index "informix".i2_moir on "informix".moir (typ,lnk_no) 
    using btree ;
create index "informix".i3_moir on "informix".moir (frm_no) using 
    btree ;
create index "informix".i2_dglmpr on "informix".dglmpr (lnk_no,
    rec_typ) using btree ;
create index "informix".i3_dglmpr on "informix".dglmpr (cmp_tim) 
    using btree ;
create index "informix".i4_dglmpr on "informix".dglmpr (prn_tim) 
    using btree ;
create index "informix".i2_npnsr on "informix".npnsr (cls_typ,
    itm_no) using btree ;
create index "informix".i2_pdpcr on "informix".pdpcr (chart,typ) 
    using btree ;
create index "informix".i2_cgppi on "informix".cgppi (pkg_cod) 
    using btree ;
create unique index "informix".i2_dci10cn on "informix".dci10cn 
    (icd_typ,icd_cod) using btree ;
create index "informix".i3_dci10cn on "informix".dci10cn (drg_cod) 
    using btree ;
create index "informix".i2_dcicdm on "informix".dcicdm (i09_cod) 
    using btree ;
create index "informix".i3_dcicdm on "informix".dcicdm (i10_cod) 
    using btree ;
create index "informix".i1_ooptmeet on "informix".ooptmeet (chart,
    visit_no) using btree ;
create index "informix".i1_ooptmret on "informix".ooptmret (chart,
    visit_no) using btree ;
create unique index "informix".i1_mrpbd99 on "informix".mrpbd99 
    (chart) using btree ;
create index "informix".i2_mrpbd99 on "informix".mrpbd99 (nam) 
    using btree ;
create unique index "informix".i3_mrpbd99 on "informix".mrpbd99 
    (id_no) using btree ;
create unique index "informix".i4_mrpbd99 on "informix".mrpbd99 
    (tel_h,nam) using btree ;
create unique index "informix".i2_emrunset on "informix".emrunset 
    (typ1,typ2) using btree ;
create index "informix".i2_mooir on "informix".mooir (chg_cod,
    typ) using btree ;
create index "informix".i2_pcvilned on "informix".pcvilned (acd_no) 
    using btree ;
create index "informix".i3_pcvilned on "informix".pcvilned (itm_cod) 
    using btree ;
create index "informix".i1_dgldap on "informix".dgldap (ord_no) 
    using btree ;
create index "informix".i2_dgldap on "informix".dgldap (apt_dat) 
    using btree ;
create index "informix".i2_npned on "informix".npned (ast_no) 
    using btree ;
create index "informix".i2_mofulog on "informix".mofulog (lnk_num) 
    using btree ;
create index "informix".i3_mofulog on "informix".mofulog (log_tim,
    fun_typ) using btree ;
create index "informix".i2_nhocmr on "informix".nhocmr (vsn) using 
    btree ;
create index "informix".i3_nhocmr on "informix".nhocmr (id_no) 
    using btree ;
create unique index "informix".i2_cgupbdm on "informix".cgupbdm 
    (cod_typ,cod,grp_id) using btree ;
create index "informix".i3_cgupbdm on "informix".cgupbdm (rul_typ) 
    using btree ;
create index "informix".i2_cgupbdr on "informix".cgupbdr (rul_no) 
    using btree ;
create index "informix".i1_cmcpd on "informix".cmcpd (chart,psy_dat) 
    using btree ;
create unique index "informix".i2_cmupl on "informix".cmupl (vsn,
    chart,icd_cod) using btree ;
create index "informix".i2_nppvlm on "informix".nppvlm (vsn) using 
    btree ;
create unique index "informix".i2_dgprn on "informix".dgprn (drg_cod,
    seq_no) using btree ;
create unique index "informix".i2_dgdbd4 on "informix".dgdbd4 
    (drg_cod,typ,use_way,seq_no) using btree ;
create unique index "informix".i2_nhailsoe on "informix".nhailsoe 
    (nhi_f,emp_no) using btree ;
create index "informix".i2_mrcnmqva on "informix".mrcnmqva (chart,
    eff_dat) using btree ;
create index "informix".i3_mrcnmqva on "informix".mrcnmqva (eff_dat,
    stp_dat) using btree ;
create index "informix".i4_mrcnmqva on "informix".mrcnmqva (eff_dat) 
    using btree ;
create unique index "informix".i2_dgdibd on "informix".dgdibd 
    (cod,itm,eff_dat) using btree ;
create index "informix".i2_mofht on "informix".mofht (fun_no) 
    using btree ;
create unique index "informix".i2_mrpsdsc on "informix".mrpsdsc 
    (chart,spc_mrk) using btree ;
create unique index "informix".i2_dcordmd on "informix".dcordmd 
    (chg_cod,typ) using btree ;
create index "informix".i2_nhpnpit on "informix".nhpnpit (chart,
    nhi_cod,frm_no) using btree ;
create index "informix".i2_dcdccr on "informix".dcdccr (dcc_no,
    itm_no) using btree ;
create index "informix".i2_bmhrpc on "informix".bmhrpc (vsn) using 
    btree ;
create index "informix".i2_dcdcc on "informix".dcdcc (dcc_tim,
    dcc_man) using btree ;
create index "informix".i3_dcdcc on "informix".dcdcc (dcc_tim,
    rpy_man) using btree ;
create index "informix".i2_dgadmcr on "informix".dgadmcr (chart) 
    using btree ;
create index "informix".i3_dgadmcr on "informix".dgadmcr (par_no) 
    using btree ;
create unique index "informix".i2_emumrt on "informix".emumrt 
    (evt_no,typ) using btree ;
create index "informix".i2_dcdcd on "informix".dcdcd (div_no,typ) 
    using btree ;
create index "informix".i2_mocrir on "informix".mocrir (typ1,lnk_no) 
    using btree ;
create index "informix".i2_cgqtsr on "informix".cgqtsr (itm_no,
    qts_typ) using btree ;
create index "informix".i2_hdpgd on "informix".hdpgd (yyymm,grp) 
    using btree ;
create index "informix".i2_cgdcdr on "informix".cgdcdr (ivc_no) 
    using btree ;
create index "informix".i3_cgdcdr on "informix".cgdcdr (vsn) using 
    btree ;
create index "informix".i2_npcrm on "informix".npcrm (vsn,typ) 
    using btree ;
create index "informix".i3_npcrm on "informix".npcrm (vsn,lnk_no) 
    using btree ;
create index "informix".i2_npcrd on "informix".npcrd (rec_no,eva_no) 
    using btree ;
create index "informix".i2_mrpcr on "informix".mrpcr (vsn,cst_typ) 
    using btree ;
create index "informix".i2_morsnm on "informix".morsnm (vsn,itm_no,
    typ_no) using btree ;
create index "informix".i2_morsndt on "informix".morsndt (rec_no) 
    using btree ;
create index "informix".i2_qmatsarm on "informix".qmatsarm (vsn,
    lnk_no) using btree ;
create index "informix".i3_qmatsarm on "informix".qmatsarm (lnk_no) 
    using btree ;
create unique index "informix".i2_qmatsari on "informix".qmatsari 
    (rec_no,eva_no,ext_no) using btree ;
create index "informix".i2_dcdicdm on "informix".dcdicdm (div_no,
    i09_cod) using btree ;
create index "informix".i3_dcdicdm on "informix".dcdicdm (div_no,
    i10_cod) using btree ;
create index "informix".i2_cgpra on "informix".cgpra (vsn) using 
    btree ;
create index "informix".i3_cgpra on "informix".cgpra (chg_tim) 
    using btree ;
create index "informix".i2_mrirbm on "informix".mrirbm (rsh_no) 
    using btree ;
create index "informix".i2_mrirbr on "informix".mrirbr (irb_cod) 
    using btree ;
create index "informix".i2_qmacarm on "informix".qmacarm (vsn,
    ast_typ) using btree ;
create index "informix".i2_qmacai on "informix".qmacai (ast_no,
    itm_no) using btree ;
create index "informix".i2_moltxt on "informix".moltxt (cls_typ,
    lnk_no) using btree ;
create index "informix".i2_rgfstdat on "informix".rgfstdat (chart,
    frv_dat) using btree ;
create index "informix".i2_cmrcud on "informix".cmrcud (rep_dat1) 
    using btree ;
create index "informix".i3_cmrcud on "informix".cmrcud (rep_dat2) 
    using btree ;
create index "informix".i4_cmrcud on "informix".cmrcud (id_no) 
    using btree ;
create index "informix".i2_cmncud on "informix".cmncud (id_no) 
    using btree ;
create index "informix".i3_cmncud on "informix".cmncud (dia_dat) 
    using btree ;
create index "informix".i1_cmcirtr on "informix".cmcirtr (chart,
    can_typ) using btree ;
create unique index "informix".i1_cmcdd on "informix".cmcdd (chart,
    can_typ) using btree ;
create index "informix".i1_cmctcrr on "informix".cmctcrr (chart,
    can_typ,cau_dat,cau_no) using btree ;
create index "informix".i2_cmctcrr on "informix".cmctcrr (sou_no,
    sou_typ) using btree ;
create index "informix".i1_cmcird on "informix".cmcird (chart,
    can_typ,ins_dat,ins_typ) using btree ;
create index "informix".i2_mofltstr on "informix".mofltstr (rec_typ,
    idx_str_1) using btree ;
create index "informix".i3_mofltstr on "informix".mofltstr (rec_typ,
    idx_str_2) using btree ;
create index "informix".i2_dcordmi on "informix".dcordmi (odm_no) 
    using btree ;
create index "informix".i2_emogi on "informix".emogi (grp_no) 
    using btree ;
create index "informix".i3_emogi on "informix".emogi (ord_no) 
    using btree ;
create index "informix".i2_osdesclog on "informix".osdesclog (order_no) 
    using btree ;
create index "informix".i3_osdesclog on "informix".osdesclog (dlr_no) 
    using btree ;
create index "informix".i2_ositemlog on "informix".ositemlog (rec_no) 
    using btree ;
create index "informix".i2_moimgm on "informix".moimgm (lnk_num) 
    using btree ;
create index "informix".i3_moimgm on "informix".moimgm (upd_tim,
    typ) using btree ;
create index "informix".i2_moimgd on "informix".moimgd (rec_no) 
    using btree ;
create index "informix".i3_moimgd on "informix".moimgd (rtt) using 
    btree ;
create index "informix".i2_rpmmrd on "informix".rpmmrd (ord_no) 
    using btree ;
create index "informix".i3_rpmmrd on "informix".rpmmrd (rec_man) 
    using btree ;
create unique index "informix".i2_cgval on "informix".cgval (chg_cod,
    typ,eff_dat) using btree ;
create unique index "informix".i2_mrrdr on "informix".mrrdr (idn,
    icd_cod,i10_cod,eff_dat) using btree ;
create index "informix".i2_uddir on "informix".uddir (itm_no) 
    using btree ;
create index "informix".i3_uddir on "informix".uddir (acc_no) 
    using btree ;
create index "informix".i4_uddir on "informix".uddir (rec_dat) 
    using btree ;
create index "informix".i5_uddir on "informix".uddir (rtt) using 
    btree ;
create index "informix".i2_hccdh on "informix".hccdh (id_no,stp_dat) 
    using btree ;
create index "informix".i3_hccdh on "informix".hccdh (crt_dat) 
    using btree ;
create index "informix".i2_nhnicatc on "informix".nhnicatc (nhi_cod,
    eff_dat) using btree ;
create index "informix".i3_nhnicatc on "informix".nhnicatc (atc_cod,
    eff_dat) using btree ;
create unique index "informix".i2_rgscdv1 on "informix".rgscdv 
    (visit_dat,sft,room,dct_no,div_no) using btree ;
create unique index "informix".i2_rgwscdv1 on "informix".rgwscdv 
    (wek_day,sft,room,div_no,stp_dat desc) using btree ;
create index "informix".i1_moepdsc on "informix".moepdsc (vsn 
    desc) using btree ;
create index "informix".i2_moepdsc on "informix".moepdsc (map_no,
    tsc,pre_dat desc,pre_hm desc) using btree ;
create index "informix".i3_moepdsc on "informix".moepdsc (exe_dat 
    desc,map_no,exe_hm desc) using btree ;
create index "informix".i1_moepitm on "informix".moepitm (epd_no,
    seq_no) using btree ;
create index "informix".i2_moepitm on "informix".moepitm (chg_cod,
    epi_no) using btree ;
create index "informix".i1_eosoerpatientddesc2 on "informix".eosoerpatientddesc2 
    (avisitno) using btree ;
create index "informix".i1_eosoerpatientdiag2 on "informix".eosoerpatientdiag2 
    (avisitno) using btree ;
create index "informix".i1_eosoerpatientdiagl2 on "informix".eosoerpatientdiagl2 
    (avisitno) using btree ;
create index "informix".i2_mecr on "informix".mecr (met_tim) using 
    btree ;
create index "informix".i2_mepr on "informix".mepr (met_no) using 
    btree ;
create index "informix".i2_moipcl on "informix".moipcl (vsn) using 
    btree ;
create unique index "informix".i3_moipcl on "informix".moipcl 
    (chart,typ,itm,ass_dat,ass_hm) using btree ;
create index "informix".i2_peerm on "informix".peerm (chart,frq) 
    using btree ;
create index "informix".i2_peged on "informix".peged (rec_no,eva_no) 
    using btree ;
create index "informix".i2_peerl on "informix".peerl (rec_typ,
    itm_no) using btree ;
create index "informix".i2_fmmrimgd on "informix".fmmrimgd (rec_no) 
    using btree ;
create index "informix".i3_fmmrimgd on "informix".fmmrimgd (uno) 
    using btree ;
create index "informix".i2_fmmrimgm on "informix".fmmrimgm (lnk_num) 
    using btree ;
create index "informix".i3_fmmrimgm on "informix".fmmrimgm (chart,
    sed_tim,typ1,typ2) using btree ;
create index "informix".i4_fmmrimgm on "informix".fmmrimgm (vsn) 
    using btree ;
create index "informix".i5_fmmrimgm on "informix".fmmrimgm (oth_lnk) 
    using btree ;
create index "root".i2_mtoitg on "root".mtoitg (typ,sts) using 
    btree ;
create index "informix".i3_mtoitg on "root".mtoitg (mt_cod) using 
    btree ;
create unique index "informix".i2_nhuapi on "informix".nhuapi 
    (chg_cod,nhi_cod,dat_f) using btree ;
create index "informix".i3_nhuapi on "informix".nhuapi (nhi_cod) 
    using btree ;
create index "informix".i2_mtoibcr on "informix".mtoibcr (itm_no,
    seq_no) using btree ;
create index "informix".i3_mtoibcr on "informix".mtoibcr (lot_no) 
    using btree ;
create index "informix".i2_fmmrimgl on "informix".fmmrimgl (det_no,
    imy_typ) using btree ;
create index "informix".i3_fmmrimgl on "informix".fmmrimgl (uno) 
    using btree ;
create index "informix".i2_nhdin on "informix".nhdin (ing_cod,
    eff_dat) using btree ;
create index "informix".i2_mocfr on "informix".mocfr (lnk_no) 
    using btree ;
create index "informix".i3_mocfr on "informix".mocfr (rtt,rtp) 
    using btree ;
create index "informix".i2_dgparm on "informix".dgparm (vsn) using 
    btree ;
create index "informix".i3_dgparm on "informix".dgparm (chart,
    par_dat) using btree ;
create index "informix".i2_dgpari on "informix".dgpari (par_no,
    itm_no) using btree ;
create index "informix".i2_cgcodctr on "informix".cgcodctr (chg_cod,
    typ) using btree ;
create index "informix".i2_mocmi2 on "informix".mocmi2 (sub_no,
    itm_no) using btree ;
create index "informix".i2_mocmm2 on "informix".mocmm2 (ord_no) 
    using btree ;
create index "informix".i2_mootxt2 on "informix".mootxt2 (cls_typ,
    itm_no) using btree ;
create index "informix".i2_mooss2 on "informix".mooss2 (cls_typ,
    itm_no) using btree ;
create index "informix".i2d_mools2 on "informix".mools2 (cls_typ,
    itm_no) using btree ;
create index "informix".i2_modds2 on "informix".modds2 (cls_typ,
    itm_no) using btree ;
create index "informix".i2_moolls2 on "informix".moolls2 (cls_typ,
    itm_no) using btree ;
create index "informix".i2_ifdpmsi on "informix".ifdpmsi (sts_no,
    itm_no) using btree ;
create unique index "informix".i2_morur on "informix".morur (ord_no,
    map_no,vis_typ) using btree ;
create index "informix".i3_morur on "informix".morur (asg_dat,
    adm_dr,tsc) using btree ;
create unique index "informix".i2_pdctbd on "informix".pdctbd 
    (typ,dat_f) using btree ;
create unique index "informix".i2_empoia on "informix".empoia 
    (map_no,itm_cod,sht_typ) using btree ;
create index "informix".i2_nptjr on "informix".nptjr (ord_no) 
    using btree ;
create unique index "informix".i3_nptjr on "informix".nptjr (bpd_n) 
    using btree ;
create index "informix".i2_moctrl on "informix".moctrl (lnk_no) 
    using btree ;
create index "informix".i3_moctrl on "informix".moctrl (log_tim,
    log_typ) using btree ;
create unique index "informix".i2_dci10fa on "informix".dci10fa 
    (yyyymm,typ1,typ2,emp_no,div_no,i10_cod) using btree ;
create index "informix".i1_dccdspcs on "informix".dccdspcs (icd_cod) 
    using btree ;
create index "informix".i2_cndcnr on "informix".cndcnr (dag_no) 
    using btree ;
create index "informix".i3_cndcnr on "informix".cndcnr (apt_dat) 
    using btree ;
create unique index "informix".i2_mrvci on "informix".mrvci (vsn,
    typ) using btree ;
create unique index "informix".i2_rfhbrd on "informix".rfhbrd 
    (hsp_no,seq) using btree ;
create index "informix".i2_npotxt on "informix".npotxt (cls_typ,
    itm_no) using btree ;
create index "informix".i2_smdmola on "informix".smdmola (sub_no,
    yymm,div_no) using btree ;
create index "informix".i3_smdmola on "informix".smdmola (dct,
    typ) using btree ;
create unique index "informix".i2_monot2 on "informix".monot (vsn,
    typ,seq_no) using btree ;
create index "informix".i2_mrvts on "informix".mrvts (lnk_no) 
    using btree ;
create index "informix".i2_ifdpmsr on "informix".ifdpmsr (sts_no) 
    using btree ;
create index "informix".i2_scerm on "informix".scerm (erm_tim,
    scp_no) using btree ;
create index "informix".i2_scedf on "informix".scedf (erm_no,eva_no) 
    using btree ;
create index "informix".i2_cgpap on "informix".cgpap (chart) using 
    btree ;
create index "informix".i2_tdcctipc on "informix".tdcctipc (chg_cod,
    eff_dat) using btree ;
create index "informix".i2_mofnd on "informix".mofnd (mst_no) 
    using btree ;
create unique index "informix".i2_nssmtc on "informix".nssmtc 
    (wrd,typ) using btree ;
create index "informix".i2_mofnm on "informix".mofnm (lnk_no,itm) 
    using btree ;
create index "informix".i3_mofnm on "informix".mofnm (rec_tim,
    itm) using btree ;
create index "informix".i2_cmrols on "informix".cmrols (res_no) 
    using btree ;
create index "informix".i2_cmirm on "informix".cmirm (chart,can_typ,
    rpt_dat) using btree ;
create index "informix".i3_cmirm on "informix".cmirm (ord_dat) 
    using btree ;
create index "informix".i2_cmird on "informix".cmird (con_no,itm_no,
    seq_no) using btree ;
create unique index "informix".i2_fofib on "informix".fofib (sys_no,
    msr_no,det_no,lnk_no) using btree ;
create index "informix".i2_fooss on "informix".fooss (ird_no) 
    using btree ;
create index "informix".i2_fools on "informix".fools (ird_no) 
    using btree ;
create index "informix".i2_foolls on "informix".foolls (ird_no) 
    using btree ;
create index "informix".i2_footxt on "informix".footxt (ird_no) 
    using btree ;
create unique index "informix".i2_tdccrdag on "informix".tdccrdag 
    (icd_grp,icd_cod,eff_dat) using btree ;
create unique index "informix".i2_tdccrda on "informix".tdccrda 
    (npd_cod,icd_grp,eff_dat) using btree ;
create index "informix".i2_fodds on "informix".fodds (ird_no) 
    using btree ;
create unique index "informix".i2_ucapes on "informix".ucapes 
    (user_id) using btree ;
create index "informix".i2_cmspr on "informix".cmspr (lnk_no,cir_no) 
    using btree ;
create index "informix".i2_cmcrm on "informix".cmcrm (lnk_no,cir_no) 
    using btree ;
create index "informix".i2_cmcrd on "informix".cmcrd (rec_no,eva_no) 
    using btree ;
create index "informix".i2_cmpcr on "informix".cmpcr (chart) using 
    btree ;
create index "informix".i3_cmpcr on "informix".cmpcr (vsn) using 
    btree ;
create index "informix".i4_cmpcr on "informix".cmpcr (eff_dat) 
    using btree ;
create index "informix".i5_cmpcr on "informix".cmpcr (stp_dat) 
    using btree ;
create index "informix".i2_cgmie on "informix".cgmie (chg_cod,
    typ) using btree ;
create index "informix".i2_tddrgspm on "informix".tddrgspm (drg_cod_f,
    drg_cod_t) using btree ;
create index "informix".i2_tddrgspd on "informix".tddrgspd (mst_no) 
    using btree ;
create index "informix".i3_tddrgspd on "informix".tddrgspd (icd_cod) 
    using btree ;
create index "informix".i2_mrpbie on "informix".mrpbie (chart) 
    using btree ;
create unique index "informix".i2_xrpdip on "informix".xrpdip 
    (chart,acs_no) using btree ;
create index "informix".i2_hcpicc on "informix".hcpicc (icd_cod) 
    using btree ;
create index "informix".i3_hcpicc on "informix".hcpicc (cod) using 
    btree ;
create index "informix".i2_eaeiicm on "informix".eaeiicm (chart) 
    using btree ;
create index "informix".i2_eaeiici on "informix".eaeiici (rec_no,
    eva_no) using btree ;
create index "informix".i2_eaeiicr on "informix".eaeiicr (rec_no) 
    using btree ;
create unique index "informix".i2_nhtdaacd on "informix".nhtdaacd 
    (chart,adm_dat,dcg_dat) using btree ;
create index "informix".i3_nhtdaacd on "informix".nhtdaacd (dcg_dat,
    dct_no) using btree ;
create unique index "informix".i2_cgqec on "informix".cgqec (chart,
    chg_cod) using btree ;
create index "informix".i2_cgqecd on "informix".cgqecd (qec_no,
    exe_dat) using btree ;
create unique index "informix".i2_cgdud on "informix".cgdud (chart,
    chg_cod,rec_typ) using btree ;
create index "informix".i1_dccdrc on "informix".dccdrc (frm_typ,
    cnc_no) using btree ;
create index "informix".i2_eoptbr on "informix".eoptbr (trg_tim) 
    using btree ;
create index "informix".i3_eoptbr on "informix".eoptbr (vsn) using 
    btree ;
create index "informix".i2_osppbr on "informix".osppbr (vsn) using 
    btree ;
create index "informix".i2_ospptr on "informix".ospptr (rec_no) 
    using btree ;
create index "informix".i2_ospprr on "informix".ospprr (rec_no) 
    using btree ;
create index "informix".i2_ntird on "informix".ntird (ass_no,itm_no,
    seq_no) using btree ;
create index "informix".i2_ntrcr on "informix".ntrcr (acc_no) 
    using btree ;
create index "informix".i3_ntrcr on "informix".ntrcr (rc_typ) 
    using btree ;
create index "informix".i2_nteid on "informix".nteid (ass_no) 
    using btree ;
create index "informix".i2_ntdwd on "informix".ntdwd (emp_no) 
    using btree ;
create index "informix".i2_nttfnud on "informix".nttfnud (tub_cod) 
    using btree ;
create index "informix".i2_mrwpr on "informix".mrwpr (lnk_no) 
    using btree ;
create unique index "informix".i2_cgnhdud on "informix".cgnhdud 
    (chart,nhi_cod,rec_typ) using btree ;
create index "informix".i2_cmrf on "informix".cmrf (vsn,rec_tim) 
    using btree ;
create index "informix".i3_cmrf on "informix".cmrf (lnk_no) using 
    btree ;
create index "informix".i2_hccexmh on "informix".hccexmh (id_no,
    stp_dat) using btree ;
create index "informix".i3_hccexmh on "informix".hccexmh (crt_dat) 
    using btree ;
create index "informix".i2_hccoprh on "informix".hccoprh (id_no,
    stp_dat) using btree ;
create index "informix".i3_hccoprh on "informix".hccoprh (crt_dat) 
    using btree ;
create index "informix".i2_hccdenh on "informix".hccdenh (id_no,
    stp_dat) using btree ;
create index "informix".i3_hccdenh on "informix".hccdenh (crt_dat) 
    using btree ;
create index "informix".i2_hccalgh on "informix".hccalgh (id_no,
    upl_dat) using btree ;
create index "informix".i3_hccalgh on "informix".hccalgh (crt_dat) 
    using btree ;
create index "informix".i2_nhcodecn on "informix".nhcodecn (typ,
    cod) using btree ;
create unique index "informix".i2_dgdfi on "informix".dgdfi (chg_cod,
    eff_tim) using btree ;
create index "informix".i2_rgdie on "informix".rgdie (vsn) using 
    btree ;
create unique index "informix".i2_pfdpdsb on "informix".pfdpdsb 
    (ord_no,itm_no,emp_no) using btree ;
create index "informix".i2_ntcar on "informix".ntcar (chart) using 
    btree ;
create index "informix".i3_ntcar on "informix".ntcar (ass_dat) 
    using btree ;
create index "informix".i2_dgdbmr on "informix".dgdbmr (vsn) using 
    btree ;
create index "informix".i3_dgdbmr on "informix".dgdbmr (gen_tim) 
    using btree ;
create index "informix".i2_dgdbir on "informix".dgdbir (bmr_no) 
    using btree ;
create index "informix".i3_dgdbir on "informix".dgdbir (bar_cod) 
    using btree ;
create index "informix".i2_cmmtr on "informix".cmmtr (lnk_no) 
    using btree ;
create index "informix".i3_cmmtr on "informix".cmmtr (chart) using 
    btree ;
create index "informix".i4_cmmtr on "informix".cmmtr (ord_dat) 
    using btree ;
create index "informix".i2_mrisrant on "informix".mrisrant (evt_no) 
    using btree ;
create index "informix".i3_mrisrant on "informix".mrisrant (cmp_dat) 
    using btree ;
create index "informix".i4_mrisrant on "informix".mrisrant (id_no) 
    using btree ;
create index "informix".i2_catkbd on "informix".catkbd (lnk_no) 
    using btree ;
create unique index "informix".i2_dcdnf10 on "informix".dcdnf10 
    (icd_cod,typ) using btree ;
create unique index "informix".i2_psdmses on "informix".psdmses 
    (emp_no,eff_dat,typ,seq_no) using btree ;
create unique index "root".i2_mmreq3 on "root".mmreq3 (sed_no,
    evt_typ) using btree ;
create index "root".i3_mmreq3 on "root".mmreq3 (rtt) using btree 
    ;
create index "informix".i2_bmathinf on "informix".bmathinf (emp_no,
    acc_no) using btree ;
create unique index "informix".i3_bmathinf on "informix".bmathinf 
    (acc_no,eff_tim,stp_tim,typ) using btree ;
create unique index "informix".i2_pbgesn on "informix".pbgesn 
    (evt_typ,evt_sou) using btree ;
create index "informix".i2_dgdsp on "informix".dgdsp (chart) using 
    btree ;
create index "informix".i3_dgdsp on "informix".dgdsp (out_tim) 
    using btree ;
create index "informix".i4_dgdsp on "informix".dgdsp (bar_cod) 
    using btree ;
create unique index "informix".i1_pseepdat on "informix".pseepdat 
    (eep_no) using btree ;
create index "informix".i2_momclog on "informix".momclog (lnk_num) 
    using btree ;
create index "informix".i3_momclog on "informix".momclog (ctl_cod,
    log_tim) using btree ;
create index "informix".i2_zzgacn on "informix".zzgacn (lnk_no) 
    using btree ;
create index "informix".i3_zzgacn on "informix".zzgacn (cod) using 
    btree ;
create index "informix".i2_ifdcd on "informix".ifdcd (gac_no) 
    using btree ;
create index "informix".i3_ifdcd on "informix".ifdcd (diag_cod) 
    using btree ;
create index "informix".i2_ifdbd on "informix".ifdbd (cod) using 
    btree ;
create index "informix".i2_mowpr on "informix".mowpr (vsn) using 
    btree ;
create index "informix".i3_mowpr on "informix".mowpr (wpr_tim) 
    using btree ;
create index "informix".i4_mowpr on "informix".mowpr (lnk_no) 
    using btree ;
create index "informix".i2_ossublog on "informix".ossublog (order_no) 
    using btree ;
create index "informix".i2_osobjlog on "informix".osobjlog (order_no) 
    using btree ;
create index "informix".i2_oscmtlog on "informix".oscmtlog (order_no) 
    using btree ;
create index "informix".i2_oransitl on "informix".oransitl (ord_no) 
    using btree ;
create index "informix".i3_oransitl on "informix".oransitl (ans_ord) 
    using btree ;
create index "informix".i2_catmf on "informix".catmf (cnr_no) 
    using btree ;
create index "informix".i2_cartf on "informix".cartf (tmf_no,cur_typ) 
    using btree ;
create index "informix".i2_catdf on "informix".catdf (tmf_no) 
    using btree ;
create index "informix".i2_caast on "informix".caast (chart) using 
    btree ;
create index "informix".i2_caasid on "informix".caasid (sim_no) 
    using btree ;
create index "informix".i2_cacmf on "informix".cacmf (tmf_no,cur_typ) 
    using btree ;
create index "informix".i3_cacmf on "informix".cacmf (itm_cod) 
    using btree ;
create index "informix".i2_mevtd on "informix".mevtd (lnk_no,typ) 
    using btree ;
create index "informix".i2_mopfr on "informix".mopfr (act_tim) 
    using btree ;
create index "informix".i3_mopfr on "informix".mopfr (lnk_no) 
    using btree ;
create index "informix".i2_mopfrpkg on "informix".mopfrpkg (pkg_no) 
    using btree ;
create index "informix".i3_mopfrpkg on "informix".mopfrpkg (evt_no) 
    using btree ;
create index "informix".i2_hccexrh on "informix".hccexrh (id_no,
    rep_dat) using btree ;
create index "informix".i3_hccexrh on "informix".hccexrh (crt_dat) 
    using btree ;
create index "informix".i2_hccdcsh on "informix".hccdcsh (id_no) 
    using btree ;
create index "informix".i3_hccdcsh on "informix".hccdcsh (crt_dat) 
    using btree ;
create index "informix".i2_hccphmh on "informix".hccphmh (id_no,
    stp_dat) using btree ;
create index "informix".i3_hccphmh on "informix".hccphmh (crt_dat) 
    using btree ;
create index "informix".i2_hccetmh on "informix".hccetmh (id_no,
    opr_dat) using btree ;
create index "informix".i3_hccetmh on "informix".hccetmh (crt_dat) 
    using btree ;
create index "informix".i2_mosysprm on "informix".mosysprm (eff_tim) 
    using btree ;
create unique index "informix".i2_dci10cn4 on "informix".dci10cn4 
    (icd_typ,icd_cod) using btree ;
create index "informix".i3_dci10cn4 on "informix".dci10cn4 (drg_cod) 
    using btree ;
create index "informix".i2_mocorif on "informix".mocorif (ptc_cod,
    tc,eff_tim) using btree ;
create unique index "informix".i2_mochgtyp on "informix".mochgtyp 
    (chg_cod,voc_no) using btree ;
create unique index "informix".i1_moitmvoc on "informix".moitmvoc 
    (itm_no) using btree ;
create index "informix".i2_movctrdf on "informix".movctrdf (chart) 
    using btree ;
create index "informix".i3_movctrdf on "informix".movctrdf (lnk_num) 
    using btree ;
create unique index "informix".i2_tddrgnfc4 on "informix".tddrgnfc4 
    (drg_cod,eff_ym) using btree ;
create unique index "informix".i2_tdncbd4 on "informix".tdncbd4 
    (mdc,eff_ym) using btree ;
create unique index "informix".i2_rfiambd on "informix".rfiambd 
    (rfi_id,eff_dat,stp_dat) using btree ;
create index "informix".i2_eherm on "informix".eherm (vsn) using 
    btree ;
create index "informix".i3_eherm on "informix".eherm (sed_tim) 
    using btree ;
create unique index "informix".i2_eherd on "informix".eherd (erm_no,
    itm_typ) using btree ;
create index "informix".i3_eherd on "informix".eherd (lnk_no) 
    using btree ;
create index "informix".i2_dgcdqm on "informix".dgcdqm (chg_cod,
    eff_dat) using btree ;
create index "informix".i3_dgcdqm on "informix".dgcdqm (chart,
    eff_dat) using btree ;
create index "informix".i2_dgcdqr on "informix".dgcdqr (ctl_no) 
    using btree ;
create index "informix".i3_dgcdqr on "informix".dgcdqr (lnk_no) 
    using btree ;
create unique index "informix".i2_tddrgab4 on "informix".tddrgab4 
    (fym,tym) using btree ;
create index "informix".i2_xrcalist on "informix".xrcalist (ord_no) 
    using btree ;
create index "informix".i2_osrfodp on "informix".osrfodp (rfo_no) 
    using btree ;
create index "informix".i2_osrfodr on "informix".osrfodr (rfo_vsn) 
    using btree ;
create index "informix".i3_osrfodr on "informix".osrfodr (frm_vsn) 
    using btree ;
create index "informix".i4_osrfodr on "informix".osrfodr (rpy_tim,
    rfo_dct) using btree ;
create index "informix".i5_osrfodr on "informix".osrfodr (rfo_tim,
    frm_dct) using btree ;
create unique index "informix".i2_tdh10ccd on "informix".tdh10ccd 
    (icd_cod_m,icd_cod_c) using btree ;
create index "informix".i2_modcui10 on "informix".modcui10 (typ,
    div_no,icd_cod) using btree ;
create index "informix".i2_mrrmp on "informix".mrrmp (lnk_no) 
    using btree ;
create index "informix".i3_mrrmp on "informix".mrrmp (rtt) using 
    btree ;
create unique index "informix".i2_rgrup1 on "informix".rgrup (opd_er,
    charg_typ,f_r,pt_typ,sft,week,eff_dat) using btree ;
create unique index "informix".i2_mrqar1 on "informix".mrqar1 
    (chart,dat,typ) using btree ;
create index "informix".i2_emtmpq on "informix".emtmpq (emq_typ2) 
    using btree ;
create index "informix".i2_emtmpql on "informix".emtmpql (lnk_no,
    cmp_tim,emq_typ1,emq_typ2) using btree ;
create index "informix".i3_emtmpql on "informix".emtmpql (cmp_tim,
    emq_typ1,emq_typ2) using btree ;
create index "informix".i2_mostts on "informix".mostts (lnk_num) 
    using btree ;
create index "informix".i2_rgdiel on "informix".rgdiel (vsn) using 
    btree ;
create index "informix".i2_rgdrdie on "informix".rgdrdie (dct_no) 
    using btree ;
create index "informix".i2_rfebdi on "informix".rfebdi (id_no) 
    using btree ;
create index "informix".i3_rfebdi on "informix".rfebdi (eff_dat) 
    using btree ;
create index "informix".i4_rfebdi on "informix".rfebdi (rf_tr_no) 
    using btree ;
create index "informix".i2_rfebdo on "informix".rfebdo (id_no) 
    using btree ;
create index "informix".i3_rfebdo on "informix".rfebdo (eff_dat) 
    using btree ;
create index "informix".i4_rfebdo on "informix".rfebdo (rf_tr_no) 
    using btree ;
create index "informix".i2_lbdema on "informix".lbdema (chart) 
    using btree ;
create index "informix".i3_lbdema on "informix".lbdema (exe_dat,
    tsc,typ) using btree ;
create index "informix".i4_lbdema on "informix".lbdema (exe_dat,
    chg_cod) using btree ;
create index "informix".i5_lbdema on "informix".lbdema (pre_dat) 
    using btree ;
create index "informix".i6_lbdema on "informix".lbdema (pay_dat) 
    using btree ;
create unique index "informix".i2_cgromdcr on "informix".cgromdcr 
    (room,bed,eff_dat,stp_dat) using btree ;
create unique index "informix".i2_cgtsrrf on "informix".cgtsrrf 
    (typ_cod,itm_no,eff_dat) using btree ;
create unique index "informix".i2_lbiisf on "informix".lbiisf 
    (chg_cod,eff_tim,src,typ) using btree ;
create unique index "informix".i2_ehpvcrf on "informix".ehpvcrf 
    (typ,cod) using btree ;
create index "informix".i2_udocr on "informix".udocr (det_no) 
    using btree ;
create index "informix".i2_cgvda on "informix".cgvda (vsn) using 
    btree ;
create index "informix".i3_cgvda on "informix".cgvda (crt_tim) 
    using btree ;
create index "informix".i4_cgvda on "informix".cgvda (apv_tim) 
    using btree ;
create unique index "informix".i2_dcidie on "informix".dcidie 
    (icd_cod,cor_typ,val) using btree ;
create index "informix".i3_dcidie on "informix".dcidie (cor_cod) 
    using btree ;
create index "informix".i2_dgcdqml on "informix".dgcdqml (lnk_no) 
    using btree ;
create index "informix".i3_dgcdqml on "informix".dgcdqml (log_tim) 
    using btree ;
create index "informix".i2_moocr on "informix".moocr (vsn,chg_cod) 
    using btree ;
create index "informix".i2_padsc on "informix".padsc (ord_no) 
    using btree ;
create index "informix".i2_dgdiad on "informix".dgdiad (srv_cod) 
    using btree ;
create index "informix".i3_dgdiad on "informix".dgdiad (clt_cod) 
    using btree ;
create index "informix".i2_dgdbde on "informix".dgdbde (lnk_num) 
    using btree ;
create index "informix".i3_dgdbde on "informix".dgdbde (val) using 
    btree ;
create index "informix".i2_dgotxt on "informix".dgotxt (cls_typ,
    lnk_num) using btree ;
create index "informix".i2_xrpodip on "informix".xrpodip (chart) 
    using btree ;
create index "informix".i3_xrpodip on "informix".xrpodip (upl_tim) 
    using btree ;
create index "informix".i2_bmptba on "informix".bmptba (chart) 
    using btree ;
create index "informix".i3_bmptba on "informix".bmptba (acc_no) 
    using btree ;
create index "informix".i4_bmptba on "informix".bmptba (frm_no) 
    using btree ;
create index "informix".i2_rgdmd on "informix".rgdmd (sd_no) using 
    btree ;
create index "informix".i2_rgdrd on "informix".rgdrd (sd_no) using 
    btree ;
create unique index "informix".i2_lbcodcmd on "informix".lbcodcmd 
    (typ,cod,stp_tim) using btree ;
create index "informix".i3_lbcodcmd on "informix".lbcodcmd (nam_s) 
    using btree ;
create index "informix".i2_cgpcmd on "informix".cgpcmd (chart) 
    using btree ;
create index "informix".i3_cgpcmd on "informix".cgpcmd (trn_tim) 
    using btree ;
create index "informix".i2_cgpcvr on "informix".cgpcvr (pcm_no) 
    using btree ;
create index "informix".i2_mrlldat on "informix".mrlldat (id_no) 
    using btree ;
create index "informix".i3_mrlldat on "informix".mrlldat (lnk_no) 
    using btree ;
create index "informix".i2_smlabrpt on "informix".smlabrpt (sed_no) 
    using btree ;
create index "informix".i3_smlabrpt on "informix".smlabrpt (chart,
    chg_cod) using btree ;
create index "informix".i2_bmrup on "informix".bmrup (acc_no) 
    using btree ;
create unique index "informix".i3_bmrup on "informix".bmrup (val) 
    using btree ;
create index "informix".i2_bmmakie on "informix".bmmakie (eff_tim,
    typ,val) using btree ;
create index "informix".i3_bmmakie on "informix".bmmakie (acc_no) 
    using btree ;
create index "informix".i2_icatfee on "informix".icatfee (acc_no) 
    using btree ;
create unique index "informix".i2_bmwrdcnt on "informix".bmwrdcnt 
    (dat,ward) using btree ;
create index "informix".i2_motbd on "informix".motbd (eff_dat,
    typ) using btree ;
create index "informix".i2_motrd on "informix".motrd (id_no) using 
    btree ;
create index "informix".i3_motrd on "informix".motrd (lnk_no) 
    using btree ;
create index "informix".i2_hccish on "informix".hccish (id_no) 
    using btree ;
create index "informix".i2_padscd on "informix".padscd (pal_no) 
    using btree ;
create unique index "informix".i2_exregrul on "informix".exregrul 
    (typ,item_cod,eff_tim) using btree ;
create index "informix".i2_oomtlrl on "informix".oomtlrl (vsn) 
    using btree ;
create index "informix".i3_oomtlrl on "informix".oomtlrl (res_dat,
    itm) using btree ;
create unique index "informix".i2_rrchgpar on "informix".rrchgpar 
    (chg_typ,par_typ1,par_typ2,par_typ3) using btree ;
create unique index "informix".i2_hecm on "informix".hecm (bar_cod) 
    using btree ;
create index "informix".i3_hecm on "informix".hecm (prj_no) using 
    btree ;
create index "informix".i4_hecm on "informix".hecm (hec_no) using 
    btree ;
create index "informix".i5_hecm on "informix".hecm (vsn) using 
    btree ;
create index "informix".i6_hecm on "informix".hecm (ana_sis) using 
    btree ;
create index "informix".i2_hecsi on "informix".hecsi (cm_no) using 
    btree ;
create index "informix".i2_hecsd on "informix".hecsd (csi_no) 
    using btree ;
create index "informix".i2_erdisaster on "informix".erdisaster 
    (vsn) using btree ;
create index "informix".i3_erdisaster on "informix".erdisaster 
    (report_tim) using btree ;
create unique index "informix".i2_moval2 on "informix".moval2 
    (lnk_num,seq_no,typ) using btree ;
create index "informix".i2_progbd on "informix".progbd (org_nam) 
    using btree ;
create index "informix".i3_progbd on "informix".progbd (org_no) 
    using btree ;
create index "informix".i4_progbd on "informix".progbd (eff_dat,
    stp_dat) using btree ;
create index "informix".i5_progbd on "informix".progbd (ogt_no) 
    using btree ;
create index "informix".i2_cgepkgi on "informix".cgepkgi (pkg_cod) 
    using btree ;
create index "informix".i2_ifdpbc on "informix".ifdpbc (rec_no) 
    using btree ;
create index "informix".i2_bmdast on "informix".bmdast (acc_no,
    eff_tim) using btree ;
create index "informix".i3_bmdast on "informix".bmdast (acc_no,
    typ,frm_no) using btree ;
create unique index "informix".i2_pssqibd on "informix".pssqibd 
    (itm_typ,itm_num,eff_dat) using btree ;
create index "informix".i2_pssqrps on "informix".pssqrps (itm_typ,
    itm_num,emp_no) using btree ;
create index "informix".i2_mmecprrf on "informix".mmecprrf (map_no,
    ecp_cod) using btree ;
create index "informix".i2_rgafdr on "informix".rgafdr (fil_cod) 
    using btree ;
create index "informix".i2_rgard on "informix".rgard (arm_no) 
    using btree ;
create index "informix".i2_rgarm on "informix".rgarm (eff_dat,
    typ) using btree ;
create index "informix".i3_rgarm on "informix".rgarm (lnk_vsn) 
    using btree ;
create unique index "informix".i2_sigdma on "informix".sigdma 
    (ma_cod,spc_typ) using btree ;
create unique index "informix".i2_sigddef on "informix".sigddef 
    (ctl_tab,ctl_fld_nam,def_cod) using btree ;
create unique index "informix".i2_sigdde on "informix".sigdde 
    (ma_cod,det_cod) using btree ;
create index "informix".i2_dgplatit on "informix".dgpcm (eff_tim,
    stp_tim,typ,typ_sub) using btree ;
create index "informix".i2_dgpladet on "informix".dgpcd (mst_no,
    eff_tim,stp_tim) using btree ;
create index "informix".i2_molog on "informix".molog (lnk_num,
    seq_no,typ) using btree ;
create index "informix".i2_moupbd on "informix".moupbd (ser_no) 
    using btree ;
create index "informix".i3_moupbd on "informix".moupbd (cod,eff_tim,
    stp_tim) using btree ;
create unique index "informix".i2_lbsperod on "informix".lbsperod 
    (lab_no,typ) using btree ;
create index "informix".i2_bmnapl on "informix".bmnapl (acc_no) 
    using btree ;
create unique index "informix".i2_moruq on "informix".moruq (ord_no,
    rur_no,typ) using btree ;
create index "informix".i3_moruq on "informix".moruq (adm_dr) 
    using btree ;
create index "informix".i4_moruq on "informix".moruq (asg_dat,
    typ,depart) using btree ;
create index "informix".i2_bmvstrod on "informix".bmvstrod (acc_no) 
    using btree ;
create index "informix".i3_bmvstrod on "informix".bmvstrod (ent_tim) 
    using btree ;
create index "informix".i4_bmvstrod on "informix".bmvstrod (id_no) 
    using btree ;
create index "informix".i2_mobar on "informix".mobar (lnk_no,bar_typ) 
    using btree ;
create index "informix".i2_mopmt on "informix".mopmt (pmt_dat,
    pmt_cod) using btree ;
create index "informix".i2_mopmtpkg on "informix".mopmtpkg (pmt_no) 
    using btree ;
create index "informix".i3_mopmtpkg on "informix".mopmtpkg (evt_no) 
    using btree ;
create index "informix".i2_pdpcitm on "informix".pdpcitm (lnk_no) 
    using btree ;
create index "informix".i2_pdpcrd on "informix".pdpcrd (lnk_no) 
    using btree ;
create index "informix".i2_moogi on "informix".moogi (grp_no) 
    using btree ;
create index "informix".i3_moogi on "informix".moogi (lnk_no,typ) 
    using btree ;
create unique index "informix".i1_ntdie on "informix".ntdie (acc_no,
    f_dat,dt_own,f_meal) using btree ;
create index "informix".i2_btsdm on "informix".btsdm (frm_no) 
    using btree ;
create index "informix".i3_btsdm on "informix".btsdm (eff_tim) 
    using btree ;
create index "informix".i2_btiod on "informix".btiod (bts_no) 
    using btree ;
create index "informix".i3_btiod on "informix".btiod (do_tim) 
    using btree ;
create index "informix".i1_btedf on "informix".btedf (bts_no) 
    using btree ;
create index "informix".i2_btedf on "informix".btedf (ord_no) 
    using btree ;
create index "informix".i3_btedf on "informix".btedf (exe_tim) 
    using btree ;
create unique index "informix".i2_bteqd on "informix".bteqd (eqd_no,
    etyp) using btree ;
create index "informix".i2_btird on "informix".btird (frm_no) 
    using btree ;
create index "informix".i2_rgvsnrel on "informix".rgvsnrel (sou_vsn) 
    using btree ;
create index "informix".i3_rgvsnrel on "informix".rgvsnrel (rel_vsn) 
    using btree ;
create index "informix".i2_rgovdie on "informix".rgovdie (wek_day,
    sft,room,stp_dat) using btree ;
create index "informix".i2_rgrldie on "informix".rgrldie (visit_dat,
    sft,room) using btree ;
create index "informix".i2_rgrdiel on "informix".rgrdiel (room) 
    using btree ;
create index "informix".i2_rgcsdie on "informix".rgcsdie (mis_num) 
    using btree ;
create index "informix".i2_udocrd on "informix".udocrd (ser_no) 
    using btree ;
create index "informix".i2_ossoalog on "informix".ossoalog (rec_no) 
    using btree ;
create index "informix".i2_hcwcl on "informix".hcwcl (ccd_no,typ) 
    using btree ;
create index "informix".i2_cghtid on "informix".cghtid (hsp_no,
    typ,chg_cod,eff_tim) using btree ;
create index "informix".i1_eotrtriage on "informix".eotrtriage 
    (avisitno) using btree ;
create index "informix".i2_eotrtriage on "informix".eotrtriage 
    (auserkeyinid) using btree ;
create index "informix".i3_eotrtriage on "informix".eotrtriage 
    (acreatedate) using btree ;
create index "informix".i2_uddmr on "informix".uddmr (vsn) using 
    btree ;
create index "informix".i2_uddid on "informix".uddid (dpm_no) 
    using btree ;
create index "informix".i3_uddid on "informix".uddid (lnk_no) 
    using btree ;
create index "informix".i4_uddid on "informix".uddid (dpm_tim) 
    using btree ;
create index "informix".i1_moowvr on "informix".moowvr (ord_no) 
    using btree ;
create index "informix".i2_moowvr on "informix".moowvr (itm_no) 
    using btree ;
create index "informix".i3_moowvr on "informix".moowvr (acc_no) 
    using btree ;
create index "informix".i1_moowvrl on "informix".moowvrl (ord_no) 
    using btree ;
create index "informix".i2_moowvrl on "informix".moowvrl (log_tim) 
    using btree ;
create unique index "informix".i2_osdcdb on "informix".osdcdb 
    (doctor,nhi_cod,icd_cod) using btree ;
create index "informix".i2_exexec2 on "informix".exexec2 (evt_num,
    typ) using btree ;
create unique index "informix".i2_exexec on "informix".exexec 
    (evt_num) using btree ;
create index "informix".i2_dgpobs on "informix".dgpobs (eff_tim) 
    using btree ;
create unique index "informix".i2_cgcar on "informix".cgcar (lnk_num,
    frm_typ,chg_typ) using btree ;
create index "informix".i3_cgcar on "informix".cgcar (eff_dat,
    org_nam) using btree ;
create index "informix".i2_moctb on "informix".moctb (emp_no) 
    using btree ;
create index "informix".i2_mocti on "informix".mocti (bmk_no) 
    using btree ;
create index "informix".i2_rgdrcdie on "informix".rgdrcdie (dsp_nam) 
    using btree ;
create index "informix".i3_rgdrcdie on "informix".rgdrcdie (typ_lnk) 
    using btree ;
create index "informix".i2_moiolog22 on "informix".moiolog2 (lnk_num) 
    using btree ;
create index "informix".i2_moiolog3 on "informix".moiolog3 (lnk_num) 
    using btree ;
create index "informix".i2_moiolog4 on "informix".moiolog4 (lnk_num) 
    using btree ;
create index "informix".i2_moiolog5 on "informix".moiolog5 (lnk_num) 
    using btree ;
create index "informix".i3_moiolog5 on "informix".moiolog5 (fun_no,
    log_tim) using btree ;
create index "informix".i2_padscg on "informix".padscg (grp_no) 
    using btree ;
create index "informix".i3_padscg on "informix".padscg (ord_no) 
    using btree ;
create index "informix".i2_mrpnie on "informix".mrpnie (chart) 
    using btree ;
create index "informix".i3_mrpnie on "informix".mrpnie (val) using 
    btree ;
create index "informix".i2_udded on "informix".udded (grp_no) 
    using btree ;
create index "informix".i3_udded on "informix".udded (lnk_no) 
    using btree ;
create index "informix".i4_udded on "informix".udded (exe_tim) 
    using btree ;
create index "informix".i2_moaar on "informix".moaar (ord_no) 
    using btree ;
create index "informix".i3_moaar on "informix".moaar (itm_typ,
    rtt) using btree ;
create index "informix".i2_mopspf on "informix".mopspf (emp_no) 
    using btree ;
create index "informix".i3_mopspf on "informix".mopspf (eff_tim,
    stp_tim) using btree ;
create index "informix".i2_moarf on "informix".moarf (eff_tim,
    stp_tim) using btree ;
create index "informix".i2_mosrpt on "informix".mosrpt (ord_no) 
    using btree ;
create index "informix".i3_mosrpt on "informix".mosrpt (itm_typ,
    rtt) using btree ;
create index "informix".i4_mosrpt on "informix".mosrpt (rpt_dat) 
    using btree ;
create unique index "informix".i2_dgmrkl on "informix".dgmrkl 
    (lnk_num,seq_no,typ) using btree ;
create index "informix".i3_dgmrkl on "informix".dgmrkl (up_tim) 
    using btree ;
create index "informix".i4_dgmrkl on "informix".dgmrkl (mrk_tim) 
    using btree ;
create index "informix".i2_cgnhded on "informix".cgnhded (typ,
    eff_dat,stp_dat) using btree ;
create unique index "informix".i2_motxt2 on "informix".motxt2 
    (ord_no,txt_typ) using btree ;
create index "informix".i3_motxt2 on "informix".motxt2 (chart,
    rpt_dat desc,rpt_hm) using btree ;
create index "informix".i4_motxt2 on "informix".motxt2 (rpt_dat) 
    using btree ;
create index "informix".i2_ordie on "informix".ordie (ord_no) 
    using btree ;
create index "informix".i2_padscm on "informix".padscm (ord_no) 
    using btree ;
create unique index "informix".i2_dtptvet on "informix".dtptvet 
    (chart,visit_no) using btree ;
create index "informix".i2_capmcr on "informix".capmcr (cnr_no) 
    using btree ;
create unique index "informix".i2_cgroompd on "informix".cgroompd 
    (class,rank,eff_dat,fee_cod) using btree ;
create unique index "informix".i2_cgroompm on "informix".cgroompm 
    (fee_cod,eff_dat) using btree ;
create index "informix".i2_dgpcf on "informix".dgpcf (drug_cod,
    m_typ,s_typ) using btree ;
create index "informix".i2_mosbldd on "informix".mosbldd (chart) 
    using btree ;
create index "informix".i3_mosbldd on "informix".mosbldd (pre_chart) 
    using btree ;
create index "informix".i4_mosbldd on "informix".mosbldd (pre_vsn) 
    using btree ;
create index "informix".i5_mosbldd on "informix".mosbldd (lnk_no) 
    using btree ;
create index "informix".i2_moblddbb on "informix".moblddbb (lnk_no) 
    using btree ;
create index "informix".i3_moblddbb on "informix".moblddbb (bpd_n) 
    using btree ;
create unique index "informix".i2_estmmf on "informix".estmmf 
    (itm_no,eff_dat,typ) using btree ;
create index "informix".i2_morrd on "informix".morrd (eff_dat,
    stp_dat,std_no) using btree ;
create index "informix".i3_morrd on "informix".morrd (eff_dat,
    stp_dat,tch_no) using btree ;
create index "informix".i2_dgdped on "informix".dgdped (license_no) 
    using btree ;
create index "informix".i3_dgdped on "informix".dgdped (ing_nam) 
    using btree ;
create index "informix".i4_dgdped on "informix".dgdped (ing_cod) 
    using btree ;
create index "informix".i5_dgdped on "informix".dgdped (eff_tim) 
    using btree ;
create index "informix".i2_dgfsob on "informix".dgfsob (license_no) 
    using btree ;
create index "informix".i3_dgfsob on "informix".dgfsob (ch_nam) 
    using btree ;
create index "informix".i4_dgfsob on "informix".dgfsob (en_nam) 
    using btree ;
create index "informix".i5_dgfsob on "informix".dgfsob (eff_tim) 
    using btree ;
create index "informix".i2_dglnd on "informix".dglnd (license_no) 
    using btree ;
create index "informix".i3_dglnd on "informix".dglnd (manu_nam) 
    using btree ;
create index "informix".i4_dglnd on "informix".dglnd (manu_site) 
    using btree ;
create index "informix".i5_dglnd on "informix".dglnd (eff_tim) 
    using btree ;
create index "informix".i2_dglned on "informix".dglned (license_no) 
    using btree ;
create index "informix".i3_dglned on "informix".dglned (eff_tim) 
    using btree ;
create index "informix".i2_dgpcatc on "informix".dgpcatc (license_no) 
    using btree ;
create index "informix".i3_dgpcatc on "informix".dgpcatc (cod) 
    using btree ;
create index "informix".i4_dgpcatc on "informix".dgpcatc (eff_tim) 
    using btree ;
create index "informix".i2_rgdrl on "informix".rgdrl (lnk_no) 
    using btree ;
create index "informix".i3_rgdrl on "informix".rgdrl (typ,eff_tim) 
    using btree ;
create index "informix".i2_rgdrc on "informix".rgdrc (lnk_no) 
    using btree ;
create index "informix".i3_rgdrc on "informix".rgdrc (typ,eff_tim) 
    using btree ;
create index "informix".i2_mrrst on "informix".mrrst (sub_yymm,
    dct_no) using btree ;
create index "informix".i3_mrrst on "informix".mrrst (vsn) using 
    btree ;
create index "informix".i2_bmdie on "informix".bmdie (acc_no) 
    using btree ;
create index "informix".i2_hcwcupl on "informix".hcwcupl (ccd_no) 
    using btree ;
create index "informix".i3_hcwcupl on "informix".hcwcupl (wrt_tim) 
    using btree ;
create index "informix".i2_cgqecdl on "informix".cgqecdl (trn_no) 
    using btree ;
create index "informix".i3_cgqecdl on "informix".cgqecdl (lnk_no) 
    using btree ;
create index "informix".i2_mocmd on "informix".mocmd (lnk_no,frm,
    func_no) using btree ;
create index "informix".i3_mocmd on "informix".mocmd (stp_tim) 
    using btree ;
create index "informix".i2_bmpvt on "informix".bmpvt (acc_no) 
    using btree ;
create index "informix".i2_rgdrcd on "informix".rgdrcd (lnk_no) 
    using btree ;
create index "informix".i3_rgdrcd on "informix".rgdrcd (eff_tim,
    typ,rul_cod) using btree ;
create unique index "informix".i1_cgoscm on "informix".cgoscm 
    (lnk_no) using btree ;
create unique index "informix".i2_cgoscm on "informix".cgoscm 
    (rtd,osc_no) using btree ;
create unique index "informix".i2_cgoscd on "informix".cgoscd 
    (osc_no) using btree ;
create index "informix".i2_tcmsnc on "informix".tcmsnc (his_id) 
    using btree ;
create index "informix".i3_tcmsnc on "informix".tcmsnc (his_dat) 
    using btree ;
create index "informix".i2_rfpar on "informix".rfpar (act_tim,
    act_typ) using btree ;
create index "informix".i3_rfpar on "informix".rfpar (vsn) using 
    btree ;
create index "informix".i2_osdugdff on "informix".osdugdff (lnk_no) 
    using btree ;
create index "informix".i3_osdugdff on "informix".osdugdff (icr_no) 
    using btree ;
create index "informix".i2_dgdbicr on "informix".dgdbicr (bmr_no) 
    using btree ;
create index "informix".i3_dgdbicr on "informix".dgdbicr (rtt) 
    using btree ;
create index "informix".i2_momblog on "informix".momblog (lnk_num) 
    using btree ;
create index "informix".i3_momblog on "informix".momblog (log_tim,
    typ) using btree ;
create index "informix".i2_osdugitm on "informix".osdugitm (lnk_no) 
    using btree ;
create index "informix".i3_osdugitm on "informix".osdugitm (del_rec_no) 
    using btree ;
create index "informix".i2_rgldie on "informix".rgldie (rd_no) 
    using btree ;
create index "informix".i2_cgipar on "informix".cgipar (evt_num) 
    using btree ;
create index "informix".i3_cgipar on "informix".cgipar (item_cod,
    eff_dat) using btree ;
create index "informix".i2_dgoutitm on "informix".dgoutitm (mst_no) 
    using btree ;
create index "informix".i3_dgoutitm on "informix".dgoutitm (rtt,
    chg_cod) using btree ;
create index "informix".i2_dgoutmst on "informix".dgoutmst (dug_dat,
    fil1,lmp_typ,lmp_no) using btree ;
create index "informix".i3_dgoutmst on "informix".dgoutmst (vsn) 
    using btree ;
create index "informix".i4_dgoutmst on "informix".dgoutmst (ord_lnk_no,
    ord_typ) using btree ;
create index "informix".i5_dgoutmst on "informix".dgoutmst (ord_tim) 
    using btree ;
create index "informix".i6_dgoutmst on "informix".dgoutmst (chg_tim) 
    using btree ;
create index "informix".i7_dgoutmst on "informix".dgoutmst (out_tim) 
    using btree ;
create index "informix".i2_paabr on "informix".paabr (pal_no) 
    using btree ;
create index "informix".i3_paabr on "informix".paabr (rec_tim,
    typ) using btree ;
create index "informix".i2_mosoahfd on "informix".mosoahfd (own_no,
    typ) using btree ;
create index "informix".i2_mormr on "informix".mormr (lnk_no,typ) 
    using btree ;
create index "informix".i3_mormr on "informix".mormr (ret_tim,
    rcv_man) using btree ;
create index "informix".i4_mormr on "informix".mormr (ret_tim,
    ret_man) using btree ;
create index "informix".i2_cgbdar on "informix".cgbdar (lnk_no,
    lnk_typ) using btree ;
create index "informix".i3_cgbdar on "informix".cgbdar (lnk_typ,
    apv_tim) using btree ;
create index "informix".i2_smrf on "informix".smrf (chart) using 
    btree ;
create index "informix".i3_smrf on "informix".smrf (sed_tim,apl_man) 
    using btree ;
create index "informix".i4_smrf on "informix".smrf (sed_tim,tel_no) 
    using btree ;
create index "informix".i5_smrf on "informix".smrf (lnk_no,lnk_typ) 
    using btree ;
create index "informix".i2_dgdipr on "informix".dgdipr (det_no) 
    using btree ;
create index "informix".i3_dgdipr on "informix".dgdipr (sdr_tim) 
    using btree ;
create index "informix".i4_dgdipr on "informix".dgdipr (bar_tim) 
    using btree ;
create index "informix".i2_moomm on "informix".moomm (lnk_no,seq_no) 
    using btree ;
create index "informix".i2_moomd on "informix".moomd (mst_no) 
    using btree ;
create index "informix".i2_moomdd on "informix".moomdd (itm_no) 
    using btree ;
create index "informix".i2_moomlls on "informix".moomlls (itm_no) 
    using btree ;
create index "informix".i2_moomls on "informix".moomls (itm_no) 
    using btree ;
create index "informix".i2_moomss on "informix".moomss (itm_no) 
    using btree ;
create unique index "informix".i2_moomtr on "informix".moomtr 
    (lnk_num,seq_no) using btree ;
create index "informix".i2_dgoutlot on "informix".dgoutlot (itm_no) 
    using btree ;
create index "informix".i3_dgoutlot on "informix".dgoutlot (lot_num) 
    using btree ;
create index "informix".i2_dgoutpar on "informix".dgoutpar (act_tim,
    act_typ) using btree ;
create index "informix".i3_dgoutpar on "informix".dgoutpar (mst_no) 
    using btree ;
create unique index "informix".i2_pscontra on "informix".pscontra 
    (emp_no,f_dat) using btree ;
create index "informix".i2_mopkgdif on "informix".mopkgdif (pkg_no) 
    using btree ;
create index "informix".i2_rgdrdn on "informix".rgdrdn (sd_no) 
    using btree ;
create index "informix".i2_rgdrcdn on "informix".rgdrcdn (lnk_no) 
    using btree ;
create index "informix".i3_rgdrcdn on "informix".rgdrcdn (eff_tim,
    typ,rul_cod) using btree ;
create index "informix".i2_pasamf on "informix".pasamf (pa_no) 
    using btree ;
create index "informix".i2_pasadf on "informix".pasadf (psa_no) 
    using btree ;
create index "informix".i2_hcwcld on "informix".hcwcld (ccd_no,
    seq_no,typ) using btree ;
create index "root".i2_momdymrk on "root".momdymrk (chart,typ) 
    using btree ;
create index "informix".i2_moprnrsn on "informix".moprnrsn (vsn) 
    using btree ;
create index "informix".i3_moprnrsn on "informix".moprnrsn (log_tim,
    typ) using btree ;
create index "informix".i2_moprnoth on "informix".moprnoth (rec_no) 
    using btree ;
create index "informix".i2_moefrd on "informix".moefrd (mst_no) 
    using btree ;
create index "informix".i3_moefrd on "informix".moefrd (lnk_typ,
    lnk_no) using btree ;
create index "informix".i2_moefrm on "informix".moefrm (frm_no) 
    using btree ;
create index "informix".i2_ntpsac on "informix".ntpsac (typ,amt) 
    using btree ;
create index "informix".i2_hcextwcr on "informix".hcextwcr (his_id) 
    using btree ;
create index "informix".i3_hcextwcr on "informix".hcextwcr (vsn) 
    using btree ;
create index "informix".i4_hcextwcr on "informix".hcextwcr (chart) 
    using btree ;
create index "informix".i5_hcextwcr on "informix".hcextwcr (his_dat) 
    using btree ;
create index "informix".i2_doolfm on "informix".doolfm (lev_no) 
    using btree ;
create index "informix".i3_doolfm on "informix".doolfm (rel_no) 
    using btree ;
create index "informix".i1_monotm on "informix".monotm (not_no) 
    using btree ;
create index "informix".i2_cggtrd on "informix".cggtrd (grp_cod) 
    using btree ;
create index "informix".i3_cggtrd on "informix".cggtrd (detai_cod) 
    using btree ;
create index "informix".i4_cggtrd on "informix".cggtrd (eff_tim,
    stp_tim) using btree ;
create index "informix".i2_cggtrdl on "informix".cggtrdl (grp_cod,
    log_tim) using btree ;
create index "informix".i2_dgdedf on "informix".dgdedf (lnk_num) 
    using btree ;
create index "informix".i3_dgdedf on "informix".dgdedf (val) using 
    btree ;
create index "informix".i2_dgtpdf on "informix".dgtpdf (srv_cod) 
    using btree ;
create index "informix".i2_moplr on "informix".moplr (id_no) using 
    btree ;
create index "informix".i3_moplr on "informix".moplr (lnk_no) 
    using btree ;
create index "informix".i4_moplr on "informix".moplr (eff_tim,
    typ) using btree ;
create index "informix".i2_dci10cnf on "informix".dci10cnf (icd_typ,
    icd_cod) using btree ;
create index "informix".i3_dci10cnf on "informix".dci10cnf (icd_ver) 
    using btree ;
create unique index "informix".i2_dcicdmf on "informix".dcicdmf 
    (src_ver,src_cod,tgt_ver,tgt_cod) using btree ;
create unique index "informix".i2_bmnurnum on "informix".bmnurnum 
    (ward,typ,stp_tim) using btree ;
create index "informix".i2_mormp on "informix".mormp (lnk_no) 
    using btree ;
create index "informix".i3_mormp on "informix".mormp (rtt) using 
    btree ;
create index "informix".i2_oostsrcd on "informix".oostsrcd (visit_dat,
    sft,room,sts_cod) using btree ;
create index "informix".i2_eodiel on "informix".eodiel (vsn) using 
    btree ;


alter table "informix".motxt add constraint (foreign key (ord_no) 
    references "informix".modsc  on delete cascade constraint 
    "informix".f1_motxt);
alter table "informix".mopdd add constraint (foreign key (vsn) 
    references "informix".mrvcsn  on delete cascade constraint 
    "informix".f1_mopdd);
alter table "informix".mopar add constraint (foreign key (ord_no) 
    references "informix".modsc  on delete cascade constraint 
    "informix".f1_mopar);
alter table "informix".moitmh add constraint (foreign key (dit_no) 
    references "informix".mosoah  on delete cascade constraint 
    "informix".i2_mosoah);
alter table "informix".hcpst add constraint (foreign key (ccd_no) 
    references "informix".hcccd  on delete cascade constraint 
    "informix".f1_hcpst);
alter table "informix".dgdcct add constraint (foreign key (dcr_no) 
    references "informix".dgdcr  on delete cascade constraint 
    "informix".f1_dgdcct);
alter table "informix".mopftr add constraint (foreign key (exm_no) 
    references "informix".mopftm  on delete cascade constraint 
    "informix".f1_mopftr);
alter table "informix".npfrdi add constraint (foreign key (rec_no) 
    references "informix".npfr  on delete cascade constraint "informix"
    .f1_npfrdi);
alter table "informix".dgpad add constraint (foreign key (par_no) 
    references "informix".dgpar  on delete cascade constraint 
    "informix".f1_dgpad);
alter table "informix".dgpadsc add constraint (foreign key (par_no) 
    references "informix".dgpar  on delete cascade constraint 
    "informix".f1_dgpadsc);
alter table "informix".moitm add constraint (foreign key (ord_no) 
    references "informix".modsc  on delete cascade constraint 
    "informix".f1_moitm);
alter table "informix".dgpadr add constraint (foreign key (dmc_no) 
    references "informix".dgadmcr  on delete cascade constraint 
    "informix".f1_dgpadr);
alter table "informix".moepitm add constraint (foreign key (epd_no) 
    references "informix".moepdsc  on delete cascade constraint 
    "informix".f1_moepitm);


create trigger "informix".t1_mrpbd1 update on "informix".mrpbd1 
    referencing old as old new as new
    for each row
        (
        insert into "informix".ooptmret (evt_no,chart,visit_no,
    evt_typ,rtp,rtt)  values (0 ,new.chart ,0 ,'MU' ,new.rtp ,CURRENT 
    year to fraction(3) ));

create trigger "informix".t1_rgdata insert on "informix".rgdata 
    referencing new as new
    for each row
        (
        insert into "informix".ooptmret (evt_no,chart,visit_no,
    evt_typ,rtp,rtt)  values (0 ,new.chart ,new.visit_no ,'RI' ,new.rtp 
    ,CURRENT year to fraction(3) ));

create trigger "informix".t2_rgdata update on "informix".rgdata 
    referencing old as old new as new
    for each row
        (
        insert into "informix".ooptmret (evt_no,chart,visit_no,
    evt_typ,rtp,rtt)  values (0 ,new.chart ,new.visit_no ,'RU' ,new.rtp 
    ,CURRENT year to fraction(3) ));

create trigger "informix".t1_mrpbd99 insert on "informix".mrpbd99 
    referencing new as new
    for each row
        (
        insert into "informix".ooptmret (evt_no,chart,visit_no,
    evt_typ,rtp,rtt)  values (0 ,new.chart ,0 ,'MI' ,new.rtp ,CURRENT 
    year to fraction(3) ));

create trigger "informix".t2_mrpbd99 update on "informix".mrpbd99 
    referencing old as old new as new
    for each row
        (
        insert into "informix".ooptmret (evt_no,chart,visit_no,
    evt_typ,rtp,rtt)  values (0 ,new.chart ,0 ,'MU' ,new.rtp ,CURRENT 
    year to fraction(3) ));

