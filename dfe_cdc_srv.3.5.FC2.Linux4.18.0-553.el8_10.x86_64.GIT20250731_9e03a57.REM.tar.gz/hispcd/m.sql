--create schema test;
CREATE TABLE  test.movoc
    (
    own_no NUMERIC(10) NOT NULL
    ,map_no NUMERIC(5) NOT NULL
    ,voc_typ CHAR(24)
    ,seq_no NUMERIC(5) NOT NULL
    ,cmt VARCHAR(240)
    ,wod VARCHAR(1020)
    ,txt text
    ,rtp NUMERIC(10)
    ,rtd DATE
    ,cdc_ts TIMESTAMP default CURRENT_TIMESTAMP
    ,PRIMARY KEY (own_no,map_no,voc_typ,seq_no)
);

