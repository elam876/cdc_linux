now=`date`
echo "
alter table dfe.dfe_types_9 add (x9 char(10), x10 numeric) modify( c char(70));
update dfe.dfe_types_9 set c='$now';
commit ;
" | sqlRun.sh
date +'%H:%M:%S'
