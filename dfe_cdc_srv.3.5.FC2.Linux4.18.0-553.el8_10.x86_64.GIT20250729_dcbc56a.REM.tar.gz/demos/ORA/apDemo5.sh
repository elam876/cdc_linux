#!/usr/bin/env bash
MODULE=demo_$CB_DBS_ID
source cbUtil.set
cnt=${1-10}
NLS_LANG=AMERICAN_AMERICA.AL32UTF8
export NLS_LANG

genSql()
{
    local id=$1
    echo 1|awk -v id=$id -v cnt=$cnt '
       {
         for(i=1;i<=cnt;i++){
            u_id=sprintf("%ld%.4d",id,i);
            printf ("insert into dfe_test_pk values(%ld, @C.%ld@, @cc\\%ld.%d@);\n", u_id,id,id, i); 
            printf("update dfe_test_pk set c=@cc\t\\%ld.%d@ where id = %ld;\n",i,id,u_id);
            if (cnt % 500 ==0) printf("commit;\n");
          }
		printf("delete from dfe_test_pk where id > %ld - %d;\n",u_id, i*0.9);
       }
       END {printf("commit;\n");}
    '|sed -e s/'@'/"'"/g
}

go()
{

  for n in 1 #2 3 4 5 6
  do
    #id=`timenow`
    genSql `timenow` | sqlRun.sh
  done
}
go  
wait
