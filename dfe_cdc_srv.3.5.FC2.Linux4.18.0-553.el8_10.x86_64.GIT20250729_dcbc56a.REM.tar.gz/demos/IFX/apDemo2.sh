#!/usr/bin/env bash
MODULE=demo_$CB_DBS_ID
source cbUtil.set
NLS_LANG=AMERICAN #---要注意這一句必須指定，不然下一句不生效。
export NLS_LANG
db=`echo dfedemo_$CB_DBS_DBMS |  tr '[:upper:]' '[:lower:]'`

NLS_DATE_FORMAT='yyyy-mm-dd hh24:mi:ss'
NLS_DATE_FORMAT='yyyy-mm-dd'
export NLS_DATE_FORMAT


genSql()
{
    dt=`date '+%Y-%m-%d'`
    tm=`date '+%H:%M:%S'`
    echo 'execute procedure sysmaster:ifx_allow_newline("t");'
    echo 1|awk -v id=$id -v id2=$id2 -v dt="$dt" -v tm="$tm" '
       BEGIN {printf("BEGIN WORK;\n");}
       {
         #for(i=1;i<=100;i++){
         for(i=1;i<=10;i++){
            newid=sprintf("%ld%.3d",id,i);
            printf ("insert into ifx_types values\
				(%ld, @cc\\%ld.\n%d@,\
                 @v_c2@,@c_v3@,%d,%lf,\
                 TO_DATE(@%s@,@YYYY-MM-DD@),\
                 TO_DATE(@%s@,@HH24:MI:SS@)\
                 );\n", \
                 newid,id,i,\
                 i,i*0.3,dt,tm); 
            printf("update ifx_types set c=@cc\t\\%ld.\n%d@, c3=@SLASH\\SLASH@ where id = %ld;\n",i,id,newid);
            printf("delete from ifx_types where id < %ld%.3d;\n",id2,i);
         }
       }
       END {printf("commit work;\n");}
    '|sed -e s/'@'/"'"/g
}

go()
{

  for n in 1 #2 3 4 5 6
  do
    id=`timenow`
    id2=`expr $id - 10`
    genSql id, id2, | sqlRun.sh $db
  done
}
go &
wait
