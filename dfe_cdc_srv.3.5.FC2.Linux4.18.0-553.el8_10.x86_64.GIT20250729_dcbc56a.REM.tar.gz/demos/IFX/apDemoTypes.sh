#!/usr/bin/env bash
cnt=$1
if [ "$cnt" = "" ]; then
    . $CB_PROJECT_DIR/$CB_CONFIG_DIR/systemCfg.cfg 
    cnt=${1-$CB_NUMBER_OF_RECORDS_IN_TEST}
fi
MODULE=demo_$CB_DBS_ID
source cbUtil.set
logMsg M run $@ $CB_DBS_DBMS $CB_DBS_ID

NLS_DATE_FORMAT='yyyy-mm-dd hh24:mi:ss'
NLS_DATE_FORMAT='yyyy-mm-dd'
export NLS_DATE_FORMAT

db=`echo dfedemo_$CB_DBS_DBMS |  tr '[:upper:]' '[:lower:]'`


genSql()
{
    local id=$1
    local id2=$2
    dt=`date '+%Y-%m-%d'`
    tm=`date '+%H:%M:%S'`
    echo 'execute procedure sysmaster:ifx_allow_newline("t");'
    echo '
       BEGIN {
           printf("execute procedure ifx_allow_newline(@t@);\n")
           printf("BEGIN WORK;\n");
       }
       {
         for(tb=1;tb<=10;tb++){
         for(i=1;i<=cnt;i++){
            newid=sprintf("%ld%.4d",id,i);
            printf ("insert into ifx_types_%d values\
				(%ld, @cc\\%ld.\n%d@,\
                 @v_c2@,@c_v3@,%d,%lf,\
                 TO_DATE(@%s@,@%%Y-%%m-%%d@),\
                 TO_DATE(@%s@,@%%H:%%M:%%S@)\
                 );\n", \
                 tb, \
                 newid,id,i,\
                 i,i*0.3,dt,tm); 
            printf("update ifx_types_%d set c=@cc\t\\%ld.\n%d@, c3=@SLASH\\SLASH@ where id = %ld;\n",tb, i,id,newid);
            if (cnt % 500 ==0) 
               printf("commit work; begin work\n");
         }
		printf("delete from ifx_types_%d where id > %ld - %d;\n",tb, newid, i*0.9);
         }
       }
       END {printf("commit work;\n");}
    ' > $MY_TMP.awk
    echo 1|awk -v id=$id -v id2=$id2 -v dt="$dt" \
               -v tm="$tm" -v cnt=$cnt -f $MY_TMP.awk \
          |sed -e s/'@'/"'"/g
}

go()
{

  for n in 1 #2 3 4 5 6
  do
    id=`timenow`
    id2=`expr $id - 10`
    genSql $id $id2 | sqlRun.sh -e $db
  done
}
go &
wait
