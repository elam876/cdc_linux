#!/usr/bin/env bash
MODULE=demo_$CB_DBS_ID
IS_BASH=1
source cbUtil.set light
db=`echo dfedemo_$CB_DBS_DBMS |  tr '[:upper:]' '[:lower:]'`
#db2=CB_DBS_USER
whoami=`whoami`
IS_CB_TEST_CASE=0
NO_REASSIGN=1

createDb()
{
    local db=$1
    echo "drop database $db;" \
        | sqlRun.sh  -e sysmaster  > /dev/null 2>&1
   
    echo "create database $db with log; "\
        | sqlRun.sh  -e sysmaster  
    echo

    echo "grant dba to $CB_DBS_USER;" \
        | sqlRun.sh  -e $db
    echo


}

go()
{
  createDb $db
  #createDb $db2
} 

go

go 2>&1  \
    | grep -v 'Cannot create or rename' \
    | grep -v 'duplicate value for a record' \
    | grep -v 'Database not selected yet' \
    > $MY_TMP.err
grep '^ *[0-9]*:' $MY_TMP.err 
if [ $? -eq 0 ]; then
    logMsg E "Failed to create db [$CB_DBS_USER] of $CB_DBS_DBMS:$CB_DBS_ID"
    cat $MY_TMP.err | logMsg M -
    exit 255
else
    ret=0
fi


#echo syscdcv1 @@@@@@@@@@@@@@@@@@@
dbaccess - $INFORMIXDIR/etc/syscdcv1.sql > /dev/null 2>&1
exit $ret
