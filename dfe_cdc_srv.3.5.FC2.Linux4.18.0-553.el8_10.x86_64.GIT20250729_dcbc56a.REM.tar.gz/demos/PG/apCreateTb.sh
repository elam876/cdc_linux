#!/usr/bin/env bash
MODULE=demo
source cbUtil.set
echo "
drop database dfe;
create database dfe;
" sqlRun.sh postgres

echo "
create schema dfedemo;
create schema $CB_DBS_USER;
create schema informix;
create schema oracle;
CREATE TABLE IF NOT EXISTS dfe_test_1 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_1 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_10; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_10 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_10 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_2; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_2 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_2 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_3; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_3 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_3 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_4; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_4 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_4 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_5; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_5 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_5 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_6; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_6 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_6 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_7; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_7 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_7 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_8; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_8 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_8 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_9; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_9 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_9 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_pk; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_pk (
    id numeric(20,0) NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE dfe_test_pk OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_pk_1; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_pk_1 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE dfe_test_pk_1 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_pk_10; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_pk_10 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE dfe_test_pk_10 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_pk_2; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_pk_2 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE dfe_test_pk_2 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_pk_3; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_pk_3 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE dfe_test_pk_3 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_pk_4; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_pk_4 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE dfe_test_pk_4 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_pk_5; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_pk_5 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE dfe_test_pk_5 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_pk_6; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_pk_6 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE dfe_test_pk_6 OWNER TO $CB_DBS_USER;


CREATE TABLE IF NOT EXISTS dfe_test_pk_10000 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE dfe_test_pk_10000 OWNER TO $CB_DBS_USER;



--
-- Name: dfe_test_pk_7; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_pk_7 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE dfe_test_pk_7 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_pk_8; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_pk_8 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE dfe_test_pk_8 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_pk_9; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_pk_9 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE dfe_test_pk_9 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_uidx_1; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_uidx_1 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_uidx_1 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_uidx_10; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_uidx_10 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_uidx_10 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_uidx_2; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_uidx_2 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_uidx_2 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_uidx_3; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_uidx_3 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_uidx_3 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_uidx_4; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_uidx_4 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_uidx_4 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_uidx_5; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_uidx_5 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_uidx_5 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_uidx_6; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_uidx_6 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_uidx_6 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_uidx_7; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_uidx_7 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_uidx_7 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_uidx_8; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_uidx_8 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_uidx_8 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_test_uidx_9; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test_uidx_9 (
    id numeric,
    c character varying(60)
);


ALTER TABLE dfe_test_uidx_9 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_types; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_types (
    id numeric(20,0) NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE dfe_types OWNER TO $CB_DBS_USER;

--
-- Name: dfe_types_1; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_types_1 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE dfe_types_1 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_types_10; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_types_10 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE dfe_types_10 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_types_2; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_types_2 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE dfe_types_2 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_types_3; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_types_3 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE dfe_types_3 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_types_4; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_types_4 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE dfe_types_4 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_types_5; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_types_5 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE dfe_types_5 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_types_6; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_types_6 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE dfe_types_6 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_types_7; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_types_7 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE dfe_types_7 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_types_8; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_types_8 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE dfe_types_8 OWNER TO $CB_DBS_USER;

--
-- Name: dfe_types_9; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_types_9 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE dfe_types_9 OWNER TO $CB_DBS_USER;

--SET search_path = db00006__dbo, pg_catalog;

--
-- Name: dfe_t; Type: TABLE; Schema: db00006__dbo; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_t (
    id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(30),
    email character varying(50) NOT NULL
);


ALTER TABLE dfe_t OWNER TO $CB_DBS_USER;

--
-- Name: dfe_t_no_pkey; Type: TABLE; Schema: db00006__dbo; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_t_no_pkey (
    id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(30),
    email character varying(50) NOT NULL
);


ALTER TABLE dfe_t_no_pkey OWNER TO $CB_DBS_USER;

--
-- Name: users; Type: TABLE; Schema: db00006__dbo; Owner: informix
--

CREATE TABLE IF NOT EXISTS users (
    id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(30),
    email character varying(50) NOT NULL
);


ALTER TABLE users OWNER TO $CB_DBS_USER;

--
-- Name: users_no_pkey; Type: TABLE; Schema: db00006__dbo; Owner: informix
--

CREATE TABLE IF NOT EXISTS users_no_pkey (
    id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(30),
    email character varying(50) NOT NULL
);


ALTER TABLE users_no_pkey OWNER TO $CB_DBS_USER;

--SET search_path = db00006__my_db, pg_catalog;

--
-- Name: dfe_t; Type: TABLE; Schema: db00006__my_db; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_t (
    id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(30),
    email character varying(50) NOT NULL
);


ALTER TABLE dfe_t OWNER TO $CB_DBS_USER;

--
-- Name: dfe_t_no_pkey; Type: TABLE; Schema: db00006__my_db; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_t_no_pkey (
    id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(30),
    email character varying(50) NOT NULL
);


ALTER TABLE dfe_t_no_pkey OWNER TO $CB_DBS_USER;

--SET search_path = $CB_DBS_USER, pg_catalog;

--
-- Name: cb_b; Type: TABLE; Schema: $CB_DBS_USER; Owner: informix
--

CREATE TABLE IF NOT EXISTS cb_b (
    id integer,
    c character(10)
);


ALTER TABLE cb_b OWNER TO $CB_DBS_USER;

--SET search_path = khyx_4500, pg_catalog;

--
-- Name: mc_t_tradpolicy; Type: TABLE; Schema: khyx_4500; Owner: informix
--

CREATE TABLE IF NOT EXISTS mc_t_tradpolicy (
    custid character varying(30) NOT NULL,
    policyno character varying(66) NOT NULL,
    proposalno character varying(66),
    inputtime timestamp without time zone,
    operatedate timestamp without time zone,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    comcode character varying(24),
    classcode character varying(6),
    riskcode character varying(9),
    businessnature character varying(9),
    inputflag character varying(2),
    policytype character varying(6),
    policysort character varying(3),
    insuredcode character varying(90),
    insuredname character varying(360),
    insuredaddress character varying(765),
    insured1code character varying(90),
    insured1name character varying(360),
    insured1address character varying(765),
    agentcode character varying(36),
    sumamount double precision,
    sumpremium double precision,
    bipremium double precision,
    cipremium double precision,
    endorsetimes numeric(38,0),
    handler1code character varying(360),
    othflag character varying(2),
    underwritecode character varying(30),
    underwritename character varying(75),
    contractno character varying(66),
    handlercode character varying(360),
    approvercode character varying(30),
    operatorcode character varying(30),
    underwriteenddate timestamp without time zone,
    remark character varying(765),
    tcol1 character varying(20),
    tcol2 character varying(30),
    tcol3 character varying(30),
    loadtime timestamp without time zone,
    creatorcode character varying(16),
    inserttimeforhis timestamp without time zone,
    updatercode character varying(16),
    operatetimeforhis timestamp without time zone DEFAULT ('now'::text)::timestamp without time zone,
    datasource character varying(50),
    validstatus character varying(2),
    flag character varying(2),
    comid character varying(8) NOT NULL,
    insuredcompany character varying(4),
    dfeflag character varying(2),
    carshiptax double precision,
    carbusitype character varying(30),
    thisdamagedbi numeric DEFAULT 0,
    thisdamagedci numeric DEFAULT 0,
    plandate timestamp without time zone,
    newmanagercode character varying(360) DEFAULT 'null'::character varying,
    monopolycode character varying(40),
    carid character varying(30),
    validtime timestamp without time zone,
    dmflag character varying(10),
    monopolyflag character varying(3),
    clausetype character varying(9),
    dwxflag character varying(30) DEFAULT '-1'::character varying,
    enrolldate timestamp without time zone,
    carkindcode character varying(9) DEFAULT '-1'::character varying,
    taxnum numeric(19,2),
    netinsamt numeric(19,2),
    carchecker character varying(60),
    generatetime timestamp without time zone
);


ALTER TABLE mc_t_tradpolicy OWNER TO $CB_DBS_USER;

--
-- Name: tm_t_jhsendmessage; Type: TABLE; Schema: khyx_4500; Owner: informix
--

CREATE TABLE IF NOT EXISTS tm_t_jhsendmessage (
    messageid character varying(30) NOT NULL,
    sendid character varying(30),
    mouldid character varying(30),
    operatorcode character varying(50) NOT NULL,
    messagecount numeric(38,0),
    phoneno character varying(20),
    suppliercode character varying(120),
    comcode character varying(8),
    smscontent character varying(3000),
    sendtime timestamp without time zone NOT NULL,
    realtime timestamp without time zone,
    needreply character varying(2),
    flag character varying(2),
    validstatus character varying(2),
    comid character varying(8) NOT NULL,
    creatorcode character varying(50),
    inserttimeforhis timestamp without time zone,
    updatercode character varying(16),
    operatetimeforhis timestamp without time zone,
    sendtype character varying(2),
    needcallback character varying(2),
    smid character varying(30),
    urlorclass character varying(100),
    funcname character varying(50),
    failreason character varying(600),
    source character varying(2),
    targettype character varying(3)
);


ALTER TABLE tm_t_jhsendmessage OWNER TO $CB_DBS_USER;

--SET search_path = public, pg_catalog;

--
-- Name: tb101; Type: TABLE; Schema: public; Owner: informix
--

CREATE TABLE IF NOT EXISTS tb101 (
    id integer NOT NULL,
    c character(10)
);


ALTER TABLE tb101 OWNER TO $CB_DBS_USER;

--
-- Name: td; Type: TABLE; Schema: public; Owner: informix
--

CREATE TABLE IF NOT EXISTS td (
    id integer,
    dt timestamp without time zone
);


ALTER TABLE td OWNER TO $CB_DBS_USER;

--
-- Name: test1; Type: TABLE; Schema: public; Owner: informix
--

CREATE TABLE IF NOT EXISTS test1 (
    id integer,
    c character(10),
    f double precision
);


ALTER TABLE test1 OWNER TO $CB_DBS_USER;

--SET search_path = $CB_DBS_USER, pg_catalog;

--
-- Name: dfe_test; Type: TABLE; Schema: $CB_DBS_USER; Owner: informix
--

CREATE TABLE IF NOT EXISTS dfe_test (
    id numeric(38,0) NOT NULL,
    c character(10)
);


ALTER TABLE dfe_test OWNER TO $CB_DBS_USER;

--
-- Name: t_ins_duplicate; Type: TABLE; Schema: $CB_DBS_USER; Owner: informix
--

CREATE TABLE IF NOT EXISTS t_ins_duplicate (
    id integer NOT NULL,
    id2 integer NOT NULL,
    c character(10)
);


ALTER TABLE t_ins_duplicate OWNER TO $CB_DBS_USER;

--
-- Name: tb_interval; Type: TABLE; Schema: $CB_DBS_USER; Owner: informix
--

CREATE TABLE IF NOT EXISTS tb_interval (
    id integer,
    it interval day to minute
);


ALTER TABLE tb_interval OWNER TO $CB_DBS_USER;

--
-- Name: test; Type: TABLE; Schema: $CB_DBS_USER; Owner: informix
--

CREATE TABLE IF NOT EXISTS test (
    id numeric(38,0) NOT NULL,
    c character(10)
);


ALTER TABLE test OWNER TO $CB_DBS_USER;

--SET search_path = test_db, pg_catalog;



-- Name: dfe_test_pk_10 dfe_test_pk_10_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_test_pk_10
    ADD CONSTRAINT dfe_test_pk_10_pkey PRIMARY KEY (id, idc);


--
-- Name: dfe_test_pk_1 dfe_test_pk_1_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_test_pk_1
    ADD CONSTRAINT dfe_test_pk_1_pkey PRIMARY KEY (id, idc);


--
-- Name: dfe_test_pk_2 dfe_test_pk_2_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_test_pk_2
    ADD CONSTRAINT dfe_test_pk_2_pkey PRIMARY KEY (id, idc);


--
-- Name: dfe_test_pk_3 dfe_test_pk_3_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_test_pk_3
    ADD CONSTRAINT dfe_test_pk_3_pkey PRIMARY KEY (id, idc);


--
-- Name: dfe_test_pk_4 dfe_test_pk_4_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_test_pk_4
    ADD CONSTRAINT dfe_test_pk_4_pkey PRIMARY KEY (id, idc);


--
-- Name: dfe_test_pk_5 dfe_test_pk_5_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_test_pk_5
    ADD CONSTRAINT dfe_test_pk_5_pkey PRIMARY KEY (id, idc);


--
-- Name: dfe_test_pk_6 dfe_test_pk_6_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_test_pk_6
    ADD CONSTRAINT dfe_test_pk_6_pkey PRIMARY KEY (id, idc);

--
-- Name: dfe_test_pk_10000 dfe_test_pk_10000_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_test_pk_10000
    ADD CONSTRAINT dfe_test_pk_10000_pkey PRIMARY KEY (id, idc);


--
-- Name: dfe_test_pk_7 dfe_test_pk_7_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_test_pk_7
    ADD CONSTRAINT dfe_test_pk_7_pkey PRIMARY KEY (id, idc);


--
-- Name: dfe_test_pk_8 dfe_test_pk_8_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_test_pk_8
    ADD CONSTRAINT dfe_test_pk_8_pkey PRIMARY KEY (id, idc);


--
-- Name: dfe_test_pk_9 dfe_test_pk_9_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_test_pk_9
    ADD CONSTRAINT dfe_test_pk_9_pkey PRIMARY KEY (id, idc);


--
-- Name: dfe_test_pk dfe_test_pk_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_test_pk
    ADD CONSTRAINT dfe_test_pk_pkey PRIMARY KEY (id, idc);


--
-- Name: dfe_types_10 dfe_types_10_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_types_10
    ADD CONSTRAINT dfe_types_10_pkey PRIMARY KEY (id);


--
-- Name: dfe_types_1 dfe_types_1_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_types_1
    ADD CONSTRAINT dfe_types_1_pkey PRIMARY KEY (id);


--
-- Name: dfe_types_2 dfe_types_2_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_types_2
    ADD CONSTRAINT dfe_types_2_pkey PRIMARY KEY (id);


--
-- Name: dfe_types_3 dfe_types_3_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_types_3
    ADD CONSTRAINT dfe_types_3_pkey PRIMARY KEY (id);


--
-- Name: dfe_types_4 dfe_types_4_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_types_4
    ADD CONSTRAINT dfe_types_4_pkey PRIMARY KEY (id);


--
-- Name: dfe_types_5 dfe_types_5_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_types_5
    ADD CONSTRAINT dfe_types_5_pkey PRIMARY KEY (id);


--
-- Name: dfe_types_6 dfe_types_6_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_types_6
    ADD CONSTRAINT dfe_types_6_pkey PRIMARY KEY (id);


--
-- Name: dfe_types_7 dfe_types_7_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_types_7
    ADD CONSTRAINT dfe_types_7_pkey PRIMARY KEY (id);


--
-- Name: dfe_types_8 dfe_types_8_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_types_8
    ADD CONSTRAINT dfe_types_8_pkey PRIMARY KEY (id);


--
-- Name: dfe_types_9 dfe_types_9_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_types_9
    ADD CONSTRAINT dfe_types_9_pkey PRIMARY KEY (id);


--
-- Name: dfe_types dfe_types_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  dfe_types
    ADD CONSTRAINT dfe_types_pkey PRIMARY KEY (id);


--SET search_path = db00006__dbo, pg_catalog;

--
-- Name: dfe_t_no_pkey dfe_t_no_pkey_pkey; Type: CONSTRAINT; Schema: db00006__dbo; Owner: informix
--

ALTER TABLE  dfe_t_no_pkey
    ADD CONSTRAINT dfe_t_no_pkey_pkey PRIMARY KEY (id, email);


--
-- Name: dfe_t dfe_t_pkey; Type: CONSTRAINT; Schema: db00006__dbo; Owner: informix
--

ALTER TABLE  dfe_t
    ADD CONSTRAINT dfe_t_pkey PRIMARY KEY (id, email);


--
-- Name: users_no_pkey users_no_pkey_pkey; Type: CONSTRAINT; Schema: db00006__dbo; Owner: informix
--

ALTER TABLE  users_no_pkey
    ADD CONSTRAINT users_no_pkey_pkey PRIMARY KEY (id, email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: db00006__dbo; Owner: informix
--

ALTER TABLE  users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id, email);


--SET search_path = db00006__my_db, pg_catalog;

--
-- Name: dfe_t_no_pkey dfe_t_no_pkey_pkey; Type: CONSTRAINT; Schema: db00006__my_db; Owner: informix
--

ALTER TABLE  dfe_t_no_pkey
    ADD CONSTRAINT dfe_t_no_pkey_pkey PRIMARY KEY (id, email);


--
-- Name: dfe_t dfe_t_pkey; Type: CONSTRAINT; Schema: db00006__my_db; Owner: informix
--

ALTER TABLE  dfe_t
    ADD CONSTRAINT dfe_t_pkey PRIMARY KEY (id, email);


--SET search_path = public, pg_catalog;

--
-- Name: tb101 tb101_pkey; Type: CONSTRAINT; Schema: public; Owner: informix
--

ALTER TABLE  tb101
    ADD CONSTRAINT tb101_pkey PRIMARY KEY (id);


--SET search_path = $CB_DBS_USER, pg_catalog;

--
-- Name: dfe_test dfe_test_pkey; Type: CONSTRAINT; Schema: $CB_DBS_USER; Owner: informix
--

ALTER TABLE  dfe_test
    ADD CONSTRAINT dfe_test_pkey PRIMARY KEY (id);


--
-- Name: t_ins_duplicate t_ins_duplicate_pkey; Type: CONSTRAINT; Schema: $CB_DBS_USER; Owner: informix
--

ALTER TABLE  t_ins_duplicate
    ADD CONSTRAINT t_ins_duplicate_pkey PRIMARY KEY (id, id2);


--
-- Name: test test_pkey; Type: CONSTRAINT; Schema: $CB_DBS_USER; Owner: informix
--

ALTER TABLE  test
    ADD CONSTRAINT test_pkey PRIMARY KEY (id);


--SET search_path = test_db, pg_catalog;

--


--SET search_path = db00001__dfe, pg_catalog;

--
-- Name: uidx_dfe_test_uidx_1; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_dfe_test_uidx_1 ON dfe_test_uidx_1 USING btree (id);


--
-- Name: uidx_dfe_test_uidx_10; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_dfe_test_uidx_10 ON dfe_test_uidx_10 USING btree (id);


--
-- Name: uidx_dfe_test_uidx_2; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_dfe_test_uidx_2 ON dfe_test_uidx_2 USING btree (id);


--
-- Name: uidx_dfe_test_uidx_3; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_dfe_test_uidx_3 ON dfe_test_uidx_3 USING btree (id);


--
-- Name: uidx_dfe_test_uidx_4; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_dfe_test_uidx_4 ON dfe_test_uidx_4 USING btree (id);


--
-- Name: uidx_dfe_test_uidx_5; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_dfe_test_uidx_5 ON dfe_test_uidx_5 USING btree (id);


--
-- Name: uidx_dfe_test_uidx_6; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_dfe_test_uidx_6 ON dfe_test_uidx_6 USING btree (id);


--
-- Name: uidx_dfe_test_uidx_7; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_dfe_test_uidx_7 ON dfe_test_uidx_7 USING btree (id);


--
-- Name: uidx_dfe_test_uidx_8; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_dfe_test_uidx_8 ON dfe_test_uidx_8 USING btree (id);


--
-- Name: uidx_dfe_test_uidx_9; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_dfe_test_uidx_9 ON dfe_test_uidx_9 USING btree (id);


---------------------- from IFX -------------
CREATE TABLE IF NOT EXISTS informix.ifx_test_1 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_1 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_10; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_10 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_10 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_2; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_2 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_2 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_3; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_3 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_3 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_4; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_4 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_4 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_5; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_5 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_5 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_6; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_6 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_6 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_7; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_7 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_7 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_8; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_8 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_8 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_9; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_9 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_9 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_pk; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_pk (
    id numeric(20,0) NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_pk OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_pk_1; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_pk_1 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_pk_1 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_pk_10; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_pk_10 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_pk_10 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_pk_2; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_pk_2 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_pk_2 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_pk_3; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_pk_3 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_pk_3 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_pk_4; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_pk_4 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_pk_4 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_pk_5; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_pk_5 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_pk_5 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_pk_6; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_pk_6 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_pk_6 OWNER TO $CB_DBS_USER;


CREATE TABLE IF NOT EXISTS informix.ifx_test_pk_10000 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_pk_10000 OWNER TO $CB_DBS_USER;



--
-- Name: informix.ifx_test_pk_7; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_pk_7 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_pk_7 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_pk_8; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_pk_8 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_pk_8 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_pk_9; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_pk_9 (
    id numeric NOT NULL,
    idc character varying(20) NOT NULL,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_pk_9 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_uidx_1; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_uidx_1 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_uidx_1 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_uidx_10; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_uidx_10 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_uidx_10 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_uidx_2; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_uidx_2 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_uidx_2 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_uidx_3; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_uidx_3 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_uidx_3 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_uidx_4; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_uidx_4 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_uidx_4 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_uidx_5; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_uidx_5 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_uidx_5 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_uidx_6; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_uidx_6 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_uidx_6 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_uidx_7; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_uidx_7 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_uidx_7 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_uidx_8; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_uidx_8 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_uidx_8 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_test_uidx_9; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test_uidx_9 (
    id numeric,
    c character varying(60)
);


ALTER TABLE informix.ifx_test_uidx_9 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_types; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_types (
    id numeric(20,0) NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE informix.ifx_types OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_types_1; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_types_1 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE informix.ifx_types_1 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_types_10; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_types_10 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE informix.ifx_types_10 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_types_2; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_types_2 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE informix.ifx_types_2 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_types_3; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_types_3 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE informix.ifx_types_3 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_types_4; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_types_4 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE informix.ifx_types_4 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_types_5; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_types_5 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE informix.ifx_types_5 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_types_6; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_types_6 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE informix.ifx_types_6 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_types_7; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_types_7 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE informix.ifx_types_7 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_types_8; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_types_8 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE informix.ifx_types_8 OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_types_9; Type: TABLE; Schema: db00001__dfe; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_types_9 (
    id numeric NOT NULL,
    c character(40),
    c2 character varying(40),
    c3 character varying(40),
    i numeric,
    f double precision,
    dt date,
    tm date,
    xxx numeric
);


ALTER TABLE informix.ifx_types_9 OWNER TO $CB_DBS_USER;

--SET search_path = db00006__dbo, pg_catalog;

--
-- Name: informix.ifx_t; Type: TABLE; Schema: db00006__dbo; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_t (
    id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(30),
    email character varying(50) NOT NULL
);


ALTER TABLE informix.ifx_t OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_t_no_pkey; Type: TABLE; Schema: db00006__dbo; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_t_no_pkey (
    id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(30),
    email character varying(50) NOT NULL
);


ALTER TABLE informix.ifx_t_no_pkey OWNER TO $CB_DBS_USER;

--
-- Name: users; Type: TABLE; Schema: db00006__dbo; Owner: informix
--

CREATE TABLE IF NOT EXISTS users (
    id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(30),
    email character varying(50) NOT NULL
);


ALTER TABLE users OWNER TO $CB_DBS_USER;

--
-- Name: users_no_pkey; Type: TABLE; Schema: db00006__dbo; Owner: informix
--

CREATE TABLE IF NOT EXISTS users_no_pkey (
    id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(30),
    email character varying(50) NOT NULL
);


ALTER TABLE users_no_pkey OWNER TO $CB_DBS_USER;

--SET search_path = db00006__my_db, pg_catalog;

--
-- Name: informix.ifx_t; Type: TABLE; Schema: db00006__my_db; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_t (
    id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(30),
    email character varying(50) NOT NULL
);


ALTER TABLE informix.ifx_t OWNER TO $CB_DBS_USER;

--
-- Name: informix.ifx_t_no_pkey; Type: TABLE; Schema: db00006__my_db; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_t_no_pkey (
    id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(30),
    email character varying(50) NOT NULL
);


ALTER TABLE informix.ifx_t_no_pkey OWNER TO $CB_DBS_USER;

--SET search_path = $CB_DBS_USER, pg_catalog;

--
-- Name: cb_b; Type: TABLE; Schema: $CB_DBS_USER; Owner: informix
--

CREATE TABLE IF NOT EXISTS cb_b (
    id integer,
    c character(10)
);


ALTER TABLE cb_b OWNER TO $CB_DBS_USER;

--SET search_path = khyx_4500, pg_catalog;

--
-- Name: mc_t_tradpolicy; Type: TABLE; Schema: khyx_4500; Owner: informix
--

CREATE TABLE IF NOT EXISTS mc_t_tradpolicy (
    custid character varying(30) NOT NULL,
    policyno character varying(66) NOT NULL,
    proposalno character varying(66),
    inputtime timestamp without time zone,
    operatedate timestamp without time zone,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    comcode character varying(24),
    classcode character varying(6),
    riskcode character varying(9),
    businessnature character varying(9),
    inputflag character varying(2),
    policytype character varying(6),
    policysort character varying(3),
    insuredcode character varying(90),
    insuredname character varying(360),
    insuredaddress character varying(765),
    insured1code character varying(90),
    insured1name character varying(360),
    insured1address character varying(765),
    agentcode character varying(36),
    sumamount double precision,
    sumpremium double precision,
    bipremium double precision,
    cipremium double precision,
    endorsetimes numeric(38,0),
    handler1code character varying(360),
    othflag character varying(2),
    underwritecode character varying(30),
    underwritename character varying(75),
    contractno character varying(66),
    handlercode character varying(360),
    approvercode character varying(30),
    operatorcode character varying(30),
    underwriteenddate timestamp without time zone,
    remark character varying(765),
    tcol1 character varying(20),
    tcol2 character varying(30),
    tcol3 character varying(30),
    loadtime timestamp without time zone,
    creatorcode character varying(16),
    inserttimeforhis timestamp without time zone,
    updatercode character varying(16),
    operatetimeforhis timestamp without time zone DEFAULT ('now'::text)::timestamp without time zone,
    datasource character varying(50),
    validstatus character varying(2),
    flag character varying(2),
    comid character varying(8) NOT NULL,
    insuredcompany character varying(4),
    dfeflag character varying(2),
    carshiptax double precision,
    carbusitype character varying(30),
    thisdamagedbi numeric DEFAULT 0,
    thisdamagedci numeric DEFAULT 0,
    plandate timestamp without time zone,
    newmanagercode character varying(360) DEFAULT 'null'::character varying,
    monopolycode character varying(40),
    carid character varying(30),
    validtime timestamp without time zone,
    dmflag character varying(10),
    monopolyflag character varying(3),
    clausetype character varying(9),
    dwxflag character varying(30) DEFAULT '-1'::character varying,
    enrolldate timestamp without time zone,
    carkindcode character varying(9) DEFAULT '-1'::character varying,
    taxnum numeric(19,2),
    netinsamt numeric(19,2),
    carchecker character varying(60),
    generatetime timestamp without time zone
);


ALTER TABLE mc_t_tradpolicy OWNER TO $CB_DBS_USER;

--
-- Name: tm_t_jhsendmessage; Type: TABLE; Schema: khyx_4500; Owner: informix
--

CREATE TABLE IF NOT EXISTS tm_t_jhsendmessage (
    messageid character varying(30) NOT NULL,
    sendid character varying(30),
    mouldid character varying(30),
    operatorcode character varying(50) NOT NULL,
    messagecount numeric(38,0),
    phoneno character varying(20),
    suppliercode character varying(120),
    comcode character varying(8),
    smscontent character varying(3000),
    sendtime timestamp without time zone NOT NULL,
    realtime timestamp without time zone,
    needreply character varying(2),
    flag character varying(2),
    validstatus character varying(2),
    comid character varying(8) NOT NULL,
    creatorcode character varying(50),
    inserttimeforhis timestamp without time zone,
    updatercode character varying(16),
    operatetimeforhis timestamp without time zone,
    sendtype character varying(2),
    needcallback character varying(2),
    smid character varying(30),
    urlorclass character varying(100),
    funcname character varying(50),
    failreason character varying(600),
    source character varying(2),
    targettype character varying(3)
);


ALTER TABLE tm_t_jhsendmessage OWNER TO $CB_DBS_USER;

--SET search_path = public, pg_catalog;

--
-- Name: tb101; Type: TABLE; Schema: public; Owner: informix
--

CREATE TABLE IF NOT EXISTS tb101 (
    id integer NOT NULL,
    c character(10)
);


ALTER TABLE tb101 OWNER TO $CB_DBS_USER;

--
-- Name: td; Type: TABLE; Schema: public; Owner: informix
--

CREATE TABLE IF NOT EXISTS td (
    id integer,
    dt timestamp without time zone
);


ALTER TABLE td OWNER TO $CB_DBS_USER;

--
-- Name: test1; Type: TABLE; Schema: public; Owner: informix
--

CREATE TABLE IF NOT EXISTS test1 (
    id integer,
    c character(10),
    f double precision
);


ALTER TABLE test1 OWNER TO $CB_DBS_USER;

--SET search_path = $CB_DBS_USER, pg_catalog;

--
-- Name: informix.ifx_test; Type: TABLE; Schema: $CB_DBS_USER; Owner: informix
--

CREATE TABLE IF NOT EXISTS informix.ifx_test (
    id numeric(38,0) NOT NULL,
    c character(10)
);


ALTER TABLE informix.ifx_test OWNER TO $CB_DBS_USER;

--
-- Name: t_ins_duplicate; Type: TABLE; Schema: $CB_DBS_USER; Owner: informix
--

CREATE TABLE IF NOT EXISTS t_ins_duplicate (
    id integer NOT NULL,
    id2 integer NOT NULL,
    c character(10)
);


ALTER TABLE t_ins_duplicate OWNER TO $CB_DBS_USER;

--
-- Name: tb_interval; Type: TABLE; Schema: $CB_DBS_USER; Owner: informix
--

CREATE TABLE IF NOT EXISTS tb_interval (
    id integer,
    it interval day to minute
);


ALTER TABLE tb_interval OWNER TO $CB_DBS_USER;

--
-- Name: test; Type: TABLE; Schema: $CB_DBS_USER; Owner: informix
--

CREATE TABLE IF NOT EXISTS test (
    id numeric(38,0) NOT NULL,
    c character(10)
);


ALTER TABLE test OWNER TO $CB_DBS_USER;

--SET search_path = test_db, pg_catalog;



-- Name: informix.ifx_test_pk_10 informix.ifx_test_pk_10_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_test_pk_10
    ADD CONSTRAINT ifx_test_pk_10_pkey PRIMARY KEY (id, idc);


--
-- Name: informix.ifx_test_pk_1 informix.ifx_test_pk_1_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_test_pk_1
    ADD CONSTRAINT ifx_test_pk_1_pkey PRIMARY KEY (id, idc);


--
-- Name: informix.ifx_test_pk_2 informix.ifx_test_pk_2_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_test_pk_2
    ADD CONSTRAINT ifx_test_pk_2_pkey PRIMARY KEY (id, idc);


--
-- Name: informix.ifx_test_pk_3 informix.ifx_test_pk_3_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_test_pk_3
    ADD CONSTRAINT ifx_test_pk_3_pkey PRIMARY KEY (id, idc);


--
-- Name: informix.ifx_test_pk_4 informix.ifx_test_pk_4_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_test_pk_4
    ADD CONSTRAINT ifx_test_pk_4_pkey PRIMARY KEY (id, idc);


--
-- Name: informix.ifx_test_pk_5 informix.ifx_test_pk_5_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_test_pk_5
    ADD CONSTRAINT ifx_test_pk_5_pkey PRIMARY KEY (id, idc);


--
-- Name: informix.ifx_test_pk_6 informix.ifx_test_pk_6_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_test_pk_6
    ADD CONSTRAINT ifx_test_pk_6_pkey PRIMARY KEY (id, idc);

--
-- Name: informix.ifx_test_pk_10000 informix.ifx_test_pk_10000_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_test_pk_10000
    ADD CONSTRAINT ifx_test_pk_10000_pkey PRIMARY KEY (id, idc);


--
-- Name: informix.ifx_test_pk_7 informix.ifx_test_pk_7_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_test_pk_7
    ADD CONSTRAINT ifx_test_pk_7_pkey PRIMARY KEY (id, idc);


--
-- Name: informix.ifx_test_pk_8 informix.ifx_test_pk_8_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_test_pk_8
    ADD CONSTRAINT ifx_test_pk_8_pkey PRIMARY KEY (id, idc);


--
-- Name: informix.ifx_test_pk_9 informix.ifx_test_pk_9_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_test_pk_9
    ADD CONSTRAINT ifx_test_pk_9_pkey PRIMARY KEY (id, idc);


--
-- Name: informix.ifx_test_pk informix.ifx_test_pk_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_test_pk
    ADD CONSTRAINT ifx_test_pk_pkey PRIMARY KEY (id, idc);


--
-- Name: informix.ifx_types_10 informix.ifx_types_10_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_types_10
    ADD CONSTRAINT ifx_types_10_pkey PRIMARY KEY (id);


--
-- Name: informix.ifx_types_1 informix.ifx_types_1_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_types_1
    ADD CONSTRAINT ifx_types_1_pkey PRIMARY KEY (id);


--
-- Name: informix.ifx_types_2 informix.ifx_types_2_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_types_2
    ADD CONSTRAINT ifx_types_2_pkey PRIMARY KEY (id);


--
-- Name: informix.ifx_types_3 informix.ifx_types_3_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_types_3
    ADD CONSTRAINT ifx_types_3_pkey PRIMARY KEY (id);


--
-- Name: informix.ifx_types_4 informix.ifx_types_4_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_types_4
    ADD CONSTRAINT ifx_types_4_pkey PRIMARY KEY (id);


--
-- Name: informix.ifx_types_5 informix.ifx_types_5_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_types_5
    ADD CONSTRAINT ifx_types_5_pkey PRIMARY KEY (id);


--
-- Name: informix.ifx_types_6 informix.ifx_types_6_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_types_6
    ADD CONSTRAINT ifx_types_6_pkey PRIMARY KEY (id);


--
-- Name: informix.ifx_types_7 informix.ifx_types_7_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_types_7
    ADD CONSTRAINT ifx_types_7_pkey PRIMARY KEY (id);


--
-- Name: informix.ifx_types_8 informix.ifx_types_8_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_types_8
    ADD CONSTRAINT ifx_types_8_pkey PRIMARY KEY (id);


--
-- Name: informix.ifx_types_9 informix.ifx_types_9_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_types_9
    ADD CONSTRAINT ifx_types_9_pkey PRIMARY KEY (id);


--
-- Name: informix.ifx_types informix.ifx_types_pkey; Type: CONSTRAINT; Schema: db00001__dfe; Owner: informix
--

ALTER TABLE  informix.ifx_types
    ADD CONSTRAINT ifx_types_pkey PRIMARY KEY (id);


--SET search_path = db00006__dbo, pg_catalog;

--
-- Name: informix.ifx_t_no_pkey informix.ifx_t_no_pkey_pkey; Type: CONSTRAINT; Schema: db00006__dbo; Owner: informix
--

ALTER TABLE  informix.ifx_t_no_pkey
    ADD CONSTRAINT ifx_t_no_pkey_pkey PRIMARY KEY (id, email);


--
-- Name: informix.ifx_t informix.ifx_t_pkey; Type: CONSTRAINT; Schema: db00006__dbo; Owner: informix
--

ALTER TABLE  informix.ifx_t
    ADD CONSTRAINT ifx_t_pkey PRIMARY KEY (id, email);


--
-- Name: users_no_pkey users_no_pkey_pkey; Type: CONSTRAINT; Schema: db00006__dbo; Owner: informix
--

ALTER TABLE  users_no_pkey
    ADD CONSTRAINT users_no_pkey_pkey PRIMARY KEY (id, email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: db00006__dbo; Owner: informix
--

ALTER TABLE  users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id, email);


--SET search_path = db00006__my_db, pg_catalog;

--
-- Name: informix.ifx_t_no_pkey informix.ifx_t_no_pkey_pkey; Type: CONSTRAINT; Schema: db00006__my_db; Owner: informix
--

ALTER TABLE  informix.ifx_t_no_pkey
    ADD CONSTRAINT ifx_t_no_pkey_pkey PRIMARY KEY (id, email);


--
-- Name: informix.ifx_t informix.ifx_t_pkey; Type: CONSTRAINT; Schema: db00006__my_db; Owner: informix
--

ALTER TABLE  informix.ifx_t
    ADD CONSTRAINT ifx_t_pkey PRIMARY KEY (id, email);


--SET search_path = public, pg_catalog;

--
-- Name: tb101 tb101_pkey; Type: CONSTRAINT; Schema: public; Owner: informix
--

ALTER TABLE  tb101
    ADD CONSTRAINT tb101_pkey PRIMARY KEY (id);


--SET search_path = $CB_DBS_USER, pg_catalog;

--
-- Name: informix.ifx_test informix.ifx_test_pkey; Type: CONSTRAINT; Schema: $CB_DBS_USER; Owner: informix
--

ALTER TABLE  informix.ifx_test
    ADD CONSTRAINT ifx_test_pkey PRIMARY KEY (id);


--
-- Name: t_ins_duplicate t_ins_duplicate_pkey; Type: CONSTRAINT; Schema: $CB_DBS_USER; Owner: informix
--

ALTER TABLE  t_ins_duplicate
    ADD CONSTRAINT t_ins_duplicate_pkey PRIMARY KEY (id, id2);


--
-- Name: test test_pkey; Type: CONSTRAINT; Schema: $CB_DBS_USER; Owner: informix
--

ALTER TABLE  test
    ADD CONSTRAINT test_pkey PRIMARY KEY (id);


--SET search_path = test_db, pg_catalog;

--


--SET search_path = db00001__dfe, pg_catalog;

--
-- Name: uidx_ifx_test_uidx_1; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_ifx_test_uidx_1 ON informix.ifx_test_uidx_1 USING btree (id);


--
-- Name: uidx_ifx_test_uidx_10; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_ifx_test_uidx_10 ON informix.ifx_test_uidx_10 USING btree (id);


--
-- Name: uidx_ifx_test_uidx_2; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_ifx_test_uidx_2 ON informix.ifx_test_uidx_2 USING btree (id);


--
-- Name: uidx_ifx_test_uidx_3; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_ifx_test_uidx_3 ON informix.ifx_test_uidx_3 USING btree (id);


--
-- Name: uidx_ifx_test_uidx_4; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_ifx_test_uidx_4 ON informix.ifx_test_uidx_4 USING btree (id);


--
-- Name: uidx_ifx_test_uidx_5; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_ifx_test_uidx_5 ON informix.ifx_test_uidx_5 USING btree (id);


--
-- Name: uidx_ifx_test_uidx_6; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_ifx_test_uidx_6 ON informix.ifx_test_uidx_6 USING btree (id);


--
-- Name: uidx_ifx_test_uidx_7; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_ifx_test_uidx_7 ON informix.ifx_test_uidx_7 USING btree (id);


--
-- Name: uidx_ifx_test_uidx_8; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_ifx_test_uidx_8 ON informix.ifx_test_uidx_8 USING btree (id);


--
-- Name: uidx_ifx_test_uidx_9; Type: INDEX; Schema: db00001__dfe; Owner: informix
--

CREATE UNIQUE INDEX IF NOT EXISTS uidx_ifx_test_uidx_9 ON informix.ifx_test_uidx_9 USING btree (id);


-----------------------end of IFX tables ----------


--
-- PostgreSQL database dump complete
--

DROP TABLE random_data;
CREATE TABLE random_data (
  id           integer,
  small_number integer,
  big_number   integer,
  norm_number   integer,
  short_string VARCHAR(50),
  long_string  VARCHAR(400),
  created_date DATE,
  CONSTRAINT random_data_pk PRIMARY KEY (id)
);

drop table if exists dfedemo.customer ;
create table dfedemo.customer 
  (
    customer_num integer,
    fname char(30),
    lname char(30),
    company char(40),
    address1 char(40),
    address2 char(40),
    city char(30),
    state char(4),
    zipcode char(10),
    phone char(36),
    primary key (customer_num) 
  );

" \
    | sqlRun.sh  2>&1 \
    | grep -v 'multiple primary keys ' \
    | grep -v 'already exists'\
    | grep ERROR > $MY_TMP.err

if [ $? -eq 0 ]; then
    logMsg E "Failed to create schema for $CB_DBS_DBMS:$CB_DBS_ID"
    cat $MY_TMP.err | logMsg M -
    exit 255
fi

