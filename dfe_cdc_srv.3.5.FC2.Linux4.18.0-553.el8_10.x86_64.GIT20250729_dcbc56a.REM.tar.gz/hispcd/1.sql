create table "informix".motxt 
  (
    ord_no integer not null ,
    chart integer not null ,
    sub varchar(255),
    obj varchar(255),
    ass varchar(255),
    cmt varchar(255),
    rpt_man smallint 
        default 0 not null ,
    rpt_dat date 
        default  '1899/12/31' not null ,
    rpt_hm smallint 
        default 0 not null ,
    rpt_typ char(4) 
        default '' not null ,
    rpt text,
    primary key (ord_no) 
  );
