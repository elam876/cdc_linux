" Use 4 spaces for a tab
set tabstop=4        " Number of visual spaces per tab character
set shiftwidth=4     " Number of spaces to use for each indentation
set softtabstop=4    " Number of spaces a <Tab> feels like in insert mode
"»··set expandtab        " Use spaces instead of tab characters

" Show whitespace characters (tabs, trailing spaces, etc.)
set list
