
#make.sh 
if [ $? -ne 0 ]; then exit 255; fi
source setDbId.set 2 > /dev/null
echo '
truncate table hispcd.bccbcr;
truncate table hispcd.bccbcr;
truncate table hispcd.bmpobd;
truncate table hispcd.test_chinese;
truncate table hispcd.motxt;
'|sqlRun.sh
if [ $? -ne 0 ]; then exit 255; fi


stopPm.sh
rm -rf workSpace/baseDataQ workSpace/baseDataTmp workSpace/ap* workSpace/debugQ log/* workSpace/doneQ workSpace/debugQ
source setDbId.set 1
unloadTb.sh hispcd asacsitm
if [ $? -ne 0 ]; then exit 255; fi
unloadTb.sh hispcd bccbcr
if [ $? -ne 0 ]; then exit 255; fi
unloadTb.sh hispcd bmpobd
if [ $? -ne 0 ]; then exit 255; fi
unloadTb.sh hispcd test_chinese
if [ $? -ne 0 ]; then exit 255; fi
unloadTb.sh hispcd motxt 
if [ $? -ne 0 ]; then exit 255; fi

find workSpace -type f|grep -v log

source setDbId.set 1 > /dev/null
export DISPATCH_Q=workSpace/baseDataQ/1

jsonMapper -e json
if [ $? -ne 0 ]; then echo ERROR:; exit 255; fi
find workSpace -type f|grep -v log

source setDbId.set 2 > /dev/null
bin/Apply1LineJsonP
echo Retrieve from Informix
echo -----------------------------------------
echo '
select count(*) from hispcd.asacsitm;
select count(*) from hispcd.bccbcr;
select count(*) from hispcd.bmpobd;
select count(*) from hispcd.test_chinese;
select count(*) from hispcd.motxt;
'|sqlRun.sh -e
echo
echo
echo Retrieve from PostgreSQL
echo -----------------------------------------
echo 'select count(*) from hispcd.asacsitm;'|sqlRun.sh -e
echo 'select count(*) from hispcd.bccbcr;'|sqlRun.sh -e
echo 'select count(*) from hispcd.bmpobd;'|sqlRun.sh -e
echo 'select count(*) from hispcd.test_chinese;'|sqlRun.sh -e
echo 'select count(*) from hispcd.motxt;'|sqlRun.sh -e
