rm -rf workSpace log
source setDbId.set 1 > /dev/null

nohup sh unloadAll.sh > unloadAll.out 2>&1 &

sleep 3

source setDbId.set 2 > /dev/null
sh truncateAll.sh
nohup sh copyAll.sh > copyAll.out 2>&1 &
