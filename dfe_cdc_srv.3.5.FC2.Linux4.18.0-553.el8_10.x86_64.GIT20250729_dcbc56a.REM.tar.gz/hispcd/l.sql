load from motxt.unl delimiter '	' insert into motxt
