#!/bin/bash

echo "== Checking current TCP TIME_WAIT settings =="
echo -n "tcp_fin_timeout: "
cat /proc/sys/net/ipv4/tcp_fin_timeout

echo -n "tcp_tw_reuse: "
cat /proc/sys/net/ipv4/tcp_tw_reuse

echo
echo "== Applying TCP optimization settings =="

# Set TIME_WAIT duration to 30 seconds
sudo sysctl -w net.ipv4.tcp_fin_timeout=30

# Allow TIME_WAIT socket reuse
sudo sysctl -w net.ipv4.tcp_tw_reuse=1

echo
echo "== Cleaning up previous entries in /etc/sysctl.conf =="

# Remove old lines from sysctl.conf if they exist
sudo sed -i '/^net\\.ipv4\\.tcp_fin_timeout/d' /etc/sysctl.conf
sudo sed -i '/^net\\.ipv4\\.tcp_tw_reuse/d' /etc/sysctl.conf

echo "== Appending new settings to /etc/sysctl.conf =="

sudo echo 'cat <<EOF >> /etc/sysctl.conf

# TCP optimization added by optimize_tcp_timewait.sh
net.ipv4.tcp_fin_timeout = 30
net.ipv4.tcp_tw_reuse = 1
EOF'

# Apply changes
sudo sysctl -p

echo
echo "== Done. Current TIME_WAIT connections =="
netstat -nat | grep TIME_WAIT | wc -l

