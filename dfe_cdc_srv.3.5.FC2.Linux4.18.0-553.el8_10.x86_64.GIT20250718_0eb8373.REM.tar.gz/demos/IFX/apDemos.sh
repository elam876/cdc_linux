#!/usr/bin/env bash
cnt=$1
if [ "$cnt" = "" ]; then
    . $CB_PROJECT_DIR/$CB_CONFIG_DIR/systemCfg.cfg 
    cnt=${1-$CB_NUMBER_OF_RECORDS_IN_TEST}
fi
MODULE=demo_$CB_DBS_ID
source cbUtil.set
logMsg M run $@ $CB_DBS_DBMS $CB_DBS_ID
db=`echo dfedemo_$CB_DBS_DBMS |  tr '[:upper:]' '[:lower:]'`

genSql()
{
    local id=$1
    
    echo 'execute procedure sysmaster:ifx_allow_newline("t");'
    echo '
       BEGIN {printf("BEGIN WORK;\n");}
       {
for(tb=1;tb<=10;tb++) {
      tbname=sprintf("ifx_test_pk_%d",tb);
         for(i=1;i<=cnt;i++){
            u_id=sprintf("%ld%.6d",id,i);
            printf ("insert into %s values(%ld, @C.%ld@, @cc\\%ld.%d@);\n", tbname, u_id,id,id, i); 
            printf("update %s set c=@cc\t\\%ld.%d@ where id = %ld;\n",tbname, i,id,u_id);
            if (cnt % 500 ==0) printf("commit work; BEGIN WORK;\n");
          }
		printf("delete from %s where id > %ld - %d;\n",tbname, u_id, i*0.9);
       }
}
       END {printf("commit work;\n");}
    ' > $MY_TMP.awk
    echo 1 \
        | awk -v id=$id -v cnt=$cnt -f $MY_TMP.awk \
        | sed -e s/'@'/"'"/g
}

go()
{

  for n in 1 #2 3 4 5 6
  do
    #id=`timenow`
    genSql `timenow` | sqlRun.sh $db
  done
}
go  
wait
