#!/usr/bin/env bash
MODULE=demo_$CB_DBS_ID
source cbUtil.set
cnt=${1-10}
NLS_LANG=AMERICAN_AMERICA.AL32UTF8
export NLS_LANG
db=`echo dfedemo_$CB_DBS_DBMS |  tr '[:upper:]' '[:lower:]'`

genSql()
{
    local id=$1
    echo 'execute procedure sysmaster:ifx_allow_newline("t");'
    echo 1|awk -v id=$id -v cnt=$cnt '
       BEGIN {printf("BEGIN WORK;\n");}
       {
         for(i=1;i<=cnt;i++){
            u_id=sprintf("%ld%.4d",id,i);
            printf ("insert into ifx_test_pk values(%ld, @C.%ld@, @cc\\%ld.%d@);\n", u_id,id,id, i); 
            printf("update ifx_test_pk set c=@cc\t\\%ld.%d@ where id = %ld;\n",i,id,u_id);
            if (cnt % 500 ==0) printf("commit work; BEGIN WORK;\n");
          }
		printf("delete from ifx_test_pk where id > %ld - %d;\n",u_id, i*0.9);
       }
       END {printf("commit work;\n");}
    '|sed -e s/'@'/"'"/g
}

go()
{

  for n in 1 #2 3 4 5 6
  do
    #id=`timenow`
    genSql `timenow` | sqlRun.sh $db
  done
}
go  
wait
