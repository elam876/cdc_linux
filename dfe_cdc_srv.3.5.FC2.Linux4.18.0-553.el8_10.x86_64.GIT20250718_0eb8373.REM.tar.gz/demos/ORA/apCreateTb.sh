#!/usr/bin/env bash
MODULE=demo_$CB_DBS_ID
source cbUtil.set

NLS_LANG=AMERICAN #---要注意這一句必須指定，不然下一句不生效。
export NLS_LANG

NLS_DATE_FORMAT='yyyy-mm-dd hh24:mi:ss'
export NLS_DATE_FORMAT

source ./sqlCmd.set


createDb()
{
    echo "create database $CB_DBS_USER; "| sqlRun.sh
}


createTb()
{
    echo "
        drop table dfe_test;
        create table dfe_test (id integer, c varchar2(60) );

        drop table dfe_test_pk;
        create table dfe_test_pk (id integer, idc varchar(20), c varchar2(60) , primary key(id, idc));

        drop table dfe_test_uidx;
        create table dfe_test_uidx (id integer, c varchar2(60));
        create unique index uidx_dfe_test_uidx on dfe_test_uidx(id);


        drop table dfe_types;
        create table dfe_types ( 
			id integer,
			c char(40),
			c2 varchar2(40),
			c3 varchar(40),
			i number,
			--l long,
			f float,
			dt date,
			tm date,
			primary key(id)
		);
				
    " | convertSqlSchema ORA $CB_DBS_DBMS | sqlRun.sh
}

go()
{
  createDb > /dev/null 2>&1
  createTb
}
go 2>&1 \
    | grep -v 'ERROR at line 1:' \
    | grep -v 'ORA-00955:' \
    | grep -v 'ORA-00954:' \
    | grep -v 'multiple primary keys' \
    | grep -v 'already exists' > $MY_TMP.err
grep ERROR $MY_TMP.err > /dev/null
if [ $? -eq 0 ]; then
    logMsg E "Failed to create demo DB for $CB_DBS_DBMS:$CB_DBS_ID"
    cat $MY_TMP.err | logMsg M -
    exit 255
fi

