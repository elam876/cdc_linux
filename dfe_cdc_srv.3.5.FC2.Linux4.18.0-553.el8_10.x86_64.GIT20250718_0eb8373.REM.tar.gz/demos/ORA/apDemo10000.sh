#!/usr/bin/env bash
MODULE=demo_$CB_DBS_ID
source cbUtil.set
cnt=${1-10}
NLS_LANG=AMERICAN_AMERICA.AL32UTF8
export NLS_LANG

genSql()
{
    echo '
       {
         k=0;
         for(i=1;i<=cnt;i++){
            utcPrev=utc;
            #if(batchSize>1) if(i%batchSize==1) printf("BEGIN\n");
            #if(i%10==0) system("sleep 1");
            utc=systime();
            if(utc!=utcPrev) 
                k=1;
            else
                k++;
            u_id=sprintf("%ld%.5d",utc,k);
            #print u_id; continue
            printf ("insert into dfe_test_pk_10000 values(%s, @C.%s@, @cc\\%ld.%d@);\n", u_id,u_id,utc, i); 
            if(i % 1000==0) printf("commit;\n");
#if(i%batchSize==1) printf("BEGIN\n");
          }
       }
       END {
           #printf("/\n\n");
           printf("commit;\n");
           #printf("/\n\n");
       }
    ' > $MY_TMP.awk
    echo 1 \
        | awk -v cnt=$cnt -v batchSize=1 -f $MY_TMP.awk \
        |sed -e s/'@'/"'"/g
}

go()
{

  for n in 1 #2 3 4 5 6
  do
    genSql | sqlRun.sh
  done
}
go  
wait
