execute function syscdcv1:cdc_set_fullrowlogging("hispcd:informix.asacsitm",0);
alter table asacsitm drop(new_col);
execute function syscdcv1:cdc_set_fullrowlogging("hispcd:informix.asacsitm",1);
