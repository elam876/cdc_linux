source setDbId.set 2 > /dev/null
echo '
truncate table hispcd.bccbcr;
truncate table hispcd.bccbcr;
truncate table hispcd.bmpobd;
truncate table hispcd.asacsitm;
truncate table hispcd.test_chinese;
truncate table hispcd.motxt;
'|sqlRun.sh
