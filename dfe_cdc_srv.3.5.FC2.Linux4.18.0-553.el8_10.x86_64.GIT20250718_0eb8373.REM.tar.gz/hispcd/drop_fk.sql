--select * from sysusers;
--select owner from systables where tabid > 100;
unload to 'dfk.sql' delimiter '	'
SELECT
    'ALTER TABLE ' || TRIM(t.tabname) ||
    ' DROP CONSTRAINT ' || TRIM(c.constrname) || ';' AS drop_sql
FROM
    sysconstraints c
JOIN systables t ON c.tabid = t.tabid
--JOIN sysusers u ON u.username = t.owner
JOIN sysreferences r ON c.constrid = r.constrid
ORDER BY t.tabname;
