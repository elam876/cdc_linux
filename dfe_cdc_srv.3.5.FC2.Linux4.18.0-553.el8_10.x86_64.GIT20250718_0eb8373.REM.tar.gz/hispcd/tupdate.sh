
#make.sh 
init=$1
if [ $? -ne 0 ]; then exit 255; fi

source setDbId.set 1
if [ "$init" = "" ]; then
    X=$(( $$ % 4 + 1 ))
else
	X=$init
fi

echo "
	update asacsitm set price1=$$ where mod(ast_no,$X) ==0;
	update bccbcr set rec_tim=current where mod(emp_no,$X)==0;
	update bmpobd set flt1='A', vsn=$$ where tel_no>0;
begin work;
	delete from bmpobd;
rollback work;
" | sqlRun.sh -e hispcd 2>&1 |grep -v -E '^$|(constant)|row.*retrieved'
if [ $? -ne 0 ]; then exit 255; fi
echo Retrieve from Informix
echo -----------------------------------------------------------
echo "
select 'ASACSITM ----------------' from systables where tabid=1;
	select price1,count(*) from asacsitm where price1=$$ group by 1 order by 1;
select 'BCCBCR   ----------------' from systables where tabid=1;
	select rec_tim,count(*) from bccbcr group by 1 order by 1;
select 'BMPOD    ----------------' from systables where tabid=1;
	select flt1, vsn from bmpobd order by 1,2;
" | sqlRun.sh hispcd 2>&1 |grep -v -E '^$|(constant)|row.*retrieved'
echo
echo -----------------------------------------------------------


sleep 3
source setDbId.set 2 > /dev/null
echo Retrieve from PostgreSQL
echo -----------------------------------------------------------
echo "
select 'ASACSITM ----------------' ;
select price1,count(*) from hispcd.asacsitm where price1=$$ group by 1 order by 1;
select 'BCCBCR ----------------' ;
select rec_tim,count(*) from hispcd.bccbcr group by 1 order by 1;
select 'BMPOD ----------------' ;
select flt1, vsn from hispcd.bmpobd order by 1,2;
"|sqlRun.sh 
